(function() {
      var target = ("undefined" == typeof self || !("undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope)) && ("undefined" != typeof module && module.exports || "undefined" != typeof window), __worker_src__, __worker_src_map__, __worker_src_origin__;
      target && (__worker_src__ = f.toString(), __worker_src_map__ = "", __worker_src_origin__ = "undefined" != typeof document && document.currentScript instanceof HTMLScriptElement ? document.currentScript.src : ""), function() {
        "use strict";
        var toString = {}.toString, classofRaw = function(e) {
          return toString.call(e).slice(8, -1);
        }, commonjsGlobal = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
        function commonjsRequire() {
          throw new Error("Dynamic requires are not currently supported by rollup-plugin-commonjs");
        }
        function unwrapExports(e) {
          return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
        }
        function createCommonjsModule(e, t2) {
          return e(t2 = { exports: {} }, t2.exports), t2.exports;
        }
        function getCjsExportFromNamespace(e) {
          return e && e.default || e;
        }
        var commonjsHelpers = Object.freeze({ commonjsGlobal, commonjsRequire, unwrapExports, createCommonjsModule, getCjsExportFromNamespace }), O = "object", check = function(e) {
          return e && e.Math == Math && e;
        }, global_1 = check(typeof globalThis == O && globalThis) || check(typeof window == O && window) || check(typeof self == O && self) || check(typeof commonjsGlobal == O && commonjsGlobal) || Function("return this")(), fails = function(e) {
          try {
            return !!e();
          } catch (e2) {
            return true;
          }
        }, descriptors = !fails(function() {
          return 7 != Object.defineProperty({}, "a", { get: function() {
            return 7;
          } }).a;
        }), isObject = function(e) {
          return "object" == typeof e ? null !== e : "function" == typeof e;
        }, document$1 = global_1.document, exist = isObject(document$1) && isObject(document$1.createElement), documentCreateElement = function(e) {
          return exist ? document$1.createElement(e) : {};
        }, ie8DomDefine = !descriptors && !fails(function() {
          return 7 != Object.defineProperty(documentCreateElement("div"), "a", { get: function() {
            return 7;
          } }).a;
        }), anObject = function(e) {
          if (!isObject(e))
            throw TypeError(String(e) + " is not an object");
          return e;
        }, toPrimitive = function(e, t2) {
          if (!isObject(e))
            return e;
          var r, i2;
          if (t2 && "function" == typeof (r = e.toString) && !isObject(i2 = r.call(e)))
            return i2;
          if ("function" == typeof (r = e.valueOf) && !isObject(i2 = r.call(e)))
            return i2;
          if (!t2 && "function" == typeof (r = e.toString) && !isObject(i2 = r.call(e)))
            return i2;
          throw TypeError("Can't convert object to primitive value");
        }, nativeDefineProperty = Object.defineProperty, f = descriptors ? nativeDefineProperty : function(e, t2, r) {
          if (anObject(e), t2 = toPrimitive(t2, true), anObject(r), ie8DomDefine)
            try {
              return nativeDefineProperty(e, t2, r);
            } catch (e2) {
            }
          if ("get" in r || "set" in r)
            throw TypeError("Accessors not supported");
          return "value" in r && (e[t2] = r.value), e;
        }, objectDefineProperty = { f }, createPropertyDescriptor = function(e, t2) {
          return { enumerable: !(1 & e), configurable: !(2 & e), writable: !(4 & e), value: t2 };
        }, hide = descriptors ? function(e, t2, r) {
          return objectDefineProperty.f(e, t2, createPropertyDescriptor(1, r));
        } : function(e, t2, r) {
          return e[t2] = r, e;
        }, setGlobal = function(t2, r) {
          try {
            hide(global_1, t2, r);
          } catch (e) {
            global_1[t2] = r;
          }
          return r;
        }, isPure = false, shared = createCommonjsModule(function(e) {
          var t2 = "__core-js_shared__", r = global_1[t2] || setGlobal(t2, {});
          (e.exports = function(e2, t3) {
            return r[e2] || (r[e2] = void 0 !== t3 ? t3 : {});
          })("versions", []).push({ version: "3.1.0", mode: "global", copyright: "© 2019 Denis Pushkarev (zloirock.ru)" });
        }), id = 0, postfix = Math.random(), uid = function(e) {
          return "Symbol(".concat(void 0 === e ? "" : e, ")_", (++id + postfix).toString(36));
        }, nativeSymbol = !fails(function() {
          return !String(Symbol());
        }), store = shared("wks"), Symbol$1 = global_1.Symbol, wellKnownSymbol = function(e) {
          return store[e] || (store[e] = nativeSymbol && Symbol$1[e] || (nativeSymbol ? Symbol$1 : uid)("Symbol." + e));
        }, TO_STRING_TAG = wellKnownSymbol("toStringTag"), CORRECT_ARGUMENTS = "Arguments" == classofRaw(/* @__PURE__ */ function() {
          return arguments;
        }()), tryGet = function(e, t2) {
          try {
            return e[t2];
          } catch (e2) {
          }
        }, classof = function(e) {
          var t2, r, i2;
          return void 0 === e ? "Undefined" : null === e ? "Null" : "string" == typeof (r = tryGet(t2 = Object(e), TO_STRING_TAG)) ? r : CORRECT_ARGUMENTS ? classofRaw(t2) : "Object" == (i2 = classofRaw(t2)) && "function" == typeof t2.callee ? "Arguments" : i2;
        }, TO_STRING_TAG$1 = wellKnownSymbol("toStringTag"), test = {};
        test[TO_STRING_TAG$1] = "z";
        var objectToString = "[object z]" !== String(test) ? function() {
          return "[object " + classof(this) + "]";
        } : test.toString, hasOwnProperty = {}.hasOwnProperty, has = function(e, t2) {
          return hasOwnProperty.call(e, t2);
        }, functionToString = shared("native-function-to-string", Function.toString), WeakMap = global_1.WeakMap, nativeWeakMap = "function" == typeof WeakMap && /native code/.test(functionToString.call(WeakMap)), shared$1 = shared("keys"), sharedKey = function(e) {
          return shared$1[e] || (shared$1[e] = uid(e));
        }, hiddenKeys = {}, WeakMap$1 = global_1.WeakMap, set, get, has$1, enforce = function(e) {
          return has$1(e) ? get(e) : set(e, {});
        }, getterFor = function(r) {
          return function(e) {
            var t2;
            if (!isObject(e) || (t2 = get(e)).type !== r)
              throw TypeError("Incompatible receiver, " + r + " required");
            return t2;
          };
        }, store$1, wmget, wmhas, wmset, set, get, has$1, STATE;
        has$1 = nativeWeakMap ? (store$1 = new WeakMap$1(), wmget = store$1.get, wmhas = store$1.has, wmset = store$1.set, set = function(e, t2) {
          return wmset.call(store$1, e, t2), t2;
        }, get = function(e) {
          return wmget.call(store$1, e) || {};
        }, function(e) {
          return wmhas.call(store$1, e);
        }) : (STATE = sharedKey("state"), hiddenKeys[STATE] = true, set = function(e, t2) {
          return hide(e, STATE, t2), t2;
        }, get = function(e) {
          return has(e, STATE) ? e[STATE] : {};
        }, function(e) {
          return has(e, STATE);
        });
        var internalState = { set, get, has: has$1, enforce, getterFor }, redefine = createCommonjsModule(function(e) {
          var t2 = internalState.get, s = internalState.enforce, l = String(functionToString).split("toString");
          shared("inspectSource", function(e2) {
            return functionToString.call(e2);
          }), (e.exports = function(e2, t3, r, i2) {
            var n = !!i2 && !!i2.unsafe, o = !!i2 && !!i2.enumerable, a2 = !!i2 && !!i2.noTargetGet;
            "function" == typeof r && ("string" != typeof t3 || has(r, "name") || hide(r, "name", t3), s(r).source = l.join("string" == typeof t3 ? t3 : "")), e2 !== global_1 ? (n ? !a2 && e2[t3] && (o = true) : delete e2[t3], o ? e2[t3] = r : hide(e2, t3, r)) : o ? e2[t3] = r : setGlobal(t3, r);
          })(Function.prototype, "toString", function() {
            return "function" == typeof this && t2(this).source || functionToString.call(this);
          });
        }), ObjectPrototype = Object.prototype;
        objectToString !== ObjectPrototype.toString && redefine(ObjectPrototype, "toString", objectToString, { unsafe: true });
        var ceil = Math.ceil, floor = Math.floor, toInteger = function(e) {
          return isNaN(e = +e) ? 0 : (0 < e ? floor : ceil)(e);
        }, requireObjectCoercible = function(e) {
          if (null == e)
            throw TypeError("Can't call method on " + e);
          return e;
        }, stringAt = function(e, t2, r) {
          var i2, n, o = String(requireObjectCoercible(e)), a2 = toInteger(t2), s = o.length;
          return a2 < 0 || s <= a2 ? r ? "" : void 0 : (i2 = o.charCodeAt(a2)) < 55296 || 56319 < i2 || a2 + 1 === s || (n = o.charCodeAt(a2 + 1)) < 56320 || 57343 < n ? r ? o.charAt(a2) : i2 : r ? o.slice(a2, a2 + 2) : n - 56320 + (i2 - 55296 << 10) + 65536;
        }, nativePropertyIsEnumerable = {}.propertyIsEnumerable, nativeGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor, NASHORN_BUG = nativeGetOwnPropertyDescriptor && !nativePropertyIsEnumerable.call({ 1: 2 }, 1), f$1 = NASHORN_BUG ? function(e) {
          var t2 = nativeGetOwnPropertyDescriptor(this, e);
          return !!t2 && t2.enumerable;
        } : nativePropertyIsEnumerable, objectPropertyIsEnumerable = { f: f$1 }, split = "".split, indexedObject = fails(function() {
          return !Object("z").propertyIsEnumerable(0);
        }) ? function(e) {
          return "String" == classofRaw(e) ? split.call(e, "") : Object(e);
        } : Object, toIndexedObject = function(e) {
          return indexedObject(requireObjectCoercible(e));
        }, nativeGetOwnPropertyDescriptor$1 = Object.getOwnPropertyDescriptor, f$2 = descriptors ? nativeGetOwnPropertyDescriptor$1 : function(e, t2) {
          if (e = toIndexedObject(e), t2 = toPrimitive(t2, true), ie8DomDefine)
            try {
              return nativeGetOwnPropertyDescriptor$1(e, t2);
            } catch (e2) {
            }
          if (has(e, t2))
            return createPropertyDescriptor(!objectPropertyIsEnumerable.f.call(e, t2), e[t2]);
        }, objectGetOwnPropertyDescriptor = { f: f$2 }, min = Math.min, toLength = function(e) {
          return 0 < e ? min(toInteger(e), 9007199254740991) : 0;
        }, max = Math.max, min$1 = Math.min, toAbsoluteIndex = function(e, t2) {
          var r = toInteger(e);
          return r < 0 ? max(r + t2, 0) : min$1(r, t2);
        }, arrayIncludes = function(s) {
          return function(e, t2, r) {
            var i2, n = toIndexedObject(e), o = toLength(n.length), a2 = toAbsoluteIndex(r, o);
            if (s && t2 != t2) {
              for (; a2 < o; )
                if ((i2 = n[a2++]) != i2)
                  return true;
            } else
              for (; a2 < o; a2++)
                if ((s || a2 in n) && n[a2] === t2)
                  return s || a2 || 0;
            return !s && -1;
          };
        }, arrayIndexOf = arrayIncludes(false), objectKeysInternal = function(e, t2) {
          var r, i2 = toIndexedObject(e), n = 0, o = [];
          for (r in i2)
            !has(hiddenKeys, r) && has(i2, r) && o.push(r);
          for (; t2.length > n; )
            has(i2, r = t2[n++]) && (~arrayIndexOf(o, r) || o.push(r));
          return o;
        }, enumBugKeys = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf"], hiddenKeys$1 = enumBugKeys.concat("length", "prototype"), f$3 = Object.getOwnPropertyNames || function(e) {
          return objectKeysInternal(e, hiddenKeys$1);
        }, objectGetOwnPropertyNames = { f: f$3 }, f$4 = Object.getOwnPropertySymbols, objectGetOwnPropertySymbols = { f: f$4 }, Reflect$1 = global_1.Reflect, ownKeys = Reflect$1 && Reflect$1.ownKeys || function(e) {
          var t2 = objectGetOwnPropertyNames.f(anObject(e)), r = objectGetOwnPropertySymbols.f;
          return r ? t2.concat(r(e)) : t2;
        }, copyConstructorProperties = function(e, t2) {
          for (var r = ownKeys(t2), i2 = objectDefineProperty.f, n = objectGetOwnPropertyDescriptor.f, o = 0; o < r.length; o++) {
            var a2 = r[o];
            has(e, a2) || i2(e, a2, n(t2, a2));
          }
        }, replacement = /#|\.prototype\./, isForced = function(e, t2) {
          var r = data[normalize(e)];
          return r == POLYFILL || r != NATIVE && ("function" == typeof t2 ? fails(t2) : !!t2);
        }, normalize = isForced.normalize = function(e) {
          return String(e).replace(replacement, ".").toLowerCase();
        }, data = isForced.data = {}, NATIVE = isForced.NATIVE = "N", POLYFILL = isForced.POLYFILL = "P", isForced_1 = isForced, getOwnPropertyDescriptor = objectGetOwnPropertyDescriptor.f, _export = function(e, t2) {
          var r, i2, n, o, a2 = e.target, s = e.global, l = e.stat, u2 = s ? global_1 : l ? global_1[a2] || setGlobal(a2, {}) : (global_1[a2] || {}).prototype;
          if (u2)
            for (r in t2) {
              if (n = t2[r], i2 = e.noTargetGet ? (o = getOwnPropertyDescriptor(u2, r)) && o.value : u2[r], !isForced_1(s ? r : a2 + (l ? "." : "#") + r, e.forced) && void 0 !== i2) {
                if (typeof n == typeof i2)
                  continue;
                copyConstructorProperties(n, i2);
              }
              (e.sham || i2 && i2.sham) && hide(n, "sham", true), redefine(u2, r, n, e);
            }
        }, toObject = function(e) {
          return Object(requireObjectCoercible(e));
        }, correctPrototypeGetter = !fails(function() {
          function e() {
          }
          return e.prototype.constructor = null, Object.getPrototypeOf(new e()) !== e.prototype;
        }), IE_PROTO = sharedKey("IE_PROTO"), ObjectPrototype$1 = Object.prototype, objectGetPrototypeOf = correctPrototypeGetter ? Object.getPrototypeOf : function(e) {
          return e = toObject(e), has(e, IE_PROTO) ? e[IE_PROTO] : "function" == typeof e.constructor && e instanceof e.constructor ? e.constructor.prototype : e instanceof Object ? ObjectPrototype$1 : null;
        }, ITERATOR = wellKnownSymbol("iterator"), BUGGY_SAFARI_ITERATORS = false, returnThis = function() {
          return this;
        }, IteratorPrototype, PrototypeOfArrayIteratorPrototype, arrayIterator;
        [].keys && (arrayIterator = [].keys(), "next" in arrayIterator ? (PrototypeOfArrayIteratorPrototype = objectGetPrototypeOf(objectGetPrototypeOf(arrayIterator)), PrototypeOfArrayIteratorPrototype !== Object.prototype && (IteratorPrototype = PrototypeOfArrayIteratorPrototype)) : BUGGY_SAFARI_ITERATORS = true), null == IteratorPrototype && (IteratorPrototype = {}), has(IteratorPrototype, ITERATOR) || hide(IteratorPrototype, ITERATOR, returnThis);
        var iteratorsCore = { IteratorPrototype, BUGGY_SAFARI_ITERATORS }, objectKeys = Object.keys || function(e) {
          return objectKeysInternal(e, enumBugKeys);
        }, objectDefineProperties = descriptors ? Object.defineProperties : function(e, t2) {
          anObject(e);
          for (var r, i2 = objectKeys(t2), n = i2.length, o = 0; o < n; )
            objectDefineProperty.f(e, r = i2[o++], t2[r]);
          return e;
        }, document$2 = global_1.document, html = document$2 && document$2.documentElement, IE_PROTO$1 = sharedKey("IE_PROTO"), PROTOTYPE = "prototype", Empty = function() {
        }, createDict = function() {
          var e, t2 = documentCreateElement("iframe"), r = enumBugKeys.length, i2 = "script";
          for (t2.style.display = "none", html.appendChild(t2), t2.src = String("javascript:"), (e = t2.contentWindow.document).open(), e.write("<script>document.F=Object</" + i2 + ">"), e.close(), createDict = e.F; r--; )
            delete createDict[PROTOTYPE][enumBugKeys[r]];
          return createDict();
        }, objectCreate = Object.create || function(e, t2) {
          var r;
          return null !== e ? (Empty[PROTOTYPE] = anObject(e), r = new Empty(), Empty[PROTOTYPE] = null, r[IE_PROTO$1] = e) : r = createDict(), void 0 === t2 ? r : objectDefineProperties(r, t2);
        };
        hiddenKeys[IE_PROTO$1] = true;
        var defineProperty = objectDefineProperty.f, TO_STRING_TAG$2 = wellKnownSymbol("toStringTag"), setToStringTag = function(e, t2, r) {
          e && !has(e = r ? e : e.prototype, TO_STRING_TAG$2) && defineProperty(e, TO_STRING_TAG$2, { configurable: true, value: t2 });
        }, iterators = {}, IteratorPrototype$1 = iteratorsCore.IteratorPrototype, returnThis$1 = function() {
          return this;
        }, createIteratorConstructor = function(e, t2, r) {
          var i2 = t2 + " Iterator";
          return e.prototype = objectCreate(IteratorPrototype$1, { next: createPropertyDescriptor(1, r) }), setToStringTag(e, i2, false, true), iterators[i2] = returnThis$1, e;
        }, validateSetPrototypeOfArguments = function(e, t2) {
          if (anObject(e), !isObject(t2) && null !== t2)
            throw TypeError("Can't set " + String(t2) + " as a prototype");
        }, objectSetPrototypeOf = Object.setPrototypeOf || ("__proto__" in {} ? function() {
          var r, i2 = false, e = {};
          try {
            (r = Object.getOwnPropertyDescriptor(Object.prototype, "__proto__").set).call(e, []), i2 = e instanceof Array;
          } catch (e2) {
          }
          return function(e2, t2) {
            return validateSetPrototypeOfArguments(e2, t2), i2 ? r.call(e2, t2) : e2.__proto__ = t2, e2;
          };
        }() : void 0), ITERATOR$1 = wellKnownSymbol("iterator"), IteratorPrototype$2 = iteratorsCore.IteratorPrototype, BUGGY_SAFARI_ITERATORS$1 = iteratorsCore.BUGGY_SAFARI_ITERATORS, KEYS = "keys", VALUES = "values", ENTRIES = "entries", returnThis$2 = function() {
          return this;
        }, defineIterator = function(e, t2, r, i2, n, o, a2) {
          createIteratorConstructor(r, t2, i2);
          function s(e2) {
            if (e2 === n && p2)
              return p2;
            if (!BUGGY_SAFARI_ITERATORS$1 && e2 in d)
              return d[e2];
            switch (e2) {
              case KEYS:
              case VALUES:
              case ENTRIES:
                return function() {
                  return new r(this, e2);
                };
            }
            return function() {
              return new r(this);
            };
          }
          var l, u2, c2, h = t2 + " Iterator", f2 = false, d = e.prototype, _ = d[ITERATOR$1] || d["@@iterator"] || n && d[n], p2 = !BUGGY_SAFARI_ITERATORS$1 && _ || s(n), g = "Array" == t2 && d.entries || _;
          if (g && (l = objectGetPrototypeOf(g.call(new e())), IteratorPrototype$2 !== Object.prototype && l.next && (objectGetPrototypeOf(l) !== IteratorPrototype$2 && (objectSetPrototypeOf ? objectSetPrototypeOf(l, IteratorPrototype$2) : "function" != typeof l[ITERATOR$1] && hide(l, ITERATOR$1, returnThis$2)), setToStringTag(l, h, true, true))), n == VALUES && _ && _.name !== VALUES && (f2 = true, p2 = function() {
            return _.call(this);
          }), d[ITERATOR$1] !== p2 && hide(d, ITERATOR$1, p2), iterators[t2] = p2, n)
            if (u2 = { values: s(VALUES), keys: o ? p2 : s(KEYS), entries: s(ENTRIES) }, a2)
              for (c2 in u2)
                !BUGGY_SAFARI_ITERATORS$1 && !f2 && c2 in d || redefine(d, c2, u2[c2]);
            else
              _export({ target: t2, proto: true, forced: BUGGY_SAFARI_ITERATORS$1 || f2 }, u2);
          return u2;
        }, STRING_ITERATOR = "String Iterator", setInternalState = internalState.set, getInternalState = internalState.getterFor(STRING_ITERATOR);
        defineIterator(String, "String", function(e) {
          setInternalState(this, { type: STRING_ITERATOR, string: String(e), index: 0 });
        }, function() {
          var e, t2 = getInternalState(this), r = t2.string, i2 = t2.index;
          return i2 >= r.length ? { value: void 0, done: true } : (e = stringAt(r, i2, true), t2.index += e.length, { value: e, done: false });
        });
        var domIterables = { CSSRuleList: 0, CSSStyleDeclaration: 0, CSSValueList: 0, ClientRectList: 0, DOMRectList: 0, DOMStringList: 0, DOMTokenList: 1, DataTransferItemList: 0, FileList: 0, HTMLAllCollection: 0, HTMLCollection: 0, HTMLFormElement: 0, HTMLSelectElement: 0, MediaList: 0, MimeTypeArray: 0, NamedNodeMap: 0, NodeList: 1, PaintRequestList: 0, Plugin: 0, PluginArray: 0, SVGLengthList: 0, SVGNumberList: 0, SVGPathSegList: 0, SVGPointList: 0, SVGStringList: 0, SVGTransformList: 0, SourceBufferList: 0, StyleSheetList: 0, TextTrackCueList: 0, TextTrackList: 0, TouchList: 0 }, UNSCOPABLES = wellKnownSymbol("unscopables"), ArrayPrototype = Array.prototype;
        null == ArrayPrototype[UNSCOPABLES] && hide(ArrayPrototype, UNSCOPABLES, objectCreate(null));
        var addToUnscopables = function(e) {
          ArrayPrototype[UNSCOPABLES][e] = true;
        }, ARRAY_ITERATOR = "Array Iterator", setInternalState$1 = internalState.set, getInternalState$1 = internalState.getterFor(ARRAY_ITERATOR), es_array_iterator = defineIterator(Array, "Array", function(e, t2) {
          setInternalState$1(this, { type: ARRAY_ITERATOR, target: toIndexedObject(e), index: 0, kind: t2 });
        }, function() {
          var e = getInternalState$1(this), t2 = e.target, r = e.kind, i2 = e.index++;
          return !t2 || i2 >= t2.length ? { value: e.target = void 0, done: true } : "keys" == r ? { value: i2, done: false } : "values" == r ? { value: t2[i2], done: false } : { value: [i2, t2[i2]], done: false };
        }, "values");
        iterators.Arguments = iterators.Array, addToUnscopables("keys"), addToUnscopables("values"), addToUnscopables("entries");
        var ITERATOR$2 = wellKnownSymbol("iterator"), TO_STRING_TAG$3 = wellKnownSymbol("toStringTag"), ArrayValues = es_array_iterator.values;
        for (var COLLECTION_NAME in domIterables) {
          var Collection = global_1[COLLECTION_NAME], CollectionPrototype = Collection && Collection.prototype;
          if (CollectionPrototype) {
            if (CollectionPrototype[ITERATOR$2] !== ArrayValues)
              try {
                hide(CollectionPrototype, ITERATOR$2, ArrayValues);
              } catch (e) {
                CollectionPrototype[ITERATOR$2] = ArrayValues;
              }
            if (CollectionPrototype[TO_STRING_TAG$3] || hide(CollectionPrototype, TO_STRING_TAG$3, COLLECTION_NAME), domIterables[COLLECTION_NAME]) {
              for (var METHOD_NAME in es_array_iterator)
                if (CollectionPrototype[METHOD_NAME] !== es_array_iterator[METHOD_NAME])
                  try {
                    hide(CollectionPrototype, METHOD_NAME, es_array_iterator[METHOD_NAME]);
                  } catch (e) {
                    CollectionPrototype[METHOD_NAME] = es_array_iterator[METHOD_NAME];
                  }
            }
          }
        }
        var aFunction = function(e) {
          if ("function" != typeof e)
            throw TypeError(String(e) + " is not a function");
          return e;
        }, anInstance = function(e, t2, r) {
          if (!(e instanceof t2))
            throw TypeError("Incorrect " + (r ? r + " " : "") + "invocation");
          return e;
        }, ITERATOR$3 = wellKnownSymbol("iterator"), ArrayPrototype$1 = Array.prototype, isArrayIteratorMethod = function(e) {
          return void 0 !== e && (iterators.Array === e || ArrayPrototype$1[ITERATOR$3] === e);
        }, bindContext = function(i2, n, e) {
          if (aFunction(i2), void 0 === n)
            return i2;
          switch (e) {
            case 0:
              return function() {
                return i2.call(n);
              };
            case 1:
              return function(e2) {
                return i2.call(n, e2);
              };
            case 2:
              return function(e2, t2) {
                return i2.call(n, e2, t2);
              };
            case 3:
              return function(e2, t2, r) {
                return i2.call(n, e2, t2, r);
              };
          }
          return function() {
            return i2.apply(n, arguments);
          };
        }, ITERATOR$4 = wellKnownSymbol("iterator"), getIteratorMethod = function(e) {
          if (null != e)
            return e[ITERATOR$4] || e["@@iterator"] || iterators[classof(e)];
        }, callWithSafeIterationClosing = function(t2, e, r, i2) {
          try {
            return i2 ? e(anObject(r)[0], r[1]) : e(r);
          } catch (e2) {
            var n = t2.return;
            throw void 0 !== n && anObject(n.call(t2)), e2;
          }
        }, iterate = createCommonjsModule(function(e) {
          var h = {};
          (e.exports = function(e2, t2, r, i2, n) {
            var o, a2, s, l, u2, c2 = bindContext(t2, r, i2 ? 2 : 1);
            if (n)
              o = e2;
            else {
              if ("function" != typeof (a2 = getIteratorMethod(e2)))
                throw TypeError("Target is not iterable");
              if (isArrayIteratorMethod(a2)) {
                for (s = 0, l = toLength(e2.length); s < l; s++)
                  if ((i2 ? c2(anObject(u2 = e2[s])[0], u2[1]) : c2(e2[s])) === h)
                    return h;
                return;
              }
              o = a2.call(e2);
            }
            for (; !(u2 = o.next()).done; )
              if (callWithSafeIterationClosing(o, c2, u2.value, i2) === h)
                return h;
          }).BREAK = h;
        }), ITERATOR$5 = wellKnownSymbol("iterator"), SAFE_CLOSING = false;
        try {
          var called = 0, iteratorWithReturn = { next: function() {
            return { done: !!called++ };
          }, return: function() {
            SAFE_CLOSING = true;
          } };
          iteratorWithReturn[ITERATOR$5] = function() {
            return this;
          };
        } catch (e) {
        }
        var checkCorrectnessOfIteration = function(e, t2) {
          if (!t2 && !SAFE_CLOSING)
            return false;
          var r = false;
          try {
            var i2 = {};
            i2[ITERATOR$5] = function() {
              return { next: function() {
                return { done: r = true };
              } };
            }, e(i2);
          } catch (e2) {
          }
          return r;
        }, SPECIES = wellKnownSymbol("species"), speciesConstructor = function(e, t2) {
          var r, i2 = anObject(e).constructor;
          return void 0 === i2 || null == (r = anObject(i2)[SPECIES]) ? t2 : aFunction(r);
        }, location = global_1.location, set$1 = global_1.setImmediate, clear = global_1.clearImmediate, process = global_1.process, MessageChannel = global_1.MessageChannel, Dispatch = global_1.Dispatch, counter = 0, queue = {}, ONREADYSTATECHANGE = "onreadystatechange", defer, channel, port, run = function(e) {
          var t2;
          queue.hasOwnProperty(e) && (t2 = queue[e], delete queue[e], t2());
        }, runner = function(e) {
          return function() {
            run(e);
          };
        }, listener = function(e) {
          run(e.data);
        }, post = function(e) {
          global_1.postMessage(e + "", location.protocol + "//" + location.host);
        };
        set$1 && clear || (set$1 = function(e) {
          for (var t2 = [], r = 1; r < arguments.length; )
            t2.push(arguments[r++]);
          return queue[++counter] = function() {
            ("function" == typeof e ? e : Function(e)).apply(void 0, t2);
          }, defer(counter), counter;
        }, clear = function(e) {
          delete queue[e];
        }, "process" == classofRaw(process) ? defer = function(e) {
          process.nextTick(runner(e));
        } : Dispatch && Dispatch.now ? defer = function(e) {
          Dispatch.now(runner(e));
        } : MessageChannel ? (channel = new MessageChannel(), port = channel.port2, channel.port1.onmessage = listener, defer = bindContext(port.postMessage, port, 1)) : !global_1.addEventListener || "function" != typeof postMessage || global_1.importScripts || fails(post) ? defer = ONREADYSTATECHANGE in documentCreateElement("script") ? function(e) {
          html.appendChild(documentCreateElement("script"))[ONREADYSTATECHANGE] = function() {
            html.removeChild(this), run(e);
          };
        } : function(e) {
          setTimeout(runner(e), 0);
        } : (defer = post, global_1.addEventListener("message", listener, false)));
        var task = { set: set$1, clear }, navigator$1 = global_1.navigator, userAgent = navigator$1 && navigator$1.userAgent || "", getOwnPropertyDescriptor$1 = objectGetOwnPropertyDescriptor.f, macrotask = task.set, MutationObserver = global_1.MutationObserver || global_1.WebKitMutationObserver, process$1 = global_1.process, Promise$1 = global_1.Promise, IS_NODE = "process" == classofRaw(process$1), queueMicrotaskDescriptor = getOwnPropertyDescriptor$1(global_1, "queueMicrotask"), queueMicrotask = queueMicrotaskDescriptor && queueMicrotaskDescriptor.value, flush, head, last, notify, toggle, node, promise;
        queueMicrotask || (flush = function() {
          var e, t2;
          for (IS_NODE && (e = process$1.domain) && e.exit(); head; ) {
            t2 = head.fn, head = head.next;
            try {
              t2();
            } catch (e2) {
              throw head ? notify() : last = void 0, e2;
            }
          }
          last = void 0, e && e.enter();
        }, notify = IS_NODE ? function() {
          process$1.nextTick(flush);
        } : MutationObserver && !/(iphone|ipod|ipad).*applewebkit/i.test(userAgent) ? (toggle = true, node = document.createTextNode(""), new MutationObserver(flush).observe(node, { characterData: true }), function() {
          node.data = toggle = !toggle;
        }) : Promise$1 && Promise$1.resolve ? (promise = Promise$1.resolve(void 0), function() {
          promise.then(flush);
        }) : function() {
          macrotask.call(global_1, flush);
        });
        var microtask = queueMicrotask || function(e) {
          var t2 = { fn: e, next: void 0 };
          last && (last.next = t2), head || (head = t2, notify()), last = t2;
        }, PromiseCapability = function(e) {
          var r, i2;
          this.promise = new e(function(e2, t2) {
            if (void 0 !== r || void 0 !== i2)
              throw TypeError("Bad Promise constructor");
            r = e2, i2 = t2;
          }), this.resolve = aFunction(r), this.reject = aFunction(i2);
        }, f$5 = function(e) {
          return new PromiseCapability(e);
        }, newPromiseCapability = { f: f$5 }, promiseResolve = function(e, t2) {
          if (anObject(e), isObject(t2) && t2.constructor === e)
            return t2;
          var r = newPromiseCapability.f(e);
          return (0, r.resolve)(t2), r.promise;
        }, hostReportErrors = function(e, t2) {
          var r = global_1.console;
          r && r.error && (1 === arguments.length ? r.error(e) : r.error(e, t2));
        }, perform = function(e) {
          try {
            return { error: false, value: e() };
          } catch (e2) {
            return { error: true, value: e2 };
          }
        }, redefineAll = function(e, t2, r) {
          for (var i2 in t2)
            redefine(e, i2, t2[i2], r);
          return e;
        }, path = global_1, aFunction$1 = function(e) {
          return "function" == typeof e ? e : void 0;
        }, getBuiltIn = function(e, t2) {
          return arguments.length < 2 ? aFunction$1(path[e]) || aFunction$1(global_1[e]) : path[e] && path[e][t2] || global_1[e] && global_1[e][t2];
        }, SPECIES$1 = wellKnownSymbol("species"), setSpecies = function(e) {
          var t2 = getBuiltIn(e), r = objectDefineProperty.f;
          descriptors && t2 && !t2[SPECIES$1] && r(t2, SPECIES$1, { configurable: true, get: function() {
            return this;
          } });
        }, PROMISE = "Promise", task$1 = task.set, SPECIES$2 = wellKnownSymbol("species"), getInternalState$2 = internalState.get, setInternalState$2 = internalState.set, getInternalPromiseState = internalState.getterFor(PROMISE), PromiseConstructor = global_1[PROMISE], TypeError$1 = global_1.TypeError, document$3 = global_1.document, process$2 = global_1.process, $fetch = global_1.fetch, versions = process$2 && process$2.versions, v8 = versions && versions.v8 || "", newPromiseCapability$1 = newPromiseCapability.f, newGenericPromiseCapability = newPromiseCapability$1, IS_NODE$1 = "process" == classofRaw(process$2), DISPATCH_EVENT = !!(document$3 && document$3.createEvent && global_1.dispatchEvent), UNHANDLED_REJECTION = "unhandledrejection", REJECTION_HANDLED = "rejectionhandled", PENDING = 0, FULFILLED = 1, REJECTED = 2, HANDLED = 1, UNHANDLED = 2, Internal, OwnPromiseCapability, PromiseWrapper, FORCED = isForced_1(PROMISE, function() {
          function t2() {
          }
          var e = PromiseConstructor.resolve(1), r = (e.constructor = {})[SPECIES$2] = function(e2) {
            e2(t2, t2);
          };
          return !((IS_NODE$1 || "function" == typeof PromiseRejectionEvent) && (!isPure || e.finally) && e.then(t2) instanceof r && 0 !== v8.indexOf("6.6") && -1 === userAgent.indexOf("Chrome/66"));
        }), INCORRECT_ITERATION = FORCED || !checkCorrectnessOfIteration(function(e) {
          PromiseConstructor.all(e).catch(function() {
          });
        }), isThenable = function(e) {
          var t2;
          return !(!isObject(e) || "function" != typeof (t2 = e.then)) && t2;
        }, notify$1 = function(c2, h, t2) {
          var r;
          h.notified || (h.notified = true, r = h.reactions, microtask(function() {
            for (var l = h.value, u2 = h.state == FULFILLED, e = 0; r.length > e; )
              !function(e2) {
                var t3, r2, i2, n = u2 ? e2.ok : e2.fail, o = e2.resolve, a2 = e2.reject, s = e2.domain;
                try {
                  n ? (u2 || (h.rejection === UNHANDLED && onHandleUnhandled(c2, h), h.rejection = HANDLED), true === n ? t3 = l : (s && s.enter(), t3 = n(l), s && (s.exit(), i2 = true)), t3 === e2.promise ? a2(TypeError$1("Promise-chain cycle")) : (r2 = isThenable(t3)) ? r2.call(t3, o, a2) : o(t3)) : a2(l);
                } catch (e3) {
                  s && !i2 && s.exit(), a2(e3);
                }
              }(r[e++]);
            h.reactions = [], h.notified = false, t2 && !h.rejection && onUnhandled(c2, h);
          }));
        }, dispatchEvent = function(e, t2, r) {
          var i2, n;
          DISPATCH_EVENT ? ((i2 = document$3.createEvent("Event")).promise = t2, i2.reason = r, i2.initEvent(e, false, true), global_1.dispatchEvent(i2)) : i2 = { promise: t2, reason: r }, (n = global_1["on" + e]) ? n(i2) : e === UNHANDLED_REJECTION && hostReportErrors("Unhandled promise rejection", r);
        }, onUnhandled = function(r, i2) {
          task$1.call(global_1, function() {
            var e, t2 = i2.value;
            if (isUnhandled(i2) && (e = perform(function() {
              IS_NODE$1 ? process$2.emit("unhandledRejection", t2, r) : dispatchEvent(UNHANDLED_REJECTION, r, t2);
            }), i2.rejection = IS_NODE$1 || isUnhandled(i2) ? UNHANDLED : HANDLED, e.error))
              throw e.value;
          });
        }, isUnhandled = function(e) {
          return e.rejection !== HANDLED && !e.parent;
        }, onHandleUnhandled = function(e, t2) {
          task$1.call(global_1, function() {
            IS_NODE$1 ? process$2.emit("rejectionHandled", e) : dispatchEvent(REJECTION_HANDLED, e, t2.value);
          });
        }, bind = function(t2, r, i2, n) {
          return function(e) {
            t2(r, i2, e, n);
          };
        }, internalReject = function(e, t2, r, i2) {
          t2.done || (t2.done = true, i2 && (t2 = i2), t2.value = r, t2.state = REJECTED, notify$1(e, t2, true));
        }, internalResolve = function(r, i2, e, t2) {
          if (!i2.done) {
            i2.done = true, t2 && (i2 = t2);
            try {
              if (r === e)
                throw TypeError$1("Promise can't be resolved itself");
              var n = isThenable(e);
              n ? microtask(function() {
                var t3 = { done: false };
                try {
                  n.call(e, bind(internalResolve, r, t3, i2), bind(internalReject, r, t3, i2));
                } catch (e2) {
                  internalReject(r, t3, e2, i2);
                }
              }) : (i2.value = e, i2.state = FULFILLED, notify$1(r, i2, false));
            } catch (e2) {
              internalReject(r, { done: false }, e2, i2);
            }
          }
        };
        FORCED && (PromiseConstructor = function(e) {
          anInstance(this, PromiseConstructor, PROMISE), aFunction(e), Internal.call(this);
          var t2 = getInternalState$2(this);
          try {
            e(bind(internalResolve, this, t2), bind(internalReject, this, t2));
          } catch (e2) {
            internalReject(this, t2, e2);
          }
        }, Internal = function() {
          setInternalState$2(this, { type: PROMISE, done: false, notified: false, parent: false, reactions: [], rejection: false, state: PENDING, value: void 0 });
        }, Internal.prototype = redefineAll(PromiseConstructor.prototype, { then: function(e, t2) {
          var r = getInternalPromiseState(this), i2 = newPromiseCapability$1(speciesConstructor(this, PromiseConstructor));
          return i2.ok = "function" != typeof e || e, i2.fail = "function" == typeof t2 && t2, i2.domain = IS_NODE$1 ? process$2.domain : void 0, r.parent = true, r.reactions.push(i2), r.state != PENDING && notify$1(this, r, false), i2.promise;
        }, catch: function(e) {
          return this.then(void 0, e);
        } }), OwnPromiseCapability = function() {
          var e = new Internal(), t2 = getInternalState$2(e);
          this.promise = e, this.resolve = bind(internalResolve, e, t2), this.reject = bind(internalReject, e, t2);
        }, newPromiseCapability.f = newPromiseCapability$1 = function(e) {
          return e === PromiseConstructor || e === PromiseWrapper ? new OwnPromiseCapability(e) : newGenericPromiseCapability(e);
        }, "function" == typeof $fetch && _export({ global: true, enumerable: true, forced: true }, { fetch: function(e) {
          return promiseResolve(PromiseConstructor, $fetch.apply(global_1, arguments));
        } })), _export({ global: true, wrap: true, forced: FORCED }, { Promise: PromiseConstructor }), setToStringTag(PromiseConstructor, PROMISE, false, true), setSpecies(PROMISE), PromiseWrapper = path[PROMISE], _export({ target: PROMISE, stat: true, forced: FORCED }, { reject: function(e) {
          var t2 = newPromiseCapability$1(this);
          return t2.reject.call(void 0, e), t2.promise;
        } }), _export({ target: PROMISE, stat: true, forced: FORCED }, { resolve: function(e) {
          return promiseResolve(this, e);
        } }), _export({ target: PROMISE, stat: true, forced: INCORRECT_ITERATION }, { all: function(e) {
          var s = this, t2 = newPromiseCapability$1(s), l = t2.resolve, u2 = t2.reject, r = perform(function() {
            var i2 = aFunction(s.resolve), n = [], o = 0, a2 = 1;
            iterate(e, function(e2) {
              var t3 = o++, r2 = false;
              n.push(void 0), a2++, i2.call(s, e2).then(function(e3) {
                r2 || (r2 = true, n[t3] = e3, --a2 || l(n));
              }, u2);
            }), --a2 || l(n);
          });
          return r.error && u2(r.value), t2.promise;
        }, race: function(e) {
          var r = this, i2 = newPromiseCapability$1(r), n = i2.reject, t2 = perform(function() {
            var t3 = aFunction(r.resolve);
            iterate(e, function(e2) {
              t3.call(r, e2).then(i2.resolve, n);
            });
          });
          return t2.error && n(t2.value), i2.promise;
        } }), _export({ target: "Promise", proto: true, real: true }, { finally: function(t2) {
          var r = speciesConstructor(this, getBuiltIn("Promise")), e = "function" == typeof t2;
          return this.then(e ? function(e2) {
            return promiseResolve(r, t2()).then(function() {
              return e2;
            });
          } : t2, e ? function(e2) {
            return promiseResolve(r, t2()).then(function() {
              throw e2;
            });
          } : t2);
        } });
        var promise$1 = path.Promise, perf, start;
        function _typeof(e) {
          return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e2) {
            return typeof e2;
          } : function(e2) {
            return e2 && "function" == typeof Symbol && e2.constructor === Symbol && e2 !== Symbol.prototype ? "symbol" : typeof e2;
          })(e);
        }
        function _classCallCheck(e, t2) {
          if (!(e instanceof t2))
            throw new TypeError("Cannot call a class as a function");
        }
        function _defineProperties(e, t2) {
          for (var r = 0; r < t2.length; r++) {
            var i2 = t2[r];
            i2.enumerable = i2.enumerable || false, i2.configurable = true, "value" in i2 && (i2.writable = true), Object.defineProperty(e, i2.key, i2);
          }
        }
        function _createClass(e, t2, r) {
          return t2 && _defineProperties(e.prototype, t2), r && _defineProperties(e, r), e;
        }
        function _defineProperty(e, t2, r) {
          return t2 in e ? Object.defineProperty(e, t2, { value: r, enumerable: true, configurable: true, writable: true }) : e[t2] = r, e;
        }
        function _inherits(e, t2) {
          if ("function" != typeof t2 && null !== t2)
            throw new TypeError("Super expression must either be null or a function");
          e.prototype = Object.create(t2 && t2.prototype, { constructor: { value: e, writable: true, configurable: true } }), t2 && _setPrototypeOf(e, t2);
        }
        function _getPrototypeOf(e) {
          return (_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function(e2) {
            return e2.__proto__ || Object.getPrototypeOf(e2);
          })(e);
        }
        function _setPrototypeOf(e, t2) {
          return (_setPrototypeOf = Object.setPrototypeOf || function(e2, t3) {
            return e2.__proto__ = t3, e2;
          })(e, t2);
        }
        function _isNativeReflectConstruct() {
          if ("undefined" == typeof Reflect || !Reflect.construct)
            return false;
          if (Reflect.construct.sham)
            return false;
          if ("function" == typeof Proxy)
            return true;
          try {
            return Date.prototype.toString.call(Reflect.construct(Date, [], function() {
            })), true;
          } catch (e) {
            return false;
          }
        }
        function _construct(e, t2, r) {
          return (_construct = _isNativeReflectConstruct() ? Reflect.construct : function(e2, t3, r2) {
            var i2 = [null];
            i2.push.apply(i2, t3);
            var n = new (Function.bind.apply(e2, i2))();
            return r2 && _setPrototypeOf(n, r2.prototype), n;
          }).apply(null, arguments);
        }
        function _isNativeFunction(e) {
          return -1 !== Function.toString.call(e).indexOf("[native code]");
        }
        function _wrapNativeSuper(e) {
          var r = "function" == typeof Map ? /* @__PURE__ */ new Map() : void 0;
          return (_wrapNativeSuper = function(e2) {
            if (null === e2 || !_isNativeFunction(e2))
              return e2;
            if ("function" != typeof e2)
              throw new TypeError("Super expression must either be null or a function");
            if (void 0 !== r) {
              if (r.has(e2))
                return r.get(e2);
              r.set(e2, t2);
            }
            function t2() {
              return _construct(e2, arguments, _getPrototypeOf(this).constructor);
            }
            return t2.prototype = Object.create(e2.prototype, { constructor: { value: t2, enumerable: false, writable: true, configurable: true } }), _setPrototypeOf(t2, e2);
          })(e);
        }
        function _assertThisInitialized(e) {
          if (void 0 === e)
            throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
          return e;
        }
        function _possibleConstructorReturn(e, t2) {
          return !t2 || "object" != typeof t2 && "function" != typeof t2 ? _assertThisInitialized(e) : t2;
        }
        function _createSuper(r) {
          var i2 = _isNativeReflectConstruct();
          return function() {
            var e, t2 = _getPrototypeOf(r);
            return _possibleConstructorReturn(this, i2 ? (e = _getPrototypeOf(this).constructor, Reflect.construct(t2, arguments, e)) : t2.apply(this, arguments));
          };
        }
        function _superPropBase(e, t2) {
          for (; !Object.prototype.hasOwnProperty.call(e, t2) && null !== (e = _getPrototypeOf(e)); )
            ;
          return e;
        }
        function _get(e, t2, r) {
          return (_get = "undefined" != typeof Reflect && Reflect.get ? Reflect.get : function(e2, t3, r2) {
            var i2 = _superPropBase(e2, t3);
            if (i2) {
              var n = Object.getOwnPropertyDescriptor(i2, t3);
              return n.get ? n.get.call(r2) : n.value;
            }
          })(e, t2, r || e);
        }
        function _slicedToArray(e, t2) {
          return _arrayWithHoles(e) || _iterableToArrayLimit(e, t2) || _unsupportedIterableToArray(e, t2) || _nonIterableRest();
        }
        function _toConsumableArray(e) {
          return _arrayWithoutHoles(e) || _iterableToArray(e) || _unsupportedIterableToArray(e) || _nonIterableSpread();
        }
        function _arrayWithoutHoles(e) {
          if (Array.isArray(e))
            return _arrayLikeToArray(e);
        }
        function _arrayWithHoles(e) {
          if (Array.isArray(e))
            return e;
        }
        function _iterableToArray(e) {
          if ("undefined" != typeof Symbol && Symbol.iterator in Object(e))
            return Array.from(e);
        }
        function _iterableToArrayLimit(e, t2) {
          if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) {
            var r = [], i2 = true, n = false, o = void 0;
            try {
              for (var a2, s = e[Symbol.iterator](); !(i2 = (a2 = s.next()).done) && (r.push(a2.value), !t2 || r.length !== t2); i2 = true)
                ;
            } catch (e2) {
              n = true, o = e2;
            } finally {
              try {
                i2 || null == s.return || s.return();
              } finally {
                if (n)
                  throw o;
              }
            }
            return r;
          }
        }
        function _unsupportedIterableToArray(e, t2) {
          if (e) {
            if ("string" == typeof e)
              return _arrayLikeToArray(e, t2);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? _arrayLikeToArray(e, t2) : void 0;
          }
        }
        function _arrayLikeToArray(e, t2) {
          (null == t2 || t2 > e.length) && (t2 = e.length);
          for (var r = 0, i2 = new Array(t2); r < t2; r++)
            i2[r] = e[r];
          return i2;
        }
        function _nonIterableSpread() {
          throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }
        function _nonIterableRest() {
          throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }
        function _createForOfIteratorHelper(e, t2) {
          var r;
          if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
            if (Array.isArray(e) || (r = _unsupportedIterableToArray(e)) || t2 && e && "number" == typeof e.length) {
              r && (e = r);
              var i2 = 0, n = function() {
              };
              return { s: n, n: function() {
                return i2 >= e.length ? { done: true } : { done: false, value: e[i2++] };
              }, e: function(e2) {
                throw e2;
              }, f: n };
            }
            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
          }
          var o, a2 = true, s = false;
          return { s: function() {
            r = e[Symbol.iterator]();
          }, n: function() {
            var e2 = r.next();
            return a2 = e2.done, e2;
          }, e: function(e2) {
            s = true, o = e2;
          }, f: function() {
            try {
              a2 || null == r.return || r.return();
            } finally {
              if (s)
                throw o;
            }
          } };
        }
        "function" != typeof Object.assign && (Object.assign = function(e) {
          if (null == e)
            throw new TypeError("Cannot convert undefined or null to object");
          for (var t2 = Object(e), r = 1; r < arguments.length; r++) {
            var i2 = arguments[r];
            if (null != i2)
              for (var n in i2)
                i2.hasOwnProperty(n) && (t2[n] = i2[n]);
          }
          return t2;
        }), "function" != typeof Object.values && (Object.values = function(t2) {
          return Object.keys(t2).map(function(e) {
            return t2[e];
          });
        }), Math.hypot = Math.hypot || function() {
          for (var e = 0, t2 = arguments.length, r = 0; r < t2; r++) {
            if (arguments[r] === 1 / 0 || arguments[r] === -1 / 0)
              return 1 / 0;
            e += arguments[r] * arguments[r];
          }
          return Math.sqrt(e);
        }, Math.log2 = Math.log2 || function(e) {
          return Math.log(e) * Math.LOG2E;
        }, "undefined" != typeof window ? ("performance" in window == false && (window.performance = {}), perf = window.performance) : "undefined" != typeof self && "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope && ("performance" in self == false && (self.performance = {}), perf = self.performance), perf && "function" != typeof perf.now && (start = +/* @__PURE__ */ new Date(), perf.now = function() {
          return /* @__PURE__ */ new Date() - start;
        });
        var global$1 = "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {}, ns = {}, MathUtils;
        (function() {
          var e, t2, o = "function" == typeof Object.defineProperties ? Object.defineProperty : function(e2, t3, r2) {
            e2 != Array.prototype && e2 != Object.prototype && (e2[t3] = r2.value);
          }, a2 = ("undefined" == typeof window || window !== this) && void 0 !== global$1 && null != global$1 ? global$1 : this;
          if ("function" == typeof Object.setPrototypeOf)
            e = Object.setPrototypeOf;
          else {
            e: {
              var r = {};
              try {
                r.__proto__ = { ea: true }, t2 = r.ea;
                break e;
              } catch (e2) {
              }
              t2 = false;
            }
            e = t2 ? function(e2, t3) {
              if (e2.__proto__ = t3, e2.__proto__ !== t3)
                throw new TypeError(e2 + " is not extensible");
              return e2;
            } : null;
          }
          var i2 = e;
          !function(e2, t3) {
            if (t3) {
              var r2 = a2;
              e2 = e2.split(".");
              for (var i3 = 0; i3 < e2.length - 1; i3++) {
                var n2 = e2[i3];
                n2 in r2 || (r2[n2] = {}), r2 = r2[n2];
              }
              (t3 = t3(i3 = r2[e2 = e2[e2.length - 1]])) != i3 && null != t3 && o(r2, e2, { configurable: true, writable: true, value: t3 });
            }
          }("Object.setPrototypeOf", function(e2) {
            return e2 || i2;
          });
          var n = this || self;
          function s(e2) {
            var t3 = _typeof(e2);
            if ("object" == t3) {
              if (!e2)
                return "null";
              if (e2 instanceof Array)
                return "array";
              if (e2 instanceof Object)
                return t3;
              var r2 = Object.prototype.toString.call(e2);
              if ("[object Window]" == r2)
                return "object";
              if ("[object Array]" == r2 || "number" == typeof e2.length && void 0 !== e2.splice && void 0 !== e2.propertyIsEnumerable && !e2.propertyIsEnumerable("splice"))
                return "array";
              if ("[object Function]" == r2 || void 0 !== e2.call && void 0 !== e2.propertyIsEnumerable && !e2.propertyIsEnumerable("call"))
                return "function";
            } else if ("function" == t3 && void 0 === e2.call)
              return "object";
            return t3;
          }
          function u2(e2) {
            return "function" == s(e2);
          }
          function c2(e2) {
            var t3 = _typeof(e2);
            return "object" == t3 && null != e2 || "function" == t3;
          }
          function l(e2, t3) {
            e2 = e2.split(".");
            var r2, i3 = n;
            e2[0] in i3 || void 0 === i3.execScript || i3.execScript("var " + e2[0]);
            for (; e2.length && (r2 = e2.shift()); )
              e2.length || void 0 === t3 ? i3 = i3[r2] && i3[r2] !== Object.prototype[r2] ? i3[r2] : i3[r2] = {} : i3[r2] = t3;
          }
          function h(e2, t3) {
            function r2() {
            }
            r2.prototype = t3.prototype, e2.ua = t3.prototype, e2.prototype = new r2(), e2.prototype.constructor = e2;
          }
          var f2 = Math, d = f2.min, _ = f2.max, p2 = f2.round, g = f2.floor, m = f2.ceil, y = f2.abs, v = f2.log, x2 = f2.sqrt, b2 = f2.pow, T2 = f2.sin, A2 = f2.asin, E2 = f2.cos, w = f2.tan, S2 = f2.atan2, k = f2.PI, P2 = k / 2, R2 = k / 4, M2 = 2 * k, L2 = 3 * k, O2 = k / 180, C2 = 180 / k;
          function N2(e2, t3, r2) {
            return r2 < e2 ? r2 : e2 < t3 ? t3 : e2;
          }
          function I(e2, t3, r2) {
            return t3 < r2 ? t3 <= e2 && e2 <= r2 : r2 <= e2 && e2 <= t3;
          }
          function B2(e2, t3, r2, i3, n2, o2) {
            return x2(b2((e2 - n2) * (i3 - o2) - (t3 - o2) * (r2 - n2), 2) / (b2(r2 - n2, 2) + b2(i3 - o2, 2)));
          }
          l("H.math.normalize", function(e2, t3, r2) {
            return t3 -= r2 = r2 || 0, (e2 -= r2) - g(e2 / t3) * t3 + r2;
          }), l("H.math.clamp", N2);
          var z2 = { NONE: 0, VERTEX: 1, EDGE: 2, SURFACE: 3 };
          function U2(e2, t3) {
            var r2 = e2.x;
            e2 = e2.y;
            for (var i3, n2, o2, a3, s2 = t3.length, l2 = s2, u3 = t3[0], c3 = 0, h2 = 0, f3 = 0; 1 != c3 && 1 < l2; )
              n2 = t3[--l2], i3 = t3[--l2], a3 = t3[l2 ? l2 - 1 : (s2 + (l2 - 1)) % s2], o2 = t3[l2 ? l2 - 2 : (s2 + (l2 - 2)) % s2], r2 <= i3 && i3 <= r2 && e2 <= n2 && n2 <= e2 || r2 <= o2 && o2 <= r2 && e2 <= a3 && a3 <= e2 ? c3 = 1 : c3 || i3 !== r2 ? !c3 && I(r2, i3, o2) && ((i3 < r2 && r2 < o2 || r2 < i3 && o2 < r2) && (h2 += e2 < (u3 = n2 + (r2 - i3) / (o2 - i3) * (a3 - n2)), f3 += u3 < e2), c3 = I(e2, n2, a3) && B2(r2, e2, i3, n2, o2, a3) <= 0 ? 2 : 0) : (o2 === r2 && (n2 < e2 && e2 < a3 || e2 < n2 && a3 < e2) || (u3 <= r2 && r2 < o2 || r2 <= u3 && o2 < r2) && (e2 <= n2 ? ++h2 : ++f3), c3 = I(e2, n2, a3) && B2(r2, e2, i3, n2, o2, a3) <= 0 ? 2 : 0), u3 = i3;
            return c3 || 0 === f3 || 0 == h2 % 2 || (c3 = 3), c3 !== z2.NONE;
          }
          function H2(e2, t3) {
            this.x = +e2, this.y = +t3;
          }
          function F2(e2, t3, r2, i3, n2, o2, a3, s2, l2, u3) {
            return e2 = { x: e2, y: t3, next: r2 || null, s: i3 || null, ta: n2 || null, X: o2 || null, o: !!a3, T: s2 || 0, O: l2 || 0, alpha: u3 || 0 }, i3 && (e2.s.next = e2), r2 && (e2.next.s = e2), e2;
          }
          function G(e2) {
            for (; e2 && e2.o; )
              e2 = e2.next;
            return e2;
          }
          function D2(e2) {
            if (e2)
              for (; e2.next; )
                e2 = e2.next;
            return e2;
          }
          function $(e2) {
            var t3 = D2(e2);
            (t3.s.next = e2).s = t3.s;
          }
          function j(e2) {
            for (var t3 = []; e2; )
              t3.push(e2.x, e2.y), e2 = e2.next;
            return t3;
          }
          function V(e2, t3, r2) {
            for (t3 = t3.next; t3 !== r2 && t3.alpha <= e2.alpha; )
              t3 = t3.next;
            e2.next = t3, e2.s = t3.s, (e2.next.s = e2).s.next = e2;
          }
          function W2(e2, t3) {
            for (var r2, i3 = null, n2 = 0, o2 = e2.length; n2 < o2; n2++)
              (r2 = F2(e2[n2].x, e2[n2].y, i3)).qa = t3, (r2.next = i3) && (i3.s = r2), i3 = r2;
            return i3;
          }
          function Y2(e2, t3, r2, i3) {
            return (e2 -= r2) * e2 + (t3 -= i3) * t3;
          }
          l("H.math.CoverType", z2), l("H.math.isPointInsidePolygon", U2), l("H.math.flatten", function(e2) {
            for (var t3 = e2.length, r2 = new Float64Array(2 * t3), i3 = t3 && e2[0].x !== Z2; t3--; ) {
              var n2 = e2[t3], o2 = t3 << 1;
              r2[o2] = i3 ? n2.x : n2[0], r2[1 + o2] = i3 ? n2.y : n2[1];
            }
            return r2;
          }), l("H.math.Point", H2), (H2.prototype.set = H2).prototype.clone = function(e2) {
            return e2 ? (e2.x = this.x, e2.y = this.y) : e2 = new H2(this.x, this.y), e2;
          }, H2.prototype.add = function(e2) {
            return this.x += e2.x, this.y += e2.y, this;
          }, H2.prototype.sub = function(e2) {
            return this.x -= e2.x, this.y -= e2.y, this;
          }, H2.prototype.scale = function(e2, t3) {
            return this.x *= e2, this.y *= void 0 === t3 ? e2 : t3, this;
          }, H2.prototype.round = function() {
            return this.x = p2(this.x), this.y = p2(this.y), this;
          }, H2.prototype.floor = function() {
            return this.x = g(this.x), this.y = g(this.y), this;
          }, H2.prototype.ceil = function() {
            return this.x = m(this.x), this.y = m(this.y), this;
          }, H2.prototype.equals = H2.prototype.w = function(e2) {
            return !(!e2 || this.x !== e2.x || this.y !== e2.y);
          }, H2.prototype.getNearest = H2.prototype.la = function(e2, t3) {
            var r2, i3 = t3.x - e2.x, n2 = t3.y - e2.y, o2 = e2;
            return (i3 || n2) && (o2 = (r2 = ((this.x - e2.x) * i3 + (this.y - e2.y) * n2) / (i3 * i3 + n2 * n2)) <= 0 ? e2 : 1 <= r2 ? t3 : new H2(e2.x + r2 * i3, e2.y + r2 * n2)), o2;
          }, H2.prototype.distance = H2.prototype.R = function(e2) {
            return x2(b2(this.x - e2.x, 2) + b2(this.y - e2.y, 2));
          }, H2.fromIPoint = function(e2) {
            if (!e2)
              throw Error("invalid argument");
            return e2 instanceof H2 ? e2 : new H2(e2.x, e2.y);
          }, l("H.math.clipping.clipStrips", function(e2, t3, r2, i3, n2, o2) {
            var a3, s2, l2, u3 = e2.length;
            if (u3)
              for (a3 = []; u3--; )
                for (var c3, h2, f3 = e2[u3], d2 = f3.length, _2 = 0, p3 = 1; p3 < d2; p3++) {
                  (l2 = function(e3, t4, r3, i4, n3, o3) {
                    var a4 = e3.x;
                    e3 = -e3.y;
                    var s3 = t4.x;
                    if (t4 = -t4.y, r3 = -r3, o3 = -o3, s3 < a4) {
                      if (n3 < s3 || a4 < i4)
                        return;
                      var l3 = a4, u4 = e3;
                      a4 = s3, e3 = t4, s3 = l3, t4 = u4, l3 = 1;
                    } else if (n3 < a4 || s3 < i4)
                      return;
                    if (t4 < e3) {
                      if (r3 < t4 || e3 < o3)
                        return;
                      var c4 = 1;
                      e3 = -e3, t4 = -t4, u4 = o3, o3 = -r3, r3 = -u4;
                    } else if (r3 < e3 || t4 < o3)
                      return;
                    if (a4 < i4) {
                      if ((e3 += (i4 - a4) * (t4 - e3) / (s3 - a4)) > r3)
                        return;
                      a4 = i4;
                    }
                    if (e3 < o3) {
                      if ((a4 += (o3 - e3) * (s3 - a4) / (t4 - e3)) > n3)
                        return;
                      e3 = o3;
                    }
                    return n3 < s3 && (t4 = e3 + (n3 - a4) * (t4 - e3) / (s3 - a4), s3 = n3), r3 < t4 && (s3 = a4 + (r3 - e3) * (s3 - a4) / (t4 - e3), t4 = r3), c4 && (e3 = -e3, t4 = -t4), l3 ? [new H2(s3, -t4), new H2(a4, -e3)] : [new H2(a4, -e3), new H2(s3, -t4)];
                  }(f3[p3 - 1], f3[p3], r2, t3, i3, n2)) && (c3 = l2[0], h2 = l2[1], _2 && _2.w(c3) ? s2.push(h2) : a3.push(s2 = l2), _2 = h2, o2 && (p3 = d2, u3 = 0));
                }
            else
              a3 = e2;
            return a3;
          }), l("H.math.clipping.clipPolygon", function(e2, t3, r2) {
            var i3;
            e2 = W2(e2, true), t3 = W2(t3, false);
            var n2 = {}, o2 = i3 = 1;
            switch (~~(r2 || 0)) {
              case 1:
                o2 = i3 = 0;
                break;
              case 2:
                i3 = 0, o2 = 1;
                break;
              case 3:
                i3 = 1, o2 = 0;
            }
            r2 = i3;
            var a3, s2, l2, u3, c3, h2, f3 = o2;
            if (t3 && e2) {
              for (t3.M = F2(t3.x, t3.y, null, D2(t3)), e2.M = F2(e2.x, e2.y, null, D2(e2)), o2 = t3; o2.next; o2 = o2.next)
                if (!o2.o)
                  for (i3 = e2; i3.next; i3 = i3.next) {
                    i3.o || (h2 = function e3(t4, r3, i4, n3, o3) {
                      var a4, s3 = r3.x - t4.x, l3 = r3.y - t4.y;
                      var u4 = n3.x - i4.x;
                      var c4 = n3.y - i4.y;
                      var h3 = s3 * c4 - l3 * u4;
                      if (!h3)
                        return 0;
                      u4 = ((i4.x - t4.x) * c4 - (i4.y - t4.y) * u4) / h3;
                      h3 = (l3 * (i4.x - t4.x) - s3 * (i4.y - t4.y)) / h3;
                      if (u4 < 0 || 1 < u4 || h3 < 0 || 1 < h3)
                        return 0;
                      0 === u4 ? a4 = t4 : 1 === u4 ? a4 = r3 : 0 === h3 ? a4 = i4 : 1 === h3 && (a4 = n3);
                      if (a4)
                        return a4.x += 2480549651603763e-20, a4.y += 7321997314118067e-20, a4.M && (a4.M.x = a4.x, a4.M.y = a4.y), e3(t4, r3, i4, n3, o3);
                      o3.xa = t4.x + u4 * s3;
                      o3.ya = t4.y + u4 * l3;
                      o3.fa = u4;
                      o3.ga = h3;
                      return 1;
                    }(o2, a3 = G(o2.next), i3, s2 = G(i3.next), n2)) && (h2 = n2.fa, l2 = n2.ga, V(h2 = F2(u3 = n2.xa, c3 = n2.ya, null, null, null, null, true, 0, 0, h2), o2, a3), V(a3 = F2(u3, c3, null, null, null, null, true, 0, 0, l2), i3, s2), (h2.X = a3).X = h2);
                  }
              for (n2 = U2(t3, j(e2)), r2 && (n2 = !n2), o2 = t3; o2; o2 = o2.next)
                o2.o && (n2 = !(o2.T = n2));
              for (n2 = U2(e2, j(t3)), f3 && (n2 = !n2), i3 = e2; i3.next; i3 = i3.next)
                i3.o && (n2 = !(i3.T = n2));
              for ($(t3), $(e2); (e2 = function(e3) {
                var t4 = e3;
                if (t4)
                  for (; (t4 = t4.next) != e3 && (!t4.o || t4.o && t4.O); )
                    ;
                return t4;
              }(t3)) != t3; ) {
                for (r2 = null; !e2.O; e2 = e2.X) {
                  for (n2 = e2.T; (r2 = F2(e2.x, e2.y, r2)).artificial = e2.o || e2.qa, e2.O = 1, e2 = n2 ? e2.next : e2.s; )
                    if (e2.o) {
                      e2.O = 1;
                      break;
                    }
                  if (!e2)
                    break;
                }
                r2.ta = d2;
                var d2 = r2;
              }
              return d2;
            }
          }), l("H.math.simplifyDP", function(e2, t3, r2) {
            return function e3(t4, r3, i3, n2, o2) {
              var a3 = 0, s2 = n2, l2 = t4[n2].x, u3 = t4[n2].y, c3 = t4[o2].x, h2 = t4[o2].y, f3 = n2 + 1, d2 = Y2(l2, u3, c3, h2);
              if (d2)
                for (; f3 < o2; ) {
                  var _2 = t4[f3++], p3 = _2.x;
                  _2 = _2.y;
                  var g2 = ((p3 - l2) * (c3 - l2) + (_2 - u3) * (h2 - u3)) / d2;
                  p3 = g2 < 0 ? Y2(p3, _2, l2, u3) : 1 < g2 ? Y2(p3, _2, c3, h2) : Y2(p3, _2, l2 + g2 * (c3 - l2), u3 + g2 * (h2 - u3)), a3 < p3 && (a3 = p3, s2 = f3 - 1);
                }
              else
                for (; f3 < o2; )
                  _2 = t4[f3++], p3 = _2.x, _2 = _2.y, p3 = Y2(p3, _2, l2, u3), a3 < p3 && (a3 = p3, s2 = f3 - 1);
              n2 = r3 <= a3 || 0 < i3 && s2 - n2 ? (--i3, 1 < s2 - n2 ? (n2 = e3(t4, r3, i3, n2, s2), n2.splice(n2.length - 1, 1)) : n2 = [t4[n2]], 1 < o2 - s2 ? n2.concat(e3(t4, r3, i3, s2, o2)) : n2.concat(t4.slice(s2, o2 + 1))) : [t4[n2], t4[o2]];
              return n2;
            }(e2, t3 * t3, r2 || 0, 0, e2.length - 1);
          });
          var q = this, X2 = String, Z2 = [].pop(), K2 = /x/.exec(""), J2 = "prototype constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
          function Q(e2, t3) {
            if (true == (e2 instanceof t3 && e2.constructor === t3))
              throw new TypeError("Illegal constructor " + ne2(t3));
          }
          l("H.lang.isArray", function(e2, t3, r2, i3) {
            var n2;
            if (!(n2 = "Array" === re2(e2)) && t3)
              throw new ue2(t3, r2, i3 !== Z2 ? i3 : e2);
            return n2;
          }), l("H.lang.isString", function(e2) {
            return "string" == typeof e2;
          });
          var ee2 = isNaN;
          function te2(e2) {
            return e2 === +e2;
          }
          function re2(e2) {
            var t3 = Object[J2[0]][J2[6]].call(e2).match(/^\[object (\w+)\]$/);
            return t3 ? t3[1] : _typeof(e2);
          }
          l("H.lang.isNumber", te2), l("H.lang.isInteger", Number.isInteger ? Number.isInteger : function(e2) {
            return "number" == typeof e2 && 0 == e2 % 1;
          });
          var ie2 = [];
          function ne2(n2, e2, o2, a3) {
            var s2, t3, l2 = "", r2 = arguments.length < 2;
            return r2 && (e2 = { H: q.H }, o2 = "", a3 = ie2.slice()), se2(e2, true, function(e3, t4) {
              try {
                if (s2 = e3[t4], r3 = s2, se2(e3, !(i3 = []), function(e4, t5) {
                  e4[t5] === r3 && i3.push(t5);
                }), t4 = i3.sort(oe2)[0], !(c2(s2) && s2.window === s2 && s2.self === s2 || c2(s2) && 0 < s2.nodeType && u2(s2.cloneNode)) && c2(s2)) {
                  if (s2 === n2)
                    return l2 = o2 + "." + t4, 1;
                  if (a3.indexOf(s2) < 0 && (a3.push(s2), l2 = ne2(n2, s2, o2 + "." + t4, a3)))
                    return 1;
                }
              } catch (e4) {
              }
              var r3, i3;
            }), r2 && (l2 = l2 ? l2.substr(1).replace("." + J2[0] + ".", "#") : "~" + (u2(n2) ? ((t3 = /^\s*function ([^\( ]+)/.exec(t3 = n2)) ? t3[1] : "anonymous") + "()" : re2(n2))), l2;
          }
          function oe2(e2, t3) {
            return t3.length - e2.length;
          }
          ie2.indexOf(ie2) < 0 && ie2.push(ie2);
          var ae2 = Object[J2[0]][J2[2]];
          function se2(e2, t3, r2) {
            var i3;
            if (e2) {
              for (n2 in e2)
                if ((!t3 || ae2.call(e2, n2)) && r2(e2, n2, true))
                  return;
              for (i3 = J2.length; i3--; ) {
                var n2 = J2[i3];
                if ((!t3 || ae2.call(e2, n2)) && r2(e2, n2, false))
                  break;
              }
            }
          }
          function le2(e2, t3, r2) {
            r2[t3] = "#" + t3;
          }
          function ue2(e2, t3, r2) {
            var i3, n2, o2 = arguments.length;
            return (t3 = t3 !== Z2 ? +t3 : t3) !== Z2 && ((n2 = i3 = (n2 = /^.*?\(([^\)]+)/.exec(("" + e2).replace(/(\/\*([\s\S]*?)\*\/)|(\/\/(.*)$)/gm, ""))) ? X2(n2[1].replace(/\s+/g, "")).split("," !== Z2 ? "," : " ") : []).forEach(le2), n2 = n2[t3] || "#" + t3), i3 = e2 ? ne2(e2) : "", o2 = 2 < o2 ? X2(r2) : "", (n2 || o2) && (i3 += " (Argument " + (n2 || "") + (o2 ? " " + o2 : "") + ")"), o2 = Error(i3), Object.setPrototypeOf(o2, ue2.prototype), o2;
          }
          function ce2(e2, t3, r2) {
            var i3 = N2(+e2, -90, 90);
            if (t3 && ee2(i3))
              throw new ue2(t3, r2, e2);
            return i3;
          }
          function he2(e2, t3, r2) {
            var i3, n2 = +e2;
            if ((n2 < -180 || 180 < n2) && (n2 = (false == (i3 = (n2 + 180) % 360) < 0 ? i3 : 360 + i3) - 180), t3 && ee2(n2))
              throw new ue2(t3, r2, e2);
            return n2;
          }
          function fe2(e2, t3, r2) {
            var i3;
            if (e2 !== Z2 && ee2(i3 = +e2) && t3)
              throw new ue2(t3, r2, e2);
            return i3;
          }
          function de2() {
            Q(this, de2);
          }
          function _e(e2, t3, r2) {
            this.lat = ce2(e2, _e, 0), this.lng = he2(t3, _e, 1), r2 !== Z2 && (this.alt = fe2(r2, _e, 2));
          }
          function pe2(e2, t3, r2) {
            var i3 = c2(e2) && !(ee2(e2.lat = ce2(e2.lat)) || ee2(e2.lng = he2(e2.lng)) || e2.alt !== Z2 && ee2(e2.alt = fe2(e2.alt)));
            if (!i3 && t3)
              throw new ue2(t3, r2, e2);
            return i3;
          }
          function ge2(e2, t3, r2, i3) {
            me2(this, ce2(e2, ge2, 0), he2(t3, ge2, 1), ce2(r2, ge2, 2), he2(i3, ge2, 3));
          }
          function me2(e2, t3, r2, i3, n2) {
            return e2.f = r2, e2.g = n2, t3 < i3 && (r2 = t3, t3 = i3, i3 = r2), e2.i = t3, e2.h = i3, e2.m = e2.b = e2.c = null, e2;
          }
          function ye2(e2, t3) {
            return (e2 = t3 - e2) + (e2 < 0 ? 360 : 0);
          }
          function ve2(e2, t3) {
            return (e2 += t3 / 2) - (180 < e2 ? 360 : 0);
          }
          function xe2(e2, t3, r2, i3, n2, o2, a3, s2, l2) {
            r2 = d(r2, a3), e2 = _(e2, n2);
            var u3 = ve2(t3, n2 = ye2(t3, i3)), c3 = ve2(o2, a3 = ye2(o2, s2)) - u3, h2 = (c3 += c3 - 1e-6 < 0 ? 360 : 0) - 1e-6 < 180 ? (u3 = t3, s2) : (c3 = 360 - c3, u3 = o2, i3);
            return 360 <= (c3 = c3 + n2 / 2 + a3 / 2) + 5e-7 ? (u3 = -180, h2 = 180) : c3 - 5e-7 < n2 ? (u3 = t3, h2 = i3) : c3 - 5e-7 < a3 && (u3 = o2, h2 = s2), l2 ? me2(l2, e2, u3, r2, h2) : new ge2(e2, u3, r2, h2);
          }
          function be2(e2, t3, r2) {
            return r2 || (pe2(e2, be2, 0), pe2(t3, be2, 1)), new ge2(e2.lat, e2.lng, t3.lat, t3.lng);
          }
          function Te2(e2, t3, r2, i3, n2, o2) {
            Q(this, Te2), this.sa = e2 || 10, this.c = this.b = null, this.j = i3 || 0, this.l = n2 || 0, this.m = t3 || 1, this.u = r2 || 1, this.I = !!o2, this.flush();
          }
          function Ae2(e2, t3, r2) {
            var i3, n2;
            if (e2.I && (i3 = e2.c))
              for (n2 = 3; 0 <= n2; n2--) {
                var o2 = t3[n2];
                if (n2 % 3 ? o2 >= i3[n2] : o2 <= i3[n2]) {
                  if (!r2) {
                    e2.c = null;
                    break;
                  }
                  i3[n2] = o2;
                }
              }
          }
          function Ee2(e2, t3) {
            var r2, i3 = e2.a;
            if (t3) {
              var n2 = t3;
              if (n2 !== i3)
                for (i3 = n2; n2 = n2.c; )
                  (n2.entries || 1 < n2.a) && (i3 = n2);
            } else
              for (; !i3.entries && (r2 = i3.a) < 2 && r2; )
                i3 = n2;
            e2.a = i3;
          }
          h(ue2, Error), l("H.lang.InvalidArgumentError", ue2), ue2.prototype.name = "InvalidArgumentError", l("H.geo.isDBC", function(e2, t3) {
            return 0 != (e2 < 0 ^ t3 < 0) && 180 < y(t3 - e2);
          }), l("H.geo.AbstractGeometry", de2), de2.prototype.getBoundingBox = de2.prototype.D, de2.prototype.equals = de2.prototype.w, de2.prototype.a = "", de2.prototype.l = "", de2.prototype.toString = function() {
            return this.I([this.a.toUpperCase(), " "]).join("");
          }, de2.prototype.toGeoJSON = de2.prototype.va = function() {
            return { type: this.l, coordinates: this.u() };
          }, de2.prototype.forWorkerMessage = de2.prototype.U = function() {
            return { type: this.a, coordinates: this.j(), boundingBox: this.D().U() };
          }, h(_e, de2), l("H.geo.Point", _e), _e.prototype.equals = _e.prototype.w = function(e2) {
            return this === e2 || !!e2 && this.lat === e2.lat && this.lng === e2.lng && (this.alt || 0) === (e2.alt || 0);
          }, _e.prototype.distance = _e.prototype.R = function(e2) {
            var t3, r2;
            return e2 = this === e2 || this.lat === e2.lat && this.lng === e2.lng ? 0 : (t3 = this.lat * O2, r2 = e2.lat * O2, 1274200158e-2 * A2(d(1, x2(b2(T2((t3 - r2) / 2), 2) + E2(t3) * E2(r2) * b2(T2((this.lng * O2 - e2.lng * O2) / 2), 2)))));
          }, _e.prototype.walk = _e.prototype.wa = function(e2, t3, r2) {
            var i3, n2, o2, a3, s2, l2, u3;
            return r2 ? ((t3 /= 637100079e-2) && (e2 *= O2, s2 = O2 * this.lat, i3 = T2(s2), n2 = T2(t3), o2 = E2(t3), a3 = O2 * this.lng, l2 = E2(s2), s2 = A2(l2 * E2(e2) * n2 + i3 * o2), l2 = (e2 = (a3 + (e2 = S2(T2(e2) * l2 * n2, o2 - i3 * T2(s2))) + k) % (2 * k) - k) * C2), t3 ? new _e(s2 * C2, (l2 + 540) % 360 - 180) : this) : 0 == ((e2 = (e2 % 360 + 360) % 360) + 90) % 180 ? (s2 = this.lng + t3 / (637100079e-2 * M2 * E2(this.lat * O2)) * (270 === e2 ? -360 : 360), new _e(this.lat, (s2 + 540) % 360 - 180)) : ((t3 /= 637100079e-2) && (e2 *= O2, a3 = this.lat * O2, i3 = this.lng * O2, o2 = (n2 = a3 + t3 * E2(e2)) - a3, s2 = v(w(n2 / 2 + R2) / w(a3 / 2 + R2)), s2 = ee2(o2 / s2) ? E2(a3) : o2 / s2, u3 = t3 * T2(e2) / s2, y(n2) > P2 && (n2 = 0 < n2 ? k - n2 : -(k + n2))), t3 ? new _e(n2 * C2, ((i3 + u3 + L2 + (y(a3 + o2) > P2 ? k : 0)) % M2 - k) * C2) : this);
          }, _e.prototype.getBoundingBox = _e.prototype.D = function() {
            return new ge2(this.lat, this.lng, this.lat, this.lng);
          }, _e.validate = pe2, _e.fromIPoint = function e2(t3) {
            if (!t3)
              throw new ue2(e2, 0, t3);
            return new _e(t3.lat, t3.lng, t3.alt);
          }, _e.prototype.a = "Point", _e.prototype.I = function(e2) {
            return e2.push("(", this.lng, " ", this.lat, ")"), e2;
          }, _e.prototype.l = "Point", _e.prototype.u = function() {
            return [this.lng, this.lat, this.alt || 0];
          }, _e.prototype.j = function() {
            return [this.lat, this.lng, this.alt || 0];
          }, h(ge2, de2), l("H.geo.Rect", ge2), ge2.prototype.a = "Polygon", ge2.prototype.I = function(e2) {
            var t3 = this.i, r2 = this.f, i3 = this.h, n2 = this.g;
            return e2.push("(", "(", r2, " ", t3, ",", n2, " ", t3, ",", n2, " ", i3, ",", r2, " ", i3, ",", r2, " ", t3, ")", ")"), e2;
          }, ge2.prototype.equals = ge2.prototype.w = function(e2) {
            return this === e2 || !!e2 && this.i === e2.i && this.f === e2.f && this.h === e2.h && this.g === e2.g;
          }, ge2.prototype.clone = function() {
            return new ge2(this.i, this.f, this.h, this.g);
          }, ge2.prototype.getTopLeft = ge2.prototype.W = function() {
            return this.m || (this.m = new _e(this.i, this.f)), this.m;
          }, ge2.prototype.getBottomRight = ge2.prototype.V = function() {
            return this.b || (this.b = new _e(this.h, this.g)), this.b;
          }, ge2.prototype.getTop = ge2.prototype.na = function() {
            return this.i;
          }, ge2.prototype.getBottom = ge2.prototype.ha = function() {
            return this.h;
          }, ge2.prototype.getLeft = ge2.prototype.ja = function() {
            return this.f;
          }, ge2.prototype.getRight = ge2.prototype.ma = function() {
            return this.g;
          }, ge2.prototype.getCenter = ge2.prototype.F = function() {
            return this.c || (this.c = new _e(this.h + (this.i - this.h) / 2, ve2(this.f, this.A()))), this.c;
          }, ge2.prototype.getWidth = ge2.prototype.A = function() {
            return ye2(this.f, this.g);
          }, ge2.prototype.getHeight = ge2.prototype.G = function() {
            return this.i - this.h;
          }, ge2.prototype.isCDB = ge2.prototype.N = function() {
            return this.f > this.g;
          }, ge2.prototype.isEmpty = ge2.prototype.ra = function() {
            return !this.A() && !this.G();
          }, ge2.prototype.getBoundingBox = ge2.prototype.D = function() {
            return new ge2(this.i, this.f, this.h, this.g);
          }, ge2.prototype.containsLatLng = ge2.prototype.L = function(e2, t3, r2) {
            var i3 = this.F();
            return r2 || (e2 = ce2(e2, this.L, 0), t3 = he2(t3, this.L, 1)), (e2 = (t3 = this.B(e2, t3, r2)).F()).lat === i3.lat && e2.lng === i3.lng && this.G() === t3.G() && this.A() === t3.A();
          }, ge2.prototype.containsPoint = ge2.prototype.$ = function(e2, t3) {
            return t3 || pe2(e2, this.$, 0), this.L(e2.lat, e2.lng, t3);
          }, ge2.prototype.containsRect = ge2.prototype.aa = function(e2, t3) {
            var r2 = this.F();
            if (!(t3 || e2 instanceof ge2))
              throw new ue2(this.aa, 0, e2);
            return (e2 = (t3 = this.J(e2, t3)).F()).lat === r2.lat && e2.lng === r2.lng && this.G() === t3.G() && this.A() === t3.A();
          }, ge2.prototype.mergeLatLng = ge2.prototype.B = function(e2, t3, r2, i3) {
            if (!r2) {
              if (ee2(e2 = ce2(e2)))
                throw new ue2(this.B, 0, e2);
              if (ee2(t3 = he2(t3)))
                throw new ue2(this.B, 1, t3);
            }
            return xe2(this.i, this.f, this.h, this.g, e2, t3, e2, t3, i3);
          }, ge2.prototype.mergePoint = ge2.prototype.ca = function(e2, t3, r2) {
            return t3 || pe2(e2, this.ca, 0), this.B(e2.lat, e2.lng, t3, r2);
          }, ge2.prototype.mergeRect = ge2.prototype.J = function(e2, t3, r2) {
            if (!(t3 || e2 instanceof ge2))
              throw new ue2(this.J, 0, e2);
            return xe2(this.i, this.f, this.h, this.g, e2.i, e2.f, e2.h, e2.g, r2);
          }, ge2.prototype.mergeTopLeftBottomRight = ge2.prototype.C = function(e2, t3, r2, i3, n2, o2) {
            return n2 || (e2 = ce2(e2, this.C, 0), t3 = he2(t3, this.C, 1), r2 = ce2(r2, this.C, 2), i3 = he2(i3, this.C, 3)), xe2(this.i, this.f, this.h, this.g, e2, t3, r2, i3, o2);
          }, ge2.prototype.intersects = ge2.prototype.ba = function(e2, t3) {
            var r2 = this.f <= this.g, i3 = e2.f <= e2.g, n2 = this.f < e2.g, o2 = e2.f < this.g;
            if (!(t3 || e2 instanceof ge2))
              throw new ue2(this.ba, 0, e2);
            return this.h <= e2.i && e2.h <= this.i && (!r2 && (!i3 || n2 || o2) || !i3 && (n2 || o2) || n2 && o2);
          }, ge2.merge = xe2, ge2.fromPoints = be2, ge2.coverPoints = function e2(t3, r2) {
            var i3 = 1, n2 = t3.length, o2 = null, a3 = s(t3);
            if ("array" != a3 && ("object" != a3 || "number" != typeof t3.length))
              throw new ue2(e2, 0, t3);
            if (0 < n2)
              for (o2 = be2(a3 = t3[0], a3, r2); i3 < n2; i3++)
                a3 = t3[i3], o2.B(a3.lat, a3.lng, r2, o2);
            return o2;
          }, ge2.coverLatLngAlts = function e2(t3, r2) {
            var i3, n2 = 3, o2 = t3.length;
            if (!(r2 || t3 && null != t3.length))
              throw new ue2(e2, 0, t3);
            if (0 < o2)
              for (i3 = new ge2(t3[0], t3[1], t3[0], t3[1]); n2 < o2; n2 += 3)
                i3.B(t3[n2], t3[n2 + 1], r2, i3);
            return i3;
          }, ge2.coverRects = function e2(t3, r2) {
            var i3, n2 = 1, o2 = t3.length;
            if (r2 && (!t3 || null == t3.length))
              throw new ue2(e2, 0, t3);
            if (0 < o2)
              for (i3 = new ge2(t3[0].i, t3[0].f, t3[0].h, t3[0].g); n2 < o2; n2++)
                i3.J(t3[n2], r2, i3);
            return i3;
          }, ge2.prototype.resizeToCenter = ge2.prototype.da = function(e2, t3) {
            var r2 = this.f, i3 = this.i, n2 = this.g, o2 = this.h, a3 = this.F().lng;
            pe2(e2, this.da, 0);
            var s2 = e2.lat - o2 - (i3 - o2) / 2, l2 = e2.lng - a3;
            return e2 = (e2 = r2 + ((l2 = 180 < l2 || l2 < -180 ? -(a3 + e2.lng) : l2) < 0 ? 2 * l2 : 0)) < -180 ? 360 + e2 : e2, n2 = 180 < (n2 += 0 < l2 ? 2 * l2 : 0) ? n2 - 360 : n2, 90 <= (i3 = 0 < s2 ? i3 + 2 * s2 : i3) && (i3 = 90), (o2 = s2 < 0 ? o2 + 2 * s2 : o2) <= -90 && (o2 = -90), t3 ? me2(t3, i3, e2, o2, n2) : new ge2(i3, e2, o2, n2);
          }, ge2.prototype.l = "Polygon", ge2.prototype.u = function() {
            return [[this.f, this.i, 0], [this.g, this.i, 0], [this.g, this.h, 0], [this.f, this.h, 0], [this.f, this.i, 0]];
          }, ge2.prototype.U = function() {
            return this.j();
          }, ge2.prototype.j = function() {
            return [this.i, this.f, this.h, this.g];
          }, Te2.prototype.remove = function(e2) {
            var t3, r2, i3, n2, o2, a3, s2 = false;
            if (e2 && (t3 = e2.a) && t3.b === this && (r2 = t3.entries) && 0 <= (i3 = r2.indexOf(e2))) {
              for (r2.splice(i3, 1), r2 = this.a; t3; ) {
                (n2 = t3.entries) && n2.length || (n2 && delete t3.entries, t3.a || !(o2 = t3.c)) ? t3 = K2 : ((i3 = o2)[a3 = (s2 = t3).j] === s2 && (delete i3[a3], delete s2.c, --i3.a), r2 === t3 && (r2 = o2), t3 = o2);
              }
              this.a !== r2 && (this.a = r2, Ee2(this)), Ae2(this, e2, false), s2 = true;
            }
            return s2;
          }, Te2.prototype.flush = function() {
            var e2 = new Se2(null, NaN, this.j - this.m, this.l - this.u, this.j + this.m, this.l + this.u);
            (e2.b = this).a = this.b = e2, this.c = null;
          }, Te2.prototype.o = function(e2, t3, r2, i3, n2, o2) {
            var a3 = [], s2 = this.a, l2 = this.b;
            return e2 <= s2[5] && t3 <= s2[6] && (n2 ? r2 >= s2[7] : r2 > s2[7]) && (o2 ? i3 >= s2[4] : i3 > s2[4]) && function e3(t4, r3, i4, n3, o3, a4, s3, l3, u3) {
              var c3, h2 = r3.entries, f3 = r3[7], d2 = r3[4], _2 = r3[5], p3 = r3[6], g2 = r3[8], m2 = r3[9];
              if (h2) {
                var y2 = h2.length;
                if (d2 < o3 || f3 < n3 || s3 < p3 || a4 < _2)
                  for (; y2--; ) {
                    f3 = h2[y2], d2 = f3[3], _2 = f3[0], p3 = f3[1];
                    var v2 = f3[2];
                    o3 <= v2 && n3 <= p3 && (_2 < s3 || l3 && _2 == s3) && (d2 < a4 || u3 && d2 == a4) && i4.push(f3);
                  }
                else
                  for (; y2--; )
                    i4.push(h2[y2]);
              }
              (g2 < a4 || u3 && a4 == g2) && (o3 < m2 && (c3 = r3[1]) && e3(t4, c3, i4, n3, o3, a4, s3, l3, u3), (m2 < s3 || l3 && s3 == m2) && (c3 = r3[3]) && e3(t4, c3, i4, n3, o3, a4, s3, l3, u3));
              n3 < g2 && (o3 < m2 && (c3 = r3[0]) && e3(t4, c3, i4, n3, o3, a4, s3, l3, u3), (m2 < s3 || l3 && s3 == m2) && (c3 = r3[2]) && e3(t4, c3, i4, n3, o3, a4, s3, l3, u3));
            }(this, s2, a3, e2, t3, r2, i3, o2 || i3 >= l2[6], n2 || r2 >= l2[5]), a3;
          };
          var we2 = 0;
          function Se2(e2, t3, r2, i3, n2, o2) {
            this.j = t3, e2 && (this.c = e2, this.b = e2.b, n2 = 1 & t3 ? (r2 = e2[8], e2[5]) : (r2 = e2[7], e2[8]), o2 = 2 & t3 ? (i3 = e2[9], e2[6]) : (i3 = e2[4], e2[9])), this[7] = r2, this[5] = n2, this[8] = (r2 + n2) / 2, this[4] = i3, this[6] = o2, this[9] = (i3 + o2) / 2;
          }
          function ke2(e2, t3, r2, i3, n2, o2) {
            ke2.ua.constructor.apply(this, arguments);
          }
          function Pe2(e2, t3, r2, i3, n2, o2, a3) {
            var s2, l2, u3 = t3[8], c3 = t3[9];
            return a3 && (n2 < u3 || (s2 = u3 <= r2)) && (o2 < c3 || (l2 = c3 <= i3)) ? r2 = (u3 = Pe2)(e2, t3 = t3[s2 |= l2 << 1] || (++t3.a, t3[s2] = new Se2(t3, s2)), r2, i3, n2, o2, a3 - 1) : (i3 = r2 = new Re2(r2, i3, n2, o2), (t3.entries || (t3.entries = [])).push(i3), i3.a = t3, Ae2(e2, r2, true), Ee2(e2, t3)), r2;
          }
          function Re2(e2, t3, r2, i3) {
            this.id = we2++, this[0] = t3, this[1] = r2, this[2] = i3, this[3] = e2;
          }
          function Me2(e2) {
            this.l = new ke2(+e2 || 10, 180, 90, 0, 0, true), this.j = [], this.m = false, this.a = this.b = this.c = null;
          }
          function Le2(e2, t3, r2, i3, n2, o2) {
            if (o2)
              o2 = new Re2(n2, -t3, r2 + 360, -i3), e2.j.push(o2), e2.m = true, e2.a && e2.a.C(t3, r2, i3, n2, true, e2.a);
            else {
              var a3 = -t3, s2 = -i3, l2 = (o2 = e2.l).b, u3 = l2[5], c3 = l2[6];
              if (!(l2[7] <= r2 && l2[4] <= a3 && (n2 < u3 || u3 === n2 && u3 === l2.b.b[5]) && (s2 < c3 || c3 === s2 && c3 === l2.b.b[6])))
                throw Error("Coordinates out of bounds");
              o2 = Pe2(o2, o2.b, r2, a3, n2, s2, o2.sa), e2.b && e2.b.C(t3, r2, i3, n2, true, e2.b);
            }
            return e2.c = null, o2;
          }
          function Oe2(e2, t3, r2, i3, n2, o2, a3) {
            var s2 = (e2 = e2.j).length, l2 = [];
            if (s2)
              for (var u3 = r2 + 360, c3 = n2 + 360; s2--; ) {
                var h2 = e2[s2];
                (Ce2(h2, t3, r2, i3, n2, o2, a3) || Ce2(h2, t3, u3, i3, c3, o2, a3)) && l2.push(h2);
              }
            return l2;
          }
          function Ce2(e2, t3, r2, i3, n2, o2, a3) {
            var s2 = e2[3], l2 = e2[0], u3 = e2[1];
            return e2 = e2[2], (o2 ? l2 <= i3 : l2 < i3) && (a3 ? s2 <= n2 : s2 < n2) && t3 <= e2 && r2 <= u3;
          }
          function Ne2(e2, t3) {
            var r2, i3;
            if (r2 = t3.length) {
              for (var n2 = e2.length, o2 = {}; n2--; )
                o2[e2[n2].id] = 1;
              for (; r2--; )
                (i3 = t3[r2]).id in o2 || e2.push(i3);
            }
          }
          function Ie2() {
          }
          function Be2(e2, t3, r2) {
            if (this.l = [], t3 && this.K(t3), r2 && !u2(r2))
              throw new ue2(Be2, 2, r2);
            this.b = 0, this.m = r2, this.a = {}, this.j = this.c = null, this.Z(e2);
          }
          function ze2(e2, t3) {
            return t3 && (e2.c = Fe2(e2, t3, e2.c)), t3;
          }
          function Ue2(e2) {
            for (; e2.b > e2.u && e2.j; )
              Ge2(e2, e2.j, true);
          }
          function Fe2(e2, t3, r2) {
            return r2 !== t3 && ((t3.H || t3.v) && Ge2(e2, t3, false), (t3.H = r2) && (t3.v = r2.v, r2.v = t3), t3.v || (e2.c = t3), t3.H || (e2.j = t3), e2.b += t3.size), t3;
          }
          function Ge2(e2, t3, r2) {
            var i3 = t3.v, n2 = t3.H;
            (i3 || n2 || t3 == e2.c && t3 == e2.j) && (i3 ? i3.H = n2 : e2.c = n2, n2 ? n2.v = i3 : e2.j = i3, e2.b -= t3.size, r2 && (delete e2.a[t3.id], De2(e2, t3))), t3.H = t3.v = null;
          }
          function De2(e2, t3) {
            for (var r2 = e2.l.length; r2--; )
              e2.l[r2].call(e2, t3.id, t3.data, t3.size);
          }
          Se2.prototype.a = 0, h(ke2, Te2), l("H.geo.QuadTree", Me2), Me2.prototype.N = function() {
            return this.m;
          }, Me2.prototype.D = function() {
            var e2;
            if (!this.c) {
              var t3, r2, i3 = [];
              if ((a3 = !this.b) && (s2 = (o2 = this.l).c, o2.I && !s2 && ((a3 = o2.a).entries || a3[0] || a3[1] || a3[2] || a3[3]) && (s2 = function e3(t4, r3) {
                for (var i4, n3, o3 = 0, a4 = 3; 0 <= a4; a4--) {
                  for (var s3 = a4 + 4, l3 = 0 < a4 % 3, u3 = [], c3 = r3[a4], h2 = t4[a4], f3 = h2.length; f3--; ) {
                    var d2 = h2[f3];
                    if (i4 = d2.entries)
                      for (n3 = i4.length; n3--; ) {
                        var _2 = i4[n3][a4];
                        (l3 ? c3 < _2 : _2 < c3) && (c3 = _2);
                      }
                    for (n3 = 4; n3--; )
                      (i4 = d2[n3]) && (l3 ? i4[s3] > c3 : i4[s3] < c3) && u3.push(i4);
                  }
                  o3 += u3.length, r3[a4] = c3, t4[a4] = u3;
                }
                return o3 && (r3 = e3(t4, r3)), r3;
              }([s2 = [a3], s2, s2, s2], [a3[6], a3[7], a3[4], a3[5]]), o2.c = s2), a3 = o2 = s2), a3 && (this.b = new ge2(-o2[0], o2[3], -o2[2], o2[1])), (e2 = this.b) && i3.push(e2), !this.a && (r2 = (t3 = this.j).length)) {
                for (a3 = 360, s2 = -(o2 = 90), l2 = 0; r2--; )
                  var n2 = t3[r2], o2 = d(o2, n2[0]), a3 = d(a3, n2[3]), s2 = _(s2, n2[2]), l2 = _(l2, n2[1]);
                this.a = new ge2(-o2, a3, -s2, l2 - 360);
              }
              (e2 = this.a) && i3.push(e2), (e2 = i3[0]) && (i3[1] && (e2 = e2.J(i3[1], true)), this.c = e2);
            }
            return this.c;
          }, Me2.prototype.insertBoundingBox = Me2.prototype.oa = function(e2) {
            var t3 = e2.W(), r2 = e2.V();
            return (e2 = e2.N()) ? Le2(this, t3.lat, r2.lng, r2.lat, t3.lng, e2) : Le2(this, t3.lat, t3.lng, r2.lat, r2.lng, e2);
          }, Me2.prototype.remove = function(e2) {
            var t3, r2;
            return e2.a ? (r2 = this.l.remove(e2), this.b = null) : (r2 = 0 <= (e2 = (t3 = this.j).indexOf(e2))) && (t3.splice(e2, 1), this.m = 0 < t3.length, this.a = null), r2 && (this.c = null), r2;
          }, Me2.prototype.intersectBoundingBox = Me2.prototype.pa = function(e2, t3, r2) {
            var i3 = this.l, n2 = e2.W(), o2 = e2.V(), a3 = -n2.lat, n2 = n2.lng, s2 = -o2.lat, o2 = o2.lng;
            return !t3 && a3 == s2 || !r2 && n2 === o2 ? e2 = [] : e2.N() ? (Ne2(e2 = i3.o(-180, a3, o2, s2, r2, t3), i3.o(n2, a3, 180, s2, false, t3)), Ne2(e2, Oe2(this, a3, o2, s2, n2 + 360, t3, r2))) : Ne2(e2 = i3.o(n2, a3, o2, s2, r2, t3), Oe2(this, a3, n2, s2, o2, t3, r2)), e2;
          }, l("H.util.ICache", Ie2), Ie2.prototype.add = function() {
          }, Ie2.prototype.get = function() {
          }, Ie2.prototype.drop = Ie2.prototype.S = function() {
          }, Ie2.prototype.forEach = function() {
          }, Ie2.prototype.removeAll = Ie2.prototype.Y = function() {
          }, Ie2.prototype.registerOnDrop = Ie2.prototype.K = function() {
          }, Ie2.prototype.deRegisterOnDrop = Ie2.prototype.P = function() {
          }, l("H.util.Cache", Be2), Be2.prototype.add = function(e2, t3, r2) {
            var i3, n2;
            if (!te2(r2 = +r2) || r2 < 0)
              throw new ue2(this.add, 2, r2);
            return e2 = String(e2), (n2 = !this.m || this.m(e2, t3, r2)) && ((i3 = this.a[e2]) ? (i3.data !== t3 && De2(this, i3), this.b += r2 - i3.size, i3.size = r2, i3.data = t3, ze2(this, i3)) : this.a[e2] = Fe2(this, { id: e2, data: t3, size: r2, H: null, v: null }, this.c), Ue2(this)), n2;
          }, Be2.prototype.registerOnDrop = Be2.prototype.K = function(e2) {
            if (!u2(e2))
              throw new ue2(this.K, 0, e2);
            this.l.push(e2);
          }, Be2.prototype.deRegisterOnDrop = Be2.prototype.P = function(t3) {
            this.l = this.l.filter(function(e2) {
              return e2 !== t3;
            });
          }, Be2.prototype.get = function(e2, t3) {
            return (e2 = t3 ? this.a[e2] : ze2(this, this.a[e2])) && e2.data;
          }, Be2.prototype.drop = Be2.prototype.S = function(e2) {
            var t3;
            (t3 = this.a[e2]) && Ge2(this, t3, true);
          }, Be2.prototype.forEach = function(e2, t3, r2) {
            var i3;
            for (i3 in this.a) {
              var n2 = this.a[i3];
              r2 && !r2(i3, n2.data, n2.size) || e2.call(t3, i3, n2.data, n2.size);
            }
          }, Be2.prototype.removeAll = Be2.prototype.Y = function(e2) {
            var t3;
            for (t3 in this.a) {
              var r2 = this.a[t3];
              e2 && !e2(t3, r2.data, r2.size) || Ge2(this, this.a[t3], true);
            }
          }, Be2.prototype.setMaxSize = Be2.prototype.Z = function(e2) {
            if (!(0 < +e2))
              throw new ue2(Be2.prototype.Z, 0, e2);
            return this.u = +e2, Ue2(this), this;
          }, Be2.prototype.getMaxSize = Be2.prototype.ka = function() {
            return this.u;
          }, Be2.prototype.getCurrentSize = Be2.prototype.ia = function() {
            return this.b;
          };
        }).call(ns);
        var MathUtils$1 = MathUtils = {}, Geo;
        function _xyToArr(e) {
          return [e.x, e.y];
        }
        function _arrToXy(e) {
          return _construct(ns.H.math.Point, _toConsumableArray(e));
        }
        MathUtils.clipPolygon = function(e, t2) {
          var r, i2, n = [], o = ns.H.math.clipping.clipPolygon(e.map(_arrToXy), t2.map(_arrToXy));
          if (o)
            do {
              for (r = [], i2 = o; r.push(_xyToArr(i2)), i2 = i2.next; )
                ;
              n.push(r);
            } while (o = o.nextPoly);
          else
            MathUtils.isPointInsidePolygon(t2[0], e) ? n.push(t2) : MathUtils.isPointInsidePolygon(e[0], t2) && n.push(e);
          return n;
        }, MathUtils.isPointInsidePolygon = function(e, t2) {
          return ns.H.math.isPointInsidePolygon({ x: e[0], y: e[1] }, ns.H.math.flatten(t2));
        }, MathUtils.clamp = function(e, t2, r) {
          return (e -= 0) > r ? r : e < t2 ? t2 : e;
        }, MathUtils.splitLegs = function(e, t2) {
          var r = [];
          e.push(e[0]);
          for (var i2 = 0; i2 < e.length - 1; i2++) {
            var n, o = e[i2], a2 = e[i2 + 1];
            r.push(o), Math.abs(a2[0] - o[0]) >= t2 && (n = [(o[0] + a2[0]) / 2, (o[1] + a2[1]) / 2], r.push(n));
          }
          return r.length !== e.length - 1 ? MathUtils.splitLegs(r, t2) : r;
        }, MathUtils.getBBox = function(e) {
          var t2 = 1 / 0, r = 1 / 0, i2 = -1 / 0, n = -1 / 0;
          return e.forEach(function(e2) {
            e2[0] < t2 && (t2 = e2[0]), e2[1] < r && (r = e2[1]), e2[0] > i2 && (i2 = e2[0]), e2[1] > n && (n = e2[1]);
          }), [t2, r, i2, n];
        }, MathUtils.getBBoxCenter = function(e) {
          var t2 = _slicedToArray(e, 4), r = t2[0], i2 = t2[1];
          return [r + (t2[2] - r) / 2, i2 + (t2[3] - i2) / 2];
        }, MathUtils.getLineLength = function(e, t2, r, i2) {
          return Math.sqrt(Math.pow(e - r, 2) + Math.pow(t2 - i2, 2));
        }, MathUtils.modulo = function(e, t2) {
          var r;
          return (r = e % t2) < 0 == t2 < 0 ? r : r + t2;
        };
        var Geo$1 = Geo = {};
        Geo.default_source_max_zoom = 18, Geo.default_view_max_zoom = 20, Geo.tile_size = 256, Geo.half_circumference_meters = 20037508342789244e-9, Geo.circumference_meters = 2 * Geo.half_circumference_meters, Geo.min_zoom_meters_per_pixel = Geo.circumference_meters / Geo.tile_size;
        var meters_per_pixel = [];
        Geo.metersPerPixel = function(e) {
          return meters_per_pixel[e] = meters_per_pixel[e] || Geo.min_zoom_meters_per_pixel / Math.pow(2, e), meters_per_pixel[e];
        };
        var meters_per_tile = [];
        Geo.metersPerTile = function(e) {
          return meters_per_tile[e] = meters_per_tile[e] || Geo.circumference_meters / Math.pow(2, e), meters_per_tile[e];
        }, Geo.tile_scale = 4096, Geo.units_per_pixel = Geo.tile_scale / Geo.tile_size, Geo.height_scale = 16;
        var units_per_meter = [];
        Geo.unitsPerMeter = function(e) {
          return units_per_meter[e] = units_per_meter[e] || Geo.tile_scale / (Geo.tile_size * Geo.metersPerPixel(e)), units_per_meter[e];
        }, Geo.metersForTile = function(e) {
          return { x: e.x * Geo.circumference_meters / Math.pow(2, e.z) - Geo.half_circumference_meters, y: -(e.y * Geo.circumference_meters / Math.pow(2, e.z) - Geo.half_circumference_meters) };
        }, Geo.tileForMeters = function(e, t2) {
          var r = _slicedToArray(e, 2), i2 = r[0], n = r[1];
          return { x: Math.floor((i2 + Geo.half_circumference_meters) / (Geo.circumference_meters / Math.pow(2, t2))), y: Math.floor((-n + Geo.half_circumference_meters) / (Geo.circumference_meters / Math.pow(2, t2))), z: t2 };
        }, Geo.metersToExactTileCoords = function(e, t2) {
          var r = _slicedToArray(e, 2), i2 = r[0], n = r[1];
          return { x: Math.pow(2, t2 - 1) * (1 + i2 / Geo.half_circumference_meters), y: Math.pow(2, t2 - 1) * (1 - n / Geo.half_circumference_meters), z: t2 };
        }, Geo.wrapTile = function(e) {
          var t2 = e.x, r = e.y, i2 = e.z, n = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : { x: true, y: false }, o = (1 << i2) - 1;
          return n.x && (t2 &= o), n.y && (r &= o), { x: t2, y: r, z: i2 };
        }, Geo.wrapMeters = function(e) {
          var t2 = e.x, r = e.y;
          return { x: MathUtils$1.modulo(t2 + Geo.half_circumference_meters, Geo.circumference_meters) - Geo.half_circumference_meters, y: r };
        }, Geo.metersToLatLng = function(e) {
          var t2 = _slicedToArray(e, 2), r = t2[0], i2 = t2[1];
          return r /= Geo.half_circumference_meters, i2 /= Geo.half_circumference_meters, i2 = (2 * Math.atan(Math.exp(i2 * Math.PI)) - Math.PI / 2) / Math.PI, [r *= 180, i2 *= 180];
        }, Geo.latLngToMeters = function(e) {
          var t2 = _slicedToArray(e, 2), r = t2[0], i2 = t2[1], i2 = Math.log(Math.tan(i2 * Math.PI / 360 + Math.PI / 4)) / Math.PI;
          return i2 *= Geo.half_circumference_meters, i2 = Math.min(Math.max(i2, -Geo.half_circumference_meters), Geo.half_circumference_meters), [r *= Geo.half_circumference_meters / 180, i2];
        }, Geo.tileSpaceToMeters = function(e, t2, r) {
          var i2 = _slicedToArray(e, 2), n = i2[0], o = i2[1], a2 = Geo.unitsPerMeter(t2);
          return [n / a2 + r.x, o / a2 + r.y];
        }, Geo.tileSpaceToLatlng = function(e, t2, n) {
          var o = Geo.unitsPerMeter(t2);
          return Geo.transformGeometry(e, function(e2) {
            e2[0] = e2[0] / o + n.x, e2[1] = e2[1] / o + n.y;
            var t3 = _slicedToArray(Geo.metersToLatLng(e2), 2), r = t3[0], i2 = t3[1];
            e2[0] = r, e2[1] = i2;
          }), e;
        }, Geo.copyGeometry = function(e) {
          if (null != e) {
            var t2 = { type: e.type };
            return "Point" === e.type ? t2.coordinates = [e.coordinates[0], e.coordinates[1]] : "LineString" === e.type || "MultiPoint" === e.type ? t2.coordinates = e.coordinates.map(function(e2) {
              return [e2[0], e2[1]];
            }) : "Polygon" === e.type || "MultiLineString" === e.type ? t2.coordinates = e.coordinates.map(function(e2) {
              return e2.map(function(e3) {
                return [e3[0], e3[1]];
              });
            }) : "MultiPolygon" === e.type && (t2.coordinates = e.coordinates.map(function(e2) {
              return e2.map(function(e3) {
                return e3.map(function(e4) {
                  return [e4[0], e4[1]];
                });
              });
            })), t2;
          }
        }, Geo.transformGeometry = function(e, t2) {
          null != e && ("Point" === e.type ? t2(e.coordinates) : "LineString" === e.type || "MultiPoint" === e.type ? e.coordinates.forEach(t2) : "Polygon" === e.type || "MultiLineString" === e.type ? e.coordinates.forEach(function(e2) {
            return e2.forEach(t2);
          }) : "MultiPolygon" === e.type && e.coordinates.forEach(function(e2) {
            e2.forEach(function(e3) {
              return e3.forEach(t2);
            });
          }));
        }, Geo.boxIntersect = function(e, t2) {
          return !(t2.sw.x > e.ne.x || t2.ne.x < e.sw.x || t2.sw.y > e.ne.y || t2.ne.y < e.sw.y);
        }, Geo.findBoundingBox = function(e) {
          for (var t2 = 1 / 0, r = -1 / 0, i2 = 1 / 0, n = -1 / 0, o = e[0].length, a2 = 0; a2 < o; a2++) {
            var s = e[0][a2];
            s[0] < t2 && (t2 = s[0]), s[1] < i2 && (i2 = s[1]), s[0] > r && (r = s[0]), s[1] > n && (n = s[1]);
          }
          return [t2, i2, r, n];
        }, Geo.geometryType = function(e) {
          return "Polygon" === e || "MultiPolygon" === e ? "polygon" : "LineString" === e || "MultiLineString" === e ? "line" : "Point" === e || "MultiPoint" === e ? "point" : void 0;
        }, Geo.centroid = function(e) {
          var t2 = !(1 < arguments.length && void 0 !== arguments[1]) || arguments[1];
          if (e && 0 !== e.length) {
            var r, i2 = 0, n = 0, o = 0, a2 = e[0], s = a2.length;
            t2 && (r = a2[0], a2 = a2.map(function(e2) {
              return [e2[0] - r[0], e2[1] - r[1]];
            }));
            for (var l = 0, u2 = s - 1; l < s; u2 = l, l++) {
              var c2 = a2[l], h = a2[u2], f2 = c2[1] * h[0] - h[1] * c2[0];
              i2 += (c2[0] + h[0]) * f2, n += (c2[1] + h[1]) * f2, o += 3 * f2;
            }
            var d = [i2 / o, n / o];
            return t2 && (d[0] += r[0], d[1] += r[1]), d;
          }
        }, Geo.multiCentroid = function(e) {
          for (var t2 = e.length, r = [0, 0], i2 = 0; i2 < e.length; i2++) {
            var n = Geo.centroid(e[i2]);
            r[0] += n[0], r[1] += n[1];
          }
          return r[0] /= t2, r[1] /= t2, r;
        }, Geo.signedPolygonRingAreaSum = function(e) {
          for (var t2 = 0, r = e.length, i2 = 0; i2 < r - 1; i2++) {
            var n = e[i2], o = e[i2 + 1];
            t2 += n[0] * o[1] - o[0] * n[1];
          }
          return t2 += e[r - 1][0] * e[0][1] - e[0][0] * e[r - 1][1];
        }, Geo.polygonRingArea = function(e) {
          return Math.abs(Geo.signedPolygonRingAreaSum(e)) / 2;
        }, Geo.polygonArea = function(e) {
          if (e)
            return Geo.polygonRingArea(e[0]);
        }, Geo.multiPolygonArea = function(e) {
          for (var t2 = 0, r = 0; r < e.length; r++)
            t2 += Geo.polygonArea(e[r]);
          return t2;
        }, Geo.ringWinding = function(e) {
          var t2 = Geo.signedPolygonRingAreaSum(e);
          return 0 < t2 ? "CW" : t2 < 0 ? "CCW" : void 0;
        }, Geo.getTileBoundingBox = function(e, t2) {
          var r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : 0, i2 = Geo.wrapTile(e, { x: true }), n = Geo.metersForTile(i2), o = Geo.metersPerPixel(i2.z), a2 = Geo.metersToLatLng([n.x - r * o, n.y + r * o]), s = Geo.metersToLatLng([n.x + (t2 + r) * o, n.y - (t2 + r) * o]), l = Geo.isLastTile(i2);
          return new ns.H.geo.Rect(0 === e.y ? 90 : MathUtils$1.clamp(a2[1], -90, 90), MathUtils$1.clamp(a2[0], -180, 180), l.row ? -90 : MathUtils$1.clamp(s[1], -90, 90), l.column ? 180 : MathUtils$1.clamp(s[0], -180, 180));
        }, Geo.isLastTile = function(e) {
          var t2 = e.x, r = e.y, i2 = e.z;
          return { row: r === Math.pow(2, i2) - 1, column: t2 === Math.pow(2, i2) - 1 };
        };
        var MethodNotImplemented = function() {
          _inherits(i2, _wrapNativeSuper(Error));
          var r = _createSuper(i2);
          function i2(e) {
            var t2;
            return _classCallCheck(this, i2), (t2 = r.call(this)).name = "MethodNotImplemented", t2.message = "Method " + e + " must be implemented in subclass", t2;
          }
          return i2;
        }(), is_worker = false, is_main = false, force_main, force_worker;
        try {
          window.document !== HTMLDocument && (is_main = true);
        } catch (e) {
          void 0 !== self && (is_worker = true, self.window = { document: {} }, self.document = self.window.document);
        }
        var Thread = { get is_fake_worker() {
          return self.is_fake_worker;
        }, get is_worker() {
          return void 0 !== force_worker ? force_worker : is_worker || self.is_fake_worker;
        }, set is_worker(e) {
          force_worker = e;
        }, get is_main() {
          return void 0 !== force_main ? force_main : is_main && !self.is_fake_worker;
        }, set is_main(e) {
          force_main = e;
        }, is_native_worker: is_worker }, WorkerBroker = {}, message_id = 0, messages = {}, targets = {}, main_worker_targets = {};
        function findTarget(e, t2) {
          var r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : targets, i2 = [];
          if ("string" == typeof e && (e = (i2 = e.split(".")).pop()), Thread.is_main && t2 && 1 === i2.length && "self" === i2[0])
            r = t2;
          else
            for (var n = 0; n < i2.length; n++) {
              if (!r[i2[n]])
                return [];
              r = r[i2[n]];
            }
          return [e, r];
        }
        WorkerBroker.addTarget = function(e, t2) {
          Thread.is_fake_worker ? main_worker_targets[e] = t2 : targets[e] = t2;
        }, WorkerBroker.removeTarget = function(e) {
          delete targets[e], delete main_worker_targets[e];
        };
        var ERROR_NO_TARGET = " No object with that name is registered on main thread.", ERROR_NO_METHOD = " Object has no method with that name.", ERROR_NOT_SET = "_worker_broker_error_not_set_";
        function setupMainThread() {
          WorkerBroker.postMessage = function(e, r) {
            for (var t2 = arguments.length, i2 = new Array(2 < t2 ? t2 - 2 : 0), n = 2; n < t2; n++)
              i2[n - 2] = arguments[n];
            if (Array.isArray(e))
              return Promise.all(e.map(function(e2) {
                return WorkerBroker.postMessage.apply(WorkerBroker, [e2, r].concat(_toConsumableArray(i2)));
              }));
            var o, a2 = {};
            "object" === _typeof(r) && (r = (a2 = r).method);
            var s = "main_send";
            "string" == typeof e ? (r = e, i2 = Array.prototype.slice.call(arguments, 1), o = true, s = "worker_send") : e.init && (o = true);
            var l, u2 = [];
            if (i2 && 1 === i2.length && i2[0] instanceof WorkerBroker.withTransferables && (u2 = i2[0].transferables, i2 = i2[0].value), l = { type: s, message_id: ++message_id, method: r, message: i2 }, o)
              return function(i3, e2) {
                var t3 = i3.type, r2 = _slicedToArray(findTarget(i3.method, e2, "main_send" === t3 ? main_worker_targets : targets), 2), n2 = r2[0], o2 = r2[1], a3 = "Worker broker could not dispatch message type ".concat(i3.method, " on target ").concat(i3.target, ".");
                if (!o2)
                  throw Error(a3 + ERROR_NO_TARGET);
                var s2 = "function" == typeof o2[n2] && o2[n2];
                if (!s2)
                  throw Error(a3 + ERROR_NO_METHOD);
                return new Promise(function(t4, r3) {
                  var e3;
                  try {
                    e3 = s2.apply(o2, i3.message);
                  } catch (e4) {
                    return void r3(e4);
                  }
                  e3 instanceof Promise ? e3.then(function(e4) {
                    e4 instanceof WorkerBroker.withTransferables && (e4 = e4.value[0]), t4(e4);
                  }, function(e4) {
                    r3(e4 instanceof Error ? "".concat(e4.message, ": ").concat(e4.stack) : e4);
                  }) : (e3 instanceof WorkerBroker.withTransferables && (e3 = e3.value[0]), t4(e3));
                });
              }(l, e && e.init ? e : void 0);
            var c2 = new Promise(function(e2, t3) {
              messages[message_id] = { method: r, message: i2, resolve: e2, reject: t3 };
            });
            return a2.stringify && (l = JSON.stringify(l)), e.postMessage(l, u2.map(function(e2) {
              return e2.object;
            })), freeTransferables(u2), c2;
          }, WorkerBroker.addWorker = function(f2) {
            if (!(f2 instanceof Worker))
              throw Error("Worker broker could not add non-Worker object", f2);
            f2.addEventListener("message", function(e) {
              var t2 = "string" == typeof e.data ? JSON.parse(e.data) : e.data, r = t2.message_id;
              if ("worker_reply" === t2.type)
                messages[r] && (t2.error ? messages[r].reject(t2.error) : messages[r].resolve(t2.message), delete messages[r]);
              else if ("worker_send" === t2.type && null != r) {
                var i2 = _slicedToArray(findTarget(t2.method), 2), n = i2[0], o = i2[1], a2 = "Worker broker could not dispatch message type ".concat(t2.method, " on target ").concat(t2.target, ".");
                if (!o)
                  throw Error(a2 + ERROR_NO_TARGET);
                var s = "function" == typeof o[n] && o[n];
                if (!s)
                  throw Error(a2 + ERROR_NO_METHOD);
                var l, u2 = ERROR_NOT_SET;
                try {
                  l = s.apply(o, t2.message);
                } catch (e2) {
                  u2 = e2;
                }
                var c2, h = [];
                l && "function" == typeof l.then ? l.then(function(e2) {
                  e2 instanceof WorkerBroker.withTransferables && (h = e2.transferables, e2 = e2.value[0]), c2 = { type: "main_reply", message_id: r, message: e2 }, f2.postMessage(c2, h.map(function(e3) {
                    return e3.object;
                  })), freeTransferables(h);
                }, function(e2) {
                  f2.postMessage({ type: "main_reply", message_id: r, error: e2 instanceof Error ? "".concat(e2.message, ": ").concat(e2.stack) : e2 });
                }) : (l instanceof WorkerBroker.withTransferables && (h = l.transferables, l = l.value[0]), c2 = { type: "main_reply", message_id: r, message: l, error: u2 instanceof Error ? "".concat(u2.message, ": ").concat(u2.stack) : u2 }, f2.postMessage(c2, h.map(function(e2) {
                  return e2.object;
                })), freeTransferables(h));
              }
            });
          }, WorkerBroker.getMessages = function() {
            return messages;
          }, WorkerBroker.getMessageId = function() {
            return message_id;
          };
        }
        function setupWorkerThread() {
          WorkerBroker.postMessage = function(r) {
            for (var e = arguments.length, i2 = new Array(1 < e ? e - 1 : 0), t2 = 1; t2 < e; t2++)
              i2[t2 - 1] = arguments[t2];
            var n = {};
            "object" === _typeof(r) && (r = (n = r).method);
            var o, a2 = new Promise(function(e2, t3) {
              messages[message_id] = { method: r, message: i2, resolve: e2, reject: t3 };
            }), s = [];
            return i2 && 1 === i2.length && i2[0] instanceof WorkerBroker.withTransferables && (s = i2[0].transferables, i2 = i2[0].value), o = { type: "worker_send", message_id, method: r, message: i2 }, n.stringify && (o = JSON.stringify(o)), self.postMessage(o, s.map(function(e2) {
              return e2.object;
            })), freeTransferables(s), message_id++, a2;
          }, self.addEventListener("message", function(e) {
            var t2 = "string" == typeof e.data ? JSON.parse(e.data) : e.data, r = t2.message_id;
            if ("main_reply" === t2.type)
              messages[r] && (t2.hasOwnProperty("error") && t2.error !== ERROR_NOT_SET ? messages[r].reject(t2.error) : messages[r].resolve(t2.message), delete messages[r]);
            else if ("main_send" === t2.type && null != r) {
              var i2 = _slicedToArray(findTarget(t2.method), 2), n = i2[0], o = i2[1], a2 = "Worker broker could not dispatch message type ".concat(t2.method, " on target ").concat(t2.target, ".");
              if (!o)
                throw Error(a2 + ERROR_NO_TARGET);
              var s, l, u2 = "function" == typeof o[n] && o[n];
              if (!u2)
                throw Error(a2 + ERROR_NO_METHOD);
              try {
                s = u2.apply(o, t2.message);
              } catch (e2) {
                l = e2;
              }
              var c2, h = [];
              s instanceof Promise ? s.then(function(e2) {
                e2 instanceof WorkerBroker.withTransferables && (h = e2.transferables, e2 = e2.value[0]), c2 = { type: "worker_reply", message_id: r, message: e2 }, self.postMessage(c2, h.map(function(e3) {
                  return e3.object;
                })), freeTransferables(h);
              }, function(e2) {
                self.postMessage({ type: "worker_reply", message_id: r, error: e2 instanceof Error ? "".concat(e2.message, ": ").concat(e2.stack) : e2 });
              }) : (s instanceof WorkerBroker.withTransferables && (h = s.transferables, s = s.value[0]), c2 = { type: "worker_reply", message_id: r, message: s, error: l instanceof Error ? "".concat(l.message, ": ").concat(l.stack) : l }, self.postMessage(c2, h.map(function(e2) {
                return e2.object;
              })), freeTransferables(h));
            }
          });
        }
        function findTransferables(r) {
          var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : null, t2 = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null, i2 = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : [];
          if (!r)
            return i2;
          if (Array.isArray(r))
            r.forEach(function(e2, t3) {
              return findTransferables(e2, r, t3, i2);
            });
          else if ("object" === _typeof(r))
            if (r instanceof ArrayBuffer)
              i2.push({ object: r, parent: e, property: t2 });
            else if (r.buffer instanceof ArrayBuffer)
              i2.push({ object: r.buffer, parent: e, property: t2 });
            else
              for (var n in r)
                findTransferables(r[n], r, n, i2);
          return i2;
        }
        function freeTransferables(e) {
          Array.isArray(e) && e.filter(function(e2) {
            return e2.parent && e2.property;
          }).forEach(function(e2) {
            return delete e2.parent[e2.property];
          });
        }
        WorkerBroker.withTransferables = function() {
          for (var e = arguments.length, t2 = new Array(e), r = 0; r < e; r++)
            t2[r] = arguments[r];
          if (!(this instanceof WorkerBroker.withTransferables))
            return _construct(WorkerBroker.withTransferables, t2);
          this.value = t2, this.transferables = findTransferables(this.value);
        }, Thread.is_main && setupMainThread(), Thread.is_worker && setupWorkerThread();
        var LEVELS = { silent: -1, error: 0, warn: 1, info: 2, debug: 3, trace: 4 }, methods = {}, logged_once = {}, Utils;
        function methodForLevel(e) {
          return methods[e] = methods[e] || (console[e] ? console[e] : console.log).bind(console), methods[e];
        }
        function log(e) {
          var t2 = "object" === _typeof(e) ? e.level : e;
          if (LEVELS[t2] <= LEVELS[log.level]) {
            for (var r = arguments.length, i2 = new Array(1 < r ? r - 1 : 0), n = 1; n < r; n++)
              i2[n - 1] = arguments[n];
            if (Thread.is_native_worker)
              WorkerBroker.postMessage.apply(WorkerBroker, [{ method: "_logProxy", stringify: true }, e].concat(i2));
            else {
              if ("object" === _typeof(e) && true === e.once) {
                if (logged_once[JSON.stringify(i2)])
                  return;
                logged_once[JSON.stringify(i2)] = true;
              }
              var o = methodForLevel(t2);
              1 < i2.length ? o.apply(void 0, ["Tangram [".concat(t2, "]: ").concat(i2[0])].concat(_toConsumableArray(i2.slice(1)))) : o("Tangram [".concat(t2, "]: ").concat(i2[0]));
            }
          }
        }
        function debounce(i2, n, o) {
          var a2, s;
          return o = o || 0, function() {
            var e = this, t2 = arguments;
            function r() {
              s = 0, i2.apply(e, t2);
            }
            clearTimeout(a2), s && o && Date.now() - s >= o ? r() : (s = s || Date.now(), a2 = setTimeout(function() {
              r();
            }, n));
          };
        }
        log.level = "info", log.workers = null, log.setLevel = function(e) {
          log.level = e, Thread.is_main && Array.isArray(log.workers) && WorkerBroker.postMessage(log.workers, "_logSetLevelProxy", e);
        }, Thread.is_main && (log.setWorkers = function(e) {
          log.workers = e;
        }, log.reset = function() {
          logged_once = {};
        }), WorkerBroker.addTarget("_logProxy", log), WorkerBroker.addTarget("_logSetLevelProxy", log.setLevel);
        var Utils$1 = Utils = {};
        WorkerBroker.addTarget("Utils", Utils), Utils.isSafari = function() {
          return /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
        }, Utils.isMicrosoft = function() {
          return /(Trident\/7.0|Edge[ /](\d+[\.\d]+))/i.test(navigator.userAgent);
        }, Utils._requests = {}, Utils._proxy_requests = {}, Utils.io = function(r) {
          var i2 = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 6e4, n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : "text", o = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : "GET", e = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : {}, t2 = 5 < arguments.length && void 0 !== arguments[5] ? arguments[5] : null, a2 = 6 < arguments.length && void 0 !== arguments[6] && arguments[6];
          if (Thread.is_worker && Utils.isMicrosoft())
            return log("debug", "Proxying request for URL to worker", r), t2 && (Utils._proxy_requests[t2] = true), WorkerBroker.postMessage("Utils.io", r, i2, n, o, e, t2, true);
          var s = new XMLHttpRequest(), l = (l = new Promise(function(e2, t3) {
            s.open(o, r, true), s.timeout = i2, s.responseType = n, s.onload = function() {
              200 === s.status ? -1 < ["text", "json"].indexOf(s.responseType) ? e2(s.responseText) : e2(s.response) : t3(Error("Request error with a status of " + s.statusText));
            }, s.onerror = function(e3) {
              t3(Error("There was a network error" + e3.toString()));
            }, s.ontimeout = function(e3) {
              t3(Error("timeout " + e3.toString()));
            }, s.send();
          })).then(function(e2) {
            return t2 && delete Utils._requests[t2], a2 ? WorkerBroker.withTransferables(e2) : e2;
          });
          return t2 && (Utils._requests[t2] = s), l;
        }, Utils.cancelRequest = function(e) {
          if (Thread.is_worker && Utils._proxy_requests[e])
            return WorkerBroker.postMessage("Utils.cancelRequest", e);
          Utils._requests[e] ? (log("trace", "Cancelling network request key '".concat(e, "'")), Utils._requests[e].abort(), delete Utils._requests[e]) : log("trace", "Could not find network request key '".concat(e, "'"));
        }, Utils.requestAnimationFramePolyfill = function() {
          "function" != typeof window.requestAnimationFrame && (window.requestAnimationFrame = window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function(e) {
            setTimeout(e, 1e3 / 60);
          });
        }, Utils.serializeWithFunctions = function(e) {
          return "function" == typeof e ? e.toString() : JSON.stringify(e, function(e2, t2) {
            return "function" == typeof t2 ? t2.toString() : t2;
          });
        }, Utils.stringsToFunctions = function(e, t2) {
          if ("string" == typeof e)
            e = Utils.stringToFunction(e, t2);
          else if (null != e && "object" === _typeof(e))
            for (var r in e)
              e[r] = Utils.stringsToFunctions(e[r], t2);
          return e;
        }, Utils._use_count = 0, Utils._function_cache = {};
        var _clear_function_cache = debounce(function() {
          log("trace", "Cleared cached ".concat(Object.keys(Utils._function_cache).length, " functions (reused ").concat(Utils._use_count, " times)")), Utils._use_count = 0, Utils._function_cache = {};
        }, 1e4), FUNCTION_MATCH_RGX = /^\s*function[^(]*\(([^)]*)\)\s*?\{([\s\S]*)\}$/m, _createObjectURL, _revokeObjectURL;
        function addBaseURL(e, t2) {
          if (!e || !isRelativeURL(e))
            return e;
          var r, i2 = "/" !== e[0];
          return t2 ? (r = document.createElement("a")).href = t2 : r = window.location, e = i2 ? pathForURL(r.href) + e : (r.origin || r.protocol + "//" + r.host) + e;
        }
        function pathForURL(e) {
          if ("string" != typeof e || -1 !== e.search(/^(data|blob):/))
            return "";
          var t2 = e.indexOf("?");
          -1 < t2 && (e = e.substr(0, t2));
          var r = e.indexOf("#");
          return -1 < r && (e = e.substr(0, r)), e.substr(0, e.lastIndexOf("/") + 1) || "";
        }
        function extensionForURL(e) {
          var t2 = (e = e.split("/").pop()).lastIndexOf(".");
          if (-1 < t2)
            return e.substring(t2 + 1);
        }
        function isRelativeURL(e) {
          return "string" == typeof e && !(-1 < e.search(/^(http|https|data|blob):/) || "//" === e.substr(0, 2));
        }
        function addParamsToURL(e, t2) {
          if (!t2 || 0 === Object.keys(t2).length)
            return [e, []];
          var r = e.indexOf("?"), i2 = e.indexOf("#"), n = "";
          -1 < i2 && (n = e.slice(i2), e = e.slice(0, i2)), -1 === r && (r = e.length, e += "?"), r++;
          var o = "", a2 = [];
          for (var s in t2)
            "" === getURLParameter(s, e) ? o += "".concat(s, "=").concat(t2[s], "&") : a2.push([s, t2[s]]);
          return [e = e.slice(0, r) + o + e.slice(r) + n, a2];
        }
        function createObjectURL(e) {
          return void 0 === _createObjectURL && "function" != typeof (_createObjectURL = window.URL && window.URL.createObjectURL || window.webkitURL && window.webkitURL.createObjectURL) && (_createObjectURL = null, log("warn", "window.URL.createObjectURL (or vendor prefix) not found, unable to create local blob URLs")), _createObjectURL ? _createObjectURL(e) : e;
        }
        function revokeObjectURL(e) {
          return void 0 === _revokeObjectURL && "function" != typeof (_revokeObjectURL = window.URL && window.URL.revokeObjectURL || window.webkitURL && window.webkitURL.revokeObjectURL) && (_revokeObjectURL = null, log("warn", "window.URL.revokeObjectURL (or vendor prefix) not found, unable to create local blob URLs")), _revokeObjectURL ? _revokeObjectURL(e) : e;
        }
        function getURLParameter(e, t2) {
          e = e.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
          var r = new RegExp("[\\?&]" + e + "=([^&#]*)").exec(t2);
          return null === r ? "" : decodeURIComponent(r[1].replace(/\+/g, " "));
        }
        Utils.stringToFunction = function(t2, e) {
          var r = t2;
          e && (r += e.toString());
          var i2 = Utils._function_cache[r];
          if (_clear_function_cache(), i2)
            return Utils._use_count++, i2;
          var n = "string" == typeof t2 && t2.match(FUNCTION_MATCH_RGX);
          if (n && 2 < n.length)
            try {
              var o = n[2], a2 = 0 < (a2 = 0 < n[1].length && n[1].split(",").map(function(e2) {
                return e2.trim();
              }).filter(function(e2) {
                return e2;
              })).length ? a2 : ["context"], s = new Function(a2.toString(), "function" == typeof e ? e(o) : o);
              return Utils._function_cache[r] = s;
            } catch (e2) {
              return t2;
            }
          return t2;
        }, Utils.device_pixel_ratio = 1, Utils.isPowerOf2 = function(e) {
          return 0 == (e & e - 1);
        }, Utils.interpolate = function(e, t2, r) {
          if (!Array.isArray(t2) || !Array.isArray(t2[0]))
            return t2;
          if (t2.length < 1)
            return t2;
          var i2, n, o, a2, s;
          if (e <= t2[0][0])
            a2 = t2[0][1], "function" == typeof r && (a2 = r(a2));
          else if (e >= t2[t2.length - 1][0])
            a2 = t2[t2.length - 1][1], "function" == typeof r && (a2 = r(a2));
          else
            for (var l = 0; l < t2.length - 1; l++)
              if (e >= t2[l][0] && e < t2[l + 1][0]) {
                if (i2 = t2[l][0], n = t2[l + 1][0], Array.isArray(t2[l][1])) {
                  a2 = [];
                  for (var u2 = 0; u2 < t2[l][1].length; u2++)
                    "function" == typeof r ? (s = r(t2[l][1][u2]), o = r(t2[l + 1][1][u2]) - s, a2[u2] = o * (e - i2) / (n - i2) + s) : (o = t2[l + 1][1][u2] - t2[l][1][u2], a2[u2] = o * (e - i2) / (n - i2) + t2[l][1][u2]);
                } else
                  a2 = "function" == typeof r ? (s = r(t2[l][1]), (o = r(t2[l + 1][1]) - s) * (e - i2) / (n - i2) + s) : (o = t2[l + 1][1] - t2[l][1]) * (e - i2) / (n - i2) + t2[l][1];
                break;
              }
          return a2;
        }, Utils.toCSSColor = function(e) {
          return 1 === e[3] ? "rgb(".concat(e.slice(0, 3).map(function(e2) {
            return Math.round(255 * e2);
          }).join(", "), ")") : "rgba(".concat(e.map(function(e2, t2) {
            return t2 < 3 && Math.round(255 * e2) || e2;
          }).join(", "), ")");
        }, Utils.pointInTile = function(e) {
          return 0 <= e[0] && e[1] > -Geo$1.tile_scale && e[0] < Geo$1.tile_scale && e[1] <= 0;
        }, Utils.zoomToTileLevel = function(e) {
          return Math.floor(e);
        };
        var DataSource = function() {
          function u2(e, t2) {
            var r = this;
            if (_classCallCheck(this, u2), this.config = e, this.sources = t2, this.id = e.id, this.name = e.name, this.pad_scale = e.pad_scale || 1e-4, this.default_winding = null, this.rasters = [], Array.isArray(e.rasters) && e.rasters.forEach(function(e2) {
              -1 === r.rasters.indexOf(e2) && r.rasters.push(e2);
            }), this.preprocess = e.preprocess, "function" == typeof this.preprocess && this.preprocess.bind(this), this.transform = e.transform, "function" == typeof this.transform)
              this.transform = this.transform.bind(this);
            else if ("object" === _typeof(this.transform))
              for (var i2 in this.transform)
                "function" == typeof this.transform[i2] && (this.transform[i2] = this.transform[i2].bind(this));
            this.extra_data = e.extra_data, this.scripts = e.scripts, this.max_zoom = null != e.max_zoom ? e.max_zoom : Geo$1.default_source_max_zoom, this.setTileSize(e.tile_size), this.max_coord_zoom = this.max_zoom + this.zoom_bias, this.min_display_zoom = null != e.min_display_zoom ? e.min_display_zoom : 0, this.max_display_zoom = null != e.max_display_zoom ? e.max_display_zoom : null, this._has_volatile_data = !!e.has_volatile_data;
          }
          return _createClass(u2, [{ key: "hasLabeledData", value: function() {
            return true;
          } }, { key: "_transformTile", value: function(e) {
            if (e.source_data.layers) {
              var t2 = { coords: e.coords }, r = [];
              if ("function" == typeof this.transform)
                r.push(this.transform);
              else if ("object" === _typeof(this.transform))
                for (var i2 = Object.keys(this.transform).sort(), n = 0; n < i2.length; n++)
                  r.push(this.transform[i2[n]]);
              for (var o = 1 === Object.keys(e.source_data.layers).length && e.source_data.layers._default, a2 = 0; a2 < r.length; a2++)
                o ? e.source_data.layers._default = r[a2](e.source_data.layers._default, this.extra_data, t2) : e.source_data.layers = r[a2](e.source_data.layers, this.extra_data, t2);
            }
          } }, { key: "_postProcessTile", value: function(e) {
            var t2 = this;
            for (var r in this._transformTile(e), e.source_data.layers) {
              var i2 = e.source_data.layers[r];
              i2 && i2.features && i2.features.forEach(function(e2) {
                Geo$1.transformGeometry(e2.geometry, function(e3) {
                  e3[1] = -e3[1], t2.pad_scale && (e3[0] = Math.round(e3[0] * (1 + t2.pad_scale) - Geo$1.tile_scale * t2.pad_scale / 2), e3[1] = Math.round(e3[1] * (1 + t2.pad_scale) - Geo$1.tile_scale * t2.pad_scale / 2));
                }), t2.updateDefaultWinding(e2.geometry);
              });
            }
            e.default_winding = this.default_winding || "CCW";
          } }, { key: "load", value: function(e) {
            return e.source_data = {}, e.source_data.layers = {}, e.pad_scale = this.pad_scale, e.rasters = _toConsumableArray(this.rasters), this._load(e);
          } }, { key: "_load", value: function() {
            throw new MethodNotImplemented("_load");
          } }, { key: "setTileSize", value: function(e) {
            this.tile_size = e || 256, ("number" != typeof this.tile_size || this.tile_size < 256 || !Utils$1.isPowerOf2(this.tile_size)) && (log({ level: "warn", once: true }, "Data source '".concat(this.name, "': 'tile_size' parameter must be a number that is a power of 2 greater than or equal to 256, but was '").concat(e, "'")), this.tile_size = 256), this.zoom_bias = Math.log2(this.tile_size) - 8;
          } }, { key: "updateDefaultWinding", value: function(e) {
            return null == this.default_winding && ("Polygon" === e.type ? this.default_winding = Geo$1.ringWinding(e.coordinates[0]) : "MultiPolygon" === e.type && (this.default_winding = Geo$1.ringWinding(e.coordinates[0][0]))), this.default_winding;
          } }, { key: "includesTile", value: function(e, t2) {
            if (e.z < this.min_display_zoom || null != this.max_display_zoom && t2 > this.max_display_zoom)
              return false;
            for (var r = 0; r < this.rasters.length; r++) {
              var i2 = this.rasters[r];
              if (this.sources[i2] && this.sources[i2] !== this && !this.sources[i2].includesTile(e, e.z))
                return false;
            }
            return true;
          } }, { key: "has_volatile_data", get: function() {
            return this._has_volatile_data;
          }, set: function(e) {
            var t2 = 0 < arguments.length && void 0 !== e && e;
            this._has_volatile_data = t2;
          } }], [{ key: "create", value: function(e, t2) {
            for (var r in t2)
              if (t2[r].config.name === e.name && u2.sameConfig(t2[r], { config: e }))
                return t2[r];
            if (u2.types[e.type])
              return new u2.types[e.type](e, t2);
          } }, { key: "sameConfig", value: function(e, t2) {
            if (!e || !t2)
              return false;
            var r = Object.assign({}, e.config, { id: null, tiled: null, url: null }), i2 = Object.assign({}, t2.config, { id: null, tiled: null, url: null });
            return JSON.stringify(r) === JSON.stringify(i2);
          } }, { key: "coordsToMeters", value: function(e) {
            var t2 = _slicedToArray(Geo$1.latLngToMeters(e), 2), r = t2[0], i2 = t2[1];
            e[0] = r, e[1] = i2;
          } }, { key: "projectData", value: function(e) {
            for (var t2 in e.layers)
              for (var r = e.layers[t2].features.length, i2 = 0; i2 < r; i2++) {
                var n = e.layers[t2].features[i2];
                Geo$1.transformGeometry(n.geometry, u2.coordsToMeters);
              }
          } }, { key: "metersToTileUnits", value: function(e, t2, r) {
            r[0] = Math.round((r[0] - t2.x) * e), r[1] = -1 * Math.round((r[1] - t2.y) * e);
          } }, { key: "scaleData", value: function(e, t2) {
            var r = t2.coords.z, i2 = t2.min, n = (t2.max, u2.metersToTileUnits.bind(this, Geo$1.unitsPerMeter(r), i2));
            for (var o in e.layers)
              for (var a2 = e.layers[o].features.length, s = 0; s < a2; s++) {
                var l = e.layers[o].features[s];
                Geo$1.transformGeometry(l.geometry, n);
              }
          } }, { key: "register", value: function(e, t2) {
            e && t2 && (u2.types[t2] = e);
          } }]), u2;
        }();
        DataSource.types = {};
        var network_request_id = 0, NetworkSource = function() {
          _inherits(s, DataSource);
          var a2 = _createSuper(s);
          function s(n, e) {
            var o;
            _classCallCheck(this, s), (o = a2.call(this, n, e)).response_type = "";
            var t2 = _slicedToArray(addParamsToURL(n.url, n.url_params), 2), r = t2[0], i2 = t2[1];
            if (o.url = r, i2.forEach(function(e2) {
              var t3 = _slicedToArray(e2, 2), r2 = t3[0], i3 = t3[1];
              log({ level: "warn", once: true }, "Data source '".concat(o.name, "': parameter '").concat(r2, "' already present in URL '").concat(n.url, "', ") + "skipping value '".concat(r2, "=").concat(i3, "' specified in 'url_params'"));
            }), "string" != typeof o.url)
              throw Error("Network data source must provide a string `url` property");
            return o;
          }
          return _createClass(s, [{ key: "_load", value: function(n) {
            var o = this, a3 = this.formatUrl(this.url, n), s2 = n.source_data;
            return s2.url = a3, new Promise(function(t2, e) {
              s2.error = null;
              var r = network_request_id++ + "-" + a3, i2 = Utils$1.io(a3, 6e4, o.response_type, "GET", {}, r);
              s2.request_id = r, i2.then(function(e2) {
                "function" == typeof o.preprocess && (e2 = o.preprocess(e2)), (e2 = e2 instanceof Promise ? e2 : Promise.resolve(e2)).then(function(e3) {
                  o.parseSourceData(n, s2, e3), o._postProcessTile(n), t2(n);
                });
              }, function(e2) {
                s2.error = e2.stack, o._postProcessTile(n), t2(n);
              });
            });
          } }, { key: "formatUrl", value: function() {
            throw new MethodNotImplemented("formatUrl");
          } }, { key: "parseSourceData", value: function() {
            throw new MethodNotImplemented("parseSourceData");
          } }]), s;
        }(), NetworkTileSource = function() {
          _inherits(n, NetworkSource);
          var i2 = _createSuper(n);
          function n(e, t2) {
            var r;
            return _classCallCheck(this, n), (r = i2.call(this, e, t2)).tiled = true, r.parseBounds(e), r.builds_geometry_tiles = false, r.tms = true === e.tms, -1 < r.url.search("{s}") && (Array.isArray(e.url_subdomains) && 0 < e.url_subdomains.length ? (r.url_subdomains = e.url_subdomains, r.next_url_subdomain = 0) : log({ level: "warn", once: true }, "Data source '".concat(r.name, "': source URL includes '{s}' subdomain marker ('").concat(r.url, "'), but no subdomains ") + "were specified in 'url_subdomains' parameter")), r;
          }
          return _createClass(n, [{ key: "parseBounds", value: function(e) {
            var t2, r, i3, n2, o;
            Array.isArray(e.bounds) && 4 === e.bounds.length && (this.bounds = e.bounds, r = (t2 = _slicedToArray(this.bounds, 4))[0], i3 = t2[1], n2 = t2[2], o = t2[3], this.bounds_meters = { min: Geo$1.latLngToMeters([r, o]), max: Geo$1.latLngToMeters([n2, i3]) }, this.bounds_tiles = { min: {}, max: {} });
          } }, { key: "checkBounds", value: function(e) {
            if (this.bounds) {
              e = Geo$1.wrapTile(e, { x: true });
              var t2 = (t2 = this.bounds_tiles.min[e.z]) || (this.bounds_tiles.min[e.z] = Geo$1.tileForMeters(this.bounds_meters.min, e.z)), r = (r = this.bounds_tiles.max[e.z]) || (this.bounds_tiles.max[e.z] = Geo$1.tileForMeters(this.bounds_meters.max, e.z));
              if (e.x < t2.x || e.x > r.x || e.y < t2.y || e.y > r.y)
                return false;
            }
            return true;
          } }, { key: "includesTile", value: function(e, t2) {
            return !!_get(_getPrototypeOf(n.prototype), "includesTile", this).call(this, e, t2) && !!this.checkBounds(e);
          } }, { key: "formatUrl", value: function(e, t2) {
            var r = Geo$1.wrapTile(t2.coords, { x: true });
            this.tms && (r.y = Math.pow(2, r.z) - 1 - r.y);
            var i3 = e.replace("{x}", r.x).replace("{y}", r.y).replace("{z}", r.z);
            return null != this.url_subdomains && (i3 = i3.replace("{s}", this.url_subdomains[this.next_url_subdomain]), this.next_url_subdomain = (this.next_url_subdomain + 1) % this.url_subdomains.length), i3;
          } }, { key: "urlHasTilePattern", value: function(e) {
            return e && -1 < e.search("{x}") && -1 < e.search("{y}") && -1 < e.search("{z}");
          } }]), n;
        }(), MapsJsSource = function() {
          _inherits(n, DataSource);
          var i2 = _createSuper(n);
          function n(e, t2) {
            var r;
            return _classCallCheck(this, n), (r = i2.call(this, e, t2)).target_name = "MapsJsSource" + e.uid, r.tiled = !!e.tiled, WorkerBroker.addTarget(r.target_name, _assertThisInitialized(r)), Thread.is_worker && WorkerBroker.postMessage(r.target_name + ".onWorkerInitialized"), Thread.is_main && (r._workers_left = 0), r;
          }
          return _createClass(n, [{ key: "initialize", value: function(e, t2, r, i3) {
            this._main_initialized || (this.provider = e, this.worker = i3, this._workers_left += r, this._on_update = t2, this._main_initialized = true, this._onProviderUpdate = this._onProviderUpdate.bind(this), e.addEventListener("update", this._onProviderUpdate), this._isReady() && this.onReady());
          } }, { key: "onWorkerInitialized", value: function() {
            --this._workers_left, this._isReady() && this.onReady();
          } }, { key: "onReady", value: function() {
          } }, { key: "_isReady", value: function() {
            return this._main_initialized && !this._workers_left;
          } }, { key: "_onProviderUpdate", value: function(e) {
            this._isReady() && this.onProviderUpdate(e);
          } }, { key: "onProviderUpdate", value: function(e) {
            this.dispatchUpdate(void 0, e.data);
          } }, { key: "dispatchUpdate", value: function(e, t2) {
            this._on_update(this.name, e, t2);
          } }, { key: "dispose", value: function() {
            WorkerBroker.removeTarget(this.target_name), this.provider.removeEventListener("update", this._onProviderUpdate);
          } }]), n;
        }(), read = function(e, t2, r, i2, n) {
          var o, a2, s = 8 * n - i2 - 1, l = (1 << s) - 1, u2 = l >> 1, c2 = -7, h = r ? n - 1 : 0, f2 = r ? -1 : 1, d = e[t2 + h];
          for (h += f2, o = d & (1 << -c2) - 1, d >>= -c2, c2 += s; 0 < c2; o = 256 * o + e[t2 + h], h += f2, c2 -= 8)
            ;
          for (a2 = o & (1 << -c2) - 1, o >>= -c2, c2 += i2; 0 < c2; a2 = 256 * a2 + e[t2 + h], h += f2, c2 -= 8)
            ;
          if (0 === o)
            o = 1 - u2;
          else {
            if (o === l)
              return a2 ? NaN : 1 / 0 * (d ? -1 : 1);
            a2 += Math.pow(2, i2), o -= u2;
          }
          return (d ? -1 : 1) * a2 * Math.pow(2, o - i2);
        }, write = function(e, t2, r, i2, n, o) {
          var a2, s, l, u2 = 8 * o - n - 1, c2 = (1 << u2) - 1, h = c2 >> 1, f2 = 23 === n ? Math.pow(2, -24) - Math.pow(2, -77) : 0, d = i2 ? 0 : o - 1, _ = i2 ? 1 : -1, p2 = t2 < 0 || 0 === t2 && 1 / t2 < 0 ? 1 : 0;
          for (t2 = Math.abs(t2), isNaN(t2) || t2 === 1 / 0 ? (s = isNaN(t2) ? 1 : 0, a2 = c2) : (a2 = Math.floor(Math.log(t2) / Math.LN2), t2 * (l = Math.pow(2, -a2)) < 1 && (a2--, l *= 2), 2 <= (t2 += 1 <= a2 + h ? f2 / l : f2 * Math.pow(2, 1 - h)) * l && (a2++, l /= 2), c2 <= a2 + h ? (s = 0, a2 = c2) : 1 <= a2 + h ? (s = (t2 * l - 1) * Math.pow(2, n), a2 += h) : (s = t2 * Math.pow(2, h - 1) * Math.pow(2, n), a2 = 0)); 8 <= n; e[r + d] = 255 & s, d += _, s /= 256, n -= 8)
            ;
          for (a2 = a2 << n | s, u2 += n; 0 < u2; e[r + d] = 255 & a2, d += _, a2 /= 256, u2 -= 8)
            ;
          e[r + d - _] |= 128 * p2;
        }, ieee754 = { read, write }, pbf = Pbf;
        function Pbf(e) {
          this.buf = ArrayBuffer.isView && ArrayBuffer.isView(e) ? e : new Uint8Array(e || 0), this.pos = 0, this.type = 0, this.length = this.buf.length;
        }
        Pbf.Varint = 0, Pbf.Fixed64 = 1, Pbf.Bytes = 2, Pbf.Fixed32 = 5;
        var SHIFT_LEFT_32 = 4294967296, SHIFT_RIGHT_32 = 1 / SHIFT_LEFT_32;
        function readVarintRemainder(e, t2, r) {
          var i2 = r.buf, n = i2[r.pos++], o = (112 & n) >> 4;
          if (n < 128)
            return toNum(e, o, t2);
          if (o |= (127 & (n = i2[r.pos++])) << 3, n < 128)
            return toNum(e, o, t2);
          if (o |= (127 & (n = i2[r.pos++])) << 10, n < 128)
            return toNum(e, o, t2);
          if (o |= (127 & (n = i2[r.pos++])) << 17, n < 128)
            return toNum(e, o, t2);
          if (o |= (127 & (n = i2[r.pos++])) << 24, n < 128)
            return toNum(e, o, t2);
          if (o |= (1 & (n = i2[r.pos++])) << 31, n < 128)
            return toNum(e, o, t2);
          throw new Error("Expected varint not more than 10 bytes");
        }
        function readPackedEnd(e) {
          return e.type === Pbf.Bytes ? e.readVarint() + e.pos : e.pos + 1;
        }
        function toNum(e, t2, r) {
          return r ? 4294967296 * t2 + (e >>> 0) : 4294967296 * (t2 >>> 0) + (e >>> 0);
        }
        function writeBigVarint(e, t2) {
          var r, i2;
          if (0 <= e ? (r = e % 4294967296 | 0, i2 = e / 4294967296 | 0) : (i2 = ~(-e / 4294967296), 4294967295 ^ (r = ~(-e % 4294967296)) ? r = r + 1 | 0 : i2 = i2 + 1 | (r = 0)), 18446744073709552e3 <= e || e < -18446744073709552e3)
            throw new Error("Given varint doesn't fit into 10 bytes");
          t2.realloc(10), writeBigVarintLow(r, i2, t2), writeBigVarintHigh(i2, t2);
        }
        function writeBigVarintLow(e, t2, r) {
          r.buf[r.pos++] = 127 & e | 128, e >>>= 7, r.buf[r.pos++] = 127 & e | 128, e >>>= 7, r.buf[r.pos++] = 127 & e | 128, e >>>= 7, r.buf[r.pos++] = 127 & e | 128, e >>>= 7, r.buf[r.pos] = 127 & e;
        }
        function writeBigVarintHigh(e, t2) {
          var r = (7 & e) << 4;
          t2.buf[t2.pos++] |= r | ((e >>>= 3) ? 128 : 0), e && (t2.buf[t2.pos++] = 127 & e | ((e >>>= 7) ? 128 : 0), e && (t2.buf[t2.pos++] = 127 & e | ((e >>>= 7) ? 128 : 0), e && (t2.buf[t2.pos++] = 127 & e | ((e >>>= 7) ? 128 : 0), e && (t2.buf[t2.pos++] = 127 & e | ((e >>>= 7) ? 128 : 0), e && (t2.buf[t2.pos++] = 127 & e)))));
        }
        function makeRoomForExtraLength(e, t2, r) {
          var i2 = t2 <= 16383 ? 1 : t2 <= 2097151 ? 2 : t2 <= 268435455 ? 3 : Math.ceil(Math.log(t2) / (7 * Math.LN2));
          r.realloc(i2);
          for (var n = r.pos - 1; e <= n; n--)
            r.buf[n + i2] = r.buf[n];
        }
        function writePackedVarint(e, t2) {
          for (var r = 0; r < e.length; r++)
            t2.writeVarint(e[r]);
        }
        function writePackedSVarint(e, t2) {
          for (var r = 0; r < e.length; r++)
            t2.writeSVarint(e[r]);
        }
        function writePackedFloat(e, t2) {
          for (var r = 0; r < e.length; r++)
            t2.writeFloat(e[r]);
        }
        function writePackedDouble(e, t2) {
          for (var r = 0; r < e.length; r++)
            t2.writeDouble(e[r]);
        }
        function writePackedBoolean(e, t2) {
          for (var r = 0; r < e.length; r++)
            t2.writeBoolean(e[r]);
        }
        function writePackedFixed32(e, t2) {
          for (var r = 0; r < e.length; r++)
            t2.writeFixed32(e[r]);
        }
        function writePackedSFixed32(e, t2) {
          for (var r = 0; r < e.length; r++)
            t2.writeSFixed32(e[r]);
        }
        function writePackedFixed64(e, t2) {
          for (var r = 0; r < e.length; r++)
            t2.writeFixed64(e[r]);
        }
        function writePackedSFixed64(e, t2) {
          for (var r = 0; r < e.length; r++)
            t2.writeSFixed64(e[r]);
        }
        function readUInt32(e, t2) {
          return (e[t2] | e[t2 + 1] << 8 | e[t2 + 2] << 16) + 16777216 * e[t2 + 3];
        }
        function writeInt32(e, t2, r) {
          e[r] = t2, e[r + 1] = t2 >>> 8, e[r + 2] = t2 >>> 16, e[r + 3] = t2 >>> 24;
        }
        function readInt32(e, t2) {
          return (e[t2] | e[t2 + 1] << 8 | e[t2 + 2] << 16) + (e[t2 + 3] << 24);
        }
        function readUtf8(e, t2, r) {
          for (var i2 = "", n = t2; n < r; ) {
            var o, a2, s, l = e[n], u2 = null, c2 = 239 < l ? 4 : 223 < l ? 3 : 191 < l ? 2 : 1;
            if (r < n + c2)
              break;
            1 === c2 ? l < 128 && (u2 = l) : 2 === c2 ? 128 == (192 & (o = e[n + 1])) && (u2 = (31 & l) << 6 | 63 & o) <= 127 && (u2 = null) : 3 === c2 ? (o = e[n + 1], a2 = e[n + 2], 128 == (192 & o) && 128 == (192 & a2) && ((u2 = (15 & l) << 12 | (63 & o) << 6 | 63 & a2) <= 2047 || 55296 <= u2 && u2 <= 57343) && (u2 = null)) : 4 === c2 && (o = e[n + 1], a2 = e[n + 2], s = e[n + 3], 128 == (192 & o) && 128 == (192 & a2) && 128 == (192 & s) && ((u2 = (15 & l) << 18 | (63 & o) << 12 | (63 & a2) << 6 | 63 & s) <= 65535 || 1114112 <= u2) && (u2 = null)), null === u2 ? (u2 = 65533, c2 = 1) : 65535 < u2 && (u2 -= 65536, i2 += String.fromCharCode(u2 >>> 10 & 1023 | 55296), u2 = 56320 | 1023 & u2), i2 += String.fromCharCode(u2), n += c2;
          }
          return i2;
        }
        function writeUtf8(e, t2, r) {
          for (var i2, n, o = 0; o < t2.length; o++) {
            if (55295 < (i2 = t2.charCodeAt(o)) && i2 < 57344) {
              if (!n) {
                56319 < i2 || o + 1 === t2.length ? (e[r++] = 239, e[r++] = 191, e[r++] = 189) : n = i2;
                continue;
              }
              if (i2 < 56320) {
                e[r++] = 239, e[r++] = 191, e[r++] = 189, n = i2;
                continue;
              }
              i2 = n - 55296 << 10 | i2 - 56320 | 65536, n = null;
            } else
              n && (e[r++] = 239, e[r++] = 191, e[r++] = 189, n = null);
            i2 < 128 ? e[r++] = i2 : (i2 < 2048 ? e[r++] = i2 >> 6 | 192 : (i2 < 65536 ? e[r++] = i2 >> 12 | 224 : (e[r++] = i2 >> 18 | 240, e[r++] = i2 >> 12 & 63 | 128), e[r++] = i2 >> 6 & 63 | 128), e[r++] = 63 & i2 | 128);
          }
          return r;
        }
        Pbf.prototype = { destroy: function() {
          this.buf = null;
        }, readFields: function(e, t2, r) {
          for (r = r || this.length; this.pos < r; ) {
            var i2 = this.readVarint(), n = i2 >> 3, o = this.pos;
            this.type = 7 & i2, e(n, t2, this), this.pos === o && this.skip(i2);
          }
          return t2;
        }, readMessage: function(e, t2) {
          return this.readFields(e, t2, this.readVarint() + this.pos);
        }, readFixed32: function() {
          var e = readUInt32(this.buf, this.pos);
          return this.pos += 4, e;
        }, readSFixed32: function() {
          var e = readInt32(this.buf, this.pos);
          return this.pos += 4, e;
        }, readFixed64: function() {
          var e = readUInt32(this.buf, this.pos) + readUInt32(this.buf, this.pos + 4) * SHIFT_LEFT_32;
          return this.pos += 8, e;
        }, readSFixed64: function() {
          var e = readUInt32(this.buf, this.pos) + readInt32(this.buf, this.pos + 4) * SHIFT_LEFT_32;
          return this.pos += 8, e;
        }, readFloat: function() {
          var e = ieee754.read(this.buf, this.pos, true, 23, 4);
          return this.pos += 4, e;
        }, readDouble: function() {
          var e = ieee754.read(this.buf, this.pos, true, 52, 8);
          return this.pos += 8, e;
        }, readVarint: function(e) {
          var t2 = this.buf, r = t2[this.pos++], i2 = 127 & r;
          return r < 128 ? i2 : (i2 |= (127 & (r = t2[this.pos++])) << 7, r < 128 ? i2 : (i2 |= (127 & (r = t2[this.pos++])) << 14, r < 128 ? i2 : (i2 |= (127 & (r = t2[this.pos++])) << 21, r < 128 ? i2 : readVarintRemainder(i2 |= (15 & (r = t2[this.pos])) << 28, e, this))));
        }, readVarint64: function() {
          return this.readVarint(true);
        }, readSVarint: function() {
          var e = this.readVarint();
          return e % 2 == 1 ? (e + 1) / -2 : e / 2;
        }, readBoolean: function() {
          return Boolean(this.readVarint());
        }, readString: function() {
          var e = this.readVarint() + this.pos, t2 = readUtf8(this.buf, this.pos, e);
          return this.pos = e, t2;
        }, readBytes: function() {
          var e = this.readVarint() + this.pos, t2 = this.buf.subarray(this.pos, e);
          return this.pos = e, t2;
        }, readPackedVarint: function(e, t2) {
          var r = readPackedEnd(this);
          for (e = e || []; this.pos < r; )
            e.push(this.readVarint(t2));
          return e;
        }, readPackedSVarint: function(e) {
          var t2 = readPackedEnd(this);
          for (e = e || []; this.pos < t2; )
            e.push(this.readSVarint());
          return e;
        }, readPackedBoolean: function(e) {
          var t2 = readPackedEnd(this);
          for (e = e || []; this.pos < t2; )
            e.push(this.readBoolean());
          return e;
        }, readPackedFloat: function(e) {
          var t2 = readPackedEnd(this);
          for (e = e || []; this.pos < t2; )
            e.push(this.readFloat());
          return e;
        }, readPackedDouble: function(e) {
          var t2 = readPackedEnd(this);
          for (e = e || []; this.pos < t2; )
            e.push(this.readDouble());
          return e;
        }, readPackedFixed32: function(e) {
          var t2 = readPackedEnd(this);
          for (e = e || []; this.pos < t2; )
            e.push(this.readFixed32());
          return e;
        }, readPackedSFixed32: function(e) {
          var t2 = readPackedEnd(this);
          for (e = e || []; this.pos < t2; )
            e.push(this.readSFixed32());
          return e;
        }, readPackedFixed64: function(e) {
          var t2 = readPackedEnd(this);
          for (e = e || []; this.pos < t2; )
            e.push(this.readFixed64());
          return e;
        }, readPackedSFixed64: function(e) {
          var t2 = readPackedEnd(this);
          for (e = e || []; this.pos < t2; )
            e.push(this.readSFixed64());
          return e;
        }, skip: function(e) {
          var t2 = 7 & e;
          if (t2 === Pbf.Varint)
            for (; 127 < this.buf[this.pos++]; )
              ;
          else if (t2 === Pbf.Bytes)
            this.pos = this.readVarint() + this.pos;
          else if (t2 === Pbf.Fixed32)
            this.pos += 4;
          else {
            if (t2 !== Pbf.Fixed64)
              throw new Error("Unimplemented type: " + t2);
            this.pos += 8;
          }
        }, writeTag: function(e, t2) {
          this.writeVarint(e << 3 | t2);
        }, realloc: function(e) {
          for (var t2, r = this.length || 16; r < this.pos + e; )
            r *= 2;
          r !== this.length && ((t2 = new Uint8Array(r)).set(this.buf), this.buf = t2, this.length = r);
        }, finish: function() {
          return this.length = this.pos, this.pos = 0, this.buf.subarray(0, this.length);
        }, writeFixed32: function(e) {
          this.realloc(4), writeInt32(this.buf, e, this.pos), this.pos += 4;
        }, writeSFixed32: function(e) {
          this.realloc(4), writeInt32(this.buf, e, this.pos), this.pos += 4;
        }, writeFixed64: function(e) {
          this.realloc(8), writeInt32(this.buf, -1 & e, this.pos), writeInt32(this.buf, Math.floor(e * SHIFT_RIGHT_32), this.pos + 4), this.pos += 8;
        }, writeSFixed64: function(e) {
          this.realloc(8), writeInt32(this.buf, -1 & e, this.pos), writeInt32(this.buf, Math.floor(e * SHIFT_RIGHT_32), this.pos + 4), this.pos += 8;
        }, writeVarint: function(e) {
          268435455 < (e = +e || 0) || e < 0 ? writeBigVarint(e, this) : (this.realloc(4), this.buf[this.pos++] = 127 & e | (127 < e ? 128 : 0), e <= 127 || (this.buf[this.pos++] = 127 & (e >>>= 7) | (127 < e ? 128 : 0), e <= 127 || (this.buf[this.pos++] = 127 & (e >>>= 7) | (127 < e ? 128 : 0), e <= 127 || (this.buf[this.pos++] = e >>> 7 & 127))));
        }, writeSVarint: function(e) {
          this.writeVarint(e < 0 ? 2 * -e - 1 : 2 * e);
        }, writeBoolean: function(e) {
          this.writeVarint(Boolean(e));
        }, writeString: function(e) {
          e = String(e), this.realloc(4 * e.length), this.pos++;
          var t2 = this.pos;
          this.pos = writeUtf8(this.buf, e, this.pos);
          var r = this.pos - t2;
          128 <= r && makeRoomForExtraLength(t2, r, this), this.pos = t2 - 1, this.writeVarint(r), this.pos += r;
        }, writeFloat: function(e) {
          this.realloc(4), ieee754.write(this.buf, e, this.pos, true, 23, 4), this.pos += 4;
        }, writeDouble: function(e) {
          this.realloc(8), ieee754.write(this.buf, e, this.pos, true, 52, 8), this.pos += 8;
        }, writeBytes: function(e) {
          var t2 = e.length;
          this.writeVarint(t2), this.realloc(t2);
          for (var r = 0; r < t2; r++)
            this.buf[this.pos++] = e[r];
        }, writeRawMessage: function(e, t2) {
          this.pos++;
          var r = this.pos;
          e(t2, this);
          var i2 = this.pos - r;
          128 <= i2 && makeRoomForExtraLength(r, i2, this), this.pos = r - 1, this.writeVarint(i2), this.pos += i2;
        }, writeMessage: function(e, t2, r) {
          this.writeTag(e, Pbf.Bytes), this.writeRawMessage(t2, r);
        }, writePackedVarint: function(e, t2) {
          this.writeMessage(e, writePackedVarint, t2);
        }, writePackedSVarint: function(e, t2) {
          this.writeMessage(e, writePackedSVarint, t2);
        }, writePackedBoolean: function(e, t2) {
          this.writeMessage(e, writePackedBoolean, t2);
        }, writePackedFloat: function(e, t2) {
          this.writeMessage(e, writePackedFloat, t2);
        }, writePackedDouble: function(e, t2) {
          this.writeMessage(e, writePackedDouble, t2);
        }, writePackedFixed32: function(e, t2) {
          this.writeMessage(e, writePackedFixed32, t2);
        }, writePackedSFixed32: function(e, t2) {
          this.writeMessage(e, writePackedSFixed32, t2);
        }, writePackedFixed64: function(e, t2) {
          this.writeMessage(e, writePackedFixed64, t2);
        }, writePackedSFixed64: function(e, t2) {
          this.writeMessage(e, writePackedSFixed64, t2);
        }, writeBytesField: function(e, t2) {
          this.writeTag(e, Pbf.Bytes), this.writeBytes(t2);
        }, writeFixed32Field: function(e, t2) {
          this.writeTag(e, Pbf.Fixed32), this.writeFixed32(t2);
        }, writeSFixed32Field: function(e, t2) {
          this.writeTag(e, Pbf.Fixed32), this.writeSFixed32(t2);
        }, writeFixed64Field: function(e, t2) {
          this.writeTag(e, Pbf.Fixed64), this.writeFixed64(t2);
        }, writeSFixed64Field: function(e, t2) {
          this.writeTag(e, Pbf.Fixed64), this.writeSFixed64(t2);
        }, writeVarintField: function(e, t2) {
          this.writeTag(e, Pbf.Varint), this.writeVarint(t2);
        }, writeSVarintField: function(e, t2) {
          this.writeTag(e, Pbf.Varint), this.writeSVarint(t2);
        }, writeStringField: function(e, t2) {
          this.writeTag(e, Pbf.Bytes), this.writeString(t2);
        }, writeFloatField: function(e, t2) {
          this.writeTag(e, Pbf.Fixed32), this.writeFloat(t2);
        }, writeDoubleField: function(e, t2) {
          this.writeTag(e, Pbf.Fixed64), this.writeDouble(t2);
        }, writeBooleanField: function(e, t2) {
          this.writeVarintField(e, Boolean(t2));
        } };
        var pointGeometry = Point;
        function Point(e, t2) {
          this.x = e, this.y = t2;
        }
        Point.prototype = { clone: function() {
          return new Point(this.x, this.y);
        }, add: function(e) {
          return this.clone()._add(e);
        }, sub: function(e) {
          return this.clone()._sub(e);
        }, multByPoint: function(e) {
          return this.clone()._multByPoint(e);
        }, divByPoint: function(e) {
          return this.clone()._divByPoint(e);
        }, mult: function(e) {
          return this.clone()._mult(e);
        }, div: function(e) {
          return this.clone()._div(e);
        }, rotate: function(e) {
          return this.clone()._rotate(e);
        }, rotateAround: function(e, t2) {
          return this.clone()._rotateAround(e, t2);
        }, matMult: function(e) {
          return this.clone()._matMult(e);
        }, unit: function() {
          return this.clone()._unit();
        }, perp: function() {
          return this.clone()._perp();
        }, round: function() {
          return this.clone()._round();
        }, mag: function() {
          return Math.sqrt(this.x * this.x + this.y * this.y);
        }, equals: function(e) {
          return this.x === e.x && this.y === e.y;
        }, dist: function(e) {
          return Math.sqrt(this.distSqr(e));
        }, distSqr: function(e) {
          var t2 = e.x - this.x, r = e.y - this.y;
          return t2 * t2 + r * r;
        }, angle: function() {
          return Math.atan2(this.y, this.x);
        }, angleTo: function(e) {
          return Math.atan2(this.y - e.y, this.x - e.x);
        }, angleWith: function(e) {
          return this.angleWithSep(e.x, e.y);
        }, angleWithSep: function(e, t2) {
          return Math.atan2(this.x * t2 - this.y * e, this.x * e + this.y * t2);
        }, _matMult: function(e) {
          var t2 = e[0] * this.x + e[1] * this.y, r = e[2] * this.x + e[3] * this.y;
          return this.x = t2, this.y = r, this;
        }, _add: function(e) {
          return this.x += e.x, this.y += e.y, this;
        }, _sub: function(e) {
          return this.x -= e.x, this.y -= e.y, this;
        }, _mult: function(e) {
          return this.x *= e, this.y *= e, this;
        }, _div: function(e) {
          return this.x /= e, this.y /= e, this;
        }, _multByPoint: function(e) {
          return this.x *= e.x, this.y *= e.y, this;
        }, _divByPoint: function(e) {
          return this.x /= e.x, this.y /= e.y, this;
        }, _unit: function() {
          return this._div(this.mag()), this;
        }, _perp: function() {
          var e = this.y;
          return this.y = this.x, this.x = -e, this;
        }, _rotate: function(e) {
          var t2 = Math.cos(e), r = Math.sin(e), i2 = t2 * this.x - r * this.y, n = r * this.x + t2 * this.y;
          return this.x = i2, this.y = n, this;
        }, _rotateAround: function(e, t2) {
          var r = Math.cos(e), i2 = Math.sin(e), n = t2.x + r * (this.x - t2.x) - i2 * (this.y - t2.y), o = t2.y + i2 * (this.x - t2.x) + r * (this.y - t2.y);
          return this.x = n, this.y = o, this;
        }, _round: function() {
          return this.x = Math.round(this.x), this.y = Math.round(this.y), this;
        } }, Point.convert = function(e) {
          return !(e instanceof Point) && Array.isArray(e) ? new Point(e[0], e[1]) : e;
        };
        var vectortilefeature = VectorTileFeature;
        function VectorTileFeature(e, t2, r, i2, n) {
          this.properties = {}, this.extent = r, this.type = 0, this._pbf = e, this._geometry = -1, this._keys = i2, this._values = n, e.readFields(readFeature, this, t2);
        }
        function readFeature(e, t2, r) {
          1 == e ? t2.id = r.readVarint() : 2 == e ? readTag(r, t2) : 3 == e ? t2.type = r.readVarint() : 4 == e && (t2._geometry = r.pos);
        }
        function readTag(e, t2) {
          for (var r = e.readVarint() + e.pos; e.pos < r; ) {
            var i2 = t2._keys[e.readVarint()], n = t2._values[e.readVarint()];
            t2.properties[i2] = n;
          }
        }
        function classifyRings(e) {
          var t2 = e.length;
          if (t2 <= 1)
            return [e];
          for (var r, i2, n = [], o = 0; o < t2; o++) {
            var a2 = signedArea(e[o]);
            0 !== a2 && (void 0 === i2 && (i2 = a2 < 0), i2 === a2 < 0 ? (r && n.push(r), r = [e[o]]) : r.push(e[o]));
          }
          return r && n.push(r), n;
        }
        function signedArea(e) {
          for (var t2, r, i2 = 0, n = 0, o = e.length, a2 = o - 1; n < o; a2 = n++)
            t2 = e[n], i2 += ((r = e[a2]).x - t2.x) * (t2.y + r.y);
          return i2;
        }
        VectorTileFeature.types = ["Unknown", "Point", "LineString", "Polygon"], VectorTileFeature.prototype.loadGeometry = function() {
          var e = this._pbf;
          e.pos = this._geometry;
          for (var t2, r, i2 = e.readVarint() + e.pos, n = 1, o = 0, a2 = 0, s = 0, l = []; e.pos < i2; ) {
            if (o || (n = 7 & (r = e.readVarint()), o = r >> 3), o--, 1 === n || 2 === n)
              a2 += e.readSVarint(), s += e.readSVarint(), 1 === n && (t2 && l.push(t2), t2 = []), t2.push(new pointGeometry(a2, s));
            else {
              if (7 !== n)
                throw new Error("unknown command " + n);
              t2 && t2.push(t2[0].clone());
            }
          }
          return t2 && l.push(t2), l;
        }, VectorTileFeature.prototype.bbox = function() {
          var e = this._pbf;
          e.pos = this._geometry;
          for (var t2, r = e.readVarint() + e.pos, i2 = 1, n = 0, o = 0, a2 = 0, s = 1 / 0, l = -1 / 0, u2 = 1 / 0, c2 = -1 / 0; e.pos < r; ) {
            if (n || (i2 = 7 & (t2 = e.readVarint()), n = t2 >> 3), n--, 1 === i2 || 2 === i2)
              (o += e.readSVarint()) < s && (s = o), l < o && (l = o), (a2 += e.readSVarint()) < u2 && (u2 = a2), c2 < a2 && (c2 = a2);
            else if (7 !== i2)
              throw new Error("unknown command " + i2);
          }
          return [s, u2, l, c2];
        }, VectorTileFeature.prototype.toGeoJSON = function(e, t2, r) {
          var i2, n = this.extent * Math.pow(2, r), o = this.extent * e, a2 = this.extent * t2, s = this.loadGeometry(), l = VectorTileFeature.types[this.type];
          function u2(e2) {
            for (var t3 = 0; t3 < e2.length; t3++) {
              var r2 = e2[t3], i3 = 180 - 360 * (r2.y + a2) / n;
              e2[t3] = [360 * (r2.x + o) / n - 180, 360 / Math.PI * Math.atan(Math.exp(i3 * Math.PI / 180)) - 90];
            }
          }
          switch (this.type) {
            case 1:
              for (var c2 = [], h = 0; h < s.length; h++)
                c2[h] = s[h][0];
              u2(s = c2);
              break;
            case 2:
              for (h = 0; h < s.length; h++)
                u2(s[h]);
              break;
            case 3:
              for (s = classifyRings(s), h = 0; h < s.length; h++)
                for (i2 = 0; i2 < s[h].length; i2++)
                  u2(s[h][i2]);
          }
          1 === s.length ? s = s[0] : l = "Multi" + l;
          var f2 = { type: "Feature", geometry: { type: l, coordinates: s }, properties: this.properties };
          return "id" in this && (f2.id = this.id), f2;
        };
        var VectorTileFeature$1 = vectortilefeature, long_1 = Long, wasm = null;
        try {
          wasm = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 13, 2, 96, 0, 1, 127, 96, 4, 127, 127, 127, 127, 1, 127, 3, 7, 6, 0, 1, 1, 1, 1, 1, 6, 6, 1, 127, 1, 65, 0, 11, 7, 50, 6, 3, 109, 117, 108, 0, 1, 5, 100, 105, 118, 95, 115, 0, 2, 5, 100, 105, 118, 95, 117, 0, 3, 5, 114, 101, 109, 95, 115, 0, 4, 5, 114, 101, 109, 95, 117, 0, 5, 8, 103, 101, 116, 95, 104, 105, 103, 104, 0, 0, 10, 191, 1, 6, 4, 0, 35, 0, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 126, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 127, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 128, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 129, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 130, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11])), {}).exports;
        } catch (e) {
        }
        function Long(e, t2, r) {
          this.low = 0 | e, this.high = 0 | t2, this.unsigned = !!r;
        }
        function isLong(e) {
          return true === (e && e.__isLong__);
        }
        Long.prototype.__isLong__, Object.defineProperty(Long.prototype, "__isLong__", { value: true }), Long.isLong = isLong;
        var INT_CACHE = {}, UINT_CACHE = {};
        function fromInt(e, t2) {
          var r, i2, n;
          return t2 ? (n = 0 <= (e >>>= 0) && e < 256) && (i2 = UINT_CACHE[e]) ? i2 : (r = fromBits(e, (0 | e) < 0 ? -1 : 0, true), n && (UINT_CACHE[e] = r), r) : (n = -128 <= (e |= 0) && e < 128) && (i2 = INT_CACHE[e]) ? i2 : (r = fromBits(e, e < 0 ? -1 : 0, false), n && (INT_CACHE[e] = r), r);
        }
        function fromNumber(e, t2) {
          if (isNaN(e))
            return t2 ? UZERO : ZERO;
          if (t2) {
            if (e < 0)
              return UZERO;
            if (TWO_PWR_64_DBL <= e)
              return MAX_UNSIGNED_VALUE;
          } else {
            if (e <= -TWO_PWR_63_DBL)
              return MIN_VALUE;
            if (TWO_PWR_63_DBL <= e + 1)
              return MAX_VALUE;
          }
          return e < 0 ? fromNumber(-e, t2).neg() : fromBits(e % TWO_PWR_32_DBL | 0, e / TWO_PWR_32_DBL | 0, t2);
        }
        function fromBits(e, t2, r) {
          return new Long(e, t2, r);
        }
        Long.fromInt = fromInt, Long.fromNumber = fromNumber, Long.fromBits = fromBits;
        var pow_dbl = Math.pow;
        function fromString(e, t2, r) {
          if (0 === e.length)
            throw Error("empty string");
          if ("NaN" === e || "Infinity" === e || "+Infinity" === e || "-Infinity" === e)
            return ZERO;
          if (t2 = "number" == typeof t2 ? (r = t2, false) : !!t2, (r = r || 10) < 2 || 36 < r)
            throw RangeError("radix");
          var i2;
          if (0 < (i2 = e.indexOf("-")))
            throw Error("interior hyphen");
          if (0 === i2)
            return fromString(e.substring(1), t2, r).neg();
          for (var n = fromNumber(pow_dbl(r, 8)), o = ZERO, a2 = 0; a2 < e.length; a2 += 8) {
            var s, l = Math.min(8, e.length - a2), u2 = parseInt(e.substring(a2, a2 + l), r);
            o = l < 8 ? (s = fromNumber(pow_dbl(r, l)), o.mul(s).add(fromNumber(u2))) : (o = o.mul(n)).add(fromNumber(u2));
          }
          return o.unsigned = t2, o;
        }
        function fromValue(e, t2) {
          return "number" == typeof e ? fromNumber(e, t2) : "string" == typeof e ? fromString(e, t2) : fromBits(e.low, e.high, "boolean" == typeof t2 ? t2 : e.unsigned);
        }
        Long.fromString = fromString, Long.fromValue = fromValue;
        var TWO_PWR_16_DBL = 65536, TWO_PWR_24_DBL = 1 << 24, TWO_PWR_32_DBL = TWO_PWR_16_DBL * TWO_PWR_16_DBL, TWO_PWR_64_DBL = TWO_PWR_32_DBL * TWO_PWR_32_DBL, TWO_PWR_63_DBL = TWO_PWR_64_DBL / 2, TWO_PWR_24 = fromInt(TWO_PWR_24_DBL), ZERO = fromInt(0);
        Long.ZERO = ZERO;
        var UZERO = fromInt(0, true);
        Long.UZERO = UZERO;
        var ONE = fromInt(1);
        Long.ONE = ONE;
        var UONE = fromInt(1, true);
        Long.UONE = UONE;
        var NEG_ONE = fromInt(-1);
        Long.NEG_ONE = NEG_ONE;
        var MAX_VALUE = fromBits(-1, 2147483647, false);
        Long.MAX_VALUE = MAX_VALUE;
        var MAX_UNSIGNED_VALUE = fromBits(-1, -1, true);
        Long.MAX_UNSIGNED_VALUE = MAX_UNSIGNED_VALUE;
        var MIN_VALUE = fromBits(0, -2147483648, false);
        Long.MIN_VALUE = MIN_VALUE;
        var LongPrototype = Long.prototype;
        LongPrototype.toInt = function() {
          return this.unsigned ? this.low >>> 0 : this.low;
        }, LongPrototype.toNumber = function() {
          return this.unsigned ? (this.high >>> 0) * TWO_PWR_32_DBL + (this.low >>> 0) : this.high * TWO_PWR_32_DBL + (this.low >>> 0);
        }, LongPrototype.toString = function(e) {
          if ((e = e || 10) < 2 || 36 < e)
            throw RangeError("radix");
          if (this.isZero())
            return "0";
          if (this.isNegative()) {
            if (this.eq(MIN_VALUE)) {
              var t2 = fromNumber(e), r = this.div(t2), i2 = r.mul(t2).sub(this);
              return r.toString(e) + i2.toInt().toString(e);
            }
            return "-" + this.neg().toString(e);
          }
          for (var n = fromNumber(pow_dbl(e, 6), this.unsigned), o = this, a2 = ""; ; ) {
            var s = o.div(n), l = (o.sub(s.mul(n)).toInt() >>> 0).toString(e);
            if ((o = s).isZero())
              return l + a2;
            for (; l.length < 6; )
              l = "0" + l;
            a2 = "" + l + a2;
          }
        }, LongPrototype.getHighBits = function() {
          return this.high;
        }, LongPrototype.getHighBitsUnsigned = function() {
          return this.high >>> 0;
        }, LongPrototype.getLowBits = function() {
          return this.low;
        }, LongPrototype.getLowBitsUnsigned = function() {
          return this.low >>> 0;
        }, LongPrototype.getNumBitsAbs = function() {
          if (this.isNegative())
            return this.eq(MIN_VALUE) ? 64 : this.neg().getNumBitsAbs();
          for (var e = 0 != this.high ? this.high : this.low, t2 = 31; 0 < t2 && 0 == (e & 1 << t2); t2--)
            ;
          return 0 != this.high ? t2 + 33 : t2 + 1;
        }, LongPrototype.isZero = function() {
          return 0 === this.high && 0 === this.low;
        }, LongPrototype.eqz = LongPrototype.isZero, LongPrototype.isNegative = function() {
          return !this.unsigned && this.high < 0;
        }, LongPrototype.isPositive = function() {
          return this.unsigned || 0 <= this.high;
        }, LongPrototype.isOdd = function() {
          return 1 == (1 & this.low);
        }, LongPrototype.isEven = function() {
          return 0 == (1 & this.low);
        }, LongPrototype.equals = function(e) {
          return isLong(e) || (e = fromValue(e)), (this.unsigned === e.unsigned || this.high >>> 31 != 1 || e.high >>> 31 != 1) && (this.high === e.high && this.low === e.low);
        }, LongPrototype.eq = LongPrototype.equals, LongPrototype.notEquals = function(e) {
          return !this.eq(e);
        }, LongPrototype.neq = LongPrototype.notEquals, LongPrototype.ne = LongPrototype.notEquals, LongPrototype.lessThan = function(e) {
          return this.comp(e) < 0;
        }, LongPrototype.lt = LongPrototype.lessThan, LongPrototype.lessThanOrEqual = function(e) {
          return this.comp(e) <= 0;
        }, LongPrototype.lte = LongPrototype.lessThanOrEqual, LongPrototype.le = LongPrototype.lessThanOrEqual, LongPrototype.greaterThan = function(e) {
          return 0 < this.comp(e);
        }, LongPrototype.gt = LongPrototype.greaterThan, LongPrototype.greaterThanOrEqual = function(e) {
          return 0 <= this.comp(e);
        }, LongPrototype.gte = LongPrototype.greaterThanOrEqual, LongPrototype.ge = LongPrototype.greaterThanOrEqual, LongPrototype.compare = function(e) {
          if (isLong(e) || (e = fromValue(e)), this.eq(e))
            return 0;
          var t2 = this.isNegative(), r = e.isNegative();
          return t2 && !r ? -1 : !t2 && r ? 1 : this.unsigned ? e.high >>> 0 > this.high >>> 0 || e.high === this.high && e.low >>> 0 > this.low >>> 0 ? -1 : 1 : this.sub(e).isNegative() ? -1 : 1;
        }, LongPrototype.comp = LongPrototype.compare, LongPrototype.negate = function() {
          return !this.unsigned && this.eq(MIN_VALUE) ? MIN_VALUE : this.not().add(ONE);
        }, LongPrototype.neg = LongPrototype.negate, LongPrototype.add = function(e) {
          isLong(e) || (e = fromValue(e));
          var t2 = this.high >>> 16, r = 65535 & this.high, i2 = this.low >>> 16, n = 65535 & this.low, o = e.high >>> 16, a2 = 65535 & e.high, s = e.low >>> 16, l = 0, u2 = 0, c2 = 0, h = 0;
          return c2 += (h += n + (65535 & e.low)) >>> 16, u2 += (c2 += i2 + s) >>> 16, l += (u2 += r + a2) >>> 16, l += t2 + o, fromBits((c2 &= 65535) << 16 | (h &= 65535), (l &= 65535) << 16 | (u2 &= 65535), this.unsigned);
        }, LongPrototype.subtract = function(e) {
          return isLong(e) || (e = fromValue(e)), this.add(e.neg());
        }, LongPrototype.sub = LongPrototype.subtract, LongPrototype.multiply = function(e) {
          if (this.isZero())
            return ZERO;
          if (isLong(e) || (e = fromValue(e)), wasm)
            return fromBits(wasm.mul(this.low, this.high, e.low, e.high), wasm.get_high(), this.unsigned);
          if (e.isZero())
            return ZERO;
          if (this.eq(MIN_VALUE))
            return e.isOdd() ? MIN_VALUE : ZERO;
          if (e.eq(MIN_VALUE))
            return this.isOdd() ? MIN_VALUE : ZERO;
          if (this.isNegative())
            return e.isNegative() ? this.neg().mul(e.neg()) : this.neg().mul(e).neg();
          if (e.isNegative())
            return this.mul(e.neg()).neg();
          if (this.lt(TWO_PWR_24) && e.lt(TWO_PWR_24))
            return fromNumber(this.toNumber() * e.toNumber(), this.unsigned);
          var t2 = this.high >>> 16, r = 65535 & this.high, i2 = this.low >>> 16, n = 65535 & this.low, o = e.high >>> 16, a2 = 65535 & e.high, s = e.low >>> 16, l = 65535 & e.low, u2 = 0, c2 = 0, h = 0, f2 = 0;
          return h += (f2 += n * l) >>> 16, c2 += (h += i2 * l) >>> 16, h &= 65535, c2 += (h += n * s) >>> 16, u2 += (c2 += r * l) >>> 16, c2 &= 65535, u2 += (c2 += i2 * s) >>> 16, c2 &= 65535, u2 += (c2 += n * a2) >>> 16, u2 += t2 * l + r * s + i2 * a2 + n * o, fromBits((h &= 65535) << 16 | (f2 &= 65535), (u2 &= 65535) << 16 | (c2 &= 65535), this.unsigned);
        }, LongPrototype.mul = LongPrototype.multiply, LongPrototype.divide = function(e) {
          if (isLong(e) || (e = fromValue(e)), e.isZero())
            throw Error("division by zero");
          var t2, r, i2;
          if (wasm)
            return this.unsigned || -2147483648 !== this.high || -1 !== e.low || -1 !== e.high ? fromBits((this.unsigned ? wasm.div_u : wasm.div_s)(this.low, this.high, e.low, e.high), wasm.get_high(), this.unsigned) : this;
          if (this.isZero())
            return this.unsigned ? UZERO : ZERO;
          if (this.unsigned) {
            if (e.unsigned || (e = e.toUnsigned()), e.gt(this))
              return UZERO;
            if (e.gt(this.shru(1)))
              return UONE;
            r = UZERO;
          } else {
            if (this.eq(MIN_VALUE))
              return e.eq(ONE) || e.eq(NEG_ONE) ? MIN_VALUE : e.eq(MIN_VALUE) ? ONE : (i2 = this.shr(1).div(e).shl(1)).eq(ZERO) ? e.isNegative() ? ONE : NEG_ONE : (t2 = this.sub(e.mul(i2)), r = i2.add(t2.div(e)));
            else if (e.eq(MIN_VALUE))
              return this.unsigned ? UZERO : ZERO;
            if (this.isNegative())
              return e.isNegative() ? this.neg().div(e.neg()) : this.neg().div(e).neg();
            if (e.isNegative())
              return this.div(e.neg()).neg();
            r = ZERO;
          }
          for (t2 = this; t2.gte(e); ) {
            i2 = Math.max(1, Math.floor(t2.toNumber() / e.toNumber()));
            for (var n = Math.ceil(Math.log(i2) / Math.LN2), o = n <= 48 ? 1 : pow_dbl(2, n - 48), a2 = fromNumber(i2), s = a2.mul(e); s.isNegative() || s.gt(t2); )
              s = (a2 = fromNumber(i2 -= o, this.unsigned)).mul(e);
            a2.isZero() && (a2 = ONE), r = r.add(a2), t2 = t2.sub(s);
          }
          return r;
        }, LongPrototype.div = LongPrototype.divide, LongPrototype.modulo = function(e) {
          return isLong(e) || (e = fromValue(e)), wasm ? fromBits((this.unsigned ? wasm.rem_u : wasm.rem_s)(this.low, this.high, e.low, e.high), wasm.get_high(), this.unsigned) : this.sub(this.div(e).mul(e));
        }, LongPrototype.mod = LongPrototype.modulo, LongPrototype.rem = LongPrototype.modulo, LongPrototype.not = function() {
          return fromBits(~this.low, ~this.high, this.unsigned);
        }, LongPrototype.and = function(e) {
          return isLong(e) || (e = fromValue(e)), fromBits(this.low & e.low, this.high & e.high, this.unsigned);
        }, LongPrototype.or = function(e) {
          return isLong(e) || (e = fromValue(e)), fromBits(this.low | e.low, this.high | e.high, this.unsigned);
        }, LongPrototype.xor = function(e) {
          return isLong(e) || (e = fromValue(e)), fromBits(this.low ^ e.low, this.high ^ e.high, this.unsigned);
        }, LongPrototype.shiftLeft = function(e) {
          return isLong(e) && (e = e.toInt()), 0 == (e &= 63) ? this : e < 32 ? fromBits(this.low << e, this.high << e | this.low >>> 32 - e, this.unsigned) : fromBits(0, this.low << e - 32, this.unsigned);
        }, LongPrototype.shl = LongPrototype.shiftLeft, LongPrototype.shiftRight = function(e) {
          return isLong(e) && (e = e.toInt()), 0 == (e &= 63) ? this : e < 32 ? fromBits(this.low >>> e | this.high << 32 - e, this.high >> e, this.unsigned) : fromBits(this.high >> e - 32, 0 <= this.high ? 0 : -1, this.unsigned);
        }, LongPrototype.shr = LongPrototype.shiftRight, LongPrototype.shiftRightUnsigned = function(e) {
          if (isLong(e) && (e = e.toInt()), 0 === (e &= 63))
            return this;
          var t2 = this.high;
          return e < 32 ? fromBits(this.low >>> e | t2 << 32 - e, t2 >>> e, this.unsigned) : fromBits(32 === e ? t2 : t2 >>> e - 32, 0, this.unsigned);
        }, LongPrototype.shru = LongPrototype.shiftRightUnsigned, LongPrototype.shr_u = LongPrototype.shiftRightUnsigned, LongPrototype.toSigned = function() {
          return this.unsigned ? fromBits(this.low, this.high, false) : this;
        }, LongPrototype.toUnsigned = function() {
          return this.unsigned ? this : fromBits(this.low, this.high, true);
        }, LongPrototype.toBytes = function(e) {
          return e ? this.toBytesLE() : this.toBytesBE();
        }, LongPrototype.toBytesLE = function() {
          var e = this.high, t2 = this.low;
          return [255 & t2, t2 >>> 8 & 255, t2 >>> 16 & 255, t2 >>> 24, 255 & e, e >>> 8 & 255, e >>> 16 & 255, e >>> 24];
        }, LongPrototype.toBytesBE = function() {
          var e = this.high, t2 = this.low;
          return [e >>> 24, e >>> 16 & 255, e >>> 8 & 255, 255 & e, t2 >>> 24, t2 >>> 16 & 255, t2 >>> 8 & 255, 255 & t2];
        }, Long.fromBytes = function(e, t2, r) {
          return r ? Long.fromBytesLE(e, t2) : Long.fromBytesBE(e, t2);
        }, Long.fromBytesLE = function(e, t2) {
          return new Long(e[0] | e[1] << 8 | e[2] << 16 | e[3] << 24, e[4] | e[5] << 8 | e[6] << 16 | e[7] << 24, t2);
        }, Long.fromBytesBE = function(e, t2) {
          return new Long(e[4] << 24 | e[5] << 16 | e[6] << 8 | e[7], e[0] << 24 | e[1] << 16 | e[2] << 8 | e[3], t2);
        };
        var aspromise = asPromise;
        function asPromise(e, t2) {
          for (var r = new Array(arguments.length - 1), o = 0, i2 = 2, a2 = true; i2 < arguments.length; )
            r[o++] = arguments[i2++];
          return new Promise(function(i3, n) {
            r[o] = function(e2) {
              if (a2)
                if (a2 = false, e2)
                  n(e2);
                else {
                  for (var t3 = new Array(arguments.length - 1), r2 = 0; r2 < t3.length; )
                    t3[r2++] = arguments[r2];
                  i3.apply(null, t3);
                }
            };
            try {
              e.apply(t2 || null, r);
            } catch (e2) {
              a2 && (a2 = false, n(e2));
            }
          });
        }
        var base64_1 = createCommonjsModule(function(e, t2) {
          var r = t2;
          r.length = function(e2) {
            var t3 = e2.length;
            if (!t3)
              return 0;
            for (var r2 = 0; 1 < --t3 % 4 && "=" === e2.charAt(t3); )
              ++r2;
            return Math.ceil(3 * e2.length) / 4 - r2;
          };
          for (var u2 = new Array(64), l = new Array(123), i2 = 0; i2 < 64; )
            l[u2[i2] = i2 < 26 ? i2 + 65 : i2 < 52 ? i2 + 71 : i2 < 62 ? i2 - 4 : i2 - 59 | 43] = i2++;
          r.encode = function(e2, t3, r2) {
            for (var i3, n = null, o = [], a2 = 0, s = 0; t3 < r2; ) {
              var l2 = e2[t3++];
              switch (s) {
                case 0:
                  o[a2++] = u2[l2 >> 2], i3 = (3 & l2) << 4, s = 1;
                  break;
                case 1:
                  o[a2++] = u2[i3 | l2 >> 4], i3 = (15 & l2) << 2, s = 2;
                  break;
                case 2:
                  o[a2++] = u2[i3 | l2 >> 6], o[a2++] = u2[63 & l2], s = 0;
              }
              8191 < a2 && ((n = n || []).push(String.fromCharCode.apply(String, o)), a2 = 0);
            }
            return s && (o[a2++] = u2[i3], o[a2++] = 61, 1 === s && (o[a2++] = 61)), n ? (a2 && n.push(String.fromCharCode.apply(String, o.slice(0, a2))), n.join("")) : String.fromCharCode.apply(String, o.slice(0, a2));
          };
          var c2 = "invalid encoding";
          r.decode = function(e2, t3, r2) {
            for (var i3, n = r2, o = 0, a2 = 0; a2 < e2.length; ) {
              var s = e2.charCodeAt(a2++);
              if (61 === s && 1 < o)
                break;
              if (void 0 === (s = l[s]))
                throw Error(c2);
              switch (o) {
                case 0:
                  i3 = s, o = 1;
                  break;
                case 1:
                  t3[r2++] = i3 << 2 | (48 & s) >> 4, i3 = s, o = 2;
                  break;
                case 2:
                  t3[r2++] = (15 & i3) << 4 | (60 & s) >> 2, i3 = s, o = 3;
                  break;
                case 3:
                  t3[r2++] = (3 & i3) << 6 | s, o = 0;
              }
            }
            if (1 === o)
              throw Error(c2);
            return r2 - n;
          }, r.test = function(e2) {
            return /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(e2);
          };
        }), eventemitter = EventEmitter;
        function EventEmitter() {
          this._listeners = {};
        }
        EventEmitter.prototype.on = function(e, t2, r) {
          return (this._listeners[e] || (this._listeners[e] = [])).push({ fn: t2, ctx: r || this }), this;
        }, EventEmitter.prototype.off = function(e, t2) {
          if (void 0 === e)
            this._listeners = {};
          else if (void 0 === t2)
            this._listeners[e] = [];
          else
            for (var r = this._listeners[e], i2 = 0; i2 < r.length; )
              r[i2].fn === t2 ? r.splice(i2, 1) : ++i2;
          return this;
        }, EventEmitter.prototype.emit = function(e) {
          var t2 = this._listeners[e];
          if (t2) {
            for (var r = [], i2 = 1; i2 < arguments.length; )
              r.push(arguments[i2++]);
            for (i2 = 0; i2 < t2.length; )
              t2[i2].fn.apply(t2[i2++].ctx, r);
          }
          return this;
        };
        var float_1 = factory(factory);
        function factory(e) {
          function t2(e2, t3, r2, i3) {
            var n2, o2 = t3 < 0 ? 1 : 0;
            o2 && (t3 = -t3), 0 === t3 ? e2(0 < 1 / t3 ? 0 : 2147483648, r2, i3) : isNaN(t3) ? e2(2143289344, r2, i3) : e2(34028234663852886e22 < t3 ? (o2 << 31 | 2139095040) >>> 0 : t3 < 11754943508222875e-54 ? (o2 << 31 | Math.round(t3 / 1401298464324817e-60)) >>> 0 : (o2 << 31 | (n2 = Math.floor(Math.log(t3) / Math.LN2)) + 127 << 23 | 8388607 & Math.round(t3 * Math.pow(2, -n2) * 8388608)) >>> 0, r2, i3);
          }
          function r(e2, t3, r2) {
            var i3 = e2(t3, r2), n2 = 2 * (i3 >> 31) + 1, o2 = i3 >>> 23 & 255, a3 = 8388607 & i3;
            return 255 == o2 ? a3 ? NaN : 1 / 0 * n2 : 0 == o2 ? 1401298464324817e-60 * n2 * a3 : n2 * Math.pow(2, o2 - 150) * (8388608 + a3);
          }
          function i2(e2, t3, r2) {
            s[0] = e2, t3[r2] = l[0], t3[r2 + 1] = l[1], t3[r2 + 2] = l[2], t3[r2 + 3] = l[3];
          }
          function n(e2, t3, r2) {
            s[0] = e2, t3[r2] = l[3], t3[r2 + 1] = l[2], t3[r2 + 2] = l[1], t3[r2 + 3] = l[0];
          }
          function o(e2, t3) {
            return l[0] = e2[t3], l[1] = e2[t3 + 1], l[2] = e2[t3 + 2], l[3] = e2[t3 + 3], s[0];
          }
          function a2(e2, t3) {
            return l[3] = e2[t3], l[2] = e2[t3 + 1], l[1] = e2[t3 + 2], l[0] = e2[t3 + 3], s[0];
          }
          var s, l, u2, c2, h, f2;
          function d(e2, t3, r2, i3, n2, o2) {
            var a3, s2, l2 = i3 < 0 ? 1 : 0;
            l2 && (i3 = -i3), 0 === i3 ? (e2(0, n2, o2 + t3), e2(0 < 1 / i3 ? 0 : 2147483648, n2, o2 + r2)) : isNaN(i3) ? (e2(0, n2, o2 + t3), e2(2146959360, n2, o2 + r2)) : 17976931348623157e292 < i3 ? (e2(0, n2, o2 + t3), e2((l2 << 31 | 2146435072) >>> 0, n2, o2 + r2)) : i3 < 22250738585072014e-324 ? (e2((a3 = i3 / 5e-324) >>> 0, n2, o2 + t3), e2((l2 << 31 | a3 / 4294967296) >>> 0, n2, o2 + r2)) : (1024 === (s2 = Math.floor(Math.log(i3) / Math.LN2)) && (s2 = 1023), e2(4503599627370496 * (a3 = i3 * Math.pow(2, -s2)) >>> 0, n2, o2 + t3), e2((l2 << 31 | s2 + 1023 << 20 | 1048576 * a3 & 1048575) >>> 0, n2, o2 + r2));
          }
          function _(e2, t3, r2, i3, n2) {
            var o2 = e2(i3, n2 + t3), a3 = e2(i3, n2 + r2), s2 = 2 * (a3 >> 31) + 1, l2 = a3 >>> 20 & 2047, u3 = 4294967296 * (1048575 & a3) + o2;
            return 2047 == l2 ? u3 ? NaN : 1 / 0 * s2 : 0 == l2 ? 5e-324 * s2 * u3 : s2 * Math.pow(2, l2 - 1075) * (u3 + 4503599627370496);
          }
          function p2(e2, t3, r2) {
            c2[0] = e2, t3[r2] = h[0], t3[r2 + 1] = h[1], t3[r2 + 2] = h[2], t3[r2 + 3] = h[3], t3[r2 + 4] = h[4], t3[r2 + 5] = h[5], t3[r2 + 6] = h[6], t3[r2 + 7] = h[7];
          }
          function g(e2, t3, r2) {
            c2[0] = e2, t3[r2] = h[7], t3[r2 + 1] = h[6], t3[r2 + 2] = h[5], t3[r2 + 3] = h[4], t3[r2 + 4] = h[3], t3[r2 + 5] = h[2], t3[r2 + 6] = h[1], t3[r2 + 7] = h[0];
          }
          function m(e2, t3) {
            return h[0] = e2[t3], h[1] = e2[t3 + 1], h[2] = e2[t3 + 2], h[3] = e2[t3 + 3], h[4] = e2[t3 + 4], h[5] = e2[t3 + 5], h[6] = e2[t3 + 6], h[7] = e2[t3 + 7], c2[0];
          }
          function y(e2, t3) {
            return h[7] = e2[t3], h[6] = e2[t3 + 1], h[5] = e2[t3 + 2], h[4] = e2[t3 + 3], h[3] = e2[t3 + 4], h[2] = e2[t3 + 5], h[1] = e2[t3 + 6], h[0] = e2[t3 + 7], c2[0];
          }
          return "undefined" != typeof Float32Array ? (s = new Float32Array([-0]), l = new Uint8Array(s.buffer), u2 = 128 === l[3], e.writeFloatLE = u2 ? i2 : n, e.writeFloatBE = u2 ? n : i2, e.readFloatLE = u2 ? o : a2, e.readFloatBE = u2 ? a2 : o) : (e.writeFloatLE = t2.bind(null, writeUintLE), e.writeFloatBE = t2.bind(null, writeUintBE), e.readFloatLE = r.bind(null, readUintLE), e.readFloatBE = r.bind(null, readUintBE)), "undefined" != typeof Float64Array ? (c2 = new Float64Array([-0]), h = new Uint8Array(c2.buffer), f2 = 128 === h[7], e.writeDoubleLE = f2 ? p2 : g, e.writeDoubleBE = f2 ? g : p2, e.readDoubleLE = f2 ? m : y, e.readDoubleBE = f2 ? y : m) : (e.writeDoubleLE = d.bind(null, writeUintLE, 0, 4), e.writeDoubleBE = d.bind(null, writeUintBE, 4, 0), e.readDoubleLE = _.bind(null, readUintLE, 0, 4), e.readDoubleBE = _.bind(null, readUintBE, 4, 0)), e;
        }
        function writeUintLE(e, t2, r) {
          t2[r] = 255 & e, t2[r + 1] = e >>> 8 & 255, t2[r + 2] = e >>> 16 & 255, t2[r + 3] = e >>> 24;
        }
        function writeUintBE(e, t2, r) {
          t2[r] = e >>> 24, t2[r + 1] = e >>> 16 & 255, t2[r + 2] = e >>> 8 & 255, t2[r + 3] = 255 & e;
        }
        function readUintLE(e, t2) {
          return (e[t2] | e[t2 + 1] << 8 | e[t2 + 2] << 16 | e[t2 + 3] << 24) >>> 0;
        }
        function readUintBE(e, t2) {
          return (e[t2] << 24 | e[t2 + 1] << 16 | e[t2 + 2] << 8 | e[t2 + 3]) >>> 0;
        }
        var inquire_1 = inquire;
        function inquire(moduleName) {
          try {
            var mod = eval("quire".replace(/^/, "re"))(moduleName);
            if (mod && (mod.length || Object.keys(mod).length))
              return mod;
          } catch (e) {
          }
          return null;
        }
        var utf8_1 = createCommonjsModule(function(e, t2) {
          var r = t2;
          r.length = function(e2) {
            for (var t3 = 0, r2 = 0, i2 = 0; i2 < e2.length; ++i2)
              (r2 = e2.charCodeAt(i2)) < 128 ? t3 += 1 : r2 < 2048 ? t3 += 2 : 55296 == (64512 & r2) && 56320 == (64512 & e2.charCodeAt(i2 + 1)) ? (++i2, t3 += 4) : t3 += 3;
            return t3;
          }, r.read = function(e2, t3, r2) {
            if (r2 - t3 < 1)
              return "";
            for (var i2, n = null, o = [], a2 = 0; t3 < r2; )
              (i2 = e2[t3++]) < 128 ? o[a2++] = i2 : 191 < i2 && i2 < 224 ? o[a2++] = (31 & i2) << 6 | 63 & e2[t3++] : 239 < i2 && i2 < 365 ? (i2 = ((7 & i2) << 18 | (63 & e2[t3++]) << 12 | (63 & e2[t3++]) << 6 | 63 & e2[t3++]) - 65536, o[a2++] = 55296 + (i2 >> 10), o[a2++] = 56320 + (1023 & i2)) : o[a2++] = (15 & i2) << 12 | (63 & e2[t3++]) << 6 | 63 & e2[t3++], 8191 < a2 && ((n = n || []).push(String.fromCharCode.apply(String, o)), a2 = 0);
            return n ? (a2 && n.push(String.fromCharCode.apply(String, o.slice(0, a2))), n.join("")) : String.fromCharCode.apply(String, o.slice(0, a2));
          }, r.write = function(e2, t3, r2) {
            for (var i2, n, o = r2, a2 = 0; a2 < e2.length; ++a2)
              (i2 = e2.charCodeAt(a2)) < 128 ? t3[r2++] = i2 : (i2 < 2048 ? t3[r2++] = i2 >> 6 | 192 : (55296 == (64512 & i2) && 56320 == (64512 & (n = e2.charCodeAt(a2 + 1))) ? (i2 = 65536 + ((1023 & i2) << 10) + (1023 & n), ++a2, t3[r2++] = i2 >> 18 | 240, t3[r2++] = i2 >> 12 & 63 | 128) : t3[r2++] = i2 >> 12 | 224, t3[r2++] = i2 >> 6 & 63 | 128), t3[r2++] = 63 & i2 | 128);
            return r2 - o;
          };
        }), pool_1 = pool;
        function pool(r, i2, e) {
          var n = e || 8192, o = n >>> 1, a2 = null, s = n;
          return function(e2) {
            if (e2 < 1 || o < e2)
              return r(e2);
            n < s + e2 && (a2 = r(n), s = 0);
            var t2 = i2.call(a2, s, s += e2);
            return 7 & s && (s = 1 + (7 | s)), t2;
          };
        }
        var longbits = LongBits;
        function LongBits(e, t2) {
          this.lo = e >>> 0, this.hi = t2 >>> 0;
        }
        var zero = LongBits.zero = new LongBits(0, 0);
        zero.toNumber = function() {
          return 0;
        }, zero.zzEncode = zero.zzDecode = function() {
          return this;
        }, zero.length = function() {
          return 1;
        };
        var zeroHash = LongBits.zeroHash = "\0\0\0\0\0\0\0\0";
        LongBits.fromNumber = function(e) {
          if (0 === e)
            return zero;
          var t2 = e < 0;
          t2 && (e = -e);
          var r = e >>> 0, i2 = (e - r) / 4294967296 >>> 0;
          return t2 && (i2 = ~i2 >>> 0, r = ~r >>> 0, 4294967295 < ++r && (r = 0, 4294967295 < ++i2 && (i2 = 0))), new LongBits(r, i2);
        }, LongBits.from = function(e) {
          if ("number" == typeof e)
            return LongBits.fromNumber(e);
          if (minimal.isString(e)) {
            if (!minimal.Long)
              return LongBits.fromNumber(parseInt(e, 10));
            e = minimal.Long.fromString(e);
          }
          return e.low || e.high ? new LongBits(e.low >>> 0, e.high >>> 0) : zero;
        }, LongBits.prototype.toNumber = function(e) {
          if (!e && this.hi >>> 31) {
            var t2 = 1 + ~this.lo >>> 0, r = ~this.hi >>> 0;
            return t2 || (r = r + 1 >>> 0), -(t2 + 4294967296 * r);
          }
          return this.lo + 4294967296 * this.hi;
        }, LongBits.prototype.toLong = function(e) {
          return minimal.Long ? new minimal.Long(0 | this.lo, 0 | this.hi, Boolean(e)) : { low: 0 | this.lo, high: 0 | this.hi, unsigned: Boolean(e) };
        };
        var charCodeAt = String.prototype.charCodeAt;
        LongBits.fromHash = function(e) {
          return e === zeroHash ? zero : new LongBits((charCodeAt.call(e, 0) | charCodeAt.call(e, 1) << 8 | charCodeAt.call(e, 2) << 16 | charCodeAt.call(e, 3) << 24) >>> 0, (charCodeAt.call(e, 4) | charCodeAt.call(e, 5) << 8 | charCodeAt.call(e, 6) << 16 | charCodeAt.call(e, 7) << 24) >>> 0);
        }, LongBits.prototype.toHash = function() {
          return String.fromCharCode(255 & this.lo, this.lo >>> 8 & 255, this.lo >>> 16 & 255, this.lo >>> 24, 255 & this.hi, this.hi >>> 8 & 255, this.hi >>> 16 & 255, this.hi >>> 24);
        }, LongBits.prototype.zzEncode = function() {
          var e = this.hi >> 31;
          return this.hi = ((this.hi << 1 | this.lo >>> 31) ^ e) >>> 0, this.lo = (this.lo << 1 ^ e) >>> 0, this;
        }, LongBits.prototype.zzDecode = function() {
          var e = -(1 & this.lo);
          return this.lo = ((this.lo >>> 1 | this.hi << 31) ^ e) >>> 0, this.hi = (this.hi >>> 1 ^ e) >>> 0, this;
        }, LongBits.prototype.length = function() {
          var e = this.lo, t2 = (this.lo >>> 28 | this.hi << 4) >>> 0, r = this.hi >>> 24;
          return 0 == r ? 0 == t2 ? e < 16384 ? e < 128 ? 1 : 2 : e < 2097152 ? 3 : 4 : t2 < 16384 ? t2 < 128 ? 5 : 6 : t2 < 2097152 ? 7 : 8 : r < 128 ? 9 : 10;
        };
        var minimal = createCommonjsModule(function(e, t2) {
          var i2 = t2;
          function n(e2, t3, r2) {
            for (var i3 = Object.keys(t3), n2 = 0; n2 < i3.length; ++n2)
              void 0 !== e2[i3[n2]] && r2 || (e2[i3[n2]] = t3[i3[n2]]);
            return e2;
          }
          function r(e2) {
            function r2(e3, t3) {
              if (!(this instanceof r2))
                return new r2(e3, t3);
              Object.defineProperty(this, "message", { get: function() {
                return e3;
              } }), Error.captureStackTrace ? Error.captureStackTrace(this, r2) : Object.defineProperty(this, "stack", { value: new Error().stack || "" }), t3 && n(this, t3);
            }
            return (r2.prototype = Object.create(Error.prototype)).constructor = r2, Object.defineProperty(r2.prototype, "name", { get: function() {
              return e2;
            } }), r2.prototype.toString = function() {
              return this.name + ": " + this.message;
            }, r2;
          }
          i2.asPromise = aspromise, i2.base64 = base64_1, i2.EventEmitter = eventemitter, i2.float = float_1, i2.inquire = inquire_1, i2.utf8 = utf8_1, i2.pool = pool_1, i2.LongBits = longbits, i2.isNode = Boolean(void 0 !== commonjsGlobal && commonjsGlobal && commonjsGlobal.process && commonjsGlobal.process.versions && commonjsGlobal.process.versions.node), i2.global = i2.isNode && commonjsGlobal || "undefined" != typeof window && window || "undefined" != typeof self && self || commonjsGlobal, i2.emptyArray = Object.freeze ? Object.freeze([]) : [], i2.emptyObject = Object.freeze ? Object.freeze({}) : {}, i2.isInteger = Number.isInteger || function(e2) {
            return "number" == typeof e2 && isFinite(e2) && Math.floor(e2) === e2;
          }, i2.isString = function(e2) {
            return "string" == typeof e2 || e2 instanceof String;
          }, i2.isObject = function(e2) {
            return e2 && "object" == typeof e2;
          }, i2.isset = i2.isSet = function(e2, t3) {
            var r2 = e2[t3];
            return !(null == r2 || !e2.hasOwnProperty(t3)) && ("object" != typeof r2 || 0 < (Array.isArray(r2) ? r2.length : Object.keys(r2).length));
          }, i2.Buffer = function() {
            try {
              var e2 = i2.inquire("buffer").Buffer;
              return e2.prototype.utf8Write ? e2 : null;
            } catch (e3) {
              return null;
            }
          }(), i2._Buffer_from = null, i2._Buffer_allocUnsafe = null, i2.newBuffer = function(e2) {
            return "number" == typeof e2 ? i2.Buffer ? i2._Buffer_allocUnsafe(e2) : new i2.Array(e2) : i2.Buffer ? i2._Buffer_from(e2) : "undefined" == typeof Uint8Array ? e2 : new Uint8Array(e2);
          }, i2.Array = "undefined" != typeof Uint8Array ? Uint8Array : Array, i2.Long = i2.global.dcodeIO && i2.global.dcodeIO.Long || i2.global.Long || i2.inquire("long"), i2.key2Re = /^true|false|0|1$/, i2.key32Re = /^-?(?:0|[1-9][0-9]*)$/, i2.key64Re = /^(?:[\\x00-\\xff]{8}|-?(?:0|[1-9][0-9]*))$/, i2.longToHash = function(e2) {
            return e2 ? i2.LongBits.from(e2).toHash() : i2.LongBits.zeroHash;
          }, i2.longFromHash = function(e2, t3) {
            var r2 = i2.LongBits.fromHash(e2);
            return i2.Long ? i2.Long.fromBits(r2.lo, r2.hi, t3) : r2.toNumber(Boolean(t3));
          }, i2.merge = n, i2.lcFirst = function(e2) {
            return e2.charAt(0).toLowerCase() + e2.substring(1);
          }, i2.newError = r, i2.ProtocolError = r("ProtocolError"), i2.oneOfGetter = function(e2) {
            for (var r2 = {}, t3 = 0; t3 < e2.length; ++t3)
              r2[e2[t3]] = 1;
            return function() {
              for (var e3 = Object.keys(this), t4 = e3.length - 1; -1 < t4; --t4)
                if (1 === r2[e3[t4]] && void 0 !== this[e3[t4]] && null !== this[e3[t4]])
                  return e3[t4];
            };
          }, i2.oneOfSetter = function(r2) {
            return function(e2) {
              for (var t3 = 0; t3 < r2.length; ++t3)
                r2[t3] !== e2 && delete this[r2[t3]];
            };
          }, i2.toJSONOptions = { longs: String, enums: String, bytes: String, json: true }, i2._configure = function() {
            var r2 = i2.Buffer;
            r2 ? (i2._Buffer_from = r2.from !== Uint8Array.from && r2.from || function(e2, t3) {
              return new r2(e2, t3);
            }, i2._Buffer_allocUnsafe = r2.allocUnsafe || function(e2) {
              return new r2(e2);
            }) : i2._Buffer_from = i2._Buffer_allocUnsafe = null;
          };
        }), writer = Writer, BufferWriter, LongBits$1 = minimal.LongBits, base64 = minimal.base64, utf8 = minimal.utf8;
        function Op(e, t2, r) {
          this.fn = e, this.len = t2, this.next = void 0, this.val = r;
        }
        function noop() {
        }
        function State(e) {
          this.head = e.head, this.tail = e.tail, this.len = e.len, this.next = e.states;
        }
        function Writer() {
          this.len = 0, this.head = new Op(noop, 0, 0), this.tail = this.head, this.states = null;
        }
        var create = function() {
          return minimal.Buffer ? function() {
            return (Writer.create = function() {
              return new BufferWriter();
            })();
          } : function() {
            return new Writer();
          };
        };
        function writeByte(e, t2, r) {
          t2[r] = 255 & e;
        }
        function writeVarint32(e, t2, r) {
          for (; 127 < e; )
            t2[r++] = 127 & e | 128, e >>>= 7;
          t2[r] = e;
        }
        function VarintOp(e, t2) {
          this.len = e, this.next = void 0, this.val = t2;
        }
        function writeVarint64(e, t2, r) {
          for (; e.hi; )
            t2[r++] = 127 & e.lo | 128, e.lo = (e.lo >>> 7 | e.hi << 25) >>> 0, e.hi >>>= 7;
          for (; 127 < e.lo; )
            t2[r++] = 127 & e.lo | 128, e.lo = e.lo >>> 7;
          t2[r++] = e.lo;
        }
        function writeFixed32(e, t2, r) {
          t2[r] = 255 & e, t2[r + 1] = e >>> 8 & 255, t2[r + 2] = e >>> 16 & 255, t2[r + 3] = e >>> 24;
        }
        Writer.create = create(), Writer.alloc = function(e) {
          return new minimal.Array(e);
        }, minimal.Array !== Array && (Writer.alloc = minimal.pool(Writer.alloc, minimal.Array.prototype.subarray)), Writer.prototype._push = function(e, t2, r) {
          return this.tail = this.tail.next = new Op(e, t2, r), this.len += t2, this;
        }, VarintOp.prototype = Object.create(Op.prototype), VarintOp.prototype.fn = writeVarint32, Writer.prototype.uint32 = function(e) {
          return this.len += (this.tail = this.tail.next = new VarintOp((e >>>= 0) < 128 ? 1 : e < 16384 ? 2 : e < 2097152 ? 3 : e < 268435456 ? 4 : 5, e)).len, this;
        }, Writer.prototype.int32 = function(e) {
          return e < 0 ? this._push(writeVarint64, 10, LongBits$1.fromNumber(e)) : this.uint32(e);
        }, Writer.prototype.sint32 = function(e) {
          return this.uint32((e << 1 ^ e >> 31) >>> 0);
        }, Writer.prototype.uint64 = function(e) {
          var t2 = LongBits$1.from(e);
          return this._push(writeVarint64, t2.length(), t2);
        }, Writer.prototype.int64 = Writer.prototype.uint64, Writer.prototype.sint64 = function(e) {
          var t2 = LongBits$1.from(e).zzEncode();
          return this._push(writeVarint64, t2.length(), t2);
        }, Writer.prototype.bool = function(e) {
          return this._push(writeByte, 1, e ? 1 : 0);
        }, Writer.prototype.fixed32 = function(e) {
          return this._push(writeFixed32, 4, e >>> 0);
        }, Writer.prototype.sfixed32 = Writer.prototype.fixed32, Writer.prototype.fixed64 = function(e) {
          var t2 = LongBits$1.from(e);
          return this._push(writeFixed32, 4, t2.lo)._push(writeFixed32, 4, t2.hi);
        }, Writer.prototype.sfixed64 = Writer.prototype.fixed64, Writer.prototype.float = function(e) {
          return this._push(minimal.float.writeFloatLE, 4, e);
        }, Writer.prototype.double = function(e) {
          return this._push(minimal.float.writeDoubleLE, 8, e);
        };
        var writeBytes = minimal.Array.prototype.set ? function(e, t2, r) {
          t2.set(e, r);
        } : function(e, t2, r) {
          for (var i2 = 0; i2 < e.length; ++i2)
            t2[r + i2] = e[i2];
        };
        Writer.prototype.bytes = function(e) {
          var t2, r = e.length >>> 0;
          return r ? (minimal.isString(e) && (t2 = Writer.alloc(r = base64.length(e)), base64.decode(e, t2, 0), e = t2), this.uint32(r)._push(writeBytes, r, e)) : this._push(writeByte, 1, 0);
        }, Writer.prototype.string = function(e) {
          var t2 = utf8.length(e);
          return t2 ? this.uint32(t2)._push(utf8.write, t2, e) : this._push(writeByte, 1, 0);
        }, Writer.prototype.fork = function() {
          return this.states = new State(this), this.head = this.tail = new Op(noop, 0, 0), this.len = 0, this;
        }, Writer.prototype.reset = function() {
          return this.states ? (this.head = this.states.head, this.tail = this.states.tail, this.len = this.states.len, this.states = this.states.next) : (this.head = this.tail = new Op(noop, 0, 0), this.len = 0), this;
        }, Writer.prototype.ldelim = function() {
          var e = this.head, t2 = this.tail, r = this.len;
          return this.reset().uint32(r), r && (this.tail.next = e.next, this.tail = t2, this.len += r), this;
        }, Writer.prototype.finish = function() {
          for (var e = this.head.next, t2 = this.constructor.alloc(this.len), r = 0; e; )
            e.fn(e.val, t2, r), r += e.len, e = e.next;
          return t2;
        }, Writer._configure = function(e) {
          BufferWriter = e, Writer.create = create(), BufferWriter._configure();
        };
        var writer_buffer = BufferWriter$1;
        function BufferWriter$1() {
          writer.call(this);
        }
        function writeStringBuffer(e, t2, r) {
          e.length < 40 ? minimal.utf8.write(e, t2, r) : t2.utf8Write ? t2.utf8Write(e, r) : t2.write(e, r);
        }
        (BufferWriter$1.prototype = Object.create(writer.prototype)).constructor = BufferWriter$1, BufferWriter$1._configure = function() {
          BufferWriter$1.alloc = minimal._Buffer_allocUnsafe, BufferWriter$1.writeBytesBuffer = minimal.Buffer && minimal.Buffer.prototype instanceof Uint8Array && "set" === minimal.Buffer.prototype.set.name ? function(e, t2, r) {
            t2.set(e, r);
          } : function(e, t2, r) {
            if (e.copy)
              e.copy(t2, r, 0, e.length);
            else
              for (var i2 = 0; i2 < e.length; )
                t2[r++] = e[i2++];
          };
        }, BufferWriter$1.prototype.bytes = function(e) {
          minimal.isString(e) && (e = minimal._Buffer_from(e, "base64"));
          var t2 = e.length >>> 0;
          return this.uint32(t2), t2 && this._push(BufferWriter$1.writeBytesBuffer, t2, e), this;
        }, BufferWriter$1.prototype.string = function(e) {
          var t2 = minimal.Buffer.byteLength(e);
          return this.uint32(t2), t2 && this._push(writeStringBuffer, t2, e), this;
        }, BufferWriter$1._configure();
        var reader = Reader, BufferReader, LongBits$2 = minimal.LongBits, utf8$1 = minimal.utf8;
        function indexOutOfRange(e, t2) {
          return RangeError("index out of range: " + e.pos + " + " + (t2 || 1) + " > " + e.len);
        }
        function Reader(e) {
          this.buf = e, this.pos = 0, this.len = e.length;
        }
        var create_array = "undefined" != typeof Uint8Array ? function(e) {
          if (e instanceof Uint8Array || Array.isArray(e))
            return new Reader(e);
          throw Error("illegal buffer");
        } : function(e) {
          if (Array.isArray(e))
            return new Reader(e);
          throw Error("illegal buffer");
        }, create$1 = function() {
          return minimal.Buffer ? function(e) {
            return (Reader.create = function(e2) {
              return minimal.Buffer.isBuffer(e2) ? new BufferReader(e2) : create_array(e2);
            })(e);
          } : create_array;
        }, fU;
        function readLongVarint() {
          var e = new LongBits$2(0, 0), t2 = 0;
          if (!(4 < this.len - this.pos)) {
            for (; t2 < 3; ++t2) {
              if (this.pos >= this.len)
                throw indexOutOfRange(this);
              if (e.lo = (e.lo | (127 & this.buf[this.pos]) << 7 * t2) >>> 0, this.buf[this.pos++] < 128)
                return e;
            }
            return e.lo = (e.lo | (127 & this.buf[this.pos++]) << 7 * t2) >>> 0, e;
          }
          for (; t2 < 4; ++t2)
            if (e.lo = (e.lo | (127 & this.buf[this.pos]) << 7 * t2) >>> 0, this.buf[this.pos++] < 128)
              return e;
          if (e.lo = (e.lo | (127 & this.buf[this.pos]) << 28) >>> 0, e.hi = (e.hi | (127 & this.buf[this.pos]) >> 4) >>> 0, this.buf[this.pos++] < 128)
            return e;
          if (t2 = 0, 4 < this.len - this.pos) {
            for (; t2 < 5; ++t2)
              if (e.hi = (e.hi | (127 & this.buf[this.pos]) << 7 * t2 + 3) >>> 0, this.buf[this.pos++] < 128)
                return e;
          } else
            for (; t2 < 5; ++t2) {
              if (this.pos >= this.len)
                throw indexOutOfRange(this);
              if (e.hi = (e.hi | (127 & this.buf[this.pos]) << 7 * t2 + 3) >>> 0, this.buf[this.pos++] < 128)
                return e;
            }
          throw Error("invalid varint encoding");
        }
        function readFixed32_end(e, t2) {
          return (e[t2 - 4] | e[t2 - 3] << 8 | e[t2 - 2] << 16 | e[t2 - 1] << 24) >>> 0;
        }
        function readFixed64() {
          if (this.pos + 8 > this.len)
            throw indexOutOfRange(this, 8);
          return new LongBits$2(readFixed32_end(this.buf, this.pos += 4), readFixed32_end(this.buf, this.pos += 4));
        }
        Reader.create = create$1(), Reader.prototype._slice = minimal.Array.prototype.subarray || minimal.Array.prototype.slice, Reader.prototype.uint32 = (fU = 4294967295, function() {
          if (fU = (127 & this.buf[this.pos]) >>> 0, this.buf[this.pos++] < 128)
            return fU;
          if (fU = (fU | (127 & this.buf[this.pos]) << 7) >>> 0, this.buf[this.pos++] < 128)
            return fU;
          if (fU = (fU | (127 & this.buf[this.pos]) << 14) >>> 0, this.buf[this.pos++] < 128)
            return fU;
          if (fU = (fU | (127 & this.buf[this.pos]) << 21) >>> 0, this.buf[this.pos++] < 128)
            return fU;
          if (fU = (fU | (15 & this.buf[this.pos]) << 28) >>> 0, this.buf[this.pos++] < 128)
            return fU;
          if ((this.pos += 5) > this.len)
            throw this.pos = this.len, indexOutOfRange(this, 10);
          return fU;
        }), Reader.prototype.int32 = function() {
          return 0 | this.uint32();
        }, Reader.prototype.sint32 = function() {
          var e = this.uint32();
          return e >>> 1 ^ -(1 & e) | 0;
        }, Reader.prototype.bool = function() {
          return 0 !== this.uint32();
        }, Reader.prototype.fixed32 = function() {
          if (this.pos + 4 > this.len)
            throw indexOutOfRange(this, 4);
          return readFixed32_end(this.buf, this.pos += 4);
        }, Reader.prototype.sfixed32 = function() {
          if (this.pos + 4 > this.len)
            throw indexOutOfRange(this, 4);
          return 0 | readFixed32_end(this.buf, this.pos += 4);
        }, Reader.prototype.float = function() {
          if (this.pos + 4 > this.len)
            throw indexOutOfRange(this, 4);
          var e = minimal.float.readFloatLE(this.buf, this.pos);
          return this.pos += 4, e;
        }, Reader.prototype.double = function() {
          if (this.pos + 8 > this.len)
            throw indexOutOfRange(this, 4);
          var e = minimal.float.readDoubleLE(this.buf, this.pos);
          return this.pos += 8, e;
        }, Reader.prototype.bytes = function() {
          var e = this.uint32(), t2 = this.pos, r = this.pos + e;
          if (r > this.len)
            throw indexOutOfRange(this, e);
          return this.pos += e, Array.isArray(this.buf) ? this.buf.slice(t2, r) : t2 === r ? new this.buf.constructor(0) : this._slice.call(this.buf, t2, r);
        }, Reader.prototype.string = function() {
          var e = this.bytes();
          return utf8$1.read(e, 0, e.length);
        }, Reader.prototype.skip = function(e) {
          if ("number" == typeof e) {
            if (this.pos + e > this.len)
              throw indexOutOfRange(this, e);
            this.pos += e;
          } else
            do {
              if (this.pos >= this.len)
                throw indexOutOfRange(this);
            } while (128 & this.buf[this.pos++]);
          return this;
        }, Reader.prototype.skipType = function(e) {
          switch (e) {
            case 0:
              this.skip();
              break;
            case 1:
              this.skip(8);
              break;
            case 2:
              this.skip(this.uint32());
              break;
            case 3:
              for (; 4 != (e = 7 & this.uint32()); )
                this.skipType(e);
              break;
            case 5:
              this.skip(4);
              break;
            default:
              throw Error("invalid wire type " + e + " at offset " + this.pos);
          }
          return this;
        }, Reader._configure = function(e) {
          BufferReader = e, Reader.create = create$1(), BufferReader._configure();
          var t2 = minimal.Long ? "toLong" : "toNumber";
          minimal.merge(Reader.prototype, { int64: function() {
            return readLongVarint.call(this)[t2](false);
          }, uint64: function() {
            return readLongVarint.call(this)[t2](true);
          }, sint64: function() {
            return readLongVarint.call(this).zzDecode()[t2](false);
          }, fixed64: function() {
            return readFixed64.call(this)[t2](true);
          }, sfixed64: function() {
            return readFixed64.call(this)[t2](false);
          } });
        };
        var reader_buffer = BufferReader$1;
        function BufferReader$1(e) {
          reader.call(this, e);
        }
        (BufferReader$1.prototype = Object.create(reader.prototype)).constructor = BufferReader$1, BufferReader$1._configure = function() {
          minimal.Buffer && (BufferReader$1.prototype._slice = minimal.Buffer.prototype.slice);
        }, BufferReader$1.prototype.string = function() {
          var e = this.uint32();
          return this.buf.utf8Slice ? this.buf.utf8Slice(this.pos, this.pos = Math.min(this.pos + e, this.len)) : this.buf.toString("utf-8", this.pos, this.pos = Math.min(this.pos + e, this.len));
        }, BufferReader$1._configure();
        var service = Service;
        function Service(e, t2, r) {
          if ("function" != typeof e)
            throw TypeError("rpcImpl must be a function");
          minimal.EventEmitter.call(this), this.rpcImpl = e, this.requestDelimited = Boolean(t2), this.responseDelimited = Boolean(r);
        }
        (Service.prototype = Object.create(minimal.EventEmitter.prototype)).constructor = Service, Service.prototype.rpcCall = function e(r, t2, i2, n, o) {
          if (!n)
            throw TypeError("request must be specified");
          var a2 = this;
          if (!o)
            return minimal.asPromise(e, a2, r, t2, i2, n);
          if (a2.rpcImpl)
            try {
              return a2.rpcImpl(r, t2[a2.requestDelimited ? "encodeDelimited" : "encode"](n).finish(), function(e2, t3) {
                if (e2)
                  return a2.emit("error", e2, r), o(e2);
                if (null !== t3) {
                  if (!(t3 instanceof i2))
                    try {
                      t3 = i2[a2.responseDelimited ? "decodeDelimited" : "decode"](t3);
                    } catch (e3) {
                      return a2.emit("error", e3, r), o(e3);
                    }
                  return a2.emit("data", t3, r), o(null, t3);
                }
                a2.end(true);
              });
            } catch (e2) {
              return a2.emit("error", e2, r), void setTimeout(function() {
                o(e2);
              }, 0);
            }
          else
            setTimeout(function() {
              o(Error("already ended"));
            }, 0);
        }, Service.prototype.end = function(e) {
          return this.rpcImpl && (e || this.rpcImpl(null, null, null), this.rpcImpl = null, this.emit("end").off()), this;
        };
        var rpc_1 = createCommonjsModule(function(e, t2) {
          t2.Service = service;
        }), roots = {}, indexMinimal = createCommonjsModule(function(e, t2) {
          var r = t2;
          function i2() {
            r.util._configure(), r.Writer._configure(r.BufferWriter), r.Reader._configure(r.BufferReader);
          }
          r.build = "minimal", r.Writer = writer, r.BufferWriter = writer_buffer, r.Reader = reader, r.BufferReader = reader_buffer, r.util = minimal, r.rpc = rpc_1, r.roots = roots, (r.configure = i2)();
        }), minimal$1 = indexMinimal;
        minimal$1.util.Long = long_1, minimal$1.configure(), VectorTileFeature$1.prototype.loadGeometry = function(e) {
          var t2 = this._pbf;
          t2.pos = this._geometry;
          for (var r, i2, n = t2.readVarint() + t2.pos, o = 1, a2 = 0, s = 0, l = 0, u2 = []; t2.pos < n; ) {
            if (a2 <= 0 && (o = 7 & (i2 = t2.readVarint()), a2 = i2 >> 3), a2--, 1 === o || 2 === o)
              s += t2.readSVarint(), l += t2.readSVarint(), 1 === o && (r && u2.push(r), r = []), r.push([s * e, l * e]);
            else {
              if (7 !== o)
                throw new Error("unknown command " + o);
              r && r.push(r[0].slice());
            }
          }
          return r && u2.push(r), u2;
        };
        var MAX_SAFE_INTEGER = long_1.fromNumber(Number.MAX_SAFE_INTEGER, true), MIN_SAFE_INTEGER = long_1.fromNumber(Number.MIN_SAFE_INTEGER, false);
        function readLong(e, t2, r) {
          t2.pos = e.pos;
          var i2 = r.call(t2);
          return e.pos = t2.pos, long_1.isLong(i2) ? 0 < i2.comp(MAX_SAFE_INTEGER) || i2.comp(MIN_SAFE_INTEGER) < 0 ? i2.toString() : i2.toNumber() : i2;
        }
        var VectorTileLayer = function() {
          function r(e, t2) {
            _classCallCheck(this, r), this.version = 1, this.name = null, this.extent = 4096, this.length = 0, this._pbf = e, this._keys = [], this._values = [], this._features = [], this._protobufjsReader = minimal$1.Reader.create(e.buf), e.readFields(readLayer, this, t2), this.length = this._features.length;
          }
          return _createClass(r, [{ key: "feature", value: function(e) {
            if (e < 0 || e >= this._features.length)
              throw new Error("feature index out of bounds");
            this._pbf.pos = this._features[e];
            var t2 = this._pbf.readVarint() + this._pbf.pos;
            return new VectorTileFeature$1(this._pbf, t2, this.extent, this._keys, this._values);
          } }]), r;
        }();
        function readLayer(e, t2, r) {
          15 === e ? t2.version = r.readVarint() : 1 === e ? t2.name = r.readString() : 5 === e ? t2.extent = r.readVarint() : 2 === e ? t2._features.push(r.pos) : 3 === e ? t2._keys.push(r.readString()) : 4 === e && t2._values.push(readValueMessage(r, t2._protobufjsReader));
        }
        function readValueMessage(e, t2) {
          for (var r = null, i2 = e.readVarint() + e.pos; e.pos < i2; )
            var n = e.readVarint() >> 3, r = 1 == n ? e.readString() : 2 == n ? e.readFloat() : 3 == n ? e.readDouble() : 4 == n ? readLong(e, t2, t2.int64) : 5 == n ? readLong(e, t2, t2.uint64) : 6 == n ? readLong(e, t2, t2.sint64) : 7 == n ? e.readBoolean() : null;
          return r;
        }
        var VectorTile = function e(t2, r) {
          _classCallCheck(this, e), this.layers = t2.readFields(readTile, {}, r);
        };
        function readTile(e, t2, r) {
          var i2;
          3 !== e || (i2 = new VectorTileLayer(r, r.readVarint() + r.pos)).length && (t2[i2.name] = i2);
        }
        function getLayersFromMVT(e) {
          var t2 = {};
          for (var r in e.layers) {
            for (var i2 = e.layers[r], n = [], o = Geo$1.tile_scale / i2.extent, a2 = 0, s = i2.length; a2 < s; a2++) {
              var l = i2.feature(a2), u2 = VectorTileFeature$1.types[l.type], c2 = l.loadGeometry(o), h = null;
              switch (u2) {
                case "Point":
                  h = decodePoint({ coordinates: c2 });
                  break;
                case "LineString":
                  h = 1 === c2.length ? { type: u2, coordinates: c2[0] } : { type: "MultiLineString", coordinates: c2 };
                  break;
                case "Polygon":
                  h = decodeMultiPolygon({ coordinates: c2 });
              }
              h && h.coordinates && n.push({ type: "Feature", geometry: h, properties: l.properties });
            }
            t2[r] = { type: "FeatureCollection", features: n };
          }
          return t2;
        }
        var GeomType = { UNKNOWN: 0, POINT: 1, LINESTRING: 2, POLYGON: 3 };
        function parseGeoJSONVectorTile(e) {
          var t2 = [], r = e && e.features;
          if (r)
            for (var i2 = 0, n = r.length; i2 < n; i2++) {
              var o = r[i2], a2 = o.type, s = void 0;
              switch (a2) {
                case GeomType.POINT:
                  s = { type: "MultiPoint", coordinates: o.geometry.map(function(e2) {
                    return e2.slice();
                  }) };
                  break;
                case GeomType.LINESTRING:
                case GeomType.POLYGON:
                  if (s = { type: "MultiLineString", coordinates: o.geometry.map(function(e2) {
                    return e2.map(function(e3) {
                      return e3.slice();
                    });
                  }) }, a2 === GeomType.POLYGON && null == (s = decodeMultiPolygon(s)))
                    continue;
                  break;
                default:
                  continue;
              }
              t2.push({ id: o.id, type: "Feature", geometry: s, properties: o.tags });
            }
          return { type: "FeatureCollection", features: t2 };
        }
        function decodeMultiPolygon(e) {
          for (var t2, r = [], i2 = [], n = 0, o = e.coordinates.length; n < o; n++) {
            var a2 = e.coordinates[n], s = Geo$1.ringWinding(a2);
            null != s && (s === (t2 = t2 || s) && i2.length && (r.push(i2), i2 = []), i2.push(a2));
          }
          return 0 < i2.length && r.push(i2), 1 === r.length ? (e.type = "Polygon", e.coordinates = r[0]) : 1 < r.length ? (e.type = "MultiPolygon", e.coordinates = r) : e = null, e;
        }
        function decodePoint(e) {
          var t2 = e.coordinates.length;
          if (1 < t2) {
            e.type = "MultiPoint";
            for (var r = [], i2 = 0; i2 < t2; i2++)
              r.push(e.coordinates[i2][0]);
            e.coordinates = r;
          } else
            e.type = "Point", e.coordinates = e.coordinates[0][0];
          return e;
        }
        var EMPTY_FEATURE_COLLECTION = { type: "FeatureCollection", features: [] }, MVTSource = function() {
          _inherits(i2, MapsJsSource);
          var r = _createSuper(i2);
          function i2(e, t2) {
            return _classCallCheck(this, i2), e.tiled = true, r.call(this, e, t2);
          }
          return _createClass(i2, [{ key: "fetchTile", value: function(e, t2, r2) {
            return this.provider ? this.provider.requestTileAsPromise(e, t2, r2).then(function(e2) {
              return e2.data;
            }) : Promise.resolve();
          } }, { key: "_load", value: function(r2) {
            var i3 = this, e = Geo$1.wrapTile(r2.coords, { x: true, y: true }), t2 = e.x, n = e.y, o = e.z;
            return WorkerBroker.postMessage(this.target_name + ".fetchTile", t2, n, o).then(function(e2) {
              var t3;
              return e2 instanceof ArrayBuffer ? (t3 = new pbf(new Uint8Array(e2)), r2.source_data.layers = getLayersFromMVT(new VectorTile(t3))) : e2 ? r2.source_data.error = e2 : r2.source_data.layers = { _default: EMPTY_FEATURE_COLLECTION }, i3._postProcessTile(r2), r2;
            });
          } }, { key: "onReady", value: function() {
            this.dispatchUpdate();
          } }]), i2;
        }();
        DataSource.register(MVTSource, "MVT"), DataSource.register(MVTSource, "OMV");
        var csscolorparser = createCommonjsModule(function(e, t2) {
          var d = { transparent: [0, 0, 0, 0], aliceblue: [240, 248, 255, 1], antiquewhite: [250, 235, 215, 1], aqua: [0, 255, 255, 1], aquamarine: [127, 255, 212, 1], azure: [240, 255, 255, 1], beige: [245, 245, 220, 1], bisque: [255, 228, 196, 1], black: [0, 0, 0, 1], blanchedalmond: [255, 235, 205, 1], blue: [0, 0, 255, 1], blueviolet: [138, 43, 226, 1], brown: [165, 42, 42, 1], burlywood: [222, 184, 135, 1], cadetblue: [95, 158, 160, 1], chartreuse: [127, 255, 0, 1], chocolate: [210, 105, 30, 1], coral: [255, 127, 80, 1], cornflowerblue: [100, 149, 237, 1], cornsilk: [255, 248, 220, 1], crimson: [220, 20, 60, 1], cyan: [0, 255, 255, 1], darkblue: [0, 0, 139, 1], darkcyan: [0, 139, 139, 1], darkgoldenrod: [184, 134, 11, 1], darkgray: [169, 169, 169, 1], darkgreen: [0, 100, 0, 1], darkgrey: [169, 169, 169, 1], darkkhaki: [189, 183, 107, 1], darkmagenta: [139, 0, 139, 1], darkolivegreen: [85, 107, 47, 1], darkorange: [255, 140, 0, 1], darkorchid: [153, 50, 204, 1], darkred: [139, 0, 0, 1], darksalmon: [233, 150, 122, 1], darkseagreen: [143, 188, 143, 1], darkslateblue: [72, 61, 139, 1], darkslategray: [47, 79, 79, 1], darkslategrey: [47, 79, 79, 1], darkturquoise: [0, 206, 209, 1], darkviolet: [148, 0, 211, 1], deeppink: [255, 20, 147, 1], deepskyblue: [0, 191, 255, 1], dimgray: [105, 105, 105, 1], dimgrey: [105, 105, 105, 1], dodgerblue: [30, 144, 255, 1], firebrick: [178, 34, 34, 1], floralwhite: [255, 250, 240, 1], forestgreen: [34, 139, 34, 1], fuchsia: [255, 0, 255, 1], gainsboro: [220, 220, 220, 1], ghostwhite: [248, 248, 255, 1], gold: [255, 215, 0, 1], goldenrod: [218, 165, 32, 1], gray: [128, 128, 128, 1], green: [0, 128, 0, 1], greenyellow: [173, 255, 47, 1], grey: [128, 128, 128, 1], honeydew: [240, 255, 240, 1], hotpink: [255, 105, 180, 1], indianred: [205, 92, 92, 1], indigo: [75, 0, 130, 1], ivory: [255, 255, 240, 1], khaki: [240, 230, 140, 1], lavender: [230, 230, 250, 1], lavenderblush: [255, 240, 245, 1], lawngreen: [124, 252, 0, 1], lemonchiffon: [255, 250, 205, 1], lightblue: [173, 216, 230, 1], lightcoral: [240, 128, 128, 1], lightcyan: [224, 255, 255, 1], lightgoldenrodyellow: [250, 250, 210, 1], lightgray: [211, 211, 211, 1], lightgreen: [144, 238, 144, 1], lightgrey: [211, 211, 211, 1], lightpink: [255, 182, 193, 1], lightsalmon: [255, 160, 122, 1], lightseagreen: [32, 178, 170, 1], lightskyblue: [135, 206, 250, 1], lightslategray: [119, 136, 153, 1], lightslategrey: [119, 136, 153, 1], lightsteelblue: [176, 196, 222, 1], lightyellow: [255, 255, 224, 1], lime: [0, 255, 0, 1], limegreen: [50, 205, 50, 1], linen: [250, 240, 230, 1], magenta: [255, 0, 255, 1], maroon: [128, 0, 0, 1], mediumaquamarine: [102, 205, 170, 1], mediumblue: [0, 0, 205, 1], mediumorchid: [186, 85, 211, 1], mediumpurple: [147, 112, 219, 1], mediumseagreen: [60, 179, 113, 1], mediumslateblue: [123, 104, 238, 1], mediumspringgreen: [0, 250, 154, 1], mediumturquoise: [72, 209, 204, 1], mediumvioletred: [199, 21, 133, 1], midnightblue: [25, 25, 112, 1], mintcream: [245, 255, 250, 1], mistyrose: [255, 228, 225, 1], moccasin: [255, 228, 181, 1], navajowhite: [255, 222, 173, 1], navy: [0, 0, 128, 1], oldlace: [253, 245, 230, 1], olive: [128, 128, 0, 1], olivedrab: [107, 142, 35, 1], orange: [255, 165, 0, 1], orangered: [255, 69, 0, 1], orchid: [218, 112, 214, 1], palegoldenrod: [238, 232, 170, 1], palegreen: [152, 251, 152, 1], paleturquoise: [175, 238, 238, 1], palevioletred: [219, 112, 147, 1], papayawhip: [255, 239, 213, 1], peachpuff: [255, 218, 185, 1], peru: [205, 133, 63, 1], pink: [255, 192, 203, 1], plum: [221, 160, 221, 1], powderblue: [176, 224, 230, 1], purple: [128, 0, 128, 1], rebeccapurple: [102, 51, 153, 1], red: [255, 0, 0, 1], rosybrown: [188, 143, 143, 1], royalblue: [65, 105, 225, 1], saddlebrown: [139, 69, 19, 1], salmon: [250, 128, 114, 1], sandybrown: [244, 164, 96, 1], seagreen: [46, 139, 87, 1], seashell: [255, 245, 238, 1], sienna: [160, 82, 45, 1], silver: [192, 192, 192, 1], skyblue: [135, 206, 235, 1], slateblue: [106, 90, 205, 1], slategray: [112, 128, 144, 1], slategrey: [112, 128, 144, 1], snow: [255, 250, 250, 1], springgreen: [0, 255, 127, 1], steelblue: [70, 130, 180, 1], tan: [210, 180, 140, 1], teal: [0, 128, 128, 1], thistle: [216, 191, 216, 1], tomato: [255, 99, 71, 1], turquoise: [64, 224, 208, 1], violet: [238, 130, 238, 1], wheat: [245, 222, 179, 1], white: [255, 255, 255, 1], whitesmoke: [245, 245, 245, 1], yellow: [255, 255, 0, 1], yellowgreen: [154, 205, 50, 1] };
          function _(e2) {
            return (e2 = Math.round(e2)) < 0 ? 0 : 255 < e2 ? 255 : e2;
          }
          function r(e2) {
            return e2 < 0 ? 0 : 1 < e2 ? 1 : e2;
          }
          function p2(e2) {
            return "%" === e2[e2.length - 1] ? _(parseFloat(e2) / 100 * 255) : _(parseInt(e2));
          }
          function g(e2) {
            return "%" === e2[e2.length - 1] ? r(parseFloat(e2) / 100) : r(parseFloat(e2));
          }
          function m(e2, t3, r2) {
            return r2 < 0 ? r2 += 1 : 1 < r2 && --r2, 6 * r2 < 1 ? e2 + (t3 - e2) * r2 * 6 : 2 * r2 < 1 ? t3 : 3 * r2 < 2 ? e2 + (t3 - e2) * (2 / 3 - r2) * 6 : e2;
          }
          try {
            t2.parseCSSColor = function(e2) {
              var t3, r2 = e2.replace(/ /g, "").toLowerCase();
              if (r2 in d)
                return d[r2].slice();
              if ("#" === r2[0])
                return 4 === r2.length ? 0 <= (t3 = parseInt(r2.substr(1), 16)) && t3 <= 4095 ? [(3840 & t3) >> 4 | (3840 & t3) >> 8, 240 & t3 | (240 & t3) >> 4, 15 & t3 | (15 & t3) << 4, 1] : null : 7 === r2.length && 0 <= (t3 = parseInt(r2.substr(1), 16)) && t3 <= 16777215 ? [(16711680 & t3) >> 16, (65280 & t3) >> 8, 255 & t3, 1] : null;
              var i2 = r2.indexOf("("), n = r2.indexOf(")");
              if (-1 !== i2 && n + 1 === r2.length) {
                var o = r2.substr(0, i2), a2 = r2.substr(i2 + 1, n - (i2 + 1)).split(","), s = 1;
                switch (o) {
                  case "rgba":
                    if (4 !== a2.length)
                      return null;
                    s = g(a2.pop());
                  case "rgb":
                    return 3 !== a2.length ? null : [p2(a2[0]), p2(a2[1]), p2(a2[2]), s];
                  case "hsla":
                    if (4 !== a2.length)
                      return null;
                    s = g(a2.pop());
                  case "hsl":
                    if (3 !== a2.length)
                      return null;
                    var l = (parseFloat(a2[0]) % 360 + 360) % 360 / 360, u2 = g(a2[1]), c2 = g(a2[2]), h = c2 <= 0.5 ? c2 * (u2 + 1) : c2 + u2 - c2 * u2, f2 = 2 * c2 - h;
                    return [_(255 * m(f2, h, l + 1 / 3)), _(255 * m(f2, h, l)), _(255 * m(f2, h, l - 1 / 3)), s];
                  default:
                    return null;
                }
              }
              return null;
            };
          } catch (e2) {
          }
        }), csscolorparser_1 = csscolorparser.parseCSSColor, StyleParser = {}, clampPositive = function(e) {
          return Math.max(e, 0);
        }, noNaN = function(e) {
          return isNaN(e) ? 0 : e;
        }, parseNumber = function(e) {
          return Array.isArray(e) ? e.map(parseFloat).map(noNaN) : noNaN(parseFloat(e));
        }, parsePositiveNumber = function(e) {
          return Array.isArray(e) ? e.map(parseNumber).map(clampPositive) : clampPositive(parseNumber(e));
        };
        Object.assign(StyleParser, { clampPositive, noNaN, parseNumber, parsePositiveNumber }), StyleParser.wrapFunction = function(e) {
          return "\n        var feature = context.feature.properties;\n        var global = context.global;\n        var $zoom = context.zoom;\n        var $layer = context.layer;\n        var $source = context.source;\n        var sources = context.sources;\n        var $geometry = context.geometry;\n        var $meters_per_pixel = context.meters_per_pixel;\n\n        var val = (function(){ ".concat(e, " }());\n\n        if (typeof val === 'number' && isNaN(val)) {\n            val = null; // convert NaNs to nulls\n        }\n\n        return val;\n    ");
        }, StyleParser.zeroPair = Object.freeze([0, 0]), StyleParser.defaults = { color: [1, 1, 1, 1], width: 1, size: 1, extrude: false, height: 20, min_height: 0, order: 0, z: 0, outline: { color: [0, 0, 0, 0], width: 0 }, material: { ambient: 1, diffuse: 1 } }, StyleParser.macros = { "Style.color.pseudoRandomColor": function() {
          return [parseInt(feature.id, 16) / 100 % 1 * 0.7, parseInt(feature.id, 16) / 1e4 % 1 * 0.7, parseInt(feature.id, 16) / 1e6 % 1 * 0.7, 1];
        }, "Style.color.randomColor": function() {
          return [0.7 * Math.random(), 0.7 * Math.random(), 0.7 * Math.random(), 1];
        } }, StyleParser.getFeatureParseContext = function(e, t2, r, i2) {
          return { feature: e, tile: t2, global: r, sources: i2, zoom: t2.style_zoom, geometry: Geo$1.geometryType(e.geometry.type), meters_per_pixel: t2.meters_per_pixel, meters_per_pixel_sq: t2.meters_per_pixel_sq, units_per_meter_overzoom: t2.units_per_meter_overzoom };
        };
        var CACHE_TYPE = { STATIC: 0, DYNAMIC: 1, ZOOM: 2 };
        StyleParser.CACHE_TYPE = CACHE_TYPE, StyleParser.createPropertyCache = function(e) {
          var r = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : null;
          if (null != e) {
            if (e.value)
              return { value: e.value, zoom: e.zoom ? {} : null, type: e.type };
            var t2 = { value: e, type: CACHE_TYPE.STATIC };
            return Array.isArray(t2.value) && Array.isArray(t2.value[0]) ? (t2.zoom = {}, t2.type = CACHE_TYPE.ZOOM) : "function" == typeof t2.value && (t2.type = CACHE_TYPE.DYNAMIC), "function" == typeof r && (t2.zoom ? t2.value = t2.value.map(function(e2, t3) {
              return [e2[0], r(e2[1], t3)];
            }) : "function" != typeof t2.value && (t2.value = r(t2.value, 0))), t2;
          }
        }, StyleParser.createColorPropertyCache = function(e) {
          return StyleParser.createPropertyCache(e, function(e2) {
            return "Style.color.pseudoRandomColor" === e2 ? Utils$1.stringToFunction(StyleParser.wrapFunction(StyleParser.macros["Style.color.pseudoRandomColor"])) : "Style.color.randomColor" === e2 ? StyleParser.macros["Style.color.randomColor"] : e2;
          });
        };
        var isPercent = function(e) {
          return "string" == typeof e && "%" === e[e.length - 1];
        }, isRatio = function(e) {
          return "auto" === e;
        }, isComputed = function(e) {
          return isPercent(e) || isRatio(e);
        }, dualRatioError = "'size' can specify either width or height as derived from aspect ratio, but not both";
        StyleParser.createPointSizePropertyCache = function(e) {
          var t2 = null, r = null;
          if (isPercent(e))
            t2 = [true];
          else if (Array.isArray(e)) {
            if (Array.isArray(e[0])) {
              if (e.some(function(e2) {
                return Array.isArray(e2[1]) ? e2[1].some(function(e3) {
                  return isComputed(e3);
                }) : isPercent(e2[1]);
              }) && (t2 = e.map(function(e2) {
                return Array.isArray(e2[1]) ? e2[1].map(function(e3) {
                  return isPercent(e3);
                }) : isPercent(e2[1]);
              }), (r = e.map(function(e2) {
                return Array.isArray(e2[1]) && e2[1].map(function(e3) {
                  return isRatio(e3);
                });
              })).some(function(e2) {
                return Array.isArray(e2) && e2.every(function(e3) {
                  return e3;
                });
              })))
                throw dualRatioError;
            } else if (e.some(isComputed) && (t2 = [e.map(isPercent)], (r = [e.map(isRatio)])[0].every(function(e2) {
              return e2;
            })))
              throw dualRatioError;
          }
          return t2 ? ((e = { value: e }).has_pct = t2, e.has_ratio = r, e.sprites = {}) : e = StyleParser.createPropertyCache(e, parsePositiveNumber), e;
        }, StyleParser.evalCachedPointSizeProperty = function(i2, n, e) {
          return i2.has_pct || i2.has_ratio ? n ? (i2.sprites[n.sprite] || (i2.sprites[n.sprite] = StyleParser.createPropertyCache(i2.value, function(t2, r) {
            return Array.isArray(t2) ? (t2 = t2.map(function(e2, t3) {
              return i2.has_ratio[r][t3] ? e2 : parsePositiveNumber(e2);
            }).map(function(e2, t3) {
              return i2.has_pct[r][t3] ? n.css_size[t3] * e2 / 100 : e2;
            }), i2.has_ratio[r][0] ? t2[0] = t2[1] * n.aspect : i2.has_ratio[r][1] && (t2[1] = t2[0] / n.aspect)) : (t2 = parsePositiveNumber(t2), t2 = i2.has_pct[r] ? n.css_size.map(function(e2) {
              return e2 * t2 / 100;
            }) : [t2, t2]), t2;
          })), StyleParser.evalCachedProperty(i2.sprites[n.sprite], e)) : void 0 : StyleParser.evalCachedProperty(i2, e);
        }, StyleParser.evalCachedProperty = function(e, t2) {
          if (null != e)
            return e.dynamic ? e.dynamic(t2) : e.static ? e.static : e.zoom && e.zoom[t2.zoom] ? e.zoom[t2.zoom] : "function" != typeof e.value ? Array.isArray(e.value) && Array.isArray(e.value[0]) ? (e.zoom = e.zoom || {}, e.zoom[t2.zoom] = Utils$1.interpolate(t2.zoom, e.value), e.zoom[t2.zoom]) : (e.static = e.value, e.static) : (e.dynamic = e.value, e.dynamic(t2));
        }, StyleParser.convertUnits = function(e, t2) {
          if (null != e.val)
            return "px" === e.units ? e.val * Geo$1.metersPerPixel(t2.zoom) : e.val;
          if ("string" == typeof e)
            "px" === e.trim().slice(-2) ? (e = parseNumber(e), e *= Geo$1.metersPerPixel(t2.zoom)) : e = parseNumber(e);
          else if (Array.isArray(e))
            return Array.isArray(e[0]) ? e.map(function(e2) {
              return [e2[0], StyleParser.convertUnits(e2[1], t2)];
            }) : e.map(function(e2) {
              return StyleParser.convertUnits(e2, t2);
            });
          return e;
        }, StyleParser.parseUnits = function(e) {
          var t2 = { val: parseNumber(e) };
          return 0 !== t2.val && "string" == typeof e && "px" === e.trim().slice(-2) && (t2.units = "px"), t2;
        }, StyleParser.evalCachedDistanceProperty = function(e, t2) {
          return e.dynamic ? e.dynamic(t2) : e.zoom && e.zoom[t2.zoom] ? e.zoom[t2.zoom] : "function" != typeof e.value ? e.zoom ? (e.zoom[t2.zoom] = Utils$1.interpolate(t2.zoom, e.value, function(e2) {
            return StyleParser.convertUnits(e2, t2);
          }), e.zoom[t2.zoom]) : StyleParser.convertUnits(e.value, t2) : (e.dynamic = e.value, e.dynamic(t2));
        }, StyleParser.string_colors = {}, StyleParser.colorForString = function(e) {
          if (StyleParser.string_colors[e])
            return StyleParser.string_colors[e];
          var t2 = null;
          return "none" !== e && ((t2 = csscolorparser.parseCSSColor(e)) && 4 === t2.length ? (t2[0] /= 255, t2[1] /= 255, t2[2] /= 255) : t2 = StyleParser.defaults.color), StyleParser.string_colors[e] = t2;
        }, StyleParser.evalCachedColorProperty = function(e) {
          var t2 = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {};
          if (e.dynamic) {
            var r = e.dynamic(t2);
            return "string" == typeof r && (r = StyleParser.colorForString(r)), r && null == r[3] && (r[3] = 1), r;
          }
          if (e.static)
            return e.static;
          if (e.zoom && e.zoom[t2.zoom])
            return e.zoom[t2.zoom];
          if ("function" == typeof e.value) {
            e.dynamic = e.value;
            var i2 = e.dynamic(t2);
            return "string" == typeof i2 && (i2 = StyleParser.colorForString(i2)), i2 && null == i2[3] && (i2[3] = 1), i2;
          }
          if ("string" == typeof e.value)
            return e.static = StyleParser.colorForString(e.value), e.static;
          if (e.zoom) {
            if (!e.zoom_preprocessed) {
              for (var n = 0; n < e.value.length; n++) {
                var o = e.value[n];
                o && "string" == typeof o[1] && (o[1] = StyleParser.colorForString(o[1]));
              }
              e.zoom_preprocessed = true;
            }
            return e.zoom[t2.zoom] = Utils$1.interpolate(t2.zoom, e.value), e.zoom[t2.zoom][3] = e.zoom[t2.zoom][3] || 1, e.zoom[t2.zoom];
          }
          return e.static = e.value.map(function(e2) {
            return e2;
          }), e.static && null == e.static[3] && (e.static[3] = 1), e.static;
        }, StyleParser.parseColor = function(e) {
          var t2 = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {};
          if ("function" == typeof e && (e = e(t2)), "string" == typeof e)
            e = StyleParser.colorForString(e);
          else if (Array.isArray(e) && Array.isArray(e[0])) {
            for (var r = 0; r < e.length; r++) {
              var i2 = e[r];
              "string" == typeof i2[1] && (i2[1] = StyleParser.colorForString(i2[1]));
            }
            t2.zoom && (e = Utils$1.interpolate(t2.zoom, e));
          }
          return Array.isArray(e) ? null == (e = e.map(function(e2) {
            return e2;
          }))[3] && (e[3] = 1) : e = [0, 0, 0, 1], e;
        }, StyleParser.calculateOrder = function(e, t2) {
          return "function" == typeof e ? e = e(t2) : "string" == typeof e && (e = t2.feature.properties[e] ? t2.feature.properties[e] : parsePositiveNumber(e)), e;
        }, StyleParser.evalProperty = function(e, t2) {
          return "function" == typeof e ? e(t2) : e;
        };
        var RepeatGroup = function() {
          function i2(e, t2) {
            _classCallCheck(this, i2), this.key = e, this.repeat_dist = t2, this.repeat_dist_sq = this.repeat_dist * this.repeat_dist, this.positions = [];
          }
          return _createClass(i2, [{ key: "check", value: function(e) {
            for (var t2 = e.position, r = 0; r < this.positions.length; r++) {
              var i3 = this.positions[r], n = t2[0] - i3[0], o = t2[1] - i3[1], a2 = n * n + o * o;
              if (a2 < this.repeat_dist_sq)
                return { dist_sq: a2, repeat_dist_sq: this.repeat_dist_sq };
            }
          } }, { key: "add", value: function(e) {
            e && e.position && this.positions.push(e.position);
          } }], [{ key: "clear", value: function(e) {
            this.groups[e] = {};
          } }, { key: "check", value: function(e, t2, r) {
            if (t2.repeat_distance && t2.repeat_group && this.groups[r][t2.repeat_group])
              return this.groups[r][t2.repeat_group].check(e);
          } }, { key: "add", value: function(e, t2, r) {
            t2.repeat_distance && t2.repeat_group && (null == this.groups[r][t2.repeat_group] && (this.groups[r][t2.repeat_group] = new i2(t2.repeat_group, t2.repeat_distance * t2.repeat_scale)), this.groups[r][t2.repeat_group].add(e));
          } }]), i2;
        }();
        RepeatGroup.groups = {};
        var GridIndex = function() {
          function a2(e, t2, r) {
            _classCallCheck(this, a2);
            var i2 = this.boxCells = [], n = this.circleCells = [];
            this.xCellCount = Math.ceil(e / r), this.yCellCount = Math.ceil(t2 / r);
            for (var o = 0; o < this.xCellCount * this.yCellCount; o++)
              i2.push([]), n.push([]);
            this.circleKeys = [], this.boxKeys = [], this.bboxes = [], this.circles = [], this.width = e, this.height = t2, this.xScale = this.xCellCount / e, this.yScale = this.yCellCount / t2, this.boxUid = 0, this.circleUid = 0;
          }
          return _createClass(a2, [{ key: "keysLength", value: function() {
            return this.boxKeys.length + this.circleKeys.length;
          } }, { key: "insert", value: function(e, t2, r, i2, n) {
            this._forEachCell(t2, r, i2, n, this._insertBoxCell, this.boxUid++), this.boxKeys.push(e), this.bboxes.push(t2), this.bboxes.push(r), this.bboxes.push(i2), this.bboxes.push(n);
          } }, { key: "insertCircle", value: function(e, t2, r, i2) {
            this._forEachCell(t2 - i2, r - i2, t2 + i2, r + i2, this._insertCircleCell, this.circleUid++), this.circleKeys.push(e), this.circles.push(t2), this.circles.push(r), this.circles.push(i2);
          } }, { key: "insertCircleList", value: function(e, t2) {
            for (var r = 0; r < t2.length - 2; r += 3)
              this.insertCircle("".concat(e, "/").concat(r), t2[r], t2[r + 1], t2[r + 2]);
          } }, { key: "_insertBoxCell", value: function(e, t2, r, i2, n, o) {
            this.boxCells[n].push(o);
          } }, { key: "_insertCircleCell", value: function(e, t2, r, i2, n, o) {
            this.circleCells[n].push(o);
          } }, { key: "_query", value: function(e, t2, r, i2, n, o) {
            if (r < 0 || e > this.width || i2 < 0 || t2 > this.height)
              return !n && [];
            var a3 = [];
            if (e <= 0 && t2 <= 0 && this.width <= r && this.height <= i2) {
              if (n)
                return true;
              for (var s = 0; s < this.boxKeys.length; s++)
                a3.push({ key: this.boxKeys[s], x1: this.bboxes[4 * s], y1: this.bboxes[4 * s + 1], x2: this.bboxes[4 * s + 2], y2: this.bboxes[4 * s + 3] });
              for (var l = 0; l < this.circleKeys.length; l++) {
                var u2 = this.circles[3 * l], c2 = this.circles[3 * l + 1], h = this.circles[3 * l + 2];
                a3.push({ key: this.circleKeys[l], x1: u2 - h, y1: c2 - h, x2: u2 + h, y2: c2 + h });
              }
              return o ? a3.filter(o) : a3;
            }
            var f2 = { hitTest: n, seenUids: { box: {}, circle: {} } };
            return this._forEachCell(e, t2, r, i2, this._queryCell, a3, f2, o), n ? 0 < a3.length : a3;
          } }, { key: "_queryCircle", value: function(e, t2, r, i2, n) {
            var o = e - r, a3 = e + r, s = t2 - r, l = t2 + r;
            if (a3 < 0 || o > this.width || l < 0 || s > this.height)
              return !i2 && [];
            var u2 = [], c2 = { hitTest: i2, circle: { x: e, y: t2, radius: r }, seenUids: { box: {}, circle: {} } };
            return this._forEachCell(o, s, a3, l, this._queryCellCircle, u2, c2, n), i2 ? 0 < u2.length : u2;
          } }, { key: "query", value: function(e, t2, r, i2, n) {
            return this._query(e, t2, r, i2, false, n);
          } }, { key: "hitTest", value: function(e, t2, r, i2, n) {
            return this._query(e, t2, r, i2, true, n);
          } }, { key: "hitTestCircle", value: function(e, t2, r, i2) {
            return this._queryCircle(e, t2, r, true, i2);
          } }, { key: "hitTestCircleList", value: function(e, t2) {
            for (var r = 0; r < e.length - 2; r += 3)
              if (this.hitTestCircle(e[r], e[r + 1], e[r + 2], t2))
                return true;
            return false;
          } }, { key: "_queryCell", value: function(e, t2, r, i2, n, o, a3, s) {
            var l = a3.seenUids, u2 = this.boxCells[n];
            if (null !== u2) {
              var c2, h = this.bboxes, f2 = _createForOfIteratorHelper(u2);
              try {
                for (f2.s(); !(c2 = f2.n()).done; ) {
                  var d = c2.value;
                  if (!l.box[d]) {
                    l.box[d] = true;
                    var _ = 4 * d;
                    if (e <= h[2 + _] && t2 <= h[3 + _] && r >= h[0 + _] && i2 >= h[1 + _] && (!s || s(this.boxKeys[d]))) {
                      if (a3.hitTest)
                        return o.push(true), true;
                      o.push({ key: this.boxKeys[d], x1: h[_], y1: h[1 + _], x2: h[2 + _], y2: h[3 + _] });
                    }
                  }
                }
              } catch (e2) {
                f2.e(e2);
              } finally {
                f2.f();
              }
            }
            var p2 = this.circleCells[n];
            if (null !== p2) {
              var g, m = this.circles, y = _createForOfIteratorHelper(p2);
              try {
                for (y.s(); !(g = y.n()).done; ) {
                  var v = g.value;
                  if (!l.circle[v]) {
                    l.circle[v] = true;
                    var x2 = 3 * v;
                    if (this._circleAndRectCollide(m[x2], m[1 + x2], m[2 + x2], e, t2, r, i2) && (!s || s(this.circleKeys[v]))) {
                      if (a3.hitTest)
                        return o.push(true), true;
                      var b2 = m[x2], T2 = m[1 + x2], A2 = m[2 + x2];
                      o.push({ key: this.circleKeys[v], x1: b2 - A2, y1: T2 - A2, x2: b2 + A2, y2: T2 + A2 });
                    }
                  }
                }
              } catch (e2) {
                y.e(e2);
              } finally {
                y.f();
              }
            }
          } }, { key: "_queryCellCircle", value: function(e, t2, r, i2, n, o, a3, s) {
            var l = a3.circle, u2 = a3.seenUids, c2 = this.boxCells[n];
            if (null !== c2) {
              var h, f2 = this.bboxes, d = _createForOfIteratorHelper(c2);
              try {
                for (d.s(); !(h = d.n()).done; ) {
                  var _ = h.value;
                  if (!u2.box[_]) {
                    u2.box[_] = true;
                    var p2 = 4 * _;
                    if (this._circleAndRectCollide(l.x, l.y, l.radius, f2[0 + p2], f2[1 + p2], f2[2 + p2], f2[3 + p2]) && (!s || s(this.boxKeys[_])))
                      return o.push(true), true;
                  }
                }
              } catch (e2) {
                d.e(e2);
              } finally {
                d.f();
              }
            }
            var g = this.circleCells[n];
            if (null !== g) {
              var m, y = this.circles, v = _createForOfIteratorHelper(g);
              try {
                for (v.s(); !(m = v.n()).done; ) {
                  var x2 = m.value;
                  if (!u2.circle[x2]) {
                    u2.circle[x2] = true;
                    var b2 = 3 * x2;
                    if (this._circlesCollide(y[b2], y[1 + b2], y[2 + b2], l.x, l.y, l.radius) && (!s || s(this.circleKeys[x2])))
                      return o.push(true), true;
                  }
                }
              } catch (e2) {
                v.e(e2);
              } finally {
                v.f();
              }
            }
          } }, { key: "_forEachCell", value: function(e, t2, r, i2, n, o, a3, s) {
            for (var l = this._convertToXCellCoord(e), u2 = this._convertToYCellCoord(t2), c2 = this._convertToXCellCoord(r), h = this._convertToYCellCoord(i2), f2 = l; f2 <= c2; f2++)
              for (var d = u2; d <= h; d++) {
                var _ = this.xCellCount * d + f2;
                if (n.call(this, e, t2, r, i2, _, o, a3, s))
                  return;
              }
          } }, { key: "_convertToXCellCoord", value: function(e) {
            return Math.max(0, Math.min(this.xCellCount - 1, Math.floor(e * this.xScale)));
          } }, { key: "_convertToYCellCoord", value: function(e) {
            return Math.max(0, Math.min(this.yCellCount - 1, Math.floor(e * this.yScale)));
          } }, { key: "_circlesCollide", value: function(e, t2, r, i2, n, o) {
            var a3 = i2 - e, s = n - t2, l = r + o;
            return a3 * a3 + s * s < l * l;
          } }, { key: "_circleAndRectCollide", value: function(e, t2, r, i2, n, o, a3) {
            var s = (o - i2) / 2, l = Math.abs(e - (i2 + s));
            if (s + r < l)
              return false;
            var u2 = (a3 - n) / 2, c2 = Math.abs(t2 - (n + u2));
            if (u2 + r < c2)
              return false;
            if (l <= s || c2 <= u2)
              return true;
            var h = l - s, f2 = c2 - u2;
            return h * h + f2 * f2 <= r * r;
          } }]), a2;
        }(), CollisionUtils = { toDiscardLabel: function(e, t2, r, i2) {
          var n;
          if (i2 && (n = function(e2) {
            return e2 !== i2.id;
          }), !t2) {
            if ("point" === e.type && !e.angle) {
              var o = e.getAABB(), a2 = o.left, s = o.top, l = o.right, u2 = o.bottom;
              if (r.hitTest(a2, -s, l, -u2, n)) {
                if (Array.isArray(e.layout.anchor))
                  for (var c2 = 1; c2 < e.layout.anchor.length; c2++) {
                    e.setAnchor(e.layout.anchor[c2]);
                    var h = e.getAABB(), f2 = h.left, d = h.top, _ = h.right, p2 = h.bottom;
                    if (!r.hitTest(f2, -d, _, -p2, n))
                      return false;
                  }
                return true;
              }
              return false;
            }
            var g = e.getBoundingCircles();
            return r.hitTestCircleList(g, n);
          }
          if (t2) {
            if ("point" === e.type && !e.isFlat()) {
              var m = e.getScreenSpaceBoundingBox(), y = m.left, v = m.top, x2 = m.right, b2 = m.bottom;
              return r.hitTest(y, v, x2, b2, n);
            }
            var T2 = e.getBoundingCircles();
            return r.hitTestCircleList(T2, n);
          }
          return false;
        }, addLabel: function(e, t2, r) {
          var i2, n, o, a2, s, l, u2, c2, h, f2, d, _, p2 = e.id;
          e.placed = true, t2 || ("point" !== e.type || e.angle ? (i2 = e.getBoundingCircles(), r.insertCircleList(p2, i2)) : (o = (n = e.getAABB()).left, a2 = n.top, s = n.right, l = n.bottom, r.insert(p2, o, -a2, s, -l))), t2 && ("point" !== e.type || e.isFlat() ? (u2 = e.getBoundingCircles(), r.insertCircleList(p2, u2)) : (h = (c2 = e.getScreenSpaceBoundingBox()).left, f2 = c2.top, d = c2.right, _ = c2.bottom, r.insert(p2, h, f2, d, _)));
        } }, Collision = { tiles: {}, startTile: function(e, t2) {
          var r = 1 < arguments.length && void 0 !== t2 ? t2 : {}, i2 = r.apply_repeat_groups, n = void 0 === i2 || i2, o = r.return_hidden, a2 = void 0 !== o && o, s = r.grid_index, l = void 0 === s ? null : s, u2 = this.tiles[e] = { grid_index: l || new GridIndex(Geo$1.tile_scale, Geo$1.tile_scale, 240), objects: {}, labels: {}, styles: {}, repeat: n, return_hidden: a2 };
          null == u2.complete && (u2.complete = new Promise(function(e2, t3) {
            u2.resolve = e2, u2.reject = t3;
          }));
        }, resetTile: function(e) {
          delete this.tiles[e];
        }, abortTile: function(e) {
          this.tiles[e] && this.tiles[e].resolve && this.tiles[e].resolve([]), this.resetTile(e);
        }, addStyle: function(e, t2) {
          this.tiles[t2].styles[e] = true;
        }, collide: function(e, t2, r) {
          var i2 = this.tiles[r];
          if (!i2)
            return Promise.resolve([]);
          for (var n = i2.objects, o = 0; o < e.length; o++) {
            var a2 = e[o], s = a2.label.layout.priority;
            n[s] = n[s] || {}, n[s][t2] = n[s][t2] || [], n[s][t2].push(a2);
          }
          return delete i2.styles[t2], 0 === Object.keys(i2.styles).length && this.endTile(r), i2.complete.then(function() {
            return i2.resolve = null, i2.labels[t2] || [];
          });
        }, endTile: function(e) {
          var t2 = this.tiles[e], r = t2.labels;
          t2.repeat && RepeatGroup.clear(e);
          for (var i2 = Object.keys(t2.objects).sort(function(e2, t3) {
            return e2 - t3;
          }), n = 0; n < i2.length; n++) {
            var o = t2.objects[i2[n]];
            if (o)
              for (var a2 in o) {
                var s = o[a2];
                r[a2] = r[a2] || [];
                for (var l = 0; l < s.length; l++) {
                  var u2 = s[l];
                  this.canBePlaced(u2, e, u2.linked, t2) ? u2.linked ? this.canBePlaced(u2.linked, e, u2, t2) ? (u2.show = true, (u2.label.breach || u2.linked.label.breach) && (u2.label.breach = true, u2.linked.label.breach = true), r[a2].push(u2), this.place(u2, e, t2), this.place(u2.linked, e, t2)) : t2.return_hidden && (u2.show = false, r[a2].push(u2)) : (u2.show = true, r[a2].push(u2), this.place(u2, e, t2)) : t2.return_hidden && (u2.show = false, r[a2].push(u2));
                }
              }
          }
          delete this.tiles[e], t2.resolve();
        }, canBePlaced: function(e, t2, r, i2) {
          var n = 2 < arguments.length && void 0 !== r ? r : null, o = (3 < arguments.length && void 0 !== i2 ? i2 : {}).repeat, a2 = void 0 === o || o, s = e.label, l = e.label.layout;
          if (null !== s.placed)
            return s.placed;
          var u2 = this.tiles[t2].grid_index;
          if (l.collide && CollisionUtils.toDiscardLabel(s, "main" === t2, u2, n && n.label))
            l.collide && (s.placed = false);
          else {
            if (!(a2 && RepeatGroup.check(s, l, t2)))
              return true;
            s.placed = false;
          }
          return s.placed;
        }, place: function(e, t2, r) {
          var i2 = e.label, n = r.repeat, o = void 0 === n || n;
          null === i2.placed && (o && RepeatGroup.add(i2, i2.layout, t2), CollisionUtils.addLabel(i2, "main" === t2, this.tiles[t2].grid_index));
        } }, Task = { id: 0, queue: [], max_time: 20, start_time: null, state: {}, ignore_user_moving_view: false, _ignoreViewMoveWithDebounce: debounce(function() {
          Task.ignore_user_moving_view = true;
        }, 0, 500), add: function(r) {
          r.id = Task.id++, r.max_time = r.max_time || Task.max_time, r.pause_factor = r.pause_factor || 1;
          var e = new Promise(function(e2, t2) {
            r.resolve = e2, r.reject = t2;
          });
          return r.promise = e, r.total_elapsed = 0, r.stats = { calls: 0 }, this.queue.push(r), this.start_time = this.start_time || performance.now(), this.elapsed = performance.now() - this.start_time, this.elapsed < Task.max_time && this.process(r), r.promise;
        }, remove: function(e) {
          var t2 = this.queue.indexOf(e);
          -1 < t2 && this.queue.splice(t2, 1);
        }, process: function(e) {
          if (!this.state.user_moving_view || false !== e.user_moving_view || this.ignore_user_moving_view)
            return e.pause ? (e.pause--, true) : (e.stats.calls++, e.start_time = performance.now(), e.run(e));
          Task._ignoreViewMoveWithDebounce();
        }, processAll: function() {
          this.start_time = this.start_time || performance.now(), this.ignore_user_moving_view && !this.hasPendingTasks() && (this.ignore_user_moving_view = false);
          for (var e = 0; e < this.queue.length; e++) {
            var t2 = this.queue[e];
            if (true !== this.process(t2) && (t2.pause || (t2.pause = t2.elapsed > t2.max_time ? t2.pause_factor : 0), t2.total_elapsed += t2.elapsed), this.elapsed = performance.now() - this.start_time, this.elapsed >= Task.max_time) {
              this.start_time = null;
              break;
            }
          }
        }, finish: function(e, t2) {
          return e.elapsed = performance.now() - e.start_time, e.total_elapsed += e.elapsed, this.remove(e), e.resolve(t2), e.promise;
        }, cancel: function(e) {
          var t2;
          e.cancel instanceof Function && (t2 = e.cancel(e)), e.resolve(t2 || {});
        }, shouldContinue: function(e) {
          return e.elapsed = performance.now() - e.start_time, this.elapsed = performance.now() - this.start_time, e.elapsed < e.max_time && this.elapsed < Task.max_time;
        }, removeForTile: function(e) {
          for (var t2 = this.queue.length - 1; 0 <= t2; t2--)
            this.queue[t2].tile_id === e && (this.cancel(this.queue[t2]), this.queue.splice(t2, 1));
        }, setState: function(e) {
          this.state = e;
        }, hasPendingTasks: function() {
          return !!this.queue.length;
        } };
        function sliceOptions(e) {
          return { coords: e.coords, uid: e.uid, filtering: e.filtering, sprites: e.sprites, url: e.url, element: e.element, data: e.data, width: e.width, height: e.height, density: e.density, repeat: e.repeat, TEXTURE_WRAP_S: e.TEXTURE_WRAP_S, TEXTURE_WRAP_T: e.TEXTURE_WRAP_T, UNPACK_FLIP_Y_WEBGL: e.UNPACK_FLIP_Y_WEBGL, UNPACK_PREMULTIPLY_ALPHA_WEBGL: e.UNPACK_PREMULTIPLY_ALPHA_WEBGL };
        }
        var Texture = function() {
          function n(e, t2, r) {
            var i2 = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : {};
            _classCallCheck(this, n), i2 = sliceOptions(i2), this.gl = e, this.texture = e.createTexture(), this.texture && (this.valid = true), this.manager = r, this.bind(), this.name = t2, this.retain_count = 0, this.config_type = null, this.loading = null, this.loaded = false, this.filtering = i2.filtering, this.density = i2.density || 1, this.sprites = i2.sprites, this.texcoords = {}, this.sizes = {}, this.css_sizes = {}, this.aspects = {}, this._byte_length = 0, this.setData(1, 1, new Uint8Array([0, 0, 0, 0]), { filtering: "nearest" }), this.loaded = false, this.manager.textures[this.name] && (this.retain_count = this.manager.textures[this.name].retain_count, this.manager.textures[this.name].retain_count = 0, this.manager.textures[this.name].destroy()), (this.manager.textures[this.name] = this).manager.texture_configs[this.name] = JSON.stringify(Object.assign({ name: t2 }, i2)), this.load(i2), log("trace", "creating Texture ".concat(this.name));
          }
          return _createClass(n, [{ key: "destroy", value: function(e) {
            var t2 = (0 < arguments.length && void 0 !== e ? e : {}).force;
            0 < this.retain_count && !t2 ? log("error", "Texture '".concat(this.name, "': destroying texture with retain count of '").concat(this.retain_count, "'")) : this.valid && (this.gl.deleteTexture(this.texture), this.texture = null, delete this.data, this.data = null, delete this.manager.textures[this.name], delete this.manager.texture_configs[this.name], this.valid = false, this._byte_length = 0, log("trace", "destroying Texture ".concat(this.name)));
          } }, { key: "retain", value: function() {
            this.retain_count++;
          } }, { key: "release", value: function() {
            this.retain_count <= 0 && log("error", "Texture '".concat(this.name, "': releasing texture with retain count of '").concat(this.retain_count, "'")), this.retain_count--, this.retain_count <= 0 && this.destroy();
          } }, { key: "bind", value: function(e) {
            var t2 = 0 < arguments.length && void 0 !== e ? e : 0;
            this.valid && (this.manager.activeUnit !== t2 && (this.gl.activeTexture(this.gl.TEXTURE0 + t2), this.manager.activeUnit = t2, this.manager.boundTexture = null), this.manager.boundTexture !== this.texture && (this.gl.bindTexture(this.gl.TEXTURE_2D, this.texture), this.manager.boundTexture = this.texture));
          } }, { key: "load", value: function(e) {
            var t2 = this;
            return e ? (this.loading = null, "string" == typeof e.url ? (this.config_type = "url", this.setUrl(e.url, e)) : e.element ? (this.config_type = "element", this.setElement(e.element, e)) : e.data && e.width && e.height && (this.config_type = "data", this.setData(e.width, e.height, e.data, e)), this.loading = this.loading && this.loading.then(function() {
              return t2.calculateSprites(), t2;
            }) || Promise.resolve(this), this.loading) : this.loading || Promise.resolve(this);
          } }, { key: "setUrl", value: function(e, t2) {
            var i2 = this, n2 = 1 < arguments.length && void 0 !== t2 ? t2 : {};
            if (this.valid)
              return this.url = e, this.loading = new Promise(function(t3, e2) {
                var r = new Image();
                r.onload = function() {
                  try {
                    i2.setElement(r, n2);
                  } catch (e3) {
                    i2.loaded = false, log("warn", "Texture '".concat(i2.name, "': failed to load url: '").concat(i2.url, "'"), e3, n2), i2.manager.trigger("warning", { message: "Failed to load texture from ".concat(i2.url), error: e3, texture: n2 });
                  }
                  i2.loaded = true, t3(i2);
                }, r.onerror = function(e3) {
                  i2.loaded = false, log("warn", "Texture '".concat(i2.name, "': failed to load url: '").concat(i2.url, "'"), e3, n2), i2.manager.trigger("warning", { message: "Failed to load texture from ".concat(i2.url), error: e3, texture: n2 }), t3(i2);
                }, Utils$1.isSafari() && "data:" === i2.url.slice(0, 5) || (r.crossOrigin = "anonymous"), r.src = i2.url;
              }), this.loading;
          } }, { key: "setData", value: function(e, t2, r, i2) {
            var n2 = 3 < arguments.length && void 0 !== i2 ? i2 : {};
            return this.width = e, this.height = t2, Array.isArray(r) && (r = new Uint8Array(r)), this.update(r, n2), this.setFiltering(n2), this.loaded = true, this.loading = Promise.resolve(this), this.loading;
          } }, { key: "setElement", value: function(e, t2) {
            var r, i2 = e;
            return "string" == typeof e && (e = document.querySelector(e)), e instanceof HTMLCanvasElement || e instanceof HTMLImageElement || e instanceof HTMLVideoElement ? (this.update(e, t2), this.setFiltering(t2)) : (this.loaded = false, r = "the 'element' parameter (`element: ".concat(JSON.stringify(i2), "`) must be a CSS "), r += "selector string, or a <canvas>, <image> or <video> object", log("warn", "Texture '".concat(this.name, "': ").concat(r), t2), this.manager.trigger("warning", { message: "Failed to load texture because ".concat(r), texture: t2 })), this.loaded = true, this.loading = Promise.resolve(this), this.loading;
          } }, { key: "update", value: function(e, t2) {
            var r = 1 < arguments.length && void 0 !== t2 ? t2 : {};
            this.valid && (this.bind(), e instanceof HTMLCanvasElement || e instanceof HTMLVideoElement || e instanceof HTMLImageElement && e.complete ? (this.width = e.width, this.height = e.height, this._byte_length = this.width * this.height * 4, this.gl.pixelStorei(this.gl.UNPACK_FLIP_Y_WEBGL, false !== r.UNPACK_FLIP_Y_WEBGL), this.gl.pixelStorei(this.gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, r.UNPACK_PREMULTIPLY_ALPHA_WEBGL || false), this.gl.texImage2D(this.gl.TEXTURE_2D, 0, this.gl.RGBA, this.gl.RGBA, this.gl.UNSIGNED_BYTE, e)) : (this._byte_length = e ? e.byteLength : 0, this.gl.pixelStorei(this.gl.UNPACK_FLIP_Y_WEBGL, false), this.gl.pixelStorei(this.gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false), this.gl.texImage2D(this.gl.TEXTURE_2D, 0, this.gl.RGBA, this.width, this.height, 0, this.gl.RGBA, this.gl.UNSIGNED_BYTE, e)), this.manager.trigger("update", this));
          } }, { key: "getByteLength", value: function() {
            return this._byte_length;
          } }, { key: "setFiltering", value: function(e) {
            var t2, r = 0 < arguments.length && void 0 !== e ? e : {};
            this.valid && (r.filtering = r.filtering || "linear", t2 = this.gl, this.bind(), Utils$1.isPowerOf2(this.width) && Utils$1.isPowerOf2(this.height) ? (this.power_of_2 = true, t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_WRAP_S, r.TEXTURE_WRAP_S || r.repeat && t2.REPEAT || t2.CLAMP_TO_EDGE), t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_WRAP_T, r.TEXTURE_WRAP_T || r.repeat && t2.REPEAT || t2.CLAMP_TO_EDGE), "mipmap" === r.filtering ? (this.filtering = "mipmap", t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_MIN_FILTER, t2.LINEAR_MIPMAP_LINEAR), t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_MAG_FILTER, t2.LINEAR), t2.generateMipmap(t2.TEXTURE_2D)) : "linear" === r.filtering ? (this.filtering = "linear", t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_MIN_FILTER, t2.LINEAR), t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_MAG_FILTER, t2.LINEAR)) : "nearest" === r.filtering && (this.filtering = "nearest", t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_MIN_FILTER, t2.NEAREST), t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_MAG_FILTER, t2.NEAREST))) : (this.power_of_2 = false, t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_WRAP_S, t2.CLAMP_TO_EDGE), t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_WRAP_T, t2.CLAMP_TO_EDGE), "nearest" === r.filtering ? (this.filtering = "nearest", t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_MIN_FILTER, t2.NEAREST), t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_MAG_FILTER, t2.NEAREST)) : (this.filtering = "linear", t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_MIN_FILTER, t2.LINEAR), t2.texParameteri(t2.TEXTURE_2D, t2.TEXTURE_MAG_FILTER, t2.LINEAR))), this.manager.trigger("update", this));
          } }, { key: "calculateSprites", value: function() {
            if (this.sprites)
              for (var e in this.sprites) {
                var t2 = this.sprites[e];
                this.texcoords[e] = this.manager.getTexcoordsForSprite([t2[0], t2[1]], [t2[2], t2[3]], [this.width, this.height]), this.sizes[e] = [t2[2], t2[3]], this.css_sizes[e] = [t2[2] / this.density, t2[3] / this.density], this.aspects[e] = t2[2] / t2[3];
              }
          } }]), n;
        }();
        function subscribeMixin(e) {
          var n = [];
          return Object.assign(e, { subscribe: function(e2) {
            -1 === n.indexOf(e2) && n.push(e2);
          }, unsubscribe: function(e2) {
            var t2 = n.indexOf(e2);
            -1 < t2 && n.splice(t2, 1);
          }, unsubscribeAll: function() {
            n = [];
          }, trigger: function(t2) {
            for (var e2 = arguments.length, r = new Array(1 < e2 ? e2 - 1 : 0), i2 = 1; i2 < e2; i2++)
              r[i2 - 1] = arguments[i2];
            n.forEach(function(e3) {
              if ("function" == typeof e3[t2])
                try {
                  e3[t2].apply(e3, r);
                } catch (e4) {
                  log("warn", "Caught exception in listener for event '".concat(t2, "':"), e4);
                }
            });
          }, hasSubscribersFor: function(t2) {
            var r = false;
            return n.forEach(function(e2) {
              "function" == typeof e2[t2] && (r = true);
            }), r;
          } });
        }
        var TextureManager = function() {
          function s(e) {
            _classCallCheck(this, s), this.default = s.DEFAULT_TEXTURE_NAME, this.textures = {}, this.texture_configs = {}, this.boundTexture = null, this.activeUnit = null, this.scene_id = e, WorkerBroker.addTarget("Texture" + this.scene_id, this), subscribeMixin(this);
          }
          return _createClass(s, [{ key: "create", value: function(e, t2, r) {
            for (var i2 = s.matchers_, n = 0; n < i2.length; n++) {
              var o = i2[n][0], a2 = i2[n][1];
              if (a2 && a2(r))
                return new o(e, t2, this, r);
            }
            return new Texture(e, t2, this, r);
          } }, { key: "retain", value: function(e) {
            this.textures[e] && this.textures[e].retain();
          } }, { key: "release", value: function(e) {
            this.textures[e] && this.textures[e].release();
          } }, { key: "getRetainCount", value: function(e) {
            if (this.textures[e])
              return this.textures[e].retain_count;
          } }, { key: "getByteLength", value: function(e) {
            if (this.textures[e])
              return this.textures[e].getByteLength();
          } }, { key: "destroy", value: function(r) {
            var i2 = this;
            Object.keys(this.textures).forEach(function(e) {
              var t2 = i2.textures[e];
              e !== i2.default && t2.gl === r && t2.destroy({ force: true });
            });
          } }, { key: "getSpriteInfo", value: function(e, t2) {
            var r = this.textures[e];
            return r && { size: r.sizes[t2], css_size: r.css_sizes[t2], aspect: r.aspects[t2], texcoords: r.texcoords[t2] };
          } }, { key: "getTexcoordsForSprite", value: function(e, t2, r) {
            var i2 = r[1] - e[1] - t2[1];
            return [e[0] / r[0], i2 / r[1], (t2[0] + e[0]) / r[0], (t2[1] + i2) / r[1]];
          } }, { key: "createFromObject", value: function(e, t2) {
            var r = [];
            if (t2)
              for (var i2 in t2) {
                var n, o = t2[i2];
                this.changed(i2, o) && (n = this.create(e, i2, o), r.push(n.loading));
              }
            return Promise.all(r);
          } }, { key: "createDefault", value: function(e) {
            return this.create(e, this.default);
          } }, { key: "changed", value: function(e, t2) {
            var r = this.textures[e];
            if (r) {
              if ("element" === r.config_type || null != t2.element)
                return true;
              if (t2 = sliceOptions(t2), this.texture_configs[e] === JSON.stringify(Object.assign({ name: e }, t2)))
                return false;
            }
            return true;
          } }, { key: "getInfo", value: function(e) {
            var t2 = this;
            if (e = e || Object.keys(this.textures), Array.isArray(e))
              return Promise.all(e.map(function(e2) {
                return t2.getInfo(e2);
              }));
            var r = this.textures[e];
            return r ? (r.loading || Promise.resolve(r)).then(function() {
              return { name: r.name, width: r.width, height: r.height, density: r.density, sprites: r.sprites, texcoords: r.texcoords, sizes: r.sizes, css_sizes: r.css_sizes, aspects: r.aspects, filtering: r.filtering, power_of_2: r.power_of_2, valid: r.valid };
            }) : Promise.resolve(null);
          } }, { key: "syncTexturesToWorker", value: function(e) {
            var r = this;
            return Thread.is_main ? Promise.all(e.map(function(e2) {
              var t2 = r.textures[e2];
              return t2 && t2.loading || Promise.resolve();
            })).then(function() {
              return r.textures;
            }) : WorkerBroker.postMessage("Texture" + this.scene_id + ".getInfo", e).then(function(e2) {
              return e2.forEach(function(e3) {
                r.textures[e3.name] = e3;
              }), r.textures;
            });
          } }, { key: "getMaxTextureSize", value: function(e) {
            return e.getParameter(e.MAX_TEXTURE_SIZE);
          } }], [{ key: "register", value: function(e, t2) {
            var r = s.matchers_;
            if (!(e instanceof Function && t2 instanceof Function))
              throw "Invalid texture constructor or matcher";
            this.deRegister(e), r.push([e, t2]);
          } }, { key: "deRegister", value: function(e) {
            for (var t2 = s.matchers_, r = 0; r < t2.length; r++)
              t2[r][0] === e && t2.splice(r, 1);
          } }]), s;
        }();
        TextureManager.DEFAULT_TEXTURE_NAME = "__default", TextureManager.matchers_ = [];
        var Registry = {};
        function getTextureManager(e) {
          return Registry[e] || (Registry[e] = new TextureManager(e)), Registry[e];
        }
        var transformMat4_1 = transformMat4;
        function transformMat4(e, t2, r) {
          var i2 = t2[0], n = t2[1], o = t2[2], a2 = (a2 = r[3] * i2 + r[7] * n + r[11] * o + r[15]) || 1;
          return e[0] = (r[0] * i2 + r[4] * n + r[8] * o + r[12]) / a2, e[1] = (r[1] * i2 + r[5] * n + r[9] * o + r[13]) / a2, e[2] = (r[2] * i2 + r[6] * n + r[10] * o + r[14]) / a2, e;
        }
        var normalFromMat4_1 = normalFromMat4;
        function normalFromMat4(e, t2) {
          var r = t2[0], i2 = t2[1], n = t2[2], o = t2[3], a2 = t2[4], s = t2[5], l = t2[6], u2 = t2[7], c2 = t2[8], h = t2[9], f2 = t2[10], d = t2[11], _ = t2[12], p2 = t2[13], g = t2[14], m = t2[15], y = r * s - i2 * a2, v = r * l - n * a2, x2 = r * u2 - o * a2, b2 = i2 * l - n * s, T2 = i2 * u2 - o * s, A2 = n * u2 - o * l, E2 = c2 * p2 - h * _, w = c2 * g - f2 * _, S2 = c2 * m - d * _, k = h * g - f2 * p2, P2 = h * m - d * p2, R2 = f2 * m - d * g, M2 = y * R2 - v * P2 + x2 * k + b2 * S2 - T2 * w + A2 * E2;
          return M2 ? (M2 = 1 / M2, e[0] = (s * R2 - l * P2 + u2 * k) * M2, e[1] = (l * S2 - a2 * R2 - u2 * w) * M2, e[2] = (a2 * P2 - s * S2 + u2 * E2) * M2, e[3] = (n * P2 - i2 * R2 - o * k) * M2, e[4] = (r * R2 - n * S2 + o * w) * M2, e[5] = (i2 * S2 - r * P2 - o * E2) * M2, e[6] = (p2 * A2 - g * T2 + m * b2) * M2, e[7] = (g * x2 - _ * A2 - m * v) * M2, e[8] = (_ * T2 - p2 * x2 + m * y) * M2, e) : null;
        }
        var invert_1 = invert;
        function invert(e, t2) {
          var r = t2[0], i2 = t2[1], n = t2[2], o = t2[3], a2 = t2[4], s = t2[5], l = t2[6], u2 = t2[7], c2 = t2[8], h = c2 * a2 - s * u2, f2 = -c2 * o + s * l, d = u2 * o - a2 * l, _ = r * h + i2 * f2 + n * d;
          return _ ? (_ = 1 / _, e[0] = h * _, e[1] = (-c2 * i2 + n * u2) * _, e[2] = (s * i2 - n * a2) * _, e[3] = f2 * _, e[4] = (c2 * r - n * l) * _, e[5] = (-s * r + n * o) * _, e[6] = d * _, e[7] = (-u2 * r + i2 * l) * _, e[8] = (a2 * r - i2 * o) * _, e) : null;
        }
        var identity_1 = identity;
        function identity(e) {
          return e[0] = 1, e[1] = 0, e[2] = 0, e[3] = 0, e[4] = 1, e[5] = 0, e[6] = 0, e[7] = 0, e[8] = 1, e;
        }
        var multiply_1 = multiply;
        function multiply(e, t2, r) {
          var i2 = t2[0], n = t2[1], o = t2[2], a2 = t2[3], s = t2[4], l = t2[5], u2 = t2[6], c2 = t2[7], h = t2[8], f2 = t2[9], d = t2[10], _ = t2[11], p2 = t2[12], g = t2[13], m = t2[14], y = t2[15], v = r[0], x2 = r[1], b2 = r[2], T2 = r[3];
          return e[0] = v * i2 + x2 * s + b2 * h + T2 * p2, e[1] = v * n + x2 * l + b2 * f2 + T2 * g, e[2] = v * o + x2 * u2 + b2 * d + T2 * m, e[3] = v * a2 + x2 * c2 + b2 * _ + T2 * y, v = r[4], x2 = r[5], b2 = r[6], T2 = r[7], e[4] = v * i2 + x2 * s + b2 * h + T2 * p2, e[5] = v * n + x2 * l + b2 * f2 + T2 * g, e[6] = v * o + x2 * u2 + b2 * d + T2 * m, e[7] = v * a2 + x2 * c2 + b2 * _ + T2 * y, v = r[8], x2 = r[9], b2 = r[10], T2 = r[11], e[8] = v * i2 + x2 * s + b2 * h + T2 * p2, e[9] = v * n + x2 * l + b2 * f2 + T2 * g, e[10] = v * o + x2 * u2 + b2 * d + T2 * m, e[11] = v * a2 + x2 * c2 + b2 * _ + T2 * y, v = r[12], x2 = r[13], b2 = r[14], T2 = r[15], e[12] = v * i2 + x2 * s + b2 * h + T2 * p2, e[13] = v * n + x2 * l + b2 * f2 + T2 * g, e[14] = v * o + x2 * u2 + b2 * d + T2 * m, e[15] = v * a2 + x2 * c2 + b2 * _ + T2 * y, e;
        }
        var translate_1 = translate;
        function translate(e, t2, r) {
          var i2, n, o, a2, s, l, u2, c2, h, f2, d, _, p2 = r[0], g = r[1], m = r[2];
          return t2 === e ? (e[12] = t2[0] * p2 + t2[4] * g + t2[8] * m + t2[12], e[13] = t2[1] * p2 + t2[5] * g + t2[9] * m + t2[13], e[14] = t2[2] * p2 + t2[6] * g + t2[10] * m + t2[14], e[15] = t2[3] * p2 + t2[7] * g + t2[11] * m + t2[15]) : (i2 = t2[0], n = t2[1], o = t2[2], a2 = t2[3], s = t2[4], l = t2[5], u2 = t2[6], c2 = t2[7], h = t2[8], f2 = t2[9], d = t2[10], _ = t2[11], e[0] = i2, e[1] = n, e[2] = o, e[3] = a2, e[4] = s, e[5] = l, e[6] = u2, e[7] = c2, e[8] = h, e[9] = f2, e[10] = d, e[11] = _, e[12] = i2 * p2 + s * g + h * m + t2[12], e[13] = n * p2 + l * g + f2 * m + t2[13], e[14] = o * p2 + u2 * g + d * m + t2[14], e[15] = a2 * p2 + c2 * g + _ * m + t2[15]), e;
        }
        var scale_1 = scale;
        function scale(e, t2, r) {
          var i2 = r[0], n = r[1], o = r[2];
          return e[0] = t2[0] * i2, e[1] = t2[1] * i2, e[2] = t2[2] * i2, e[3] = t2[3] * i2, e[4] = t2[4] * n, e[5] = t2[5] * n, e[6] = t2[6] * n, e[7] = t2[7] * n, e[8] = t2[8] * o, e[9] = t2[9] * o, e[10] = t2[10] * o, e[11] = t2[11] * o, e[12] = t2[12], e[13] = t2[13], e[14] = t2[14], e[15] = t2[15], e;
        }
        var perspective_1 = perspective;
        function perspective(e, t2, r, i2, n) {
          var o = 1 / Math.tan(t2 / 2), a2 = 1 / (i2 - n);
          return e[0] = o / r, e[1] = 0, e[2] = 0, e[3] = 0, e[4] = 0, e[5] = o, e[6] = 0, e[7] = 0, e[8] = 0, e[9] = 0, e[10] = (n + i2) * a2, e[11] = -1, e[12] = 0, e[13] = 0, e[14] = 2 * n * i2 * a2, e[15] = 0, e;
        }
        var identity_1$1 = identity$1;
        function identity$1(e) {
          return e[0] = 1, e[1] = 0, e[2] = 0, e[3] = 0, e[4] = 0, e[5] = 1, e[6] = 0, e[7] = 0, e[8] = 0, e[9] = 0, e[10] = 1, e[11] = 0, e[12] = 0, e[13] = 0, e[14] = 0, e[15] = 1, e;
        }
        var lookAt_1 = lookAt;
        function lookAt(e, t2, r, i2) {
          var n, o, a2, s, l, u2, c2, h, f2, d, _ = t2[0], p2 = t2[1], g = t2[2], m = i2[0], y = i2[1], v = i2[2], x2 = r[0], b2 = r[1], T2 = r[2];
          return Math.abs(_ - x2) < 1e-6 && Math.abs(p2 - b2) < 1e-6 && Math.abs(g - T2) < 1e-6 ? identity_1$1(e) : (c2 = _ - x2, h = p2 - b2, f2 = g - T2, n = y * (f2 *= d = 1 / Math.sqrt(c2 * c2 + h * h + f2 * f2)) - v * (h *= d), o = v * (c2 *= d) - m * f2, a2 = m * h - y * c2, (d = Math.sqrt(n * n + o * o + a2 * a2)) ? (n *= d = 1 / d, o *= d, a2 *= d) : a2 = o = n = 0, s = h * a2 - f2 * o, l = f2 * n - c2 * a2, u2 = c2 * o - h * n, (d = Math.sqrt(s * s + l * l + u2 * u2)) ? (s *= d = 1 / d, l *= d, u2 *= d) : u2 = l = s = 0, e[0] = n, e[1] = s, e[2] = c2, e[3] = 0, e[4] = o, e[5] = l, e[6] = h, e[7] = 0, e[8] = a2, e[9] = u2, e[10] = f2, e[11] = 0, e[12] = -(n * _ + o * p2 + a2 * g), e[13] = -(s * _ + l * p2 + u2 * g), e[14] = -(c2 * _ + h * p2 + f2 * g), e[15] = 1, e);
        }
        var copy_1 = copy;
        function copy(e, t2) {
          return e[0] = t2[0], e[1] = t2[1], e[2] = t2[2], e[3] = t2[3], e[4] = t2[4], e[5] = t2[5], e[6] = t2[6], e[7] = t2[7], e[8] = t2[8], e[9] = t2[9], e[10] = t2[10], e[11] = t2[11], e[12] = t2[12], e[13] = t2[13], e[14] = t2[14], e[15] = t2[15], e;
        }
        var invert_1$1 = invert$1;
        function invert$1(e, t2) {
          var r = t2[0], i2 = t2[1], n = t2[2], o = t2[3], a2 = t2[4], s = t2[5], l = t2[6], u2 = t2[7], c2 = t2[8], h = t2[9], f2 = t2[10], d = t2[11], _ = t2[12], p2 = t2[13], g = t2[14], m = t2[15], y = r * s - i2 * a2, v = r * l - n * a2, x2 = r * u2 - o * a2, b2 = i2 * l - n * s, T2 = i2 * u2 - o * s, A2 = n * u2 - o * l, E2 = c2 * p2 - h * _, w = c2 * g - f2 * _, S2 = c2 * m - d * _, k = h * g - f2 * p2, P2 = h * m - d * p2, R2 = f2 * m - d * g, M2 = y * R2 - v * P2 + x2 * k + b2 * S2 - T2 * w + A2 * E2;
          return M2 ? (M2 = 1 / M2, e[0] = (s * R2 - l * P2 + u2 * k) * M2, e[1] = (n * P2 - i2 * R2 - o * k) * M2, e[2] = (p2 * A2 - g * T2 + m * b2) * M2, e[3] = (f2 * T2 - h * A2 - d * b2) * M2, e[4] = (l * S2 - a2 * R2 - u2 * w) * M2, e[5] = (r * R2 - n * S2 + o * w) * M2, e[6] = (g * x2 - _ * A2 - m * v) * M2, e[7] = (c2 * A2 - f2 * x2 + d * v) * M2, e[8] = (a2 * P2 - s * S2 + u2 * E2) * M2, e[9] = (i2 * S2 - r * P2 - o * E2) * M2, e[10] = (_ * T2 - p2 * x2 + m * y) * M2, e[11] = (h * x2 - c2 * T2 - d * y) * M2, e[12] = (s * w - a2 * k - l * E2) * M2, e[13] = (r * k - i2 * w + n * E2) * M2, e[14] = (p2 * v - _ * b2 - g * y) * M2, e[15] = (c2 * b2 - h * v + f2 * y) * M2, e) : null;
        }
        var transformMat4_1$1 = transformMat4$1;
        function transformMat4$1(e, t2, r) {
          var i2 = t2[0], n = t2[1], o = t2[2], a2 = t2[3];
          return e[0] = r[0] * i2 + r[4] * n + r[8] * o + r[12] * a2, e[1] = r[1] * i2 + r[5] * n + r[9] * o + r[13] * a2, e[2] = r[2] * i2 + r[6] * n + r[10] * o + r[14] * a2, e[3] = r[3] * i2 + r[7] * n + r[11] * o + r[15] * a2, e;
        }
        var normalize_1 = normalize$1;
        function normalize$1(e, t2) {
          var r = t2[0], i2 = t2[1], n = t2[2], o = t2[3], a2 = r * r + i2 * i2 + n * n + o * o;
          return 0 < a2 && (a2 = 1 / Math.sqrt(a2), e[0] = r * a2, e[1] = i2 * a2, e[2] = n * a2, e[3] = o * a2), e;
        }
        var scale_1$1 = scale$1;
        function scale$1(e, t2, r) {
          return e[0] = t2[0] * r, e[1] = t2[1] * r, e[2] = t2[2] * r, e[3] = t2[3] * r, e;
        }
        var vec3 = { fromValues: function(e, t2, r) {
          var i2 = new Float64Array(3);
          return i2[0] = e, i2[1] = t2, i2[2] = r, i2;
        }, transformMat4: transformMat4_1 }, mat3 = { normalFromMat4: normalFromMat4_1, invert: invert_1, identity: identity_1 }, mat4 = { multiply: multiply_1, translate: translate_1, scale: scale_1, perspective: perspective_1, lookAt: lookAt_1, identity: identity_1$1, copy: copy_1, invert: invert_1$1 }, vec4 = { transformMat4: transformMat4_1$1, normalize: normalize_1, scale: scale_1$1 }, FeatureSelection = function() {
          function b2(e, t2) {
            _classCallCheck(this, b2), this._gl = e, this._requests = {}, this._pixels = null, this._has_dirty_buffer = false, this._fbo = this._gl.createFramebuffer(), this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, this._fbo), this._fbo_size = { width: 256, height: 256 };
            var r = getTextureManager(t2).create(this._gl, "selection_fbo", { filtering: "nearest" });
            r.setData(this._fbo_size.width, this._fbo_size.height, null, { filtering: "nearest" }), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.COLOR_ATTACHMENT0, this._gl.TEXTURE_2D, r.texture, 0);
            var i2 = this._gl.createRenderbuffer();
            this._gl.bindRenderbuffer(this._gl.RENDERBUFFER, i2), this._gl.renderbufferStorage(this._gl.RENDERBUFFER, this._gl.DEPTH_COMPONENT16, this._fbo_size.width, this._fbo_size.height), this._gl.framebufferRenderbuffer(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.RENDERBUFFER, i2), this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, null);
          }
          return _createClass(b2, [{ key: "destroy", value: function() {
            this._gl && this._fbo && (this._gl.deleteFramebuffer(this._fbo), this._fbo = null, this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, null));
          } }, { key: "bind", value: function() {
            var e;
            this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, this._fbo), this._gl.viewport(0, 0, this._fbo_size.width, this._fbo_size.height), (e = this._gl).clearColor.apply(e, _toConsumableArray(b2.defaultColor));
          } }, { key: "getFeatureAt", value: function(e, t2, r) {
            var i2 = t2.radius, n = t2.top_most_only, o = void 0 === n || n;
            !e || e.x < 0 || e.y < 0 || 1 < e.x || 1 < e.y ? r({ features: null }) : (this.selection_request_id = this.selection_request_id + 1 || 0, this._requests[this.selection_request_id] = { id: this.selection_request_id, point: e, radius: i2, top_most_only: o, ttl: o ? 1 : b2.MAX_PICKING_TRIES, callback: r });
          } }, { key: "hasPendingRequests", value: function() {
            return 0 < Object.keys(this._requests).length;
          } }, { key: "clearPendingRequests", value: function() {
            for (var e in this._requests) {
              this._requests[e].callback(new Error("cleared")), delete this._requests[e];
            }
            this._pending_deep_request = null;
          } }, { key: "read", value: function(e) {
            if (this.hasPendingRequests()) {
              var t2 = this._gl;
              for (var r in t2.bindFramebuffer(t2.FRAMEBUFFER, this._fbo), this._pending_deep_request && this.processRequest(this._pending_deep_request, e), this._requests)
                if (this.processRequest(this._requests[r], e))
                  break;
              t2.bindFramebuffer(t2.FRAMEBUFFER, null);
            }
          } }, { key: "processRequest", value: function(e, t2) {
            var r, i2, n, o = this._gl, a2 = 255, s = e.point, l = e.radius, u2 = (n = l ? (i2 = Math.min(this._fbo_size.width, this._fbo_size.height), { x: Math.min(Math.ceil(2 * l.x * this._fbo_size.width), i2), y: Math.min(Math.ceil(2 * l.y * this._fbo_size.height), i2) }) : (l = { x: 0, y: 0 }, { x: 1, y: 1 })).x * n.y * 4;
            if (null == this._pixels || this._pixels.byteLength < u2)
              this._pixels = new Uint8Array(u2);
            else if (this._pixels.fill instanceof Function)
              this._pixels.fill(0, 0, u2);
            else
              for (var c2 = 0; c2 < u2; c2++)
                this._pixels[c2] = 0;
            o.readPixels(Math.round((s.x - l.x) * this._fbo_size.width), Math.round((1 - s.y - l.y) * this._fbo_size.height), n.x, n.y, o.RGBA, o.UNSIGNED_BYTE, this._pixels), e.ttl--;
            var h = Math.floor(n.x / 2), f2 = Math.floor(n.y / 2), d = 4 * (f2 * n.x + h), _ = this._pixels.slice(d, d + 4), p2 = _[0] + (_[1] << 8) + (_[2] << 16);
            if (0 < p2)
              r = p2 + (_[3] << 24) >>> 0, a2 = _[3];
            else if (4 < u2)
              for (var g = 1 / 0, d = 0, m = 0; m < n.y; m++)
                for (var y, v = 0; v < n.x; v++, d += 4) {
                  0 < (p2 = (_ = this._pixels.slice(d, d + 4))[0] + (_[1] << 8) + (_[2] << 16)) && ((y = Math.pow(v - h, 2) + Math.pow(m - f2, 2)) < g && (r = p2 + (_[3] << 24) >>> 0, a2 = _[3], g = y));
                }
            if (255 !== a2) {
              var x2 = this._getFeatureByKey(r, t2);
              if (e.features || (e.features = []), !x2)
                return void this._finishRead(e);
              if (e.features.every(function(e2) {
                return e2.id !== x2.id;
              }) && e.features.push(x2), e.ttl)
                return this._pending_deep_request = e, b2._discardColor(_), this._has_dirty_buffer = true;
              this._finishRead(e);
            } else
              this._finishRead(e);
          } }, { key: "_finishRead", value: function(e) {
            var t2 = e.features || b2.EMPTY_ARRAY;
            e.top_most_only || (this._pending_deep_request = null, b2._resetDiscardedColors()), delete this._requests[e.id], e.callback({ features: t2 });
          } }, { key: "_getFeatureByKey", value: function(e, t2) {
            for (var r = null, i2 = 0; i2 < t2.length; i2++) {
              var n = t2[i2];
              if (n.selection_data && (r = n.selection_data[e])) {
                r.tile = { coords: n.coords };
                break;
              }
            }
            return r;
          } }, { key: "setupDiscards", value: function(e) {
            for (var t2 = b2.MAX_PICKING_TRIES; t2--; )
              e.uniform("4fv", "u_selection_discard".concat(t2), b2._discarded_colors[t2] || b2.defaultColor);
          } }, { key: "has_dirty_buffer", get: function() {
            return this._has_dirty_buffer;
          }, set: function() {
            this._has_dirty_buffer = !!this._pending_deep_request;
          } }], [{ key: "makeEntry", value: function() {
            this.map_entry++;
            var e = 255 & this.map_entry, t2 = this.map_entry >> 8 & 255, r = this.map_entry >> 16 & 255, i2 = this.map_prefix;
            return { key: e + (t2 << 8) + (r << 16) + (i2 << 24) >>> 0, color: [e / 255, t2 / 255, r / 255, i2 / 255] };
          } }, { key: "reset", value: function() {
            this.map_entry = 0;
          } }, { key: "setPrefix", value: function(e) {
            this.map_prefix = e;
          } }, { key: "_discardColor", value: function(e) {
            this._discarded_colors.push([e[0] / 255, e[1] / 255, e[2] / 255, e[3] / 255]);
          } }, { key: "_resetDiscardedColors", value: function() {
            this._discarded_colors.length = 0;
          } }]), b2;
        }();
        FeatureSelection._discarded_colors = [], FeatureSelection.map_entry = 0, FeatureSelection.map_prefix = 0, FeatureSelection.defaultColor = [0, 0, 0, 1], FeatureSelection.MAX_PICKING_TRIES = 10, FeatureSelection.EMPTY_ARRAY = Object.freeze([]);
        var GLSL = { parseUniforms: function(e) {
          var t2 = [];
          for (var r in e) {
            var i2, n = r, o = e[r];
            if ("number" == typeof o)
              t2.push({ type: "float", method: "1f", name: r, value: o, key: n, uniforms: e });
            else if (Array.isArray(o)) {
              if ("number" == typeof o[0])
                2 <= o.length && o.length <= 4 ? t2.push({ type: "vec" + o.length, method: o.length + "fv", name: r, value: o, key: n, uniforms: e }) : 4 < o.length && t2.push({ type: "float[]", method: "1fv", name: r + "[0]", value: o, key: n, uniforms: e });
              else if ("string" == typeof o[0])
                for (i2 = 0; i2 < o.length; i2++)
                  t2.push({ type: "sampler2D", method: "1i", name: r + "[" + i2 + "]", value: o[i2], key: i2, uniforms: o });
              else if (Array.isArray(o[0]) && "number" == typeof o[0][0] && 2 <= o[0].length && o[0].length <= 4)
                for (i2 = 0; i2 < o.length; i2++)
                  t2.push({ type: "vec" + o[0].length, method: o[i2].length + "fv", name: r + "[" + i2 + "]", value: o[i2], key: i2, uniforms: o });
            } else
              "boolean" == typeof o ? t2.push({ type: "bool", method: "1i", name: r, value: o, key: n, uniforms: e }) : "string" == typeof o && t2.push({ type: "sampler2D", method: "1i", name: r, value: o, key: n, uniforms: e });
          }
          return t2;
        }, defineVariable: function(e, t2) {
          var r, i2;
          if ("number" == typeof t2)
            r = "float";
          else if (Array.isArray(t2))
            "number" == typeof t2[0] ? 2 <= t2.length && t2.length <= 4 ? r = "vec" + t2.length : (r = "float", i2 = t2.length) : "string" == typeof t2[0] && (r = "sampler2D", i2 = t2.length);
          else if ("boolean" == typeof t2)
            r = "bool";
          else {
            if ("string" != typeof t2)
              return;
            r = "sampler2D";
          }
          var n = "";
          return n += "".concat(r, " ").concat(e), i2 && (n += "[".concat(i2, "]")), n += ";\n";
        }, defineUniform: function(e, t2) {
          var r = GLSL.defineVariable(e, t2);
          if (r)
            return "uniform " + r;
        }, isUniformDefined: function(e, t2) {
          var r = new RegExp("uniform[^;]+(?:{[\\s\\S]*})?[^;]*\\b" + e + "\\b", "g");
          return !!t2.match(r);
        }, isSymbolReferenced: function(e, t2) {
          var r = new RegExp("\\b" + e + "\\b", "g");
          return 0 <= t2.search(r);
        }, expandVec3: function(e) {
          var t2, r = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 1;
          if (Array.isArray(e)) {
            if (2 !== e.length)
              return e;
            t2 = [].concat(_toConsumableArray(e), [r]).map(parseFloat);
          } else
            t2 = [e, e, e].map(parseFloat);
          if (t2 && t2.every(function(e2) {
            return "number" == typeof e2 && !isNaN(e2);
          }))
            return t2;
        }, expandVec4: function(e) {
          var t2, r = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 1;
          if (Array.isArray(e)) {
            if (3 !== e.length)
              return e;
            t2 = [].concat(_toConsumableArray(e), [r]).map(parseFloat);
          } else
            t2 = [e, e, e, r].map(parseFloat);
          if (t2 && t2.every(function(e2) {
            return "number" == typeof e2 && !isNaN(e2);
          }))
            return t2;
        } }, extensions = [];
        function getExtension(t2, e) {
          var r = extensions.filter(function(e2) {
            return e2[0] === t2;
          })[0];
          return (r = r && r[1]) || (extensions.push([t2, {}]), r = extensions[extensions.length - 1][1]), r[e] || (r[e] = t2.getExtension(e)), r[e];
        }
        function hashString(e) {
          var t2, r, i2 = 0;
          if (0 === e.length)
            return i2;
          for (t2 = 0, r = e.length; t2 < r; t2++)
            i2 = (i2 << 5) - i2 + e.charCodeAt(t2), i2 |= 0;
          return i2;
        }
        var stripComments = createCommonjsModule(function(e) {
          var i2 = "(.|[\\r\\n]|\\n)*?\\*\\/\\n?\\n?", n = /(^|[^\S\n])(?:\/\/)([\s\S]+?)$/gm, o = /(^|[^\S\n])(?:\/\/[^!])([\s\S]+?)$/gm, r = e.exports = function(e2, t2) {
            return e2 ? r.block(r.line(e2, t2), t2) : "";
          };
          r.block = function(e2, t2) {
            t2 = t2 || {};
            var r2 = new RegExp("\\/\\*" + i2, "gm");
            return t2.safe && (r2 = new RegExp("\\/\\*(?!\\*?\\!)" + i2, "gm")), e2 ? e2.replace(r2, "") : "";
          }, r.line = function(e2, t2) {
            var r2 = n;
            return (t2 = t2 || {}).safe && (r2 = o), e2 ? e2.replace(r2, "") : "";
          };
        }), glShaderErrors = parseErrors;
        function parseErrors(e) {
          e = String(e);
          for (var t2, r = []; t2 = e.match(/ERROR\:([^\n]+)/); ) {
            e = e.slice(t2.index + 1);
            var i2 = (a2 = t2[1].trim()).split(":"), n = i2.slice(2).join(":").trim(), o = parseInt(i2[0], 10), a2 = parseInt(i2[1], 10);
            r.push({ message: n, file: o, line: a2 });
          }
          return r;
        }
        var re_pragma = /^\s*#pragma.*$/gm, re_continue_line = /\\\s*\n/gm, ShaderProgram = function() {
          function f2(e, t2, r, i2, n) {
            if (_classCallCheck(this, f2), n = n || {}, this.textureManager = getTextureManager(i2), this.gl = e, this.program = null, this.compiled = false, this.compiling = false, this.error = null, !f2.polyfills[i2]) {
              f2.polyfills[i2] = {};
              try {
                this.gl.uniformMatrix3fv(null, false, new Float64Array(9));
              } catch (e2) {
                f2.polyfills[i2].uniformMatrix3fv = this.gl.uniformMatrix3fv, this.gl.uniformMatrix3fv = function(e3, t3, r2) {
                  f2.polyfills[i2].uniformMatrix3fv.call(this, e3, t3, new Float32Array(r2));
                };
              }
              try {
                this.gl.uniformMatrix4fv(null, false, new Float64Array(16));
              } catch (e2) {
                f2.polyfills[i2].uniformMatrix4fv = this.gl.uniformMatrix4fv, this.gl.uniformMatrix4fv = function(e3, t3, r2) {
                  f2.polyfills[i2].uniformMatrix4fv.call(this, e3, t3, new Float32Array(r2));
                };
              }
            }
            this.defines = Object.assign({}, n.defines || {}), this.blocks = Object.assign({}, n.blocks || {}), this.block_scopes = Object.assign({}, n.block_scopes || {}), this.extensions = n.extensions || [], this.dependent_uniforms = n.uniforms, this.uniforms = {}, this.attribs = {}, this.vertex_source = t2, this.fragment_source = r, this.id = f2.id++, this.name = n.name;
          }
          return _createClass(f2, [{ key: "destroy", value: function() {
            this.gl.useProgram(null), this.gl.deleteProgram(this.program), this.program = null, this.uniforms = {}, this.attribs = {}, this.compiled = false;
          } }, { key: "use", value: function() {
            this.compiled && (f2.current !== this && this.gl.useProgram(this.program), f2.current = this);
          } }, { key: "compile", value: function() {
            var r = this;
            if (this.compiling)
              throw new Error("ShaderProgram.compile(): skipping for ".concat(this.id, " (").concat(this.name, ") because already compiling"));
            this.compiling = true, this.compiled = false, this.error = null, this.computed_vertex_source = this.vertex_source, this.computed_fragment_source = this.fragment_source;
            var e, t2 = this.checkExtensions(), i2 = this.buildDefineList(), n = this.buildShaderBlockList();
            for (var o in n) {
              var a2, s, l, u2 = n[o];
              !u2 || Array.isArray(u2) && 0 === u2.length || (e = new RegExp("^\\s*#pragma\\s+tangram:\\s+" + o + "\\s*$", "m"), a2 = this.computed_vertex_source.match(e), s = this.computed_fragment_source.match(e), null == a2 && null == s || (l = "", u2.forEach(function(e2) {
                var t3 = "".concat(e2.scope, ", ").concat(e2.key, ", ").concat(e2.num);
                l += "\n// tangram-block-start: ".concat(t3, "\n"), l += e2.source, l += "\n// tangram-block-end: ".concat(t3, "\n");
              }), null != a2 && (this.computed_vertex_source = this.computed_vertex_source.replace(e, l)), null != s && (this.computed_fragment_source = this.computed_fragment_source.replace(e, l)), i2["TANGRAM_BLOCK_" + o.replace(/[\s-]+/g, "_").toUpperCase()] = true));
            }
            this.computed_vertex_source = this.computed_vertex_source.replace(re_pragma, ""), this.computed_fragment_source = this.computed_fragment_source.replace(re_pragma, ""), this.ensureUniforms(this.dependent_uniforms);
            var c2 = "", h = this.gl.getShaderPrecisionFormat(this.gl.FRAGMENT_SHADER, this.gl.HIGH_FLOAT), c2 = h && 0 < h.precision ? "precision highp float;\n" : "precision mediump float;\n";
            i2.TANGRAM_VERTEX_SHADER = true, i2.TANGRAM_FRAGMENT_SHADER = false, this.computed_vertex_source = c2 + f2.buildDefineString(i2) + this.computed_vertex_source, i2.TANGRAM_VERTEX_SHADER = false, i2.TANGRAM_FRAGMENT_SHADER = true, this.computed_fragment_source = f2.buildExtensionString(t2) + c2 + f2.buildDefineString(i2) + this.computed_fragment_source, this.computed_vertex_source = this.computed_vertex_source.replace(re_continue_line, ""), this.computed_fragment_source = this.computed_fragment_source.replace(re_continue_line, "");
            try {
              this.program = f2.updateProgram(this.gl, this.program, this.computed_vertex_source, this.computed_fragment_source), this.compiled = true, this.compiling = false;
            } catch (t3) {
              throw this.program = null, this.compiled = false, this.compiling = false, "vertex" !== (this.error = t3).type && "fragment" !== t3.type || (this.shader_errors = t3.errors, this.shader_errors.forEach(function(e2) {
                e2.type = t3.type, e2.block = r.block(t3.type, e2.line);
              })), t3;
            }
            this.computed_vertex_source = null, this.computed_fragment_source = null, this.use(), this.refreshUniforms(), this.refreshAttributes();
          } }, { key: "buildDefineList", value: function() {
            var e, t2 = {};
            for (e in f2.defines)
              t2[e] = f2.defines[e];
            for (e in this.defines)
              t2[e] = this.defines[e];
            return t2;
          } }, { key: "buildShaderBlockList", value: function() {
            var r, e, t2 = {};
            for (r in f2.blocks) {
              t2[r] = [], Array.isArray(f2.blocks[r]) ? (e = t2[r]).push.apply(e, _toConsumableArray(f2.blocks[r].map(function(e2, t3) {
                return { key: r, source: e2, num: t3, scope: "ShaderProgram" };
              }))) : t2[r] = [{ key: r, source: f2.blocks[r], num: 0, scope: "ShaderProgram" }];
            }
            for (r in this.blocks)
              if (t2[r] = t2[r] || [], Array.isArray(this.blocks[r]))
                for (var i2 = this.block_scopes && this.block_scopes[r] || [], n = null, o = 0, a2 = 0; a2 < this.blocks[r].length; a2++)
                  i2[a2] !== n && (n = i2[a2], o = 0), t2[r].push({ key: r, source: this.blocks[r][a2], num: o, scope: n || this.name }), o++;
              else
                t2[r].push({ key: r, source: this.blocks[r], num: 0, scope: this.name });
            return t2;
          } }, { key: "ensureUniforms", value: function(e) {
            if (e) {
              var t2, r = stripComments(this.computed_vertex_source), i2 = stripComments(this.computed_fragment_source), n = [], o = [];
              for (var a2 in e) {
                var s = GLSL.isUniformDefined(a2, r), l = GLSL.isUniformDefined(a2, i2);
                if (!s || !l) {
                  if (!(t2 = GLSL.defineUniform(a2, e[a2])))
                    continue;
                  s || (log("trace", "Program ".concat(this.name, ": ").concat(a2, " not defined in vertex shader, injecting: '").concat(t2, "'")), n.push(t2)), l || (log("trace", "Program ".concat(this.name, ": ").concat(a2, " not defined in fragment shader, injecting: '").concat(t2, "'")), o.push(t2));
                }
              }
              0 < n.length && (this.computed_vertex_source = n.join("\n") + this.computed_vertex_source), 0 < o.length && (this.computed_fragment_source = o.join("\n") + this.computed_fragment_source);
            }
          } }, { key: "setUniforms", value: function(e, t2) {
            var r = !(1 < arguments.length && void 0 !== t2) || t2;
            if (this.compiled) {
              r && (this.texture_unit = 0);
              for (var i2 = GLSL.parseUniforms(e), n = 0; n < i2.length; n++) {
                var o = i2[n];
                "sampler2D" === o.type ? this.setTextureUniform(o.name, o.value) : this.uniform(o.method, o.name, o.value);
              }
            }
          } }, { key: "saveUniforms", value: function(e) {
            var t2 = e || this.uniforms;
            for (var r in t2) {
              var i2 = this.uniforms[r];
              i2 && (i2.saved_value = i2.value);
            }
            this.saved_texture_unit = this.texture_unit || 0;
          } }, { key: "restoreUniforms", value: function(e) {
            var t2 = e || this.uniforms;
            for (var r in t2) {
              var i2 = this.uniforms[r];
              i2 && i2.saved_value && (i2.value = i2.saved_value, this.updateUniform(i2));
            }
            this.texture_unit = this.saved_texture_unit || 0;
          } }, { key: "setTextureUniform", value: function(e, t2) {
            var r = this.textureManager.textures[t2];
            null != r ? (r.bind(this.texture_unit), this.uniform("1i", e, this.texture_unit), this.texture_unit++) : log("warn", "Cannot find texture '".concat(t2, "'"));
          } }, { key: "uniform", value: function(e, t2, r) {
            var i2;
            this.compiled && (this.uniforms[t2] = this.uniforms[t2] || {}, i2 = this.uniforms[t2], i2.name = t2, void 0 === i2.location && (i2.location = this.gl.getUniformLocation(this.program, t2)), i2.method = e, i2.value = r, this.updateUniform(i2));
          } }, { key: "updateUniform", value: function(e) {
            this.compiled && e && null != e.location && (this.use(), this.commitUniform(e));
          } }, { key: "commitUniform", value: function(e) {
            var t2 = e.location, r = e.value;
            switch (e.method) {
              case "1i":
                this.gl.uniform1i(t2, r);
                break;
              case "1f":
                this.gl.uniform1f(t2, r);
                break;
              case "2f":
                this.gl.uniform2f(t2, r[0], r[1]);
                break;
              case "3f":
                this.gl.uniform3f(t2, r[0], r[1], r[2]);
                break;
              case "4f":
                this.gl.uniform4f(t2, r[0], r[1], r[2], r[3]);
                break;
              case "1iv":
                this.gl.uniform1iv(t2, r);
                break;
              case "3iv":
                this.gl.uniform3iv(t2, r);
                break;
              case "1fv":
                this.gl.uniform1fv(t2, r);
                break;
              case "2fv":
                this.gl.uniform2fv(t2, r);
                break;
              case "3fv":
                this.gl.uniform3fv(t2, r);
                break;
              case "4fv":
                this.gl.uniform4fv(t2, r);
                break;
              case "Matrix3fv":
                this.gl.uniformMatrix3fv(t2, false, r);
                break;
              case "Matrix4fv":
                this.gl.uniformMatrix4fv(t2, false, r);
            }
          } }, { key: "refreshUniforms", value: function() {
            if (this.compiled)
              for (var e in this.uniforms) {
                var t2 = this.uniforms[e];
                t2.location = this.gl.getUniformLocation(this.program, e), this.updateUniform(t2);
              }
          } }, { key: "refreshAttributes", value: function() {
            this.attribs = {};
          } }, { key: "attribute", value: function(e) {
            if (this.compiled) {
              var t2 = this.attribs[e] = this.attribs[e] || {};
              return null != t2.location ? t2 : (t2.name = e, t2.location = this.gl.getAttribLocation(this.program, e), t2);
            }
          } }, { key: "source", value: function(e) {
            return "vertex" === e ? this.computed_vertex_source : "fragment" === e ? this.computed_fragment_source : void 0;
          } }, { key: "lines", value: function(e) {
            var t2 = this.source(e);
            return t2 ? t2.split("\n") : [];
          } }, { key: "line", value: function(e, t2) {
            var r = this.lines(e);
            if (r)
              return r[t2];
          } }, { key: "block", value: function(e, t2) {
            for (var r, i2 = this.lines(e), n = 0; n < t2 && n < i2.length; n++) {
              var o = i2[n], a2 = o.match(/\/\/ tangram-block-start: ([A-Za-z0-9_-]+), ([A-Za-z0-9_-]+), (\d+)/);
              a2 && 1 < a2.length ? r = { scope: a2[1], name: a2[2], num: a2[3] } : (a2 = o.match(/\/\/ tangram-block-end: ([A-Za-z0-9_-]+), ([A-Za-z0-9_-]+), (\d+)/)) && 1 < a2.length && (r = null), r && (r.line = null == r.line ? -1 : r.line + 1, r.source = o);
            }
            return r;
          } }, { key: "checkExtensions", value: function() {
            var i2 = this, n = [];
            return this.extensions.forEach(function(e) {
              var t2 = getExtension(i2.gl, e), r = "TANGRAM_EXTENSION_".concat(e);
              i2.defines[r] = null != t2, t2 ? n.push(e) : log("debug", "Could not enable extension '".concat(e, "'"));
            }), n;
          } }]), f2;
        }();
        ShaderProgram.polyfills = {}, ShaderProgram.id = 0, ShaderProgram.current = null, ShaderProgram.defines = {}, ShaderProgram.blocks = {}, ShaderProgram.reset = function() {
          ShaderProgram.programs_by_source = {}, ShaderProgram.shaders_by_source = {};
        }, ShaderProgram.reset(), ShaderProgram.buildDefineString = function(e) {
          var t2 = "";
          for (var r in e)
            null != e[r] && false !== e[r] && ("boolean" == typeof e[r] && true === e[r] ? t2 += "#define " + r + "\n" : "number" == typeof e[r] && Math.floor(e[r]) === e[r] ? t2 += "#define " + r + " " + e[r].toFixed(1) + "\n" : t2 += "#define " + r + " " + e[r] + "\n");
          return t2;
        }, ShaderProgram.buildExtensionString = function(e) {
          var t2 = "";
          return (e = e || []).forEach(function(e2) {
            t2 += "#ifdef GL_".concat(e2, "\n#extension GL_").concat(e2, " : enable\n#endif\n");
          }), t2;
        }, ShaderProgram.addBlock = function(e) {
          var t2;
          ShaderProgram.blocks[e] = ShaderProgram.blocks[e] || [];
          for (var r = arguments.length, i2 = new Array(1 < r ? r - 1 : 0), n = 1; n < r; n++)
            i2[n - 1] = arguments[n];
          (t2 = ShaderProgram.blocks[e]).push.apply(t2, i2);
        }, ShaderProgram.removeBlock = function(e) {
          ShaderProgram.blocks[e] = [];
        }, ShaderProgram.replaceBlock = function(e) {
          ShaderProgram.removeBlock(e);
          for (var t2 = arguments.length, r = new Array(1 < t2 ? t2 - 1 : 0), i2 = 1; i2 < t2; i2++)
            r[i2 - 1] = arguments[i2];
          ShaderProgram.addBlock.apply(ShaderProgram, [e].concat(r));
        }, ShaderProgram.updateProgram = function(e, t2, r, i2) {
          var n = hashString(e._tangram_id + "::" + r + "::" + i2);
          if (ShaderProgram.programs_by_source[n])
            return log("trace", "Reusing identical source GL program object"), ShaderProgram.programs_by_source[n];
          var o = ShaderProgram.createShader(e, r, e.VERTEX_SHADER), a2 = ShaderProgram.createShader(e, i2, e.FRAGMENT_SHADER);
          if (e.useProgram(null), null != t2)
            for (var s = e.getAttachedShaders(t2), l = 0; l < s.length; l++)
              e.detachShader(t2, s[l]);
          else
            t2 = e.createProgram();
          if (null == o || null == a2)
            return t2;
          if (e.attachShader(t2, o), e.attachShader(t2, a2), e.linkProgram(t2), e.getProgramParameter(t2, e.LINK_STATUS))
            return ShaderProgram.programs_by_source[n] = t2;
          var u2 = new Error("WebGL program error:\n            VALIDATE_STATUS: ".concat(e.getProgramParameter(t2, e.VALIDATE_STATUS), "\n            ERROR: ").concat(e.getError(), "\n            --- Vertex Shader ---\n            ").concat(r, "\n            --- Fragment Shader ---\n            ").concat(i2));
          throw Object.assign(new Error(u2), { type: "program" });
        }, ShaderProgram.createShader = function(e, t2, r) {
          var i2 = hashString(e._tangram_id + "::" + t2);
          if (ShaderProgram.shaders_by_source[i2])
            return log("trace", "Reusing identical source GL shader object"), ShaderProgram.shaders_by_source[i2];
          var n = e.createShader(r);
          if (e.shaderSource(n, t2), e.compileShader(n), e.getShaderParameter(n, e.COMPILE_STATUS))
            return ShaderProgram.shaders_by_source[i2] = n;
          var o = r === e.VERTEX_SHADER ? "vertex" : "fragment", a2 = e.getShaderInfoLog(n), s = glShaderErrors(a2);
          throw Object.assign(new Error(a2), { type: o, errors: s });
        };
        var VertexArrayObject = { disabled: false, bound_vao: [], init: function(e) {
          var t2;
          true !== this.disabled && (t2 = getExtension(e, "OES_vertex_array_object")), null != t2 ? log("info", "Vertex Array Object extension available") : true !== this.disabled ? log("warn", "Vertex Array Object extension NOT available") : log("warn", "Vertex Array Object extension force disabled");
        }, create: function(e, t2, r) {
          var i2 = {};
          i2.setup = t2, i2.teardown = r;
          var n = getExtension(e, "OES_vertex_array_object");
          return null != n && (i2._vao = n.createVertexArrayOES(), n.bindVertexArrayOES(i2._vao)), i2.setup(true), i2;
        }, getCurrentBinding: function(t2) {
          var e = this.bound_vao.filter(function(e2) {
            return e2[0] === t2;
          })[0];
          return e && e[1];
        }, setCurrentBinding: function(t2, e) {
          var r = this.bound_vao, i2 = r.filter(function(e2) {
            return e2[0] === t2;
          })[0];
          null == i2 ? r.push([t2, e]) : i2[1] = e;
        }, bind: function(e, t2) {
          var r, i2 = getExtension(e, "OES_vertex_array_object");
          null != t2 ? null != i2 && null != t2._vao ? (i2.bindVertexArrayOES(t2._vao), this.setCurrentBinding(e, t2)) : t2.setup(false) : (r = this.getCurrentBinding(e), null != i2 ? i2.bindVertexArrayOES(null) : null != r && "function" == typeof r.teardown && r.teardown(), this.setCurrentBinding(e, null));
        }, destroy: function(e, t2) {
          var r = getExtension(e, "OES_vertex_array_object");
          null != r && null != t2 && null != t2._vao && (r.deleteVertexArrayOES(t2._vao), t2._vao = null);
        } }, VBOMesh = function() {
          function a2(e, t2, r, i2, n, o) {
            _classCallCheck(this, a2), o = o || {}, this.textureManager = getTextureManager(n), this.gl = e, this.vertex_data = t2, this.element_data = r, this.vertex_layout = i2, this.vertex_buffer = this.gl.createBuffer(), this.buffer_size = this.vertex_data.byteLength, this.draw_mode = o.draw_mode || this.gl.TRIANGLES, this.data_usage = o.data_usage || this.gl.STATIC_DRAW, this.vertices_per_geometry = 3, this.uniforms = o.uniforms, this.textures = o.textures, this.retain = o.retain || false, this.created_at = +/* @__PURE__ */ new Date(), this.fade_in_time = o.fade_in_time || 0, this.vertex_count = this.vertex_data.byteLength / this.vertex_layout.stride, this.element_count = 0, this.vaos = {}, this.toggle_element_array = false, this.element_data ? (this.toggle_element_array = true, this.element_count = this.element_data.length, this.geometry_count = this.element_count / this.vertices_per_geometry, this.element_type = this.element_data.constructor === Uint16Array ? this.gl.UNSIGNED_SHORT : this.gl.UNSIGNED_INT, this.element_buffer = this.gl.createBuffer(), this.buffer_size += this.element_data.byteLength, this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, this.element_buffer), this.gl.bufferData(this.gl.ELEMENT_ARRAY_BUFFER, this.element_data, this.data_usage)) : this.geometry_count = this.vertex_count / this.vertices_per_geometry, this.upload(), this.retain || (delete this.vertex_data, delete this.element_data), this.valid = true;
          }
          return _createClass(a2, [{ key: "render", value: function(e) {
            var t2 = 0 < arguments.length && void 0 !== e ? e : {};
            if (!this.valid)
              return false;
            var r = t2.program || ShaderProgram.current;
            r.use(), this.uniforms && (r.saveUniforms(this.uniforms), r.setUniforms(this.uniforms, false));
            var i2 = (/* @__PURE__ */ new Date() - this.created_at) / 1e3;
            return r.uniform("1f", "u_visible_time", i2), this.bind(r), this.toggle_element_array ? this.gl.drawElements(this.draw_mode, this.element_count, this.element_type, 0) : this.gl.drawArrays(this.draw_mode, 0, this.vertex_count), VertexArrayObject.bind(this.gl, null), this.uniforms && r.restoreUniforms(this.uniforms), i2 < this.fade_in_time;
          } }, { key: "bind", value: function(t2) {
            var r = this, e = this.vaos[t2.id];
            e ? VertexArrayObject.bind(this.gl, e) : this.vaos[t2.id] = VertexArrayObject.create(this.gl, function(e2) {
              r.gl.bindBuffer(r.gl.ARRAY_BUFFER, r.vertex_buffer), r.toggle_element_array && r.gl.bindBuffer(r.gl.ELEMENT_ARRAY_BUFFER, r.element_buffer), r.vertex_layout.enable(r.gl, t2, e2);
            });
          } }, { key: "upload", value: function() {
            this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.vertex_buffer), this.gl.bufferData(this.gl.ARRAY_BUFFER, this.vertex_data, this.data_usage);
          } }, { key: "destroy", value: function() {
            var t2 = this;
            if (!this.valid)
              return false;
            for (var e in this.valid = false, this.vaos)
              VertexArrayObject.destroy(this.gl, this.vaos[e]);
            return this.gl.deleteBuffer(this.vertex_buffer), this.vertex_buffer = null, this.element_buffer && (this.gl.deleteBuffer(this.element_buffer), this.element_buffer = null), delete this.vertex_data, delete this.element_data, this.textures && this.textures.forEach(function(e2) {
              return t2.textureManager.release(e2);
            }), true;
          } }]), a2;
        }(), shaderSrc_material = "/*Defines globals:materiallight_accumulator_**/struct Material{\n#ifdef TANGRAM_MATERIAL_EMISSION\nvec4 emission;\n#ifdef TANGRAM_MATERIAL_EMISSION_TEXTURE\nvec3 emissionScale;\n#endif\n#endif\n#ifdef TANGRAM_MATERIAL_AMBIENT\nvec4 ambient;\n#ifdef TANGRAM_MATERIAL_AMBIENT_TEXTURE\nvec3 ambientScale;\n#endif\n#endif\n#ifdef TANGRAM_MATERIAL_DIFFUSE\nvec4 diffuse;\n#ifdef TANGRAM_MATERIAL_DIFFUSE_TEXTURE\nvec3 diffuseScale;\n#endif\n#endif\n#ifdef TANGRAM_MATERIAL_SPECULAR\nvec4 specular;float shininess;\n#ifdef TANGRAM_MATERIAL_SPECULAR_TEXTURE\nvec3 specularScale;\n#endif\n#endif\n#ifdef TANGRAM_MATERIAL_NORMAL_TEXTURE\nvec3 normalScale;float normalAmount;\n#endif\n};uniform Material u_material;Material material;\n#ifdef TANGRAM_MATERIAL_EMISSION_TEXTURE\nuniform sampler2D u_material_emission_texture;\n#endif\n#ifdef TANGRAM_MATERIAL_AMBIENT_TEXTURE\nuniform sampler2D u_material_ambient_texture;\n#endif\n#ifdef TANGRAM_MATERIAL_DIFFUSE_TEXTURE\nuniform sampler2D u_material_diffuse_texture;\n#endif\n#ifdef TANGRAM_MATERIAL_SPECULAR_TEXTURE\nuniform sampler2D u_material_specular_texture;\n#endif\n#ifdef TANGRAM_MATERIAL_NORMAL_TEXTURE\nuniform sampler2D u_material_normal_texture;\n#endif\nvec4 light_accumulator_ambient=vec4(vec3(0.0),1.);vec4 light_accumulator_diffuse=vec4(vec3(0.0),1.);\n#ifdef TANGRAM_MATERIAL_SPECULAR\nvec4 light_accumulator_specular=vec4(vec3(0.0),1.);\n#endif\n#ifdef TANGRAM_MATERIAL_TEXTURE_SPHEREMAP\nvec4 getSphereMap(in sampler2D _tex,in vec3 _eyeToPoint,in vec3 _normal,in vec2 _skew){vec3 eye=normalize(_eyeToPoint);eye.xy-=_skew;eye=normalize(eye);vec3 r=reflect(eye,_normal);r.z+=1.0;float m=2.*length(r);vec2 uv=r.xy/m+.5;return texture2D(_tex,uv);}\n#endif\n#ifdef TANGRAM_MATERIAL_TEXTURE_TRIPLANAR\nvec3 getTriPlanarBlend(in vec3 _normal){vec3 blending=abs(_normal);blending=normalize(max(blending,0.00001));float b=(blending.x+blending.y+blending.z);return blending/b;}vec4 getTriPlanar(in sampler2D _tex,in vec3 _pos,in vec3 _normal,in vec3 _scale){vec3 blending=getTriPlanarBlend(_normal);vec4 xaxis=texture2D(_tex,fract(_pos.yz*_scale.x));vec4 yaxis=texture2D(_tex,fract(_pos.xz*_scale.y));vec4 zaxis=texture2D(_tex,fract(_pos.xy*_scale.z));return xaxis*blending.x+yaxis*blending.y+zaxis*blending.z;}\n#endif\n#ifdef TANGRAM_MATERIAL_TEXTURE_PLANAR\nvec4 getPlanar(in sampler2D _tex,in vec3 _pos,in vec2 _scale){return texture2D(_tex,fract(_pos.xy*_scale.x));}\n#endif\n#ifdef TANGRAM_MATERIAL_NORMAL_TEXTURE\nvoid calculateNormal(inout vec3 _normal){\n#ifdef TANGRAM_MATERIAL_NORMAL_TEXTURE_UV\n_normal+=texture2D(u_material_normal_texture,fract(v_texcoord*material.normalScale.xy)).rgb*2.0-1.0;\n#endif\n#ifdef TANGRAM_MATERIAL_NORMAL_TEXTURE_PLANAR\nvec3 normalTex=getPlanar(u_material_normal_texture,v_world_position.xyz,material.normalScale.xy).rgb*2.0-1.0;_normal+=normalTex;\n#endif\n#ifdef TANGRAM_MATERIAL_NORMAL_TEXTURE_TRIPLANAR\nvec3 normalTex=getTriPlanar(u_material_normal_texture,v_world_position.xyz,_normal,material.normalScale).rgb*2.0-1.0;_normal+=normalTex;\n#endif\n_normal=normalize(_normal);}\n#endif\nvoid calculateMaterial(in vec3 _eyeToPoint,inout vec3 _normal){\n#ifdef TANGRAM_MATERIAL_EMISSION_TEXTURE\n#ifdef TANGRAM_MATERIAL_EMISSION_TEXTURE_UV\nmaterial.emission*=texture2D(u_material_emission_texture,v_texcoord);\n#endif\n#ifdef TANGRAM_MATERIAL_EMISSION_TEXTURE_PLANAR\nmaterial.emission*=getPlanar(u_material_emission_texture,v_world_position.xyz,material.emissionScale.xy);\n#endif\n#ifdef TANGRAM_MATERIAL_EMISSION_TEXTURE_TRIPLANAR\nmaterial.emission*=getTriPlanar(u_material_emission_texture,v_world_position.xyz,_normal,material.emissionScale);\n#endif\n#ifdef TANGRAM_MATERIAL_EMISSION_TEXTURE_SPHEREMAP\nmaterial.emission*=getSphereMap(u_material_emission_texture,_eyeToPoint,_normal,u_center_offset);\n#endif\n#endif\n#ifdef TANGRAM_MATERIAL_AMBIENT_TEXTURE\n#ifdef TANGRAM_MATERIAL_AMBIENT_TEXTURE_UV\nmaterial.ambient*=texture2D(u_material_ambient_texture,v_texcoord);\n#endif\n#ifdef TANGRAM_MATERIAL_AMBIENT_TEXTURE_PLANAR\nmaterial.ambient*=getPlanar(u_material_ambient_texture,v_world_position.xyz,material.ambientScale.xy);\n#endif\n#ifdef TANGRAM_MATERIAL_AMBIENT_TEXTURE_TRIPLANAR\nmaterial.ambient*=getTriPlanar(u_material_ambient_texture,v_world_position.xyz,_normal,material.ambientScale);\n#endif\n#ifdef TANGRAM_MATERIAL_AMBIENT_TEXTURE_SPHEREMAP\nmaterial.ambient*=getSphereMap(u_material_ambient_texture,_eyeToPoint,_normal,u_center_offset);\n#endif\n#endif\n#ifdef TANGRAM_MATERIAL_DIFFUSE_TEXTURE\n#ifdef TANGRAM_MATERIAL_DIFFUSE_TEXTURE_UV\nmaterial.diffuse*=texture2D(u_material_diffuse_texture,v_texcoord);\n#endif\n#ifdef TANGRAM_MATERIAL_DIFFUSE_TEXTURE_PLANAR\nmaterial.diffuse*=getPlanar(u_material_diffuse_texture,v_world_position.xyz,material.diffuseScale.xy);\n#endif\n#ifdef TANGRAM_MATERIAL_DIFFUSE_TEXTURE_TRIPLANAR\nmaterial.diffuse*=getTriPlanar(u_material_diffuse_texture,v_world_position.xyz,_normal,material.diffuseScale);\n#endif\n#ifdef TANGRAM_MATERIAL_DIFFUSE_TEXTURE_SPHEREMAP\nmaterial.diffuse*=getSphereMap(u_material_diffuse_texture,_eyeToPoint,_normal,u_center_offset);\n#endif\n#endif\n#ifdef TANGRAM_MATERIAL_SPECULAR_TEXTURE\n#ifdef TANGRAM_MATERIAL_SPECULAR_TEXTURE_UV\nmaterial.specular*=texture2D(u_material_specular_texture,v_texcoord);\n#endif\n#ifdef TANGRAM_MATERIAL_SPECULAR_TEXTURE_PLANAR\nmaterial.specular*=getPlanar(u_material_specular_texture,v_world_position.xyz,material.specularScale.xy);\n#endif\n#ifdef TANGRAM_MATERIAL_SPECULAR_TEXTURE_TRIPLANAR\nmaterial.specular*=getTriPlanar(u_material_specular_texture,v_world_position.xyz,_normal,material.specularScale);\n#endif\n#ifdef TANGRAM_MATERIAL_SPECULAR_TEXTURE_SPHEREMAP\nmaterial.specular*=getSphereMap(u_material_specular_texture,_eyeToPoint,_normal,u_center_offset);\n#endif\n#endif\n}", material_props = ["emission", "ambient", "diffuse", "specular"], Material = function() {
          function e(r) {
            var i2 = this;
            _classCallCheck(this, e), r = r || {}, material_props.forEach(function(e2) {
              var t2 = r[e2];
              null != t2 && (t2.texture ? i2[e2] = { texture: t2.texture, mapping: t2.mapping || "spheremap", scale: GLSL.expandVec3(null != t2.scale ? t2.scale : 1), amount: GLSL.expandVec4(null != t2.amount ? t2.amount : 1) } : "number" == typeof t2 || Array.isArray(t2) ? i2[e2] = { amount: GLSL.expandVec4(t2) } : i2[e2] = "string" == typeof t2 ? { amount: StyleParser.parseColor(t2) } : t2);
            }), this.specular && (this.specular.shininess = r.shininess ? parseFloat(r.shininess) : 0.2), null != r.normal && (this.normal = { texture: r.normal.texture, mapping: r.normal.mapping || "triplanar", scale: GLSL.expandVec3(null != r.normal.scale ? r.normal.scale : 1), amount: null != r.normal.amount ? r.normal.amount : 1 });
          }
          return _createClass(e, [{ key: "inject", value: function(i2) {
            var n = this;
            material_props.forEach(function(e2) {
              var t2 = "TANGRAM_MATERIAL_".concat(e2.toUpperCase()), r = t2 + "_TEXTURE";
              i2.defines[t2] = null != n[e2], n[e2] && n[e2].texture && (i2.defines[r] = true, i2.defines[r + "_" + n[e2].mapping.toUpperCase()] = true, i2.defines["TANGRAM_MATERIAL_TEXTURE_".concat(n[e2].mapping.toUpperCase())] = true, i2.texcoords = i2.texcoords || "uv" === n[e2].mapping);
            }), this.normal && this.normal.texture && (i2.defines.TANGRAM_MATERIAL_NORMAL_TEXTURE = true, i2.defines["TANGRAM_MATERIAL_NORMAL_TEXTURE_" + this.normal.mapping.toUpperCase()] = true, i2.defines["TANGRAM_MATERIAL_TEXTURE_".concat(this.normal.mapping.toUpperCase())] = true, i2.texcoords = i2.texcoords || "uv" === this.normal.mapping), i2.replaceShaderBlock(e.block, shaderSrc_material, "Material"), i2.addShaderBlock("setup", "\nmaterial = u_material;\n", "Material");
          } }, { key: "setupProgram", value: function(t2) {
            var r = this;
            material_props.forEach(function(e2) {
              r[e2] && (r[e2].texture ? (t2.setTextureUniform("u_material_".concat(e2, "_texture"), r[e2].texture), t2.uniform("3fv", "u_material.".concat(e2, "Scale"), r[e2].scale), t2.uniform("4fv", "u_material.".concat(e2), r[e2].amount)) : r[e2].amount && t2.uniform("4fv", "u_material.".concat(e2), r[e2].amount));
            }), this.specular && t2.uniform("1f", "u_material.shininess", this.specular.shininess), this.normal && this.normal.texture && (t2.setTextureUniform("u_material_normal_texture", this.normal.texture), t2.uniform("3fv", "u_material.normalScale", this.normal.scale), t2.uniform("1f", "u_material.normalAmount", this.normal.amount));
          } }], [{ key: "isValid", value: function(e2) {
            return null != e2 && (null != e2.emission || null != e2.ambient || null != e2.diffuse || null != e2.specular);
          } }]), e;
        }(), Vector;
        Material.block = "material";
        var Vector$1 = Vector = {};
        Vector.copy = function(e) {
          for (var t2 = [], r = e.length, i2 = 0; i2 < r; i2++)
            t2[i2] = e[i2];
          return t2;
        }, Vector.neg = function(e) {
          for (var t2 = [], r = e.length, i2 = 0; i2 < r; i2++)
            t2[i2] = -e[i2];
          return t2;
        }, Vector.add = function(e, t2) {
          for (var r = [], i2 = Math.min(e.length, t2.length), n = 0; n < i2; n++)
            r[n] = e[n] + t2[n];
          return r;
        }, Vector.sub = function(e, t2) {
          for (var r = [], i2 = Math.min(e.length, t2.length), n = 0; n < i2; n++)
            r[n] = e[n] - t2[n];
          return r;
        }, Vector.signed_area = function(e, t2, r) {
          return (t2[0] - e[0]) * (r[1] - e[1]) - (r[0] - e[0]) * (t2[1] - e[1]);
        }, Vector.mult = function(e, t2) {
          var r, i2 = [], n = e.length;
          if ("number" == typeof t2)
            for (r = 0; r < n; r++)
              i2[r] = e[r] * t2;
          else
            for (n = Math.min(e.length, t2.length), r = 0; r < n; r++)
              i2[r] = e[r] * t2[r];
          return i2;
        }, Vector.multMatrix = function(e, t2) {
          return [e[0][0] * t2[0] + e[0][1] * t2[1], e[1][0] * t2[0] + e[1][1] * t2[1]];
        }, Vector.div = function(e, t2) {
          var r = [];
          if ("number" == typeof t2)
            for (n = 0; n < e.length; n++)
              r[n] = e[n] / t2;
          else
            for (var i2 = Math.min(e.length, t2.length), n = 0; n < i2; n++)
              r[n] = e[n] / t2[n];
          return r;
        }, Vector.perp = function(e, t2) {
          return [t2[1] - e[1], e[0] - t2[0]];
        }, Vector.rot = function(e, t2) {
          var r = Math.cos(t2), i2 = Math.sin(t2);
          return [e[0] * r - e[1] * i2, e[0] * i2 + e[1] * r];
        }, Vector.angle = function(e) {
          var t2 = _slicedToArray(e, 2), r = t2[0], i2 = t2[1];
          return Math.atan2(i2, r);
        }, Vector.angleBetween = function(e, t2) {
          var r = Vector.dot(Vector.normalize(Vector.copy(e)), Vector.normalize(Vector.copy(t2)));
          return 1 < r && (r = 1), Math.acos(r);
        }, Vector.signedAngleBetween = function(e, t2) {
          return Math.atan2(e[0] * t2[1] - e[1] * t2[0], e[0] * t2[0] + e[1] * t2[1]);
        }, Vector.isEqual = function(e, t2) {
          for (var r = e.length, i2 = 0; i2 < r; i2++)
            if (e[i2] !== t2[i2])
              return false;
          return true;
        }, Vector.lengthSq = function(e) {
          return 2 === e.length ? e[0] * e[0] + e[1] * e[1] : 3 <= e.length ? e[0] * e[0] + e[1] * e[1] + e[2] * e[2] : 0;
        }, Vector.length = function(e) {
          return Math.sqrt(Vector.lengthSq(e));
        }, Vector.normalize = function(e) {
          var t2;
          if (2 === e.length) {
            if (1 === (t2 = e[0] * e[0] + e[1] * e[1]))
              return e;
            0 !== (t2 = Math.sqrt(t2)) ? (e[0] /= t2, e[1] /= t2) : (e[0] = 0, e[1] = 0);
          } else if (3 <= e.length) {
            if (1 === (t2 = e[0] * e[0] + e[1] * e[1] + e[2] * e[2]))
              return e;
            0 !== (t2 = Math.sqrt(t2)) ? (e[0] /= t2, e[1] /= t2, e[2] /= t2) : (e[0] = 0, e[1] = 0, e[2] = 0);
          }
          return e;
        }, Vector.cross = function(e, t2) {
          return 2 === e.length ? e[0] * t2[1] - e[1] * t2[0] : 3 === e.length ? [e[1] * t2[2] - e[2] * t2[1], e[2] * t2[0] - e[0] * t2[2], e[0] * t2[1] - e[1] * t2[0]] : void 0;
        }, Vector.dot = function(e, t2) {
          for (var r = 0, i2 = Math.min(e.length, t2.length), n = 0; n < i2; n++)
            r += e[n] * t2[n];
          return r;
        };
        var shaderSrc_ambientLight = "/*Expected globals:light_accumulator_**/struct AmbientLight{vec3 ambient;};void calculateLight(in AmbientLight _light,in vec3 _eyeToPoint,in vec3 _normal){light_accumulator_ambient.rgb+=_light.ambient;}", shaderSrc_directionalLight = "/*Expected globals:materiallight_accumulator_**/struct DirectionalLight{vec3 ambient;vec3 diffuse;vec3 specular;vec3 direction;};void calculateLight(in DirectionalLight _light,in vec3 _eyeToPoint,in vec3 _normal){light_accumulator_ambient.rgb+=_light.ambient;float nDotVP=clamp(dot(_normal,-_light.direction),0.0,1.0);\n#ifdef TANGRAM_MATERIAL_DIFFUSE\nlight_accumulator_diffuse.rgb+=_light.diffuse*nDotVP;\n#endif\n#ifdef TANGRAM_MATERIAL_SPECULAR\nfloat pf=0.0;if(nDotVP>0.0){vec3 reflectVector=reflect(_light.direction,_normal);float eyeDotR=max(dot(normalize(_eyeToPoint),reflectVector),0.0);pf=pow(eyeDotR,material.shininess);}light_accumulator_specular.rgb+=_light.specular*pf;\n#endif\n}", shaderSrc_pointLight = "/*Expected globals:materiallight_accumulator_**/struct PointLight{vec3 ambient;vec3 diffuse;vec3 specular;vec4 position;\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_EXPONENT\nfloat attenuationExponent;\n#endif\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_INNER_RADIUS\nfloat innerRadius;\n#endif\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_OUTER_RADIUS\nfloat outerRadius;\n#endif\n};void calculateLight(in PointLight _light,in vec3 _eyeToPoint,in vec3 _normal){float dist=length(_light.position.xyz-_eyeToPoint);vec3 VP=(_light.position.xyz-_eyeToPoint)/dist;float nDotVP=clamp(dot(VP,_normal),0.0,1.0);float attenuation=1.0;\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_EXPONENT\nfloat Rin=1.0;float e=_light.attenuationExponent;\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_INNER_RADIUS\nRin=_light.innerRadius;\n#endif\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_OUTER_RADIUS\nfloat Rdiff=_light.outerRadius-Rin;float d=clamp(max(0.0,dist-Rin)/Rdiff,0.0,1.0);attenuation=1.0-(pow(d,e));\n#else\nfloat d=max(0.0,dist-Rin)/Rin+1.0;attenuation=clamp(1.0/(pow(d,e)),0.0,1.0);\n#endif\n#else\nfloat Rin=0.0;\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_INNER_RADIUS\nRin=_light.innerRadius;\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_OUTER_RADIUS\nfloat Rdiff=_light.outerRadius-Rin;float d=clamp(max(0.0,dist-Rin)/Rdiff,0.0,1.0);attenuation=1.0-d*d;\n#else\nfloat d=max(0.0,dist-Rin)/Rin+1.0;attenuation=clamp(1.0/d,0.0,1.0);\n#endif\n#else\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_OUTER_RADIUS\nfloat d=clamp(dist/_light.outerRadius,0.0,1.0);attenuation=1.0-d*d;\n#else\nattenuation=1.0;\n#endif\n#endif\n#endif\nlight_accumulator_ambient.rgb+=_light.ambient*attenuation;\n#ifdef TANGRAM_MATERIAL_DIFFUSE\nlight_accumulator_diffuse.rgb+=_light.diffuse*nDotVP*attenuation;\n#endif\n#ifdef TANGRAM_MATERIAL_SPECULAR\nfloat pf=0.0;if(nDotVP>0.0){vec3 reflectVector=reflect(-VP,_normal);float eyeDotR=max(0.0,dot(-normalize(_eyeToPoint),reflectVector));pf=pow(eyeDotR,material.shininess);}light_accumulator_specular.rgb+=_light.specular*pf*attenuation;\n#endif\n}", shaderSrc_spotLight = "/*Expected globals:materiallight_accumulator_**/struct SpotLight{vec3 ambient;vec3 diffuse;vec3 specular;vec4 position;\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_EXPONENT\nfloat attenuationExponent;\n#endif\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_INNER_RADIUS\nfloat innerRadius;\n#endif\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_OUTER_RADIUS\nfloat outerRadius;\n#endif\nvec3 direction;float spotCosCutoff;float spotExponent;};void calculateLight(in SpotLight _light,in vec3 _eyeToPoint,in vec3 _normal){float dist=length(_light.position.xyz-_eyeToPoint);vec3 VP=(_light.position.xyz-_eyeToPoint)/dist;float nDotVP=clamp(dot(_normal,VP),0.0,1.0);float attenuation=1.0;\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_EXPONENT\nfloat Rin=1.0;float e=_light.attenuationExponent;\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_INNER_RADIUS\nRin=_light.innerRadius;\n#endif\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_OUTER_RADIUS\nfloat Rdiff=_light.outerRadius-Rin;float d=clamp(max(0.0,dist-Rin)/Rdiff,0.0,1.0);attenuation=1.0-(pow(d,e));\n#else\nfloat d=max(0.0,dist-Rin)/Rin+1.0;attenuation=clamp(1.0/(pow(d,e)),0.0,1.0);\n#endif\n#else\nfloat Rin=0.0;\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_INNER_RADIUS\nRin=_light.innerRadius;\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_OUTER_RADIUS\nfloat Rdiff=_light.outerRadius-Rin;float d=clamp(max(0.0,dist-Rin)/Rdiff,0.0,1.0);attenuation=1.0-d*d;\n#else\nfloat d=max(0.0,dist-Rin)/Rin+1.0;attenuation=clamp(1.0/d,0.0,1.0);\n#endif\n#else\n#ifdef TANGRAM_POINTLIGHT_ATTENUATION_OUTER_RADIUS\nfloat d=clamp(dist/_light.outerRadius,0.0,1.0);attenuation=1.0-d*d;\n#else\nattenuation=1.0;\n#endif\n#endif\n#endif\nfloat spotAttenuation=0.0;float spotDot=clamp(dot(-VP,_light.direction),0.0,1.0);if(spotDot>=_light.spotCosCutoff){spotAttenuation=pow(spotDot,_light.spotExponent);}light_accumulator_ambient.rgb+=_light.ambient*attenuation*spotAttenuation;\n#ifdef TANGRAM_MATERIAL_DIFFUSE\nlight_accumulator_diffuse.rgb+=_light.diffuse*nDotVP*attenuation*spotAttenuation;\n#endif\n#ifdef TANGRAM_MATERIAL_SPECULAR\nfloat pf=0.0;if(nDotVP>0.0){vec3 reflectVector=reflect(-VP,_normal);float eyeDotR=max(dot(-normalize(_eyeToPoint),reflectVector),0.0);pf=pow(eyeDotR,material.shininess);}light_accumulator_specular.rgb+=_light.specular*pf*attenuation*spotAttenuation;\n#endif\n}", Light = function() {
          function s(e, t2) {
            _classCallCheck(this, s), this.name = t2.name, this.view = e, null == t2.ambient || "number" == typeof t2.ambient ? this.ambient = GLSL.expandVec3(t2.ambient || 0) : this.ambient = StyleParser.parseColor(t2.ambient).slice(0, 3), null == t2.diffuse || "number" == typeof t2.diffuse ? this.diffuse = GLSL.expandVec3(null != t2.diffuse ? t2.diffuse : 1) : this.diffuse = StyleParser.parseColor(t2.diffuse).slice(0, 3), null == t2.specular || "number" == typeof t2.specular ? this.specular = GLSL.expandVec3(t2.specular || 0) : this.specular = StyleParser.parseColor(t2.specular).slice(0, 3);
          }
          return _createClass(s, [{ key: "inject", value: function() {
            var e = "\n            uniform ".concat(this.struct_name, " u_").concat(this.name, ";\n            ").concat(this.struct_name, " ").concat(this.name, ";\n            "), t2 = "\n            ".concat(this.name, " = u_").concat(this.name, ";\n\n        ");
            ShaderProgram.addBlock(s.block, e), ShaderProgram.addBlock("setup", t2);
          } }, { key: "update", value: function() {
          } }, { key: "setupProgram", value: function(e) {
            e.uniform("3fv", "u_".concat(this.name, ".ambient"), this.ambient), e.uniform("3fv", "u_".concat(this.name, ".diffuse"), this.diffuse), e.uniform("3fv", "u_".concat(this.name, ".specular"), this.specular);
          } }], [{ key: "create", value: function(e, t2) {
            if (s.types[t2.type])
              return new s.types[t2.type](e, t2);
          } }, { key: "setMode", value: function(e, t2) {
            true === e && (e = "fragment"), e = s.enabled && (null != e ? e : "fragment"), t2.defines.TANGRAM_LIGHTING_FRAGMENT = "fragment" === e, t2.defines.TANGRAM_LIGHTING_VERTEX = "vertex" === e;
          } }, { key: "inject", value: function(e) {
            if (ShaderProgram.removeBlock(s.block), s.enabled) {
              var t2 = "";
              if (e && 0 < Object.keys(e).length) {
                var r = {};
                for (var i2 in e)
                  r[e[i2].type] = true;
                for (var n in r)
                  s.types[n].inject();
                for (var o in e)
                  e[o].inject(), t2 += "calculateLight(".concat(o, ", _eyeToPoint, _normal);\n");
              }
              var a2 = "\n            vec4 calculateLighting(in vec3 _eyeToPoint, in vec3 _normal, in vec4 _color) {\n\n                // Do initial material calculations over normal, emission, ambient, diffuse and specular values\n                calculateMaterial(_eyeToPoint,_normal);\n\n                // Un roll the loop of individual ligths to calculate\n                ".concat(t2, "\n\n                //  Final light intensity calculation\n                vec4 color = vec4(vec3(0.), _color.a); // start with vertex color alpha\n\n                #ifdef TANGRAM_MATERIAL_EMISSION\n                    color.rgb = material.emission.rgb;\n                    color.a *= material.emission.a;\n                #endif\n\n                #ifdef TANGRAM_MATERIAL_AMBIENT\n                    color.rgb += light_accumulator_ambient.rgb * _color.rgb * material.ambient.rgb;\n                    color.a *= material.ambient.a;\n                #else\n                    #ifdef TANGRAM_MATERIAL_DIFFUSE\n                        color.rgb += light_accumulator_ambient.rgb * _color.rgb * material.diffuse.rgb;\n                    #endif\n                #endif\n\n                #ifdef TANGRAM_MATERIAL_DIFFUSE\n                    color.rgb += light_accumulator_diffuse.rgb * _color.rgb * material.diffuse.rgb;\n                    color.a *= material.diffuse.a;\n                #endif\n\n                #ifdef TANGRAM_MATERIAL_SPECULAR\n                    color.rgb += light_accumulator_specular.rgb * material.specular.rgb;\n                    color.a *= material.specular.a;\n                #endif\n\n                // Clamp final color\n                color = clamp(color, 0.0, 1.0);\n\n                return color;\n            }");
              ShaderProgram.addBlock(s.block, a2);
            }
          } }]), s;
        }();
        Light.types = {}, Light.block = "lighting", Light.enabled = true;
        var AmbientLight = function() {
          _inherits(n, Light);
          var i2 = _createSuper(n);
          function n(e, t2) {
            var r;
            return _classCallCheck(this, n), (r = i2.call(this, e, t2)).type = "ambient", r.struct_name = "AmbientLight", r;
          }
          return _createClass(n, [{ key: "setupProgram", value: function(e) {
            e.uniform("3fv", "u_".concat(this.name, ".ambient"), this.ambient);
          } }], [{ key: "inject", value: function() {
            ShaderProgram.addBlock(Light.block, shaderSrc_ambientLight);
          } }]), n;
        }();
        Light.types.ambient = AmbientLight;
        var DirectionalLight = function() {
          _inherits(o, Light);
          var n = _createSuper(o);
          function o(e, t2) {
            var r, i2;
            return _classCallCheck(this, o), (r = n.call(this, e, t2)).type = "directional", r.struct_name = "DirectionalLight", t2.direction ? r._direction = t2.direction : (i2 = Math.sin(60 * Math.PI / 180), r._direction = [Math.cos(135 * Math.PI / 180) * i2, Math.sin(135 * Math.PI / 180) * i2, -0.5]), null == t2.ambient && (r.ambient = GLSL.expandVec3(0.5)), r.direction = r._direction.map(parseFloat), r._initial_direction = [r.direction[0], r.direction[1], r.direction[2]], r;
          }
          return _createClass(o, [{ key: "update", value: function() {
            vec3.transformMat4(this.direction, this._initial_direction, this.view.lookAtManipulator.getTransformationMatrix());
          } }, { key: "setupProgram", value: function(e) {
            _get(_getPrototypeOf(o.prototype), "setupProgram", this).call(this, e), e.uniform("3fv", "u_".concat(this.name, ".direction"), this.direction);
          } }, { key: "direction", get: function() {
            return this._direction;
          }, set: function(e) {
            this._direction = Vector$1.normalize(Vector$1.copy(e));
          } }], [{ key: "inject", value: function() {
            ShaderProgram.addBlock(Light.block, shaderSrc_directionalLight);
          } }]), o;
        }();
        Light.types.directional = DirectionalLight;
        var PointLight = function() {
          _inherits(n, Light);
          var i2 = _createSuper(n);
          function n(e, t2) {
            var r;
            return _classCallCheck(this, n), (r = i2.call(this, e, t2)).type = "point", r.struct_name = "PointLight", r.position = t2.position || [0, 0, "100px"], r.position_eye = [], r.origin = t2.origin || "ground", r.attenuation = isNaN(parseFloat(t2.attenuation)) ? 0 : parseFloat(t2.attenuation), t2.radius ? Array.isArray(t2.radius) && 2 === t2.radius.length ? r.radius = t2.radius : r.radius = [null, t2.radius] : r.radius = null, r;
          }
          return _createClass(n, [{ key: "inject", value: function() {
            _get(_getPrototypeOf(n.prototype), "inject", this).call(this), ShaderProgram.defines.TANGRAM_POINTLIGHT_ATTENUATION_EXPONENT = 0 !== this.attenuation, ShaderProgram.defines.TANGRAM_POINTLIGHT_ATTENUATION_INNER_RADIUS = null != this.radius && null != this.radius[0], ShaderProgram.defines.TANGRAM_POINTLIGHT_ATTENUATION_OUTER_RADIUS = null != this.radius;
          } }, { key: "update", value: function() {
            var e, t2, r, i3 = this.view.lookAtManipulator.getLookAtData().zoom;
            "world" === this.origin ? (t2 = (e = _slicedToArray(Geo$1.latLngToMeters(this.position), 2))[0], r = e[1], this.position_eye[0] = t2 - this.view.lookAtManipulator.getLookAtData().position[0], this.position_eye[1] = r - this.view.lookAtManipulator.getLookAtData().position[1], this.position_eye[2] = StyleParser.convertUnits(this.position[2], { zoom: i3, meters_per_pixel: Geo$1.metersPerPixel(i3) }), this.position_eye[2] = this.position_eye[2] - this.view.lookAtManipulator.getLookAtData().distance) : "ground" !== this.origin && "camera" !== this.origin || (this.position_eye = StyleParser.convertUnits(this.position, { zoom: i3, meters_per_pixel: Geo$1.metersPerPixel(i3) }), "ground" === this.origin && (this.position_eye[2] = this.position_eye[2] - this.view.lookAtManipulator.getLookAtData().distance)), this.position_eye[3] = 1;
          } }, { key: "setupProgram", value: function(e) {
            _get(_getPrototypeOf(n.prototype), "setupProgram", this).call(this, e), e.uniform("4fv", "u_".concat(this.name, ".position"), this.position_eye), ShaderProgram.defines.TANGRAM_POINTLIGHT_ATTENUATION_EXPONENT && e.uniform("1f", "u_".concat(this.name, ".attenuationExponent"), this.attenuation);
            var t2 = this.view.lookAtManipulator.getLookAtData().zoom;
            ShaderProgram.defines.TANGRAM_POINTLIGHT_ATTENUATION_INNER_RADIUS && e.uniform("1f", "u_".concat(this.name, ".innerRadius"), StyleParser.convertUnits(this.radius[0], { zoom: t2, meters_per_pixel: Geo$1.metersPerPixel(t2) })), ShaderProgram.defines.TANGRAM_POINTLIGHT_ATTENUATION_OUTER_RADIUS && e.uniform("1f", "u_".concat(this.name, ".outerRadius"), StyleParser.convertUnits(this.radius[1], { zoom: t2, meters_per_pixel: Geo$1.metersPerPixel(t2) }));
          } }], [{ key: "inject", value: function() {
            ShaderProgram.addBlock(Light.block, shaderSrc_pointLight);
          } }]), n;
        }();
        Light.types.point = PointLight;
        var SpotLight = function() {
          _inherits(n, PointLight);
          var i2 = _createSuper(n);
          function n(e, t2) {
            var r;
            return _classCallCheck(this, n), (r = i2.call(this, e, t2)).type = "spotlight", r.struct_name = "SpotLight", r.direction = r._direction = (t2.direction || [0, 0, -1]).map(parseFloat), r._initial_direction = [r.direction[0], r.direction[1], r.direction[2]], r.exponent = t2.exponent ? parseFloat(t2.exponent) : 0.2, r.angle = t2.angle ? parseFloat(t2.angle) : 20, r;
          }
          return _createClass(n, [{ key: "setupProgram", value: function(e) {
            _get(_getPrototypeOf(n.prototype), "setupProgram", this).call(this, e), e.uniform("3fv", "u_".concat(this.name, ".direction"), this.direction), e.uniform("1f", "u_".concat(this.name, ".spotCosCutoff"), Math.cos(3.14159 * this.angle / 180)), e.uniform("1f", "u_".concat(this.name, ".spotExponent"), this.exponent);
          } }, { key: "update", value: function() {
            _get(_getPrototypeOf(n.prototype), "update", this).call(this), vec3.transformMat4(this.direction, this._initial_direction, this.view.lookAtManipulator.getTransformationMatrix());
          } }, { key: "direction", get: function() {
            return this._direction;
          }, set: function(e) {
            this._direction = Vector$1.normalize(Vector$1.copy(e));
          } }], [{ key: "inject", value: function() {
            ShaderProgram.addBlock(Light.block, shaderSrc_spotLight);
          } }]), n;
        }();
        function mergeObjects(e) {
          for (var t2 = 0; t2 < (arguments.length <= 1 ? 0 : arguments.length - 1); t2++) {
            var r = t2 + 1 < 1 || arguments.length <= t2 + 1 ? void 0 : arguments[t2 + 1];
            if (r)
              for (var i2 in r) {
                var n = r[i2];
                null === n || "object" !== _typeof(n) || Array.isArray(n) ? void 0 !== n && (e[i2] = n) : null === e[i2] || "object" !== _typeof(e[i2]) || Array.isArray(e[i2]) ? e[i2] = mergeObjects({}, n) : e[i2] = mergeObjects(e[i2], n);
              }
          }
          return e;
        }
        Light.types.spotlight = SpotLight;
        var shaderSrc_selectionFragment = "\n#ifdef TANGRAM_FEATURE_SELECTION\nvarying vec4 v_selection_color;\n#endif\nvoid main(void){\n#ifdef TANGRAM_FEATURE_SELECTION\ngl_FragColor=v_selection_color;\n#else\ngl_FragColor=vec4(0.,0.,0.,1.);\n#endif\n}", shaderSrc_selectionCropFragment = "\n#pragma tangram: utils\n#ifdef TANGRAM_FEATURE_SELECTION\nuniform float u_meters_per_pixel;varying vec4 v_selection_color;varying vec4 v_local_space_position;\n#endif\nvoid main(void){\n#ifdef TANGRAM_FEATURE_SELECTION\nif(isLocalSpacePixelOutsideTile(v_local_space_position,TANGRAM_TILE_SCALE.x)){discard;}else{gl_FragColor=v_selection_color;}\n#else\ngl_FragColor=vec4(0.,0.,0.,1.);\n#endif\n}", shaderSrc_rasters = "#ifdef TANGRAM_FRAGMENT_SHADER\nuniform sampler2D u_raster;uniform vec3 u_raster_offset;\n#define sampleRaster() (texture2D(u_raster, v_modelpos_base_zoom.xy * u_raster_offset.z + u_raster_offset.xy))\n#endif\n", Style = { init: function(e) {
          var t2 = 0 < arguments.length && void 0 !== e ? e : {}, r = t2.generation, i2 = t2.styles, n = t2.sources, o = void 0 === n ? {} : n, a2 = t2.introspection, s = t2.id, l = void 0 !== s ? s + "/" : "";
          this.scene_id = s, this.textureManager = getTextureManager(s), this.main_thread_target = "".concat(l, "Style/").concat(this.name), this.setGeneration(r), this.styles = i2, this.sources = o, this.defines = this.hasOwnProperty("defines") && this.defines || {}, this.shaders = this.hasOwnProperty("shaders") && this.shaders || {}, this.introspection = a2 || false, this.selection = this.selection || this.introspection || false, this.compile_setup = false, this.program = null, this.selection_program = null, this.feature_style = {}, this.vertex_template = [], this.tile_data = {}, this.defines.TANGRAM_WORLD_POSITION_WRAP = 1e5, this.blend = this.blend || "opaque", this.defines["TANGRAM_BLEND_".concat(this.blend.toUpperCase())] = true, null == this.blend_order && (this.blend_order = -1), this.removeShaderBlock("setup"), this.material instanceof Material || (Material.isValid(this.material) || (this.material = StyleParser.defaults.material), this.material = new Material(this.material)), this.material.inject(this), Light.setMode(this.lighting, this), this.setupRasters(), this.initialized = true;
        }, destroy: function() {
          this.program && (this.program.destroy(), this.program = null), this.selection_program && (this.selection_program.destroy(), this.selection_program = null), WorkerBroker.removeTarget(this.main_thread_target), this.gl = null, this.initialized = false;
        }, reset: function() {
        }, baseStyle: function() {
          return this.base || this.name;
        }, setGeneration: function(e) {
          this.generation = e, Thread.is_main && WorkerBroker.addTarget(this.main_thread_target, this);
        }, fillVertexTemplate: function(e, t2, r, i2) {
          var n = i2.size, o = void 0 === (o = i2.offset) ? 0 : o, a2 = e.index[t2];
          if (void 0 !== a2)
            for (var s = 0; s < n; ++s) {
              var l = r.length > s ? r[s] : r;
              this.vertex_template[a2 + s + o] = l;
            }
          else
            log("warn", "Style: in style '".concat(this.name, "', no index found in vertex layout for attribute '").concat(t2, "'"));
        }, startData: function(e) {
          this.tile_data[e.id] = this.tile_data[e.id] || { meshes: {}, uniforms: {}, textures: [] };
        }, endData: function(e) {
          var t2 = this.tile_data[e.id];
          if (this.tile_data[e.id] = null, t2 && 0 < Object.keys(t2.meshes).length) {
            for (var r in t2.meshes) {
              var i2 = t2.meshes[r];
              0 !== i2.vertex_data.vertex_count ? (i2.vertex_data.end(), i2.vertex_elements = i2.vertex_data.element_buffer, i2.vertex_data = i2.vertex_data.vertex_buffer) : delete t2.meshes[r];
            }
            return e.mesh_data[this.name] = t2, this.buildRasterTextures(e, t2).then(function(e2) {
              return e2;
            });
          }
          return Promise.resolve(null);
        }, hasDataForTile: function(e) {
          return null != this.tile_data[e.id];
        }, getTileMesh: function(e, t2) {
          var r = this.tile_data[e.id].meshes;
          return null == r[t2.key] && (r[t2.key] = { variant: t2, vertex_data: this.vertexLayoutForMeshVariant(t2).createVertexData() }), r[t2.key];
        }, vertexLayoutForMeshVariant: function() {
          return this.vertex_layout;
        }, default_mesh_variant: { key: 0 }, style_mesh_variants: { default: { variants: { 0: { variant: { key: 0 }, times_unref: 0 } } } }, addMeshVariantForDraw: function(e, t2) {
          this.style_mesh_variants[e] || (this.style_mesh_variants[e] = { variants: {} });
          var r = this.computeVariantForDraw(t2);
          return this.style_mesh_variants[e].variants[r.key] = { variant: r, times_unref: 0 }, this.style_mesh_variants[e].variants[r.key].variant;
        }, getMeshVariantTypeForDraw: function(e) {
          return this.getMeshVariantType(this.base, e);
        }, getMeshVariantType: function(e, t2) {
          void 0 === e && (e = "default");
          var r = this.style_mesh_variants[e];
          if (void 0 === t2.variantKey || !r || !r.variants[t2.variantKey])
            return this.addMeshVariantForDraw(e, t2);
          var i2 = t2.variantKey, n = r.variants[i2];
          return n.times_unref = 0, n.variant;
        }, updateMeshVariantTypeCache: function(e) {
          for (var t2 in this.style_mesh_variants) {
            var r = this.style_mesh_variants[t2].variants;
            for (var i2 in r) {
              var n = r[i2];
              n.times_unref++, n.times_unref > e && ("default" !== t2 || 0 != +i2) && (delete r[i2], 0 === Object.keys(r).length && delete this.style_mesh_variants[t2]);
            }
          }
        }, computeVariantForDraw: function() {
          return this.default_mesh_variant;
        }, addFeature: function(e, t2, r) {
          var i2 = r.tile;
          this.tile_data[i2.id] || this.startData(i2);
          var n, o, a2, s, l = this.parseFeature(e, t2, r);
          l && (n = "lines" === this.base ? this.getMeshVariantTypeForDraw(t2) : this.getMeshVariantTypeForDraw(l), a2 = (o = this.getTileMesh(i2, n)).vertex_data.offset, s = o.vertex_data.vertex_count, 0 < this.buildGeometry(e.geometry, l, o, r) ? e.generation = this.generation : o.vertex_data.vertex_count > s && (o.vertex_data.vertex_buffer.fill(0, a2, o.vertex_data.offset), o.vertex_data.vertex_count = s, o.vertex_data.offset = a2));
        }, buildGeometry: function(e, t2, r, i2) {
          var n;
          return "Polygon" === e.type ? n = this.buildPolygons([e.coordinates], t2, r, i2) : "MultiPolygon" === e.type ? n = this.buildPolygons(e.coordinates, t2, r, i2) : "LineString" === e.type ? n = this.buildLines([e.coordinates], t2, r, i2) : "MultiLineString" === e.type ? n = this.buildLines(e.coordinates, t2, r, i2) : "Point" === e.type ? n = this.buildPoints([e.coordinates], t2, r, i2) : "MultiPoint" === e.type && (n = this.buildPoints(e.coordinates, t2, r, i2)), n;
        }, parseFeature: function(t2, e, r) {
          try {
            var i2, n, o, a2 = this.feature_style;
            if (a2.order = this.parseOrder(e.order, r), null == a2.order && "overlay" !== this.blend) {
              var s = "Layer '".concat(e.layers.join(", "), "', draw group '").concat(e.group, "': ");
              return s += "'order' parameter is required unless blend mode is 'overlay'", null != e.order && (s += "; 'order' was set to a dynamic value (e.g. string tied to feature property, ", s += "or JS function), but evaluated to null for one or more features"), void log({ level: "warn", once: true }, s);
            }
            if (!(a2 = this._parseFeature(t2, e, r)))
              return;
            return this.selection ? a2.interactive = StyleParser.evalProperty(this.introspection || e.interactive, r) : a2.interactive = false, true === a2.interactive ? (n = (i2 = FeatureSelection.makeEntry()).color, o = i2.key, a2.selection_color = n, r.tile.selection_data || (r.tile.selection_data = {}), r.tile.selection_data[o] = { id: t2.id || o, properties: t2.properties, source_name: r.source, source_layer: r.layer, layers: r.layers }) : a2.selection_color = FeatureSelection.defaultColor, a2;
          } catch (e2) {
            log("error", "Style.parseFeature: style parsing error", t2, a2, e2.stack);
          }
        }, _parseFeature: function() {
          return this.feature_style;
        }, preprocess: function(e, t2) {
          if (!e.preprocessed) {
            if (this.draw)
              for (var r in this.draw) {
                var i2 = this.draw[r];
                "object" !== _typeof(i2) || Array.isArray(i2) ? null == e[r] && (e[r] = i2) : e[r] = mergeObjects({}, i2, e[r]);
              }
            var n = t2 || "";
            if (!(e = this._preprocess(e, n)))
              return;
            e.preprocessed = true;
          }
          return e;
        }, _preprocess: function(e) {
          return e;
        }, parseOrder: function(e, t2) {
          return "number" != typeof e ? StyleParser.calculateOrder(e, t2) : e;
        }, scaleOrder: function(e) {
          return 2 * e;
        }, parseColor: function(e, t2) {
          return e ? StyleParser.evalCachedColorProperty(e, t2) : this.shaders.blocks.color || this.shaders.blocks.filter ? StyleParser.defaults.color : void 0;
        }, buildPolygons: function() {
          return 0;
        }, buildLines: function() {
          return 0;
        }, buildPoints: function() {
          return 0;
        }, setGL: function(e) {
          this.gl = e, this.max_texture_size = this.textureManager.getMaxTextureSize(this.gl);
        }, makeMesh: function(e, t2, r) {
          var i2 = 2 < arguments.length && void 0 !== r ? r : {}, n = this.vertexLayoutForMeshVariant(i2.variant);
          return new VBOMesh(this.gl, e, t2, n, this.scene_id, i2);
        }, render: function(e) {
          return e.render();
        }, getProgram: function(e) {
          var t2 = 0 < arguments.length && void 0 !== e ? e : "program";
          this.compileSetup();
          var r = this[t2];
          if (r && !r.error) {
            if (!r.compiled)
              try {
                r.compile();
              } catch (e2) {
                log("error", "Style: error compiling program for style '".concat(this.name, "' (program key '").concat(t2, "')"), this, e2.stack);
              }
            return r;
          }
        }, compileSetup: function() {
          if (!this.compile_setup) {
            if (!this.gl)
              throw new Error("style.compile(): skipping for ".concat(this.name, " because no GL context"));
            var e, t2 = this.buildDefineList();
            this.selection && ((e = Object.assign({}, t2)).TANGRAM_FEATURE_SELECTION = true);
            var r = this.shaders && this.shaders.blocks, i2 = this.shaders && this.shaders.block_scopes, n = Object.assign({}, this.shaders && this.shaders.uniforms);
            for (var o in n)
              null == n[o] && log({ level: "warn", once: true }, "Style '".concat(this.name, "' has invalid uniform '").concat(o, "': uniform values must be non-null"));
            var a2 = this.shaders && this.shaders.extensions;
            "string" == typeof a2 && (a2 = [a2]), this.program = new ShaderProgram(this.gl, this.vertex_shader_src, this.fragment_shader_src, this.scene_id, { name: this.name, defines: t2, uniforms: n, blocks: r, block_scopes: i2, extensions: a2 }), this.selection ? this.selection_program = new ShaderProgram(this.gl, this.vertex_shader_src, this.crop_by_tile ? shaderSrc_selectionCropFragment : shaderSrc_selectionFragment, this.scene_id, { name: this.name + " (selection)", defines: e, uniforms: n, blocks: r, block_scopes: i2, extensions: a2 }) : this.selection_program = null, this.compile_setup = true;
          }
        }, addShaderBlock: function(e, t2, r) {
          var i2 = 2 < arguments.length && void 0 !== r ? r : null;
          this.shaders.blocks = this.shaders.blocks || {}, this.shaders.blocks[e] = this.shaders.blocks[e] || [], this.shaders.blocks[e].push(t2), this.shaders.block_scopes = this.shaders.block_scopes || {}, this.shaders.block_scopes[e] = this.shaders.block_scopes[e] || [], this.shaders.block_scopes[e].push(i2);
        }, removeShaderBlock: function(e) {
          this.shaders.blocks && (this.shaders.blocks[e] = null);
        }, replaceShaderBlock: function(e, t2, r) {
          var i2 = 2 < arguments.length && void 0 !== r ? r : null;
          this.removeShaderBlock(e), this.addShaderBlock(e, t2, i2);
        }, buildDefineList: function() {
          var e = {};
          if (null != this.defines)
            for (var t2 in this.defines)
              e[t2] = this.defines[t2];
          if (null != this.shaders && null != this.shaders.defines)
            for (t2 in this.shaders.defines)
              e[t2] = this.shaders.defines[t2];
          return e;
        }, hasRasters: function() {
          return -1 < ["color", "normal", "custom"].indexOf(this.raster);
        }, setupRasters: function() {
          if (!Thread.is_main)
            return false;
          if (!this.hasRasters())
            return false;
          "color" === this.raster ? this.defines.TANGRAM_RASTER_TEXTURE_COLOR = true : "normal" === this.raster && (this.defines.TANGRAM_RASTER_TEXTURE_NORMAL = true);
          var e = false;
          for (var t2 in this.sources)
            if (this.sources[t2] instanceof RasterTileSource) {
              e = true;
              break;
            }
          return !!e && (this.defines.TANGRAM_MODEL_POSITION_BASE_ZOOM_VARYING = true, this.replaceShaderBlock("raster", shaderSrc_rasters, "Raster"), true);
        }, buildRasterTextures: function(o, a2) {
          var t2 = this;
          if (!this.hasRasters())
            return Promise.resolve(a2);
          var s = {};
          return o.rasters.map(function(e) {
            return t2.sources[e];
          }).filter(function(e) {
            return e;
          }).forEach(function(e, t3) {
            var r;
            e instanceof RasterTileSource && (r = e.tileTexture(o), s[r.url] = r);
          }), 0 === Object.keys(s).length ? Promise.resolve(a2) : WorkerBroker.postMessage(this.main_thread_target + ".loadTextures", s).then(function(e) {
            if (!e || e.length < 1)
              return log("trace", "Missing texture info for tile ".concat(o.key)), null;
            if (e.some(function(e2) {
              return !e2.loaded;
            }))
              return null;
            a2.uniforms = a2.uniforms || {}, a2.textures = a2.textures || [];
            var t3, r, i2 = e[0].name, n = s[i2].coords;
            return a2.uniforms.u_raster = i2, a2.textures.push(i2), o.coords.z > n.z ? (t3 = o.coords.z - n.z, r = Math.pow(2, t3), a2.uniforms.u_raster_offset = [(o.coords.x % r + r) % r / r, (r - 1 - o.coords.y % r) / r, 1 / r]) : a2.uniforms.u_raster_offset = [0, 0, 1], a2;
          });
        }, loadTextures: function(e) {
          var t2 = this;
          return this.textureManager.createFromObject(this.gl, e).then(function() {
            return Promise.all(Object.keys(e).map(function(e2) {
              return t2.textureManager.textures[e2] && t2.textureManager.textures[e2].load();
            }).filter(function(e2) {
              return e2;
            }));
          }).then(function(e2) {
            return e2.forEach(function(e3) {
              return e3.retain();
            }), e2.map(function(e3) {
              return { name: e3.name, width: e3.width, height: e3.height, loaded: e3.loaded };
            });
          });
        }, setup: function() {
          this.setUniforms(), this.material.setupProgram(ShaderProgram.current);
        }, setUniforms: function() {
          var e = ShaderProgram.current;
          e && e.setUniforms(this.shaders && this.shaders.uniforms, true);
        }, render_states: { opaque: { depth_test: true, depth_write: true }, translucent: { depth_test: true, depth_write: true }, add: { depth_test: true, depth_write: false }, multiply: { depth_test: true, depth_write: false }, inlay: { depth_test: true, depth_write: false }, overlay: { depth_test: false, depth_write: false } }, default_blend_orders: { opaque: 0, add: 1, multiply: 2, inlay: 3, translucent: 4, overlay: 5 }, sortByBlendOrderWithinLayers: function(e) {
          var t2 = [], r = {};
          for (var i2 in e.forEach(function(e2) {
            var t3 = parseInt(e2.name, 10) || 0;
            r[t3] || (r[t3] = []), r[t3].push(e2);
          }), r)
            t2.push.apply(t2, _toConsumableArray(r[i2].sort(Style.blendOrderSort)));
          return t2;
        }, blendOrderSort: function(e, t2) {
          return "opaque" === e.blend || "opaque" === t2.blend ? "opaque" === e.blend && "opaque" === t2.blend ? e.name < t2.name ? -1 : 1 : "opaque" === e.blend ? -1 : 1 : e.blend_order < t2.blend_order || !(e.blend_order > t2.blend_order) && (Style.default_blend_orders[e.blend] < Style.default_blend_orders[t2.blend] || !(Style.default_blend_orders[e.blend] > Style.default_blend_orders[t2.blend]) && e.name < t2.name) ? -1 : 1;
        } }, id$1 = 0, build_id = 0, Tile = function() {
          function E2(e) {
            var t2 = e.coords, r = e.style_zoom, i2 = e.source, n = e.worker, o = e.view, a2 = e.sceneId;
            _classCallCheck(this, E2), this.textureManager = getTextureManager(a2), this.id = id$1++, this.worker = n, this.view = o, this.source = i2, this.generation = null, this.valid = true, this.proxy_for = null, this.proxy_depth = 0, this.proxied_as = null, this.fade_in = true, this.loading = false, this.loaded = false, this.built = false, this.labeled = false, this.error = null, this.style_zoom = r, this.coords = E2.normalizedCoordinate(t2, this.source, this.style_zoom), this.key = E2.key(this.coords, this.source, this.style_zoom), this.overzoom = Math.max(this.style_zoom - this.coords.z, 0), this.overzoom2 = Math.pow(2, this.overzoom), this.min = Geo$1.metersForTile(this.coords), this.max = Geo$1.metersForTile({ x: this.coords.x + 1, y: this.coords.y + 1, z: this.coords.z }), this.span = { x: this.max.x - this.min.x, y: this.max.y - this.min.y }, this.bounds = { sw: { x: this.min.x, y: this.max.y }, ne: { x: this.max.x, y: this.min.y } }, this.center_dist = 0, this.meters_per_pixel = Geo$1.metersPerPixel(this.style_zoom), this.meters_per_pixel_sq = this.meters_per_pixel * this.meters_per_pixel, this.units_per_pixel = Geo$1.units_per_pixel / this.overzoom2, this.units_per_meter_overzoom = Geo$1.unitsPerMeter(this.coords.z) * this.overzoom2, this.meshes = {}, this.new_mesh_styles = [];
          }
          return _createClass(E2, [{ key: "freeResources", value: function() {
            for (var e in this.meshes)
              this.meshes[e].forEach(function(e2) {
                return e2.destroy();
              });
            this.meshes = {};
          } }, { key: "destroy", value: function() {
            Task.removeForTile(this.id), this.workerMessage("self.removeTile", this.id), this.freeResources(), this.worker = null, this.valid = false;
          } }, { key: "buildAsMessage", value: function() {
            return { id: this.id, key: this.key, source: this.source.name, coords: this.coords, min: this.min, max: this.max, units_per_pixel: this.units_per_pixel, meters_per_pixel: this.meters_per_pixel, meters_per_pixel_sq: this.meters_per_pixel_sq, units_per_meter_overzoom: this.units_per_meter_overzoom, style_zoom: this.style_zoom, overzoom: this.overzoom, overzoom2: this.overzoom2, generation: this.generation };
          } }, { key: "workerMessage", value: function() {
            for (var e = arguments.length, t2 = new Array(e), r = 0; r < e; r++)
              t2[r] = arguments[r];
            return WorkerBroker.postMessage.apply(WorkerBroker, [this.worker].concat(t2));
          } }, { key: "build", value: function(e, t2) {
            var r = (1 < arguments.length && void 0 !== t2 ? t2 : {}).fade_in, i2 = void 0 === r || r;
            return this.generation = e, this.fade_in = i2, this.loaded || (this.loading = true, this.built = false, this.labeled = false), this.workerMessage("self.buildTile", { tile: this.buildAsMessage() });
          } }, { key: "buildMeshes", value: function(e, t2) {
            if (!this.error) {
              this.build_id = build_id++;
              var r = {}, i2 = this.mesh_data;
              if (i2)
                for (var n in i2) {
                  for (var o in i2[n].meshes) {
                    var a2 = i2[n].meshes[o];
                    if (a2.vertex_data) {
                      if (!e[n]) {
                        log("warn", "Could not create mesh because style '".concat(n, "' not found, for tile ").concat(this.key, ", aborting tile"));
                        break;
                      }
                      var s = Object.assign({}, i2[n]);
                      s.uniforms = Object.assign({}, s.uniforms, a2.uniforms), s.variant = a2.variant, a2.textures && (s.textures = a2.textures), a2.labels && (s.retain = true);
                      var l = e[n].makeMesh(a2.vertex_data, a2.vertex_elements, s);
                      l.variant = s.variant, l.labels = a2.labels, r[n] = r[n] || [], r[n].push(l), null == l.variant.order && (l.variant.order = r[n].length - 1);
                    }
                  }
                  r[n] && r[n].sort(function(e2, t3) {
                    var r2 = e2.variant.order, i3 = t3.variant.order;
                    return null != r2 && (null == i3 || r2 < i3) ? -1 : 1;
                  });
                }
              for (var u2 in delete this.mesh_data, r)
                this.meshes[u2] && this.meshes[u2].forEach(function(e2) {
                  return e2.destroy();
                }), this.meshes[u2] = r[u2], this.new_mesh_styles.push(u2);
              if (t2.done) {
                for (var c2 in this.meshes)
                  -1 === this.new_mesh_styles.indexOf(c2) && (this.meshes[c2].forEach(function(e2) {
                    return e2.destroy();
                  }), delete this.meshes[c2]);
                this.new_mesh_styles = [];
              }
            }
          } }, { key: "setProxyFor", value: function(e) {
            e ? (this.proxy_for = this.proxy_for || [], this.proxy_for.push(e), this.proxy_depth = 1, e.proxied_as = e.style_zoom > this.style_zoom ? "child" : "parent") : (this.proxy_for = null, this.proxy_depth = 0);
          } }, { key: "isProxy", value: function() {
            return null != this.proxy_for;
          } }, { key: "shouldProxyForStyle", value: function(t2) {
            return !this.proxy_for || this.proxy_for.some(function(e) {
              return null == e.meshes[t2];
            });
          } }, { key: "setupProgram", value: function(e, t2) {
            var r = e.model, i2 = e.model32;
            t2.uniform("4fv", "u_tile_origin", [this.min.x, this.min.y, this.style_zoom, this.coords.z]), t2.uniform("1f", "u_tile_proxy_depth", this.proxy_depth), mat4.identity(r), mat4.translate(r, r, vec3.fromValues(this.min.x, this.min.y, 0)), mat4.scale(r, r, vec3.fromValues(this.span.x / Geo$1.tile_scale, -1 * this.span.y / Geo$1.tile_scale, 1)), mat4.copy(i2, r), t2.uniform("Matrix4fv", "u_model", i2), t2.uniform("1i", "u_tile_fade_in", this.fade_in && "child" !== this.proxied_as);
          } }, { key: "merge", value: function(e) {
            return this.loading = e.loading, this.loaded = e.loaded, this.generation = e.generation, this.error = e.error, this.mesh_data = e.mesh_data, this.selection_data ? Object.assign(this.selection_data, e.selection_data) : this.selection_data = e.selection_data, this;
          } }], [{ key: "coord", value: function(e) {
            return { x: e.x, y: e.y, z: e.z, key: E2.coordKey(e) };
          } }, { key: "coordKey", value: function(e) {
            return e.x + "/" + e.y + "/" + e.z;
          } }, { key: "key", value: function(e, t2, r) {
            if (!(e.y < 0 || e.y >= 1 << e.z || e.z < 0))
              return [t2.name, r, e.x, e.y, e.z].join("/");
          } }, { key: "normalizedKey", value: function(e, t2, r) {
            return E2.key(E2.normalizedCoordinate(e, t2, r), t2, r);
          } }, { key: "normalizedCoordinate", value: function(e, t2) {
            return t2.zoom_bias && (e = E2.coordinateAtZoom(e, Math.max(0, e.z - t2.zoom_bias))), E2.coordinateWithMaxZoom(e, t2.max_zoom);
          } }, { key: "coordinateAtZoom", value: function(e, t2) {
            var r, i2 = e.x, n = e.y, o = e.z;
            return o !== t2 && (r = Math.pow(2, o - t2), i2 = Math.floor(i2 / r), n = Math.floor(n / r), o = t2), E2.coord({ x: i2, y: n, z: o });
          } }, { key: "coordinateWithMaxZoom", value: function(e, t2) {
            var r = e.x, i2 = e.y, n = e.z;
            return void 0 !== t2 && t2 < n ? E2.coordinateAtZoom({ x: r, y: i2, z: n }, t2) : E2.coord({ x: r, y: i2, z: n });
          } }, { key: "childrenForCoordinate", value: function(e) {
            var t2 = e.x, r = e.y, i2 = e.z, n = e.key;
            return E2.coord_children[n] || (i2++, t2 *= 2, r *= 2, E2.coord_children[n] = [E2.coord({ x: t2, y: r, z: i2 }), E2.coord({ x: t2 + 1, y: r, z: i2 }), E2.coord({ x: t2, y: r + 1, z: i2 }), E2.coord({ x: t2 + 1, y: r + 1, z: i2 })]), E2.coord_children[n];
          } }, { key: "isDescendant", value: function(e, t2) {
            if (t2.z > e.z) {
              var r = E2.coordinateAtZoom(t2, e.z), i2 = r.x, n = r.y;
              return e.x === i2 && e.y === n;
            }
            return false;
          } }, { key: "cancel", value: function(e) {
            e && (e.canceled = true, e.source_data && e.source_data.request_id && (Utils$1.cancelRequest(e.source_data.request_id), e.source_data.request_id = null), E2.abortBuild(e));
          } }, { key: "buildGeometry", value: function(e, t2) {
            var r = t2.scene_id, i2 = t2.layers, n = t2.styles, o = t2.global, a2 = t2.sources, s = t2.meshVariantMaxLife, l = e.source_data;
            for (var u2 in Collision.startTile(e.id, { apply_repeat_groups: true }), i2) {
              var c2 = i2[u2];
              if (c2 && c2.config_data) {
                if (c2.config_data.source === e.source)
                  for (var h = E2._getDataForSource(l, c2.config_data, u2), f2 = 0; f2 < h.length; f2++) {
                    var d = h[f2], _ = d.geom;
                    if (_)
                      for (var p2 = 0; p2 < _.features.length; p2++) {
                        var g = _.features[p2];
                        if (null != g.geometry) {
                          var m = StyleParser.getFeatureParseContext(g, e, o, a2);
                          m.winding = e.default_winding, m.source = e.source, m.layer = d.layer;
                          var y = c2.buildDrawGroups(m, true);
                          if (y)
                            for (var v in y) {
                              var x2 = y[v], b2 = x2.style || v, T2 = n[b2];
                              T2 ? null != (x2 = T2.preprocess(x2, e.source)) && false !== x2.visible && (m.layers = x2.layers, T2.addFeature(g, x2, m)) : log("warn", "Style '".concat(b2, "' not found, skipping layer '").concat(u2, "':"), x2, g);
                            }
                        }
                      }
                  }
              } else
                log("warn", "Layer ".concat(u2, " was defined without a geometry data source and will not be rendered."));
            }
            var A2 = E2._stylesForTile(e, n);
            E2._sendStyleGroups(e, A2, { scene_id: r, meshVariantMaxLife: s }, function(e2) {
              return e2.collision ? "collision" : "non-collision";
            });
          } }, { key: "_stylesForTile", value: function(e, t2) {
            var r = [];
            for (var i2 in t2)
              t2[i2].hasDataForTile(e) && r.push(t2[i2]);
            return r;
          } }, { key: "_sendStyleGroups", value: function(i2, e, t2, r) {
            var n = t2.scene_id, o = t2.meshVariantMaxLife, a2 = {};
            e.forEach(function(e2) {
              var t3 = r(e2);
              a2[t3] = a2[t3] || [], a2[t3].push(e2);
            }), 0 < Object.keys(a2).length ? function() {
              var r2 = { start: true };
              i2.mesh_data = {};
              for (var e2 in a2)
                !function(t3) {
                  var e3 = a2[t3];
                  Promise.all(e3.map(function(e4) {
                    return e4.endData(i2);
                  })).then(function() {
                    log("trace", "Finished style group '".concat(t3, "' for tile ").concat(i2.key)), a2[t3] = [], Object.keys(a2).every(function(e4) {
                      return 0 === a2[e4].length;
                    }) && (r2.done = true), WorkerBroker.postMessage("TileManager_".concat(n, ".buildTileStylesCompleted"), WorkerBroker.withTransferables({ tile: E2.slice(i2, ["mesh_data", "selection_data"]), progress: r2 })), r2.start = null, i2.mesh_data = {}, i2.selection_data = {}, r2.done && Collision.resetTile(i2.id);
                  }, function(e4) {
                    log("error", "Error for style group '".concat(t3, "' for tile ").concat(i2.key), e4);
                  });
                }(e2);
              Style.updateMeshVariantTypeCache(o);
            }() : (WorkerBroker.postMessage("TileManager_".concat(n, ".buildTileStylesCompleted"), WorkerBroker.withTransferables({ tile: E2.slice(i2), progress: { start: true, done: true } })), Collision.resetTile(i2.id));
          } }, { key: "_getDataForSource", value: function(t2, e, r) {
            var i2 = 2 < arguments.length && void 0 !== r ? r : null, n = [];
            return null != e && null != t2 && null != t2.layers && (!e.layer && t2.layers._default || "string" == typeof e.layer && !t2.layers[e.layer] && new RegExp("^\\d+_" + e.layer + "$").test(i2) && t2.layers._default ? n.push({ geom: t2.layers._default }) : !e.layer && i2 ? n.push({ layer: i2, geom: t2.layers[i2] }) : "string" == typeof e.layer ? n.push({ layer: e.layer, geom: t2.layers[e.layer] }) : Array.isArray(e.layer) && e.layer.forEach(function(e2) {
              t2.layers[e2] && t2.layers[e2].features && n.push({ layer: e2, geom: t2.layers[e2] });
            })), n;
          } }, { key: "abortBuild", value: function(r, i2) {
            if (Task.removeForTile(r.id), Collision.abortTile(r.id), r.mesh_data)
              for (var e in r.mesh_data) {
                var t2 = r.mesh_data[e].textures;
                t2 && t2.forEach(function(e2) {
                  var t3 = getTextureManager(i2).textures[e2];
                  t3 && (log("trace", "releasing texture ".concat(e2, " for tile ").concat(r.key)), t3.release());
                });
              }
          } }, { key: "slice", value: function(e, t2) {
            var r = ["id", "key", "loading", "loaded", "generation", "error", "debug"];
            Array.isArray(t2) && r.push.apply(r, _toConsumableArray(t2));
            for (var i2 = {}, n = 0; n < r.length; n++) {
              var o = r[n];
              i2[o] = e[o];
            }
            return i2;
          } }]), E2;
        }();
        Tile.coord_children = {};
        var RasterTileSource = function() {
          _inherits(n, NetworkTileSource);
          var i2 = _createSuper(n);
          function n(e, t2) {
            var r;
            return _classCallCheck(this, n), -1 === (r = i2.call(this, e, t2)).rasters.indexOf(r.name) && r.rasters.unshift(r.name), r.filtering = e.filtering, r.textures = {}, r;
          }
          return _createClass(n, [{ key: "load", value: function(e) {
            e.source_data = {}, e.source_data.layers = {}, e.pad_scale = this.pad_scale, e.rasters = _toConsumableArray(this.rasters);
            var t2 = Geo$1.tile_scale;
            return e.source_data.layers = { _default: { type: "FeatureCollection", features: [{ geometry: { type: "Polygon", coordinates: [[[0, 0], [t2, 0], [t2, -t2], [0, -t2], [0, 0]]] }, properties: {} }] } }, e.default_winding = "CW", Promise.resolve(e);
          } }, { key: "tileTexture", value: function(e) {
            var t2, r, i3 = e.coords.key;
            return this.textures[i3] || (t2 = Tile.coordinateWithMaxZoom(e.coords, this.max_zoom), r = this.formatUrl(this.url, { coords: t2 }), this.textures[i3] = { url: r, filtering: this.filtering, coords: t2 }), this.textures[i3];
          } }]), n;
        }(), ArrayUtils;
        DataSource.register(RasterTileSource, "Raster");
        var ArrayUtils$1 = ArrayUtils = {};
        function simplify(e, t2, r, i2) {
          for (var n, o = i2, a2 = r - t2 >> 1, s = r - t2, l = e[t2], u2 = e[t2 + 1], c2 = e[r], h = e[r + 1], f2 = t2 + 3; f2 < r; f2 += 3) {
            var d, _ = getSqSegDist(e[f2], e[f2 + 1], l, u2, c2, h);
            o < _ ? (n = f2, o = _) : _ !== o || (d = Math.abs(f2 - a2)) < s && (n = f2, s = d);
          }
          i2 < o && (3 < n - t2 && simplify(e, t2, n, i2), e[n + 2] = o, 3 < r - n && simplify(e, n, r, i2));
        }
        function getSqSegDist(e, t2, r, i2, n, o) {
          var a2, s = n - r, l = o - i2;
          return 0 === s && 0 === l || (1 < (a2 = ((e - r) * s + (t2 - i2) * l) / (s * s + l * l)) ? (r = n, i2 = o) : 0 < a2 && (r += s * a2, i2 += l * a2)), (s = e - r) * s + (l = t2 - i2) * l;
        }
        function createFeature(e, t2, r, i2) {
          var n = { id: void 0 === e ? null : e, type: t2, geometry: r, tags: i2, minX: 1 / 0, minY: 1 / 0, maxX: -1 / 0, maxY: -1 / 0 };
          return calcBBox(n), n;
        }
        function calcBBox(e) {
          var t2 = e.geometry, r = e.type;
          if ("Point" === r || "MultiPoint" === r || "LineString" === r)
            calcLineBBox(e, t2);
          else if ("Polygon" === r || "MultiLineString" === r)
            for (var i2 = 0; i2 < t2.length; i2++)
              calcLineBBox(e, t2[i2]);
          else if ("MultiPolygon" === r)
            for (i2 = 0; i2 < t2.length; i2++)
              for (var n = 0; n < t2[i2].length; n++)
                calcLineBBox(e, t2[i2][n]);
        }
        function calcLineBBox(e, t2) {
          for (var r = 0; r < t2.length; r += 3)
            e.minX = Math.min(e.minX, t2[r]), e.minY = Math.min(e.minY, t2[r + 1]), e.maxX = Math.max(e.maxX, t2[r]), e.maxY = Math.max(e.maxY, t2[r + 1]);
        }
        function convert(e, t2) {
          var r = [];
          if ("FeatureCollection" === e.type)
            for (var i2 = 0; i2 < e.features.length; i2++)
              convertFeature(r, e.features[i2], t2, i2);
          else
            "Feature" === e.type ? convertFeature(r, e, t2) : convertFeature(r, { geometry: e }, t2);
          return r;
        }
        function convertFeature(e, t2, r, i2) {
          if (t2.geometry) {
            var n = t2.geometry.coordinates, o = t2.geometry.type, a2 = Math.pow(r.tolerance / ((1 << r.maxZoom) * r.extent), 2), s = [], l = t2.id;
            if (r.promoteId ? l = t2.properties[r.promoteId] : r.generateId && (l = i2 || 0), "Point" === o)
              convertPoint(n, s);
            else if ("MultiPoint" === o)
              for (var u2 = 0; u2 < n.length; u2++)
                convertPoint(n[u2], s);
            else if ("LineString" === o)
              convertLine(n, s, a2, false);
            else if ("MultiLineString" === o) {
              if (r.lineMetrics) {
                for (u2 = 0; u2 < n.length; u2++)
                  s = [], convertLine(n[u2], s, a2, false), e.push(createFeature(l, "LineString", s, t2.properties));
                return;
              }
              convertLines(n, s, a2, false);
            } else if ("Polygon" === o)
              convertLines(n, s, a2, true);
            else {
              if ("MultiPolygon" !== o) {
                if ("GeometryCollection" !== o)
                  throw new Error("Input data is not a valid GeoJSON object.");
                for (u2 = 0; u2 < t2.geometry.geometries.length; u2++)
                  convertFeature(e, { id: l, geometry: t2.geometry.geometries[u2], properties: t2.properties }, r, i2);
                return;
              }
              for (u2 = 0; u2 < n.length; u2++) {
                var c2 = [];
                convertLines(n[u2], c2, a2, true), s.push(c2);
              }
            }
            e.push(createFeature(l, o, s, t2.properties));
          }
        }
        function convertPoint(e, t2) {
          t2.push(projectX(e[0])), t2.push(projectY(e[1])), t2.push(0);
        }
        function convertLine(e, t2, r, i2) {
          for (var n, o, a2 = 0, s = 0; s < e.length; s++) {
            var l = projectX(e[s][0]), u2 = projectY(e[s][1]);
            t2.push(l), t2.push(u2), t2.push(0), 0 < s && (a2 += i2 ? (n * u2 - l * o) / 2 : Math.sqrt(Math.pow(l - n, 2) + Math.pow(u2 - o, 2))), n = l, o = u2;
          }
          var c2 = t2.length - 3;
          t2[2] = 1, simplify(t2, 0, c2, r), t2[2 + c2] = 1, t2.size = Math.abs(a2), t2.start = 0, t2.end = t2.size;
        }
        function convertLines(e, t2, r, i2) {
          for (var n = 0; n < e.length; n++) {
            var o = [];
            convertLine(e[n], o, r, i2), t2.push(o);
          }
        }
        function projectX(e) {
          return e / 360 + 0.5;
        }
        function projectY(e) {
          var t2 = Math.sin(e * Math.PI / 180), r = 0.5 - 0.25 * Math.log((1 + t2) / (1 - t2)) / Math.PI;
          return r < 0 ? 0 : 1 < r ? 1 : r;
        }
        function clip(e, t2, r, i2, n, o, a2, s) {
          if (i2 /= t2, (r /= t2) <= o && a2 < i2)
            return e;
          if (a2 < r || i2 <= o)
            return null;
          for (var l = [], u2 = 0; u2 < e.length; u2++) {
            var c2 = e[u2], h = c2.geometry, f2 = c2.type, d = 0 === n ? c2.minX : c2.minY, _ = 0 === n ? c2.maxX : c2.maxY;
            if (r <= d && _ < i2)
              l.push(c2);
            else if (!(_ < r || i2 <= d)) {
              var p2 = [];
              if ("Point" === f2 || "MultiPoint" === f2)
                clipPoints(h, p2, r, i2, n);
              else if ("LineString" === f2)
                clipLine(h, p2, r, i2, n, false, s.lineMetrics);
              else if ("MultiLineString" === f2)
                clipLines(h, p2, r, i2, n, false);
              else if ("Polygon" === f2)
                clipLines(h, p2, r, i2, n, true);
              else if ("MultiPolygon" === f2)
                for (var g = 0; g < h.length; g++) {
                  var m = [];
                  clipLines(h[g], m, r, i2, n, true), m.length && p2.push(m);
                }
              if (p2.length) {
                if (s.lineMetrics && "LineString" === f2) {
                  for (g = 0; g < p2.length; g++)
                    l.push(createFeature(c2.id, f2, p2[g], c2.tags));
                  continue;
                }
                "LineString" !== f2 && "MultiLineString" !== f2 || (1 === p2.length ? (f2 = "LineString", p2 = p2[0]) : f2 = "MultiLineString"), "Point" !== f2 && "MultiPoint" !== f2 || (f2 = 3 === p2.length ? "Point" : "MultiPoint"), l.push(createFeature(c2.id, f2, p2, c2.tags));
              }
            }
          }
          return l.length ? l : null;
        }
        function clipPoints(e, t2, r, i2, n) {
          for (var o = 0; o < e.length; o += 3) {
            var a2 = e[o + n];
            r <= a2 && a2 <= i2 && (t2.push(e[o]), t2.push(e[o + 1]), t2.push(e[o + 2]));
          }
        }
        function clipLine(e, t2, r, i2, n, o, a2) {
          for (var s, l, u2 = newSlice(e), c2 = 0 === n ? intersectX : intersectY, h = e.start, f2 = 0; f2 < e.length - 3; f2 += 3) {
            var d = e[f2], _ = e[f2 + 1], p2 = e[f2 + 2], g = e[f2 + 3], m = e[f2 + 4], y = 0 === n ? d : _, v = 0 === n ? g : m, x2 = false;
            a2 && (s = Math.sqrt(Math.pow(d - g, 2) + Math.pow(_ - m, 2))), y < r ? r < v && (l = c2(u2, d, _, g, m, r), a2 && (u2.start = h + s * l)) : i2 < y ? v < i2 && (l = c2(u2, d, _, g, m, i2), a2 && (u2.start = h + s * l)) : addPoint(u2, d, _, p2), v < r && r <= y && (l = c2(u2, d, _, g, m, r), x2 = true), i2 < v && y <= i2 && (l = c2(u2, d, _, g, m, i2), x2 = true), !o && x2 && (a2 && (u2.end = h + s * l), t2.push(u2), u2 = newSlice(e)), a2 && (h += s);
          }
          var b2 = e.length - 3, d = e[b2], _ = e[b2 + 1], p2 = e[b2 + 2];
          r <= (y = 0 === n ? d : _) && y <= i2 && addPoint(u2, d, _, p2), b2 = u2.length - 3, o && 3 <= b2 && (u2[b2] !== u2[0] || u2[b2 + 1] !== u2[1]) && addPoint(u2, u2[0], u2[1], u2[2]), u2.length && t2.push(u2);
        }
        function newSlice(e) {
          var t2 = [];
          return t2.size = e.size, t2.start = e.start, t2.end = e.end, t2;
        }
        function clipLines(e, t2, r, i2, n, o) {
          for (var a2 = 0; a2 < e.length; a2++)
            clipLine(e[a2], t2, r, i2, n, o, false);
        }
        function addPoint(e, t2, r, i2) {
          e.push(t2), e.push(r), e.push(i2);
        }
        function intersectX(e, t2, r, i2, n, o) {
          var a2 = (o - t2) / (i2 - t2);
          return e.push(o), e.push(r + (n - r) * a2), e.push(1), a2;
        }
        function intersectY(e, t2, r, i2, n, o) {
          var a2 = (o - r) / (n - r);
          return e.push(t2 + (i2 - t2) * a2), e.push(o), e.push(1), a2;
        }
        function wrap(e, t2) {
          var r = t2.buffer / t2.extent, i2 = e, n = clip(e, 1, -1 - r, r, 0, -1, 2, t2), o = clip(e, 1, 1 - r, 2 + r, 0, -1, 2, t2);
          return (n || o) && (i2 = clip(e, 1, -r, 1 + r, 0, -1, 2, t2) || [], n && (i2 = shiftFeatureCoords(n, 1).concat(i2)), o && (i2 = i2.concat(shiftFeatureCoords(o, -1)))), i2;
        }
        function shiftFeatureCoords(e, t2) {
          for (var r = [], i2 = 0; i2 < e.length; i2++) {
            var n, o = e[i2], a2 = o.type;
            if ("Point" === a2 || "MultiPoint" === a2 || "LineString" === a2)
              n = shiftCoords(o.geometry, t2);
            else if ("MultiLineString" === a2 || "Polygon" === a2) {
              n = [];
              for (var s = 0; s < o.geometry.length; s++)
                n.push(shiftCoords(o.geometry[s], t2));
            } else if ("MultiPolygon" === a2)
              for (n = [], s = 0; s < o.geometry.length; s++) {
                for (var l = [], u2 = 0; u2 < o.geometry[s].length; u2++)
                  l.push(shiftCoords(o.geometry[s][u2], t2));
                n.push(l);
              }
            r.push(createFeature(o.id, a2, n, o.tags));
          }
          return r;
        }
        function shiftCoords(e, t2) {
          var r = [];
          r.size = e.size, void 0 !== e.start && (r.start = e.start, r.end = e.end);
          for (var i2 = 0; i2 < e.length; i2 += 3)
            r.push(e[i2] + t2, e[i2 + 1], e[i2 + 2]);
          return r;
        }
        function transformTile(e, t2) {
          if (e.transformed)
            return e;
          for (var r, i2 = 1 << e.z, n = e.x, o = e.y, a2 = 0; a2 < e.features.length; a2++) {
            var s = e.features[a2], l = s.geometry, u2 = s.type;
            if (s.geometry = [], 1 === u2)
              for (r = 0; r < l.length; r += 2)
                s.geometry.push(transformPoint(l[r], l[r + 1], t2, i2, n, o));
            else
              for (r = 0; r < l.length; r++) {
                for (var c2 = [], h = 0; h < l[r].length; h += 2)
                  c2.push(transformPoint(l[r][h], l[r][h + 1], t2, i2, n, o));
                s.geometry.push(c2);
              }
          }
          return e.transformed = true, e;
        }
        function transformPoint(e, t2, r, i2, n, o) {
          return [Math.round(r * (e * i2 - n)), Math.round(r * (t2 * i2 - o))];
        }
        function createTile(e, t2, r, i2, n) {
          for (var o = t2 === n.maxZoom ? 0 : n.tolerance / ((1 << t2) * n.extent), a2 = { features: [], numPoints: 0, numSimplified: 0, numFeatures: 0, source: null, x: r, y: i2, z: t2, transformed: false, minX: 2, minY: 1, maxX: -1, maxY: 0 }, s = 0; s < e.length; s++) {
            a2.numFeatures++, addFeature(a2, e[s], o, n);
            var l = e[s].minX, u2 = e[s].minY, c2 = e[s].maxX, h = e[s].maxY;
            l < a2.minX && (a2.minX = l), u2 < a2.minY && (a2.minY = u2), c2 > a2.maxX && (a2.maxX = c2), h > a2.maxY && (a2.maxY = h);
          }
          return a2;
        }
        function addFeature(e, t2, r, i2) {
          var n = t2.geometry, o = t2.type, a2 = [];
          if ("Point" === o || "MultiPoint" === o)
            for (var s = 0; s < n.length; s += 3)
              a2.push(n[s]), a2.push(n[s + 1]), e.numPoints++, e.numSimplified++;
          else if ("LineString" === o)
            addLine(a2, n, e, r, false, false);
          else if ("MultiLineString" === o || "Polygon" === o)
            for (s = 0; s < n.length; s++)
              addLine(a2, n[s], e, r, "Polygon" === o, 0 === s);
          else if ("MultiPolygon" === o)
            for (var l = 0; l < n.length; l++)
              for (var u2 = n[l], s = 0; s < u2.length; s++)
                addLine(a2, u2[s], e, r, true, 0 === s);
          if (a2.length) {
            var c2 = t2.tags || null;
            if ("LineString" === o && i2.lineMetrics) {
              for (var h in c2 = {}, t2.tags)
                c2[h] = t2.tags[h];
              c2.mapbox_clip_start = n.start / n.size, c2.mapbox_clip_end = n.end / n.size;
            }
            var f2 = { geometry: a2, type: "Polygon" === o || "MultiPolygon" === o ? 3 : "LineString" === o || "MultiLineString" === o ? 2 : 1, tags: c2 };
            null !== t2.id && (f2.id = t2.id), e.features.push(f2);
          }
        }
        function addLine(e, t2, r, i2, n, o) {
          var a2 = i2 * i2;
          if (0 < i2 && t2.size < (n ? a2 : i2))
            r.numPoints += t2.length / 3;
          else {
            for (var s = [], l = 0; l < t2.length; l += 3)
              (0 === i2 || t2[l + 2] > a2) && (r.numSimplified++, s.push(t2[l]), s.push(t2[l + 1])), r.numPoints++;
            n && rewind(s, o), e.push(s);
          }
        }
        function rewind(e, t2) {
          for (var r = 0, i2 = 0, n = e.length, o = n - 2; i2 < n; o = i2, i2 += 2)
            r += (e[i2] - e[o]) * (e[i2 + 1] + e[o + 1]);
          if (0 < r === t2)
            for (i2 = 0, n = e.length; i2 < n / 2; i2 += 2) {
              var a2 = e[i2], s = e[i2 + 1];
              e[i2] = e[n - 2 - i2], e[i2 + 1] = e[n - 1 - i2], e[n - 2 - i2] = a2, e[n - 1 - i2] = s;
            }
        }
        ArrayUtils.deepClone = function(e) {
          return Array.isArray(e) ? e.map(ArrayUtils.deepClone) : e;
        };
        var defaults = { maxZoom: 14, tolerance: 3, extent: 4096, buffer: 64, lineMetrics: false, promoteId: null, generateId: false };
        function createGeoJsonTile(e, t2, r, i2, n) {
          var o = Object.assign({}, defaults, n), a2 = convert(e, o), s = getBBox(a2 = wrap(a2, o)), l = s.minX, u2 = s.minY, c2 = s.maxX, h = s.maxY, f2 = 1 << t2, d = o.buffer / o.extent, _ = 1 + d;
          return a2 = clip(a2, f2, r - d, r + _, 0, l, c2, o) || [], transformTile(createTile(a2 = clip(a2, f2, i2 - d, i2 + _, 1, u2, h, o) || [], t2, r, i2, o), o.extent);
        }
        function getBBox(e) {
          var t2, r = 2, i2 = -1, n = 1, o = 0, a2 = _createForOfIteratorHelper(e);
          try {
            for (a2.s(); !(t2 = a2.n()).done; ) {
              var s = t2.value;
              s.minX < r && (r = s.minX), s.maxX > i2 && (i2 = s.maxX), s.minY < n && (n = s.minY), s.maxY > o && (o = s.maxY);
            }
          } catch (e2) {
            a2.e(e2);
          } finally {
            a2.f();
          }
          return { minX: r, maxX: i2, minY: n, maxY: o };
        }
        function PackingSmith(e, t2) {
          this.items = [], this.algorithm = e;
          var r = void 0 === (t2 = t2 || {}).sort || t2.sort;
          this.sort = r;
        }
        PackingSmith.prototype = { addItem: function(e) {
          this.items.push(e);
        }, normalizeCoordinates: function() {
          var e = this.items, r = 1 / 0, i2 = 1 / 0;
          e.forEach(function(e2) {
            var t2 = e2;
            r = Math.min(r, t2.x), i2 = Math.min(i2, t2.y);
          }), e.forEach(function(e2) {
            var t2 = e2;
            t2.x -= r, t2.y -= i2;
          });
        }, getStats: function() {
          var e = this.items.map(function(e2) {
            return e2;
          }), t2 = e.map(function(e2) {
            return e2.x;
          }), r = e.map(function(e2) {
            return e2.y;
          }), i2 = e.map(function(e2) {
            return e2.x + e2.width;
          }), n = e.map(function(e2) {
            return e2.y + e2.height;
          });
          return { minX: Math.max.apply(Math, t2), minY: Math.max.apply(Math, r), maxX: Math.max.apply(Math, i2), maxY: Math.max.apply(Math, n) };
        }, getItems: function() {
          return this.items;
        }, processItems: function() {
          var e = this.items;
          return this.sort && (e = this.algorithm.sort(e)), e = this.algorithm.placeItems(e), this.items = e;
        }, exportItems: function() {
          return this.processItems(), this.normalizeCoordinates(), this.items;
        }, export: function() {
          var e = this.exportItems(), t2 = this.getStats();
          return { height: t2.maxY, width: t2.maxX, items: e };
        } };
        var packing_smith = PackingSmith, lookup = [], revLookup = [], Arr = "undefined" != typeof Uint8Array ? Uint8Array : Array, inited = false;
        function init() {
          inited = true;
          for (var e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", t2 = 0, r = e.length; t2 < r; ++t2)
            lookup[t2] = e[t2], revLookup[e.charCodeAt(t2)] = t2;
          revLookup["-".charCodeAt(0)] = 62, revLookup["_".charCodeAt(0)] = 63;
        }
        function toByteArray(e) {
          var t2, r, i2, n;
          inited || init();
          var o = e.length;
          if (0 < o % 4)
            throw new Error("Invalid string. Length must be a multiple of 4");
          i2 = "=" === e[o - 2] ? 2 : "=" === e[o - 1] ? 1 : 0, n = new Arr(3 * o / 4 - i2), t2 = 0 < i2 ? o - 4 : o;
          for (var a2 = 0, s = 0; s < t2; s += 4, 0)
            r = revLookup[e.charCodeAt(s)] << 18 | revLookup[e.charCodeAt(s + 1)] << 12 | revLookup[e.charCodeAt(s + 2)] << 6 | revLookup[e.charCodeAt(s + 3)], n[a2++] = r >> 16 & 255, n[a2++] = r >> 8 & 255, n[a2++] = 255 & r;
          return 2 == i2 ? (r = revLookup[e.charCodeAt(s)] << 2 | revLookup[e.charCodeAt(s + 1)] >> 4, n[a2++] = 255 & r) : 1 == i2 && (r = revLookup[e.charCodeAt(s)] << 10 | revLookup[e.charCodeAt(s + 1)] << 4 | revLookup[e.charCodeAt(s + 2)] >> 2, n[a2++] = r >> 8 & 255, n[a2++] = 255 & r), n;
        }
        function tripletToBase64(e) {
          return lookup[e >> 18 & 63] + lookup[e >> 12 & 63] + lookup[e >> 6 & 63] + lookup[63 & e];
        }
        function encodeChunk(e, t2, r) {
          for (var i2, n = [], o = t2; o < r; o += 3)
            i2 = (e[o] << 16) + (e[o + 1] << 8) + e[o + 2], n.push(tripletToBase64(i2));
          return n.join("");
        }
        function fromByteArray(e) {
          var t2;
          inited || init();
          for (var r = e.length, i2 = r % 3, n = "", o = [], a2 = 0, s = r - i2; a2 < s; a2 += 16383)
            o.push(encodeChunk(e, a2, s < a2 + 16383 ? s : a2 + 16383));
          return 1 == i2 ? (t2 = e[r - 1], n += lookup[t2 >> 2], n += lookup[t2 << 4 & 63], n += "==") : 2 == i2 && (t2 = (e[r - 2] << 8) + e[r - 1], n += lookup[t2 >> 10], n += lookup[t2 >> 4 & 63], n += lookup[t2 << 2 & 63], n += "="), o.push(n), o.join("");
        }
        var base64$1 = Object.freeze({ toByteArray, fromByteArray });
        function read$1(e, t2, r, i2, n) {
          var o, a2, s = 8 * n - i2 - 1, l = (1 << s) - 1, u2 = l >> 1, c2 = -7, h = r ? n - 1 : 0, f2 = r ? -1 : 1, d = e[t2 + h];
          for (h += f2, o = d & (1 << -c2) - 1, d >>= -c2, c2 += s; 0 < c2; o = 256 * o + e[t2 + h], h += f2, c2 -= 8)
            ;
          for (a2 = o & (1 << -c2) - 1, o >>= -c2, c2 += i2; 0 < c2; a2 = 256 * a2 + e[t2 + h], h += f2, c2 -= 8)
            ;
          if (0 === o)
            o = 1 - u2;
          else {
            if (o === l)
              return a2 ? NaN : 1 / 0 * (d ? -1 : 1);
            a2 += Math.pow(2, i2), o -= u2;
          }
          return (d ? -1 : 1) * a2 * Math.pow(2, o - i2);
        }
        function write$1(e, t2, r, i2, n, o) {
          var a2, s, l, u2 = 8 * o - n - 1, c2 = (1 << u2) - 1, h = c2 >> 1, f2 = 23 === n ? Math.pow(2, -24) - Math.pow(2, -77) : 0, d = i2 ? 0 : o - 1, _ = i2 ? 1 : -1, p2 = t2 < 0 || 0 === t2 && 1 / t2 < 0 ? 1 : 0;
          for (t2 = Math.abs(t2), isNaN(t2) || t2 === 1 / 0 ? (s = isNaN(t2) ? 1 : 0, a2 = c2) : (a2 = Math.floor(Math.log(t2) / Math.LN2), t2 * (l = Math.pow(2, -a2)) < 1 && (a2--, l *= 2), 2 <= (t2 += 1 <= a2 + h ? f2 / l : f2 * Math.pow(2, 1 - h)) * l && (a2++, l /= 2), c2 <= a2 + h ? (s = 0, a2 = c2) : 1 <= a2 + h ? (s = (t2 * l - 1) * Math.pow(2, n), a2 += h) : (s = t2 * Math.pow(2, h - 1) * Math.pow(2, n), a2 = 0)); 8 <= n; e[r + d] = 255 & s, d += _, s /= 256, n -= 8)
            ;
          for (a2 = a2 << n | s, u2 += n; 0 < u2; e[r + d] = 255 & a2, d += _, a2 /= 256, u2 -= 8)
            ;
          e[r + d - _] |= 128 * p2;
        }
        var toString$1 = {}.toString, isArray = Array.isArray || function(e) {
          return "[object Array]" == toString$1.call(e);
        }, INSPECT_MAX_BYTES = 50;
        Buffer.TYPED_ARRAY_SUPPORT = void 0 === global$1.TYPED_ARRAY_SUPPORT || global$1.TYPED_ARRAY_SUPPORT;
        var _kMaxLength = kMaxLength();
        function kMaxLength() {
          return Buffer.TYPED_ARRAY_SUPPORT ? 2147483647 : 1073741823;
        }
        function createBuffer(e, t2) {
          if (kMaxLength() < t2)
            throw new RangeError("Invalid typed array length");
          return Buffer.TYPED_ARRAY_SUPPORT ? (e = new Uint8Array(t2)).__proto__ = Buffer.prototype : (null === e && (e = new Buffer(t2)), e.length = t2), e;
        }
        function Buffer(e, t2, r) {
          if (!(Buffer.TYPED_ARRAY_SUPPORT || this instanceof Buffer))
            return new Buffer(e, t2, r);
          if ("number" != typeof e)
            return from(this, e, t2, r);
          if ("string" == typeof t2)
            throw new Error("If encoding is specified then the first argument must be a string");
          return allocUnsafe(this, e);
        }
        function from(e, t2, r, i2) {
          if ("number" == typeof t2)
            throw new TypeError('"value" argument must not be a number');
          return "undefined" != typeof ArrayBuffer && t2 instanceof ArrayBuffer ? fromArrayBuffer(e, t2, r, i2) : "string" == typeof t2 ? fromString$1(e, t2, r) : fromObject(e, t2);
        }
        function assertSize(e) {
          if ("number" != typeof e)
            throw new TypeError('"size" argument must be a number');
          if (e < 0)
            throw new RangeError('"size" argument must not be negative');
        }
        function alloc(e, t2, r, i2) {
          return assertSize(t2), !(t2 <= 0) && void 0 !== r ? "string" == typeof i2 ? createBuffer(e, t2).fill(r, i2) : createBuffer(e, t2).fill(r) : createBuffer(e, t2);
        }
        function allocUnsafe(e, t2) {
          if (assertSize(t2), e = createBuffer(e, t2 < 0 ? 0 : 0 | checked(t2)), !Buffer.TYPED_ARRAY_SUPPORT)
            for (var r = 0; r < t2; ++r)
              e[r] = 0;
          return e;
        }
        function fromString$1(e, t2, r) {
          if ("string" == typeof r && "" !== r || (r = "utf8"), !Buffer.isEncoding(r))
            throw new TypeError('"encoding" must be a valid string encoding');
          var i2 = 0 | byteLength(t2, r), n = (e = createBuffer(e, i2)).write(t2, r);
          return n !== i2 && (e = e.slice(0, n)), e;
        }
        function fromArrayLike(e, t2) {
          var r = t2.length < 0 ? 0 : 0 | checked(t2.length);
          e = createBuffer(e, r);
          for (var i2 = 0; i2 < r; i2 += 1)
            e[i2] = 255 & t2[i2];
          return e;
        }
        function fromArrayBuffer(e, t2, r, i2) {
          if (t2.byteLength, r < 0 || t2.byteLength < r)
            throw new RangeError("'offset' is out of bounds");
          if (t2.byteLength < r + (i2 || 0))
            throw new RangeError("'length' is out of bounds");
          return t2 = void 0 === r && void 0 === i2 ? new Uint8Array(t2) : void 0 === i2 ? new Uint8Array(t2, r) : new Uint8Array(t2, r, i2), Buffer.TYPED_ARRAY_SUPPORT ? (e = t2).__proto__ = Buffer.prototype : e = fromArrayLike(e, t2), e;
        }
        function fromObject(e, t2) {
          if (internalIsBuffer(t2)) {
            var r = 0 | checked(t2.length);
            return 0 === (e = createBuffer(e, r)).length ? e : (t2.copy(e, 0, 0, r), e);
          }
          if (t2) {
            if ("undefined" != typeof ArrayBuffer && t2.buffer instanceof ArrayBuffer || "length" in t2)
              return "number" != typeof t2.length || isnan(t2.length) ? createBuffer(e, 0) : fromArrayLike(e, t2);
            if ("Buffer" === t2.type && isArray(t2.data))
              return fromArrayLike(e, t2.data);
          }
          throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.");
        }
        function checked(e) {
          if (e >= kMaxLength())
            throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + kMaxLength().toString(16) + " bytes");
          return 0 | e;
        }
        function SlowBuffer(e) {
          return +e != e && (e = 0), Buffer.alloc(+e);
        }
        function internalIsBuffer(e) {
          return null != e && e._isBuffer;
        }
        function byteLength(e, t2) {
          if (internalIsBuffer(e))
            return e.length;
          if ("undefined" != typeof ArrayBuffer && "function" == typeof ArrayBuffer.isView && (ArrayBuffer.isView(e) || e instanceof ArrayBuffer))
            return e.byteLength;
          "string" != typeof e && (e = "" + e);
          var r = e.length;
          if (0 === r)
            return 0;
          for (var i2 = false; ; )
            switch (t2) {
              case "ascii":
              case "latin1":
              case "binary":
                return r;
              case "utf8":
              case "utf-8":
              case void 0:
                return utf8ToBytes(e).length;
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return 2 * r;
              case "hex":
                return r >>> 1;
              case "base64":
                return base64ToBytes(e).length;
              default:
                if (i2)
                  return utf8ToBytes(e).length;
                t2 = ("" + t2).toLowerCase(), i2 = true;
            }
        }
        function slowToString(e, t2, r) {
          var i2 = false;
          if ((void 0 === t2 || t2 < 0) && (t2 = 0), t2 > this.length)
            return "";
          if ((void 0 === r || r > this.length) && (r = this.length), r <= 0)
            return "";
          if ((r >>>= 0) <= (t2 >>>= 0))
            return "";
          for (e = e || "utf8"; ; )
            switch (e) {
              case "hex":
                return hexSlice(this, t2, r);
              case "utf8":
              case "utf-8":
                return utf8Slice(this, t2, r);
              case "ascii":
                return asciiSlice(this, t2, r);
              case "latin1":
              case "binary":
                return latin1Slice(this, t2, r);
              case "base64":
                return base64Slice(this, t2, r);
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return utf16leSlice(this, t2, r);
              default:
                if (i2)
                  throw new TypeError("Unknown encoding: " + e);
                e = (e + "").toLowerCase(), i2 = true;
            }
        }
        function swap(e, t2, r) {
          var i2 = e[t2];
          e[t2] = e[r], e[r] = i2;
        }
        function bidirectionalIndexOf(e, t2, r, i2, n) {
          if (0 === e.length)
            return -1;
          if ("string" == typeof r ? (i2 = r, r = 0) : 2147483647 < r ? r = 2147483647 : r < -2147483648 && (r = -2147483648), r = +r, isNaN(r) && (r = n ? 0 : e.length - 1), r < 0 && (r = e.length + r), r >= e.length) {
            if (n)
              return -1;
            r = e.length - 1;
          } else if (r < 0) {
            if (!n)
              return -1;
            r = 0;
          }
          if ("string" == typeof t2 && (t2 = Buffer.from(t2, i2)), internalIsBuffer(t2))
            return 0 === t2.length ? -1 : arrayIndexOf$1(e, t2, r, i2, n);
          if ("number" == typeof t2)
            return t2 &= 255, Buffer.TYPED_ARRAY_SUPPORT && "function" == typeof Uint8Array.prototype.indexOf ? n ? Uint8Array.prototype.indexOf.call(e, t2, r) : Uint8Array.prototype.lastIndexOf.call(e, t2, r) : arrayIndexOf$1(e, [t2], r, i2, n);
          throw new TypeError("val must be string, number or Buffer");
        }
        function arrayIndexOf$1(e, t2, r, i2, n) {
          var o = 1, a2 = e.length, s = t2.length;
          if (void 0 !== i2 && ("ucs2" === (i2 = String(i2).toLowerCase()) || "ucs-2" === i2 || "utf16le" === i2 || "utf-16le" === i2)) {
            if (e.length < 2 || t2.length < 2)
              return -1;
            a2 /= o = 2, s /= 2, r /= 2;
          }
          function l(e2, t3) {
            return 1 === o ? e2[t3] : e2.readUInt16BE(t3 * o);
          }
          if (n)
            for (var u2 = -1, c2 = r; c2 < a2; c2++)
              if (l(e, c2) === l(t2, -1 === u2 ? 0 : c2 - u2)) {
                if (-1 === u2 && (u2 = c2), c2 - u2 + 1 === s)
                  return u2 * o;
              } else
                -1 !== u2 && (c2 -= c2 - u2), u2 = -1;
          else
            for (a2 < r + s && (r = a2 - s), c2 = r; 0 <= c2; c2--) {
              for (var h = true, f2 = 0; f2 < s; f2++)
                if (l(e, c2 + f2) !== l(t2, f2)) {
                  h = false;
                  break;
                }
              if (h)
                return c2;
            }
          return -1;
        }
        function hexWrite(e, t2, r, i2) {
          r = Number(r) || 0;
          var n = e.length - r;
          (!i2 || n < (i2 = Number(i2))) && (i2 = n);
          var o = t2.length;
          if (o % 2 != 0)
            throw new TypeError("Invalid hex string");
          o / 2 < i2 && (i2 = o / 2);
          for (var a2 = 0; a2 < i2; ++a2) {
            var s = parseInt(t2.substr(2 * a2, 2), 16);
            if (isNaN(s))
              return a2;
            e[r + a2] = s;
          }
          return a2;
        }
        function utf8Write(e, t2, r, i2) {
          return blitBuffer(utf8ToBytes(t2, e.length - r), e, r, i2);
        }
        function asciiWrite(e, t2, r, i2) {
          return blitBuffer(asciiToBytes(t2), e, r, i2);
        }
        function latin1Write(e, t2, r, i2) {
          return asciiWrite(e, t2, r, i2);
        }
        function base64Write(e, t2, r, i2) {
          return blitBuffer(base64ToBytes(t2), e, r, i2);
        }
        function ucs2Write(e, t2, r, i2) {
          return blitBuffer(utf16leToBytes(t2, e.length - r), e, r, i2);
        }
        function base64Slice(e, t2, r) {
          return 0 === t2 && r === e.length ? fromByteArray(e) : fromByteArray(e.slice(t2, r));
        }
        function utf8Slice(e, t2, r) {
          r = Math.min(e.length, r);
          for (var i2 = [], n = t2; n < r; ) {
            var o, a2, s, l, u2 = e[n], c2 = null, h = 239 < u2 ? 4 : 223 < u2 ? 3 : 191 < u2 ? 2 : 1;
            if (n + h <= r)
              switch (h) {
                case 1:
                  u2 < 128 && (c2 = u2);
                  break;
                case 2:
                  128 == (192 & (o = e[n + 1])) && 127 < (l = (31 & u2) << 6 | 63 & o) && (c2 = l);
                  break;
                case 3:
                  o = e[n + 1], a2 = e[n + 2], 128 == (192 & o) && 128 == (192 & a2) && 2047 < (l = (15 & u2) << 12 | (63 & o) << 6 | 63 & a2) && (l < 55296 || 57343 < l) && (c2 = l);
                  break;
                case 4:
                  o = e[n + 1], a2 = e[n + 2], s = e[n + 3], 128 == (192 & o) && 128 == (192 & a2) && 128 == (192 & s) && 65535 < (l = (15 & u2) << 18 | (63 & o) << 12 | (63 & a2) << 6 | 63 & s) && l < 1114112 && (c2 = l);
              }
            null === c2 ? (c2 = 65533, h = 1) : 65535 < c2 && (c2 -= 65536, i2.push(c2 >>> 10 & 1023 | 55296), c2 = 56320 | 1023 & c2), i2.push(c2), n += h;
          }
          return decodeCodePointsArray(i2);
        }
        Buffer.poolSize = 8192, Buffer._augment = function(e) {
          return e.__proto__ = Buffer.prototype, e;
        }, Buffer.from = function(e, t2, r) {
          return from(null, e, t2, r);
        }, Buffer.TYPED_ARRAY_SUPPORT && (Buffer.prototype.__proto__ = Uint8Array.prototype, Buffer.__proto__ = Uint8Array), Buffer.alloc = function(e, t2, r) {
          return alloc(null, e, t2, r);
        }, Buffer.allocUnsafe = function(e) {
          return allocUnsafe(null, e);
        }, Buffer.allocUnsafeSlow = function(e) {
          return allocUnsafe(null, e);
        }, Buffer.isBuffer = isBuffer, Buffer.compare = function(e, t2) {
          if (!internalIsBuffer(e) || !internalIsBuffer(t2))
            throw new TypeError("Arguments must be Buffers");
          if (e === t2)
            return 0;
          for (var r = e.length, i2 = t2.length, n = 0, o = Math.min(r, i2); n < o; ++n)
            if (e[n] !== t2[n]) {
              r = e[n], i2 = t2[n];
              break;
            }
          return r < i2 ? -1 : i2 < r ? 1 : 0;
        }, Buffer.isEncoding = function(e) {
          switch (String(e).toLowerCase()) {
            case "hex":
            case "utf8":
            case "utf-8":
            case "ascii":
            case "latin1":
            case "binary":
            case "base64":
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return true;
            default:
              return false;
          }
        }, Buffer.concat = function(e, t2) {
          if (!isArray(e))
            throw new TypeError('"list" argument must be an Array of Buffers');
          if (0 === e.length)
            return Buffer.alloc(0);
          if (void 0 === t2)
            for (n = t2 = 0; n < e.length; ++n)
              t2 += e[n].length;
          for (var r = Buffer.allocUnsafe(t2), i2 = 0, n = 0; n < e.length; ++n) {
            var o = e[n];
            if (!internalIsBuffer(o))
              throw new TypeError('"list" argument must be an Array of Buffers');
            o.copy(r, i2), i2 += o.length;
          }
          return r;
        }, Buffer.byteLength = byteLength, Buffer.prototype._isBuffer = true, Buffer.prototype.swap16 = function() {
          var e = this.length;
          if (e % 2 != 0)
            throw new RangeError("Buffer size must be a multiple of 16-bits");
          for (var t2 = 0; t2 < e; t2 += 2)
            swap(this, t2, t2 + 1);
          return this;
        }, Buffer.prototype.swap32 = function() {
          var e = this.length;
          if (e % 4 != 0)
            throw new RangeError("Buffer size must be a multiple of 32-bits");
          for (var t2 = 0; t2 < e; t2 += 4)
            swap(this, t2, t2 + 3), swap(this, t2 + 1, t2 + 2);
          return this;
        }, Buffer.prototype.swap64 = function() {
          var e = this.length;
          if (e % 8 != 0)
            throw new RangeError("Buffer size must be a multiple of 64-bits");
          for (var t2 = 0; t2 < e; t2 += 8)
            swap(this, t2, t2 + 7), swap(this, t2 + 1, t2 + 6), swap(this, t2 + 2, t2 + 5), swap(this, t2 + 3, t2 + 4);
          return this;
        }, Buffer.prototype.toString = function() {
          var e = 0 | this.length;
          return 0 == e ? "" : 0 === arguments.length ? utf8Slice(this, 0, e) : slowToString.apply(this, arguments);
        }, Buffer.prototype.equals = function(e) {
          if (!internalIsBuffer(e))
            throw new TypeError("Argument must be a Buffer");
          return this === e || 0 === Buffer.compare(this, e);
        }, Buffer.prototype.inspect = function() {
          var e = "", t2 = INSPECT_MAX_BYTES;
          return 0 < this.length && (e = this.toString("hex", 0, t2).match(/.{2}/g).join(" "), this.length > t2 && (e += " ... ")), "<Buffer " + e + ">";
        }, Buffer.prototype.compare = function(e, t2, r, i2, n) {
          if (!internalIsBuffer(e))
            throw new TypeError("Argument must be a Buffer");
          if (void 0 === t2 && (t2 = 0), void 0 === r && (r = e ? e.length : 0), void 0 === i2 && (i2 = 0), void 0 === n && (n = this.length), t2 < 0 || r > e.length || i2 < 0 || n > this.length)
            throw new RangeError("out of range index");
          if (n <= i2 && r <= t2)
            return 0;
          if (n <= i2)
            return -1;
          if (r <= t2)
            return 1;
          if (this === e)
            return 0;
          for (var o = (n >>>= 0) - (i2 >>>= 0), a2 = (r >>>= 0) - (t2 >>>= 0), s = Math.min(o, a2), l = this.slice(i2, n), u2 = e.slice(t2, r), c2 = 0; c2 < s; ++c2)
            if (l[c2] !== u2[c2]) {
              o = l[c2], a2 = u2[c2];
              break;
            }
          return o < a2 ? -1 : a2 < o ? 1 : 0;
        }, Buffer.prototype.includes = function(e, t2, r) {
          return -1 !== this.indexOf(e, t2, r);
        }, Buffer.prototype.indexOf = function(e, t2, r) {
          return bidirectionalIndexOf(this, e, t2, r, true);
        }, Buffer.prototype.lastIndexOf = function(e, t2, r) {
          return bidirectionalIndexOf(this, e, t2, r, false);
        }, Buffer.prototype.write = function(e, t2, r, i2) {
          if (void 0 === t2)
            i2 = "utf8", r = this.length, t2 = 0;
          else if (void 0 === r && "string" == typeof t2)
            i2 = t2, r = this.length, t2 = 0;
          else {
            if (!isFinite(t2))
              throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
            t2 |= 0, isFinite(r) ? (r |= 0, void 0 === i2 && (i2 = "utf8")) : (i2 = r, r = void 0);
          }
          var n = this.length - t2;
          if ((void 0 === r || n < r) && (r = n), 0 < e.length && (r < 0 || t2 < 0) || t2 > this.length)
            throw new RangeError("Attempt to write outside buffer bounds");
          i2 = i2 || "utf8";
          for (var o = false; ; )
            switch (i2) {
              case "hex":
                return hexWrite(this, e, t2, r);
              case "utf8":
              case "utf-8":
                return utf8Write(this, e, t2, r);
              case "ascii":
                return asciiWrite(this, e, t2, r);
              case "latin1":
              case "binary":
                return latin1Write(this, e, t2, r);
              case "base64":
                return base64Write(this, e, t2, r);
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return ucs2Write(this, e, t2, r);
              default:
                if (o)
                  throw new TypeError("Unknown encoding: " + i2);
                i2 = ("" + i2).toLowerCase(), o = true;
            }
        }, Buffer.prototype.toJSON = function() {
          return { type: "Buffer", data: Array.prototype.slice.call(this._arr || this, 0) };
        };
        var MAX_ARGUMENTS_LENGTH = 4096;
        function decodeCodePointsArray(e) {
          var t2 = e.length;
          if (t2 <= MAX_ARGUMENTS_LENGTH)
            return String.fromCharCode.apply(String, e);
          for (var r = "", i2 = 0; i2 < t2; )
            r += String.fromCharCode.apply(String, e.slice(i2, i2 += MAX_ARGUMENTS_LENGTH));
          return r;
        }
        function asciiSlice(e, t2, r) {
          var i2 = "";
          r = Math.min(e.length, r);
          for (var n = t2; n < r; ++n)
            i2 += String.fromCharCode(127 & e[n]);
          return i2;
        }
        function latin1Slice(e, t2, r) {
          var i2 = "";
          r = Math.min(e.length, r);
          for (var n = t2; n < r; ++n)
            i2 += String.fromCharCode(e[n]);
          return i2;
        }
        function hexSlice(e, t2, r) {
          var i2 = e.length;
          (!t2 || t2 < 0) && (t2 = 0), (!r || r < 0 || i2 < r) && (r = i2);
          for (var n = "", o = t2; o < r; ++o)
            n += toHex(e[o]);
          return n;
        }
        function utf16leSlice(e, t2, r) {
          for (var i2 = e.slice(t2, r), n = "", o = 0; o < i2.length; o += 2)
            n += String.fromCharCode(i2[o] + 256 * i2[o + 1]);
          return n;
        }
        function checkOffset(e, t2, r) {
          if (e % 1 != 0 || e < 0)
            throw new RangeError("offset is not uint");
          if (r < e + t2)
            throw new RangeError("Trying to access beyond buffer length");
        }
        function checkInt(e, t2, r, i2, n, o) {
          if (!internalIsBuffer(e))
            throw new TypeError('"buffer" argument must be a Buffer instance');
          if (n < t2 || t2 < o)
            throw new RangeError('"value" argument is out of bounds');
          if (r + i2 > e.length)
            throw new RangeError("Index out of range");
        }
        function objectWriteUInt16(e, t2, r, i2) {
          t2 < 0 && (t2 = 65535 + t2 + 1);
          for (var n = 0, o = Math.min(e.length - r, 2); n < o; ++n)
            e[r + n] = (t2 & 255 << 8 * (i2 ? n : 1 - n)) >>> 8 * (i2 ? n : 1 - n);
        }
        function objectWriteUInt32(e, t2, r, i2) {
          t2 < 0 && (t2 = 4294967295 + t2 + 1);
          for (var n = 0, o = Math.min(e.length - r, 4); n < o; ++n)
            e[r + n] = t2 >>> 8 * (i2 ? n : 3 - n) & 255;
        }
        function checkIEEE754(e, t2, r, i2, n, o) {
          if (r + i2 > e.length)
            throw new RangeError("Index out of range");
          if (r < 0)
            throw new RangeError("Index out of range");
        }
        function writeFloat(e, t2, r, i2, n) {
          return n || checkIEEE754(e, t2, r, 4, 34028234663852886e22, -34028234663852886e22), write$1(e, t2, r, i2, 23, 4), r + 4;
        }
        function writeDouble(e, t2, r, i2, n) {
          return n || checkIEEE754(e, t2, r, 8, 17976931348623157e292, -17976931348623157e292), write$1(e, t2, r, i2, 52, 8), r + 8;
        }
        Buffer.prototype.slice = function(e, t2) {
          var r = this.length;
          if ((e = ~~e) < 0 ? (e += r) < 0 && (e = 0) : r < e && (e = r), (t2 = void 0 === t2 ? r : ~~t2) < 0 ? (t2 += r) < 0 && (t2 = 0) : r < t2 && (t2 = r), t2 < e && (t2 = e), Buffer.TYPED_ARRAY_SUPPORT)
            (n = this.subarray(e, t2)).__proto__ = Buffer.prototype;
          else
            for (var i2 = t2 - e, n = new Buffer(i2, void 0), o = 0; o < i2; ++o)
              n[o] = this[o + e];
          return n;
        }, Buffer.prototype.readUIntLE = function(e, t2, r) {
          e |= 0, t2 |= 0, r || checkOffset(e, t2, this.length);
          for (var i2 = this[e], n = 1, o = 0; ++o < t2 && (n *= 256); )
            i2 += this[e + o] * n;
          return i2;
        }, Buffer.prototype.readUIntBE = function(e, t2, r) {
          e |= 0, t2 |= 0, r || checkOffset(e, t2, this.length);
          for (var i2 = this[e + --t2], n = 1; 0 < t2 && (n *= 256); )
            i2 += this[e + --t2] * n;
          return i2;
        }, Buffer.prototype.readUInt8 = function(e, t2) {
          return t2 || checkOffset(e, 1, this.length), this[e];
        }, Buffer.prototype.readUInt16LE = function(e, t2) {
          return t2 || checkOffset(e, 2, this.length), this[e] | this[e + 1] << 8;
        }, Buffer.prototype.readUInt16BE = function(e, t2) {
          return t2 || checkOffset(e, 2, this.length), this[e] << 8 | this[e + 1];
        }, Buffer.prototype.readUInt32LE = function(e, t2) {
          return t2 || checkOffset(e, 4, this.length), (this[e] | this[e + 1] << 8 | this[e + 2] << 16) + 16777216 * this[e + 3];
        }, Buffer.prototype.readUInt32BE = function(e, t2) {
          return t2 || checkOffset(e, 4, this.length), 16777216 * this[e] + (this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3]);
        }, Buffer.prototype.readIntLE = function(e, t2, r) {
          e |= 0, t2 |= 0, r || checkOffset(e, t2, this.length);
          for (var i2 = this[e], n = 1, o = 0; ++o < t2 && (n *= 256); )
            i2 += this[e + o] * n;
          return (n *= 128) <= i2 && (i2 -= Math.pow(2, 8 * t2)), i2;
        }, Buffer.prototype.readIntBE = function(e, t2, r) {
          e |= 0, t2 |= 0, r || checkOffset(e, t2, this.length);
          for (var i2 = t2, n = 1, o = this[e + --i2]; 0 < i2 && (n *= 256); )
            o += this[e + --i2] * n;
          return (n *= 128) <= o && (o -= Math.pow(2, 8 * t2)), o;
        }, Buffer.prototype.readInt8 = function(e, t2) {
          return t2 || checkOffset(e, 1, this.length), 128 & this[e] ? -1 * (255 - this[e] + 1) : this[e];
        }, Buffer.prototype.readInt16LE = function(e, t2) {
          t2 || checkOffset(e, 2, this.length);
          var r = this[e] | this[e + 1] << 8;
          return 32768 & r ? 4294901760 | r : r;
        }, Buffer.prototype.readInt16BE = function(e, t2) {
          t2 || checkOffset(e, 2, this.length);
          var r = this[e + 1] | this[e] << 8;
          return 32768 & r ? 4294901760 | r : r;
        }, Buffer.prototype.readInt32LE = function(e, t2) {
          return t2 || checkOffset(e, 4, this.length), this[e] | this[e + 1] << 8 | this[e + 2] << 16 | this[e + 3] << 24;
        }, Buffer.prototype.readInt32BE = function(e, t2) {
          return t2 || checkOffset(e, 4, this.length), this[e] << 24 | this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3];
        }, Buffer.prototype.readFloatLE = function(e, t2) {
          return t2 || checkOffset(e, 4, this.length), read$1(this, e, true, 23, 4);
        }, Buffer.prototype.readFloatBE = function(e, t2) {
          return t2 || checkOffset(e, 4, this.length), read$1(this, e, false, 23, 4);
        }, Buffer.prototype.readDoubleLE = function(e, t2) {
          return t2 || checkOffset(e, 8, this.length), read$1(this, e, true, 52, 8);
        }, Buffer.prototype.readDoubleBE = function(e, t2) {
          return t2 || checkOffset(e, 8, this.length), read$1(this, e, false, 52, 8);
        }, Buffer.prototype.writeUIntLE = function(e, t2, r, i2) {
          e = +e, t2 |= 0, r |= 0, i2 || checkInt(this, e, t2, r, Math.pow(2, 8 * r) - 1, 0);
          var n = 1, o = 0;
          for (this[t2] = 255 & e; ++o < r && (n *= 256); )
            this[t2 + o] = e / n & 255;
          return t2 + r;
        }, Buffer.prototype.writeUIntBE = function(e, t2, r, i2) {
          e = +e, t2 |= 0, r |= 0, i2 || checkInt(this, e, t2, r, Math.pow(2, 8 * r) - 1, 0);
          var n = r - 1, o = 1;
          for (this[t2 + n] = 255 & e; 0 <= --n && (o *= 256); )
            this[t2 + n] = e / o & 255;
          return t2 + r;
        }, Buffer.prototype.writeUInt8 = function(e, t2, r) {
          return e = +e, t2 |= 0, r || checkInt(this, e, t2, 1, 255, 0), Buffer.TYPED_ARRAY_SUPPORT || (e = Math.floor(e)), this[t2] = 255 & e, t2 + 1;
        }, Buffer.prototype.writeUInt16LE = function(e, t2, r) {
          return e = +e, t2 |= 0, r || checkInt(this, e, t2, 2, 65535, 0), Buffer.TYPED_ARRAY_SUPPORT ? (this[t2] = 255 & e, this[t2 + 1] = e >>> 8) : objectWriteUInt16(this, e, t2, true), t2 + 2;
        }, Buffer.prototype.writeUInt16BE = function(e, t2, r) {
          return e = +e, t2 |= 0, r || checkInt(this, e, t2, 2, 65535, 0), Buffer.TYPED_ARRAY_SUPPORT ? (this[t2] = e >>> 8, this[t2 + 1] = 255 & e) : objectWriteUInt16(this, e, t2, false), t2 + 2;
        }, Buffer.prototype.writeUInt32LE = function(e, t2, r) {
          return e = +e, t2 |= 0, r || checkInt(this, e, t2, 4, 4294967295, 0), Buffer.TYPED_ARRAY_SUPPORT ? (this[t2 + 3] = e >>> 24, this[t2 + 2] = e >>> 16, this[t2 + 1] = e >>> 8, this[t2] = 255 & e) : objectWriteUInt32(this, e, t2, true), t2 + 4;
        }, Buffer.prototype.writeUInt32BE = function(e, t2, r) {
          return e = +e, t2 |= 0, r || checkInt(this, e, t2, 4, 4294967295, 0), Buffer.TYPED_ARRAY_SUPPORT ? (this[t2] = e >>> 24, this[t2 + 1] = e >>> 16, this[t2 + 2] = e >>> 8, this[t2 + 3] = 255 & e) : objectWriteUInt32(this, e, t2, false), t2 + 4;
        }, Buffer.prototype.writeIntLE = function(e, t2, r, i2) {
          var n;
          e = +e, t2 |= 0, i2 || checkInt(this, e, t2, r, (n = Math.pow(2, 8 * r - 1)) - 1, -n);
          var o = 0, a2 = 1, s = 0;
          for (this[t2] = 255 & e; ++o < r && (a2 *= 256); )
            e < 0 && 0 === s && 0 !== this[t2 + o - 1] && (s = 1), this[t2 + o] = (e / a2 >> 0) - s & 255;
          return t2 + r;
        }, Buffer.prototype.writeIntBE = function(e, t2, r, i2) {
          var n;
          e = +e, t2 |= 0, i2 || checkInt(this, e, t2, r, (n = Math.pow(2, 8 * r - 1)) - 1, -n);
          var o = r - 1, a2 = 1, s = 0;
          for (this[t2 + o] = 255 & e; 0 <= --o && (a2 *= 256); )
            e < 0 && 0 === s && 0 !== this[t2 + o + 1] && (s = 1), this[t2 + o] = (e / a2 >> 0) - s & 255;
          return t2 + r;
        }, Buffer.prototype.writeInt8 = function(e, t2, r) {
          return e = +e, t2 |= 0, r || checkInt(this, e, t2, 1, 127, -128), Buffer.TYPED_ARRAY_SUPPORT || (e = Math.floor(e)), e < 0 && (e = 255 + e + 1), this[t2] = 255 & e, t2 + 1;
        }, Buffer.prototype.writeInt16LE = function(e, t2, r) {
          return e = +e, t2 |= 0, r || checkInt(this, e, t2, 2, 32767, -32768), Buffer.TYPED_ARRAY_SUPPORT ? (this[t2] = 255 & e, this[t2 + 1] = e >>> 8) : objectWriteUInt16(this, e, t2, true), t2 + 2;
        }, Buffer.prototype.writeInt16BE = function(e, t2, r) {
          return e = +e, t2 |= 0, r || checkInt(this, e, t2, 2, 32767, -32768), Buffer.TYPED_ARRAY_SUPPORT ? (this[t2] = e >>> 8, this[t2 + 1] = 255 & e) : objectWriteUInt16(this, e, t2, false), t2 + 2;
        }, Buffer.prototype.writeInt32LE = function(e, t2, r) {
          return e = +e, t2 |= 0, r || checkInt(this, e, t2, 4, 2147483647, -2147483648), Buffer.TYPED_ARRAY_SUPPORT ? (this[t2] = 255 & e, this[t2 + 1] = e >>> 8, this[t2 + 2] = e >>> 16, this[t2 + 3] = e >>> 24) : objectWriteUInt32(this, e, t2, true), t2 + 4;
        }, Buffer.prototype.writeInt32BE = function(e, t2, r) {
          return e = +e, t2 |= 0, r || checkInt(this, e, t2, 4, 2147483647, -2147483648), e < 0 && (e = 4294967295 + e + 1), Buffer.TYPED_ARRAY_SUPPORT ? (this[t2] = e >>> 24, this[t2 + 1] = e >>> 16, this[t2 + 2] = e >>> 8, this[t2 + 3] = 255 & e) : objectWriteUInt32(this, e, t2, false), t2 + 4;
        }, Buffer.prototype.writeFloatLE = function(e, t2, r) {
          return writeFloat(this, e, t2, true, r);
        }, Buffer.prototype.writeFloatBE = function(e, t2, r) {
          return writeFloat(this, e, t2, false, r);
        }, Buffer.prototype.writeDoubleLE = function(e, t2, r) {
          return writeDouble(this, e, t2, true, r);
        }, Buffer.prototype.writeDoubleBE = function(e, t2, r) {
          return writeDouble(this, e, t2, false, r);
        }, Buffer.prototype.copy = function(e, t2, r, i2) {
          if (r = r || 0, i2 || 0 === i2 || (i2 = this.length), t2 >= e.length && (t2 = e.length), t2 = t2 || 0, 0 < i2 && i2 < r && (i2 = r), i2 === r)
            return 0;
          if (0 === e.length || 0 === this.length)
            return 0;
          if (t2 < 0)
            throw new RangeError("targetStart out of bounds");
          if (r < 0 || r >= this.length)
            throw new RangeError("sourceStart out of bounds");
          if (i2 < 0)
            throw new RangeError("sourceEnd out of bounds");
          i2 > this.length && (i2 = this.length), e.length - t2 < i2 - r && (i2 = e.length - t2 + r);
          var n, o = i2 - r;
          if (this === e && r < t2 && t2 < i2)
            for (n = o - 1; 0 <= n; --n)
              e[n + t2] = this[n + r];
          else if (o < 1e3 || !Buffer.TYPED_ARRAY_SUPPORT)
            for (n = 0; n < o; ++n)
              e[n + t2] = this[n + r];
          else
            Uint8Array.prototype.set.call(e, this.subarray(r, r + o), t2);
          return o;
        }, Buffer.prototype.fill = function(e, t2, r, i2) {
          if ("string" == typeof e) {
            var n;
            if ("string" == typeof t2 ? (i2 = t2, t2 = 0, r = this.length) : "string" == typeof r && (i2 = r, r = this.length), 1 !== e.length || (n = e.charCodeAt(0)) < 256 && (e = n), void 0 !== i2 && "string" != typeof i2)
              throw new TypeError("encoding must be a string");
            if ("string" == typeof i2 && !Buffer.isEncoding(i2))
              throw new TypeError("Unknown encoding: " + i2);
          } else
            "number" == typeof e && (e &= 255);
          if (t2 < 0 || this.length < t2 || this.length < r)
            throw new RangeError("Out of range index");
          if (r <= t2)
            return this;
          if (t2 >>>= 0, r = void 0 === r ? this.length : r >>> 0, "number" == typeof (e = e || 0))
            for (s = t2; s < r; ++s)
              this[s] = e;
          else
            for (var o = internalIsBuffer(e) ? e : utf8ToBytes(new Buffer(e, i2).toString()), a2 = o.length, s = 0; s < r - t2; ++s)
              this[s + t2] = o[s % a2];
          return this;
        };
        var INVALID_BASE64_RE = /[^+\/0-9A-Za-z-_]/g;
        function base64clean(e) {
          if ((e = stringtrim(e).replace(INVALID_BASE64_RE, "")).length < 2)
            return "";
          for (; e.length % 4 != 0; )
            e += "=";
          return e;
        }
        function stringtrim(e) {
          return e.trim ? e.trim() : e.replace(/^\s+|\s+$/g, "");
        }
        function toHex(e) {
          return e < 16 ? "0" + e.toString(16) : e.toString(16);
        }
        function utf8ToBytes(e, t2) {
          var r;
          t2 = t2 || 1 / 0;
          for (var i2 = e.length, n = null, o = [], a2 = 0; a2 < i2; ++a2) {
            if (55295 < (r = e.charCodeAt(a2)) && r < 57344) {
              if (!n) {
                if (56319 < r) {
                  -1 < (t2 -= 3) && o.push(239, 191, 189);
                  continue;
                }
                if (a2 + 1 === i2) {
                  -1 < (t2 -= 3) && o.push(239, 191, 189);
                  continue;
                }
                n = r;
                continue;
              }
              if (r < 56320) {
                -1 < (t2 -= 3) && o.push(239, 191, 189), n = r;
                continue;
              }
              r = 65536 + (n - 55296 << 10 | r - 56320);
            } else
              n && -1 < (t2 -= 3) && o.push(239, 191, 189);
            if (n = null, r < 128) {
              if (--t2 < 0)
                break;
              o.push(r);
            } else if (r < 2048) {
              if ((t2 -= 2) < 0)
                break;
              o.push(r >> 6 | 192, 63 & r | 128);
            } else if (r < 65536) {
              if ((t2 -= 3) < 0)
                break;
              o.push(r >> 12 | 224, r >> 6 & 63 | 128, 63 & r | 128);
            } else {
              if (!(r < 1114112))
                throw new Error("Invalid code point");
              if ((t2 -= 4) < 0)
                break;
              o.push(r >> 18 | 240, r >> 12 & 63 | 128, r >> 6 & 63 | 128, 63 & r | 128);
            }
          }
          return o;
        }
        function asciiToBytes(e) {
          for (var t2 = [], r = 0; r < e.length; ++r)
            t2.push(255 & e.charCodeAt(r));
          return t2;
        }
        function utf16leToBytes(e, t2) {
          for (var r, i2, n, o = [], a2 = 0; a2 < e.length && !((t2 -= 2) < 0); ++a2)
            i2 = (r = e.charCodeAt(a2)) >> 8, n = r % 256, o.push(n), o.push(i2);
          return o;
        }
        function base64ToBytes(e) {
          return toByteArray(base64clean(e));
        }
        function blitBuffer(e, t2, r, i2) {
          for (var n = 0; n < i2 && !(n + r >= t2.length || n >= e.length); ++n)
            t2[n + r] = e[n];
          return n;
        }
        function isnan(e) {
          return e != e;
        }
        function isBuffer(e) {
          return null != e && (!!e._isBuffer || isFastBuffer(e) || isSlowBuffer(e));
        }
        function isFastBuffer(e) {
          return !!e.constructor && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e);
        }
        function isSlowBuffer(e) {
          return "function" == typeof e.readFloatLE && "function" == typeof e.slice && isFastBuffer(e.slice(0, 0));
        }
        var bufferEs6 = Object.freeze({ INSPECT_MAX_BYTES, kMaxLength: _kMaxLength, Buffer, SlowBuffer, isBuffer });
        global$1.setTimeout, global$1.clearTimeout;
        var performance$1 = global$1.performance || {}, performanceNow = performance$1.now || performance$1.mozNow || performance$1.msNow || performance$1.oNow || performance$1.webkitNow || function() {
          return (/* @__PURE__ */ new Date()).getTime();
        }, inherits, inherits = "function" == typeof Object.create ? function(e, t2) {
          e.super_ = t2, e.prototype = Object.create(t2.prototype, { constructor: { value: e, enumerable: false, writable: true, configurable: true } });
        } : function(e, t2) {
          e.super_ = t2;
          function r() {
          }
          r.prototype = t2.prototype, e.prototype = new r(), e.prototype.constructor = e;
        }, inherits$1 = inherits;
        function inspect(e, t2) {
          var r = { seen: [], stylize: stylizeNoColor };
          return 3 <= arguments.length && (r.depth = arguments[2]), 4 <= arguments.length && (r.colors = arguments[3]), isBoolean(t2) ? r.showHidden = t2 : t2 && _extend(r, t2), isUndefined(r.showHidden) && (r.showHidden = false), isUndefined(r.depth) && (r.depth = 2), isUndefined(r.colors) && (r.colors = false), isUndefined(r.customInspect) && (r.customInspect = true), r.colors && (r.stylize = stylizeWithColor), formatValue(r, e, r.depth);
        }
        function stylizeWithColor(e, t2) {
          var r = inspect.styles[t2];
          return r ? "\x1B[" + inspect.colors[r][0] + "m" + e + "\x1B[" + inspect.colors[r][1] + "m" : e;
        }
        function stylizeNoColor(e, t2) {
          return e;
        }
        function arrayToHash(e) {
          var r = {};
          return e.forEach(function(e2, t2) {
            r[e2] = true;
          }), r;
        }
        function formatValue(t2, r, i2) {
          if (t2.customInspect && r && isFunction(r.inspect) && r.inspect !== inspect && (!r.constructor || r.constructor.prototype !== r)) {
            var e = r.inspect(i2, t2);
            return isString(e) || (e = formatValue(t2, e, i2)), e;
          }
          var n = formatPrimitive(t2, r);
          if (n)
            return n;
          var o = Object.keys(r), a2 = arrayToHash(o);
          if (t2.showHidden && (o = Object.getOwnPropertyNames(r)), isError(r) && (0 <= o.indexOf("message") || 0 <= o.indexOf("description")))
            return formatError(r);
          if (0 === o.length) {
            if (isFunction(r)) {
              var s = r.name ? ": " + r.name : "";
              return t2.stylize("[Function" + s + "]", "special");
            }
            if (isRegExp(r))
              return t2.stylize(RegExp.prototype.toString.call(r), "regexp");
            if (isDate(r))
              return t2.stylize(Date.prototype.toString.call(r), "date");
            if (isError(r))
              return formatError(r);
          }
          var l, u2 = "", c2 = false, h = ["{", "}"];
          return isArray$1(r) && (c2 = true, h = ["[", "]"]), isFunction(r) && (u2 = " [Function" + (r.name ? ": " + r.name : "") + "]"), isRegExp(r) && (u2 = " " + RegExp.prototype.toString.call(r)), isDate(r) && (u2 = " " + Date.prototype.toUTCString.call(r)), isError(r) && (u2 = " " + formatError(r)), 0 !== o.length || c2 && 0 != r.length ? i2 < 0 ? isRegExp(r) ? t2.stylize(RegExp.prototype.toString.call(r), "regexp") : t2.stylize("[Object]", "special") : (t2.seen.push(r), l = c2 ? formatArray(t2, r, i2, a2, o) : o.map(function(e2) {
            return formatProperty(t2, r, i2, a2, e2, c2);
          }), t2.seen.pop(), reduceToSingleString(l, u2, h)) : h[0] + u2 + h[1];
        }
        function formatPrimitive(e, t2) {
          if (isUndefined(t2))
            return e.stylize("undefined", "undefined");
          if (isString(t2)) {
            var r = "'" + JSON.stringify(t2).replace(/^"|"$/g, "").replace(/'/g, "\\'").replace(/\\"/g, '"') + "'";
            return e.stylize(r, "string");
          }
          return isNumber(t2) ? e.stylize("" + t2, "number") : isBoolean(t2) ? e.stylize("" + t2, "boolean") : isNull(t2) ? e.stylize("null", "null") : void 0;
        }
        function formatError(e) {
          return "[" + Error.prototype.toString.call(e) + "]";
        }
        function formatArray(t2, r, i2, n, e) {
          for (var o = [], a2 = 0, s = r.length; a2 < s; ++a2)
            hasOwnProperty$1(r, String(a2)) ? o.push(formatProperty(t2, r, i2, n, String(a2), true)) : o.push("");
          return e.forEach(function(e2) {
            e2.match(/^\d+$/) || o.push(formatProperty(t2, r, i2, n, e2, true));
          }), o;
        }
        function formatProperty(e, t2, r, i2, n, o) {
          var a2, s, l = Object.getOwnPropertyDescriptor(t2, n) || { value: t2[n] };
          if (l.get ? s = l.set ? e.stylize("[Getter/Setter]", "special") : e.stylize("[Getter]", "special") : l.set && (s = e.stylize("[Setter]", "special")), hasOwnProperty$1(i2, n) || (a2 = "[" + n + "]"), s || (e.seen.indexOf(l.value) < 0 ? -1 < (s = isNull(r) ? formatValue(e, l.value, null) : formatValue(e, l.value, r - 1)).indexOf("\n") && (s = o ? s.split("\n").map(function(e2) {
            return "  " + e2;
          }).join("\n").substr(2) : "\n" + s.split("\n").map(function(e2) {
            return "   " + e2;
          }).join("\n")) : s = e.stylize("[Circular]", "special")), isUndefined(a2)) {
            if (o && n.match(/^\d+$/))
              return s;
            a2 = (a2 = JSON.stringify("" + n)).match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/) ? (a2 = a2.substr(1, a2.length - 2), e.stylize(a2, "name")) : (a2 = a2.replace(/'/g, "\\'").replace(/\\"/g, '"').replace(/(^"|"$)/g, "'"), e.stylize(a2, "string"));
          }
          return a2 + ": " + s;
        }
        function reduceToSingleString(e, t2, r) {
          return 60 < e.reduce(function(e2, t3) {
            return t3.indexOf("\n"), e2 + t3.replace(/\u001b\[\d\d?m/g, "").length + 1;
          }, 0) ? r[0] + ("" === t2 ? "" : t2 + "\n ") + " " + e.join(",\n  ") + " " + r[1] : r[0] + t2 + " " + e.join(", ") + " " + r[1];
        }
        function isArray$1(e) {
          return Array.isArray(e);
        }
        function isBoolean(e) {
          return "boolean" == typeof e;
        }
        function isNull(e) {
          return null === e;
        }
        function isNumber(e) {
          return "number" == typeof e;
        }
        function isString(e) {
          return "string" == typeof e;
        }
        function isUndefined(e) {
          return void 0 === e;
        }
        function isRegExp(e) {
          return isObject$1(e) && "[object RegExp]" === objectToString$1(e);
        }
        function isObject$1(e) {
          return "object" == typeof e && null !== e;
        }
        function isDate(e) {
          return isObject$1(e) && "[object Date]" === objectToString$1(e);
        }
        function isError(e) {
          return isObject$1(e) && ("[object Error]" === objectToString$1(e) || e instanceof Error);
        }
        function isFunction(e) {
          return "function" == typeof e;
        }
        function isPrimitive(e) {
          return null === e || "boolean" == typeof e || "number" == typeof e || "string" == typeof e || "symbol" == typeof e || void 0 === e;
        }
        function objectToString$1(e) {
          return Object.prototype.toString.call(e);
        }
        function _extend(e, t2) {
          if (!t2 || !isObject$1(t2))
            return e;
          for (var r = Object.keys(t2), i2 = r.length; i2--; )
            e[r[i2]] = t2[r[i2]];
          return e;
        }
        function hasOwnProperty$1(e, t2) {
          return Object.prototype.hasOwnProperty.call(e, t2);
        }
        function compare(e, t2) {
          if (e === t2)
            return 0;
          for (var r = e.length, i2 = t2.length, n = 0, o = Math.min(r, i2); n < o; ++n)
            if (e[n] !== t2[n]) {
              r = e[n], i2 = t2[n];
              break;
            }
          return r < i2 ? -1 : i2 < r ? 1 : 0;
        }
        inspect.colors = { bold: [1, 22], italic: [3, 23], underline: [4, 24], inverse: [7, 27], white: [37, 39], grey: [90, 39], black: [30, 39], blue: [34, 39], cyan: [36, 39], green: [32, 39], magenta: [35, 39], red: [31, 39], yellow: [33, 39] }, inspect.styles = { special: "cyan", number: "yellow", boolean: "yellow", undefined: "grey", null: "bold", string: "green", date: "magenta", regexp: "red" };
        var hasOwn = Object.prototype.hasOwnProperty, objectKeys$1 = Object.keys || function(e) {
          var t2 = [];
          for (var r in e)
            hasOwn.call(e, r) && t2.push(r);
          return t2;
        }, pSlice = Array.prototype.slice, _functionsHaveNames;
        function functionsHaveNames() {
          return void 0 !== _functionsHaveNames ? _functionsHaveNames : _functionsHaveNames = "foo" === (function() {
          }).name;
        }
        function pToString(e) {
          return Object.prototype.toString.call(e);
        }
        function isView(e) {
          if (!isBuffer(e) && "function" == typeof global$1.ArrayBuffer) {
            if ("function" == typeof ArrayBuffer.isView)
              return ArrayBuffer.isView(e);
            if (e)
              return e instanceof DataView || !!(e.buffer && e.buffer instanceof ArrayBuffer);
          }
        }
        function assert(e, t2) {
          e || fail(e, true, t2, "==", ok);
        }
        var regex = /\s*function\s+([^\(\s]*)\s*/;
        function getName(e) {
          if (isFunction(e)) {
            if (functionsHaveNames())
              return e.name;
            var t2 = e.toString().match(regex);
            return t2 && t2[1];
          }
        }
        function AssertionError(e) {
          this.name = "AssertionError", this.actual = e.actual, this.expected = e.expected, this.operator = e.operator, e.message ? (this.message = e.message, this.generatedMessage = false) : (this.message = getMessage(this), this.generatedMessage = true);
          var t2, r, i2, n, o, a2 = e.stackStartFunction || fail;
          Error.captureStackTrace ? Error.captureStackTrace(this, a2) : (t2 = new Error()).stack && (o = t2.stack, r = getName(a2), 0 <= (i2 = o.indexOf("\n" + r)) && (n = o.indexOf("\n", i2 + 1), o = o.substring(n + 1)), this.stack = o);
        }
        function truncate(e, t2) {
          return "string" != typeof e || e.length < t2 ? e : e.slice(0, t2);
        }
        function inspect$1(e) {
          if (functionsHaveNames() || !isFunction(e))
            return inspect(e);
          var t2 = getName(e);
          return "[Function" + (t2 ? ": " + t2 : "") + "]";
        }
        function getMessage(e) {
          return truncate(inspect$1(e.actual), 128) + " " + e.operator + " " + truncate(inspect$1(e.expected), 128);
        }
        function fail(e, t2, r, i2, n) {
          throw new AssertionError({ message: r, actual: e, expected: t2, operator: i2, stackStartFunction: n });
        }
        function ok(e, t2) {
          e || fail(e, true, t2, "==", ok);
        }
        function equal(e, t2, r) {
          e != t2 && fail(e, t2, r, "==", equal);
        }
        function notEqual(e, t2, r) {
          e == t2 && fail(e, t2, r, "!=", notEqual);
        }
        function deepEqual(e, t2, r) {
          _deepEqual(e, t2, false) || fail(e, t2, r, "deepEqual", deepEqual);
        }
        function deepStrictEqual(e, t2, r) {
          _deepEqual(e, t2, true) || fail(e, t2, r, "deepStrictEqual", deepStrictEqual);
        }
        function _deepEqual(e, t2, r, i2) {
          if (e === t2)
            return true;
          if (isBuffer(e) && isBuffer(t2))
            return 0 === compare(e, t2);
          if (isDate(e) && isDate(t2))
            return e.getTime() === t2.getTime();
          if (isRegExp(e) && isRegExp(t2))
            return e.source === t2.source && e.global === t2.global && e.multiline === t2.multiline && e.lastIndex === t2.lastIndex && e.ignoreCase === t2.ignoreCase;
          if (null !== e && "object" == typeof e || null !== t2 && "object" == typeof t2) {
            if (isView(e) && isView(t2) && pToString(e) === pToString(t2) && !(e instanceof Float32Array || e instanceof Float64Array))
              return 0 === compare(new Uint8Array(e.buffer), new Uint8Array(t2.buffer));
            if (isBuffer(e) !== isBuffer(t2))
              return false;
            var n = (i2 = i2 || { actual: [], expected: [] }).actual.indexOf(e);
            return -1 !== n && n === i2.expected.indexOf(t2) || (i2.actual.push(e), i2.expected.push(t2), objEquiv(e, t2, r, i2));
          }
          return r ? e === t2 : e == t2;
        }
        function isArguments(e) {
          return "[object Arguments]" == Object.prototype.toString.call(e);
        }
        function objEquiv(e, t2, r, i2) {
          if (null == e || null == t2)
            return false;
          if (isPrimitive(e) || isPrimitive(t2))
            return e === t2;
          if (r && Object.getPrototypeOf(e) !== Object.getPrototypeOf(t2))
            return false;
          var n = isArguments(e), o = isArguments(t2);
          if (n && !o || !n && o)
            return false;
          if (n)
            return _deepEqual(e = pSlice.call(e), t2 = pSlice.call(t2), r);
          var a2, s, l = objectKeys$1(e), u2 = objectKeys$1(t2);
          if (l.length !== u2.length)
            return false;
          for (l.sort(), u2.sort(), s = l.length - 1; 0 <= s; s--)
            if (l[s] !== u2[s])
              return false;
          for (s = l.length - 1; 0 <= s; s--)
            if (!_deepEqual(e[a2 = l[s]], t2[a2], r, i2))
              return false;
          return true;
        }
        function notDeepEqual(e, t2, r) {
          _deepEqual(e, t2, false) && fail(e, t2, r, "notDeepEqual", notDeepEqual);
        }
        function notDeepStrictEqual(e, t2, r) {
          _deepEqual(e, t2, true) && fail(e, t2, r, "notDeepStrictEqual", notDeepStrictEqual);
        }
        function strictEqual(e, t2, r) {
          e !== t2 && fail(e, t2, r, "===", strictEqual);
        }
        function notStrictEqual(e, t2, r) {
          e === t2 && fail(e, t2, r, "!==", notStrictEqual);
        }
        function expectedException(e, t2) {
          if (e && t2) {
            if ("[object RegExp]" == Object.prototype.toString.call(t2))
              return t2.test(e);
            try {
              if (e instanceof t2)
                return 1;
            } catch (e2) {
            }
            if (!Error.isPrototypeOf(t2))
              return true === t2.call({}, e);
          }
        }
        function _tryBlock(e) {
          var t2;
          try {
            e();
          } catch (e2) {
            t2 = e2;
          }
          return t2;
        }
        function _throws(e, t2, r, i2) {
          var n;
          if ("function" != typeof t2)
            throw new TypeError('"block" argument must be a function');
          "string" == typeof r && (i2 = r, r = null), n = _tryBlock(t2), i2 = (r && r.name ? " (" + r.name + ")." : ".") + (i2 ? " " + i2 : "."), e && !n && fail(n, r, "Missing expected exception" + i2);
          var o = "string" == typeof i2, a2 = !e && n && !r;
          if ((!e && isError(n) && o && expectedException(n, r) || a2) && fail(n, r, "Got unwanted exception" + i2), e && n && r && !expectedException(n, r) || !e && n)
            throw n;
        }
        function throws(e, t2, r) {
          _throws(true, e, t2, r);
        }
        function doesNotThrow(e, t2, r) {
          _throws(false, e, t2, r);
        }
        function ifError(e) {
          if (e)
            throw e;
        }
        assert.AssertionError = AssertionError, inherits$1(AssertionError, Error), assert.fail = fail, assert.ok = ok, assert.equal = equal, assert.notEqual = notEqual, assert.deepEqual = deepEqual, assert.deepStrictEqual = deepStrictEqual, assert.notDeepEqual = notDeepEqual, assert.notDeepStrictEqual = notDeepStrictEqual, assert.strictEqual = strictEqual, assert.notStrictEqual = notStrictEqual, assert.throws = throws, assert.doesNotThrow = doesNotThrow, assert.ifError = ifError;
        var sort = function(e) {
          return e.sort(function(e2, t2) {
            return e2.height - t2.height;
          }), e;
        }, placeItems = function(e) {
          var t2 = 0;
          return e.forEach(function(e2) {
            e2.x = 0, e2.y = t2, t2 += e2.height;
          }), e;
        }, topDown_algorithm = { sort, placeItems }, sort$1 = function(e) {
          return e.sort(function(e2, t2) {
            return e2.width - t2.width;
          }), e;
        }, placeItems$1 = function(e) {
          var t2 = 0;
          return e.forEach(function(e2) {
            e2.x = t2, e2.y = 0, t2 += e2.width;
          }), e;
        }, leftRight_algorithm = { sort: sort$1, placeItems: placeItems$1 }, sort$2 = function(e) {
          return e.sort(function(e2, t2) {
            return Math.sqrt(Math.pow(e2.height, 2) + Math.pow(e2.width, 2)) - Math.sqrt(Math.pow(t2.height, 2) + Math.pow(t2.width, 2));
          }), e;
        }, placeItems$2 = function(e) {
          var t2 = 0, r = 0;
          return e.forEach(function(e2) {
            e2.x = t2, e2.y = r, t2 += e2.width, r += e2.height;
          }), e;
        }, diagonal_algorithm = { sort: sort$2, placeItems: placeItems$2 }, sort$3 = function(e) {
          return e.sort(function(e2, t2) {
            return Math.sqrt(Math.pow(e2.height, 2) + Math.pow(e2.width, 2)) - Math.sqrt(Math.pow(t2.height, 2) + Math.pow(t2.width, 2));
          }), e;
        }, placeItems$3 = function(e) {
          var r = 0, i2 = 0;
          return e.forEach(function(e2) {
            var t2 = e2.width;
            e2.x = r - t2, e2.y = i2, r -= t2, i2 += e2.height;
          }), e;
        }, altDiagonal_algorithm = { sort: sort$3, placeItems: placeItems$3 }, GrowingPacker = function() {
        };
        GrowingPacker.prototype = { fit: function(e) {
          var t2, r, i2, n, o = e.length, a2 = 0 < o ? e[0].width : 0, s = 0 < o ? e[0].height : 0;
          for (this.root = { x: 0, y: 0, width: a2, height: s }, t2 = 0; t2 < o; t2++)
            i2 = e[t2], n = (r = this.findNode(this.root, i2.width, i2.height)) ? this.splitNode(r, i2.width, i2.height) : this.growNode(i2.width, i2.height), i2.x = n.x, i2.y = n.y;
        }, findNode: function(e, t2, r) {
          return e.used ? this.findNode(e.right, t2, r) || this.findNode(e.down, t2, r) : t2 <= e.width && r <= e.height ? e : null;
        }, splitNode: function(e, t2, r) {
          return e.used = true, e.down = { x: e.x, y: e.y + r, width: e.width, height: e.height - r }, e.right = { x: e.x + t2, y: e.y, width: e.width - t2, height: r }, e;
        }, growNode: function(e, t2) {
          var r = e <= this.root.width, i2 = t2 <= this.root.height, n = i2 && this.root.height >= this.root.width + e, o = r && this.root.width >= this.root.height + t2;
          return n ? this.growRight(e, t2) : o ? this.growDown(e, t2) : i2 ? this.growRight(e, t2) : r ? this.growDown(e, t2) : null;
        }, growRight: function(e, t2) {
          var r;
          return this.root = { used: true, x: 0, y: 0, width: this.root.width + e, height: this.root.height, down: this.root, right: { x: this.root.width, y: 0, width: e, height: this.root.height } }, (r = this.findNode(this.root, e, t2)) ? this.splitNode(r, e, t2) : null;
        }, growDown: function(e, t2) {
          var r;
          return this.root = { used: true, x: 0, y: 0, width: this.root.width, height: this.root.height + t2, down: { x: 0, y: this.root.height, width: this.root.width, height: t2 }, right: this.root }, (r = this.findNode(this.root, e, t2)) ? this.splitNode(r, e, t2) : null;
        } };
        var packer_growing = GrowingPacker, binPack = function(e, t2) {
          t2 = t2 || {};
          var r = new packer_growing(), i2 = t2.inPlace || false, n = (n = e.map(function(e2) {
            return i2 ? e2 : { width: e2.width, height: e2.height, item: e2 };
          })).sort(function(e2, t3) {
            return t3.width * t3.height - e2.width * e2.height;
          });
          r.fit(n);
          var o = { width: n.reduce(function(e2, t3) {
            return Math.max(e2, t3.x + t3.width);
          }, 0), height: n.reduce(function(e2, t3) {
            return Math.max(e2, t3.y + t3.height);
          }, 0) };
          return i2 || (o.items = n), o;
        }, sort$4 = function(e) {
          return e;
        }, placeItems$4 = function(e) {
          return binPack(e, { inPlace: true }), e;
        }, binaryTree_algorithm = { sort: sort$4, placeItems: placeItems$4 }, algorithms = {};
        function Layout(e, t2) {
          var r = e || "top-down";
          return "string" == typeof r && assert(r = algorithms[e], "Sorry, the '" + e + "' algorithm could not be loaded."), new packing_smith(r, t2);
        }
        function addAlgorithm(e, t2) {
          algorithms[e] = t2;
        }
        Layout.PackingSmith = packing_smith, Layout.addAlgorithm = addAlgorithm, Layout.algorithms = algorithms, addAlgorithm("top-down", topDown_algorithm), addAlgorithm("left-right", leftRight_algorithm), addAlgorithm("diagonal", diagonal_algorithm), addAlgorithm("alt-diagonal", altDiagonal_algorithm), addAlgorithm("binary-tree", binaryTree_algorithm);
        var layout = Layout;
        function isTainting(e) {
          var t2;
          try {
            e.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, 1, 1);
          } catch (e2) {
            t2 = e2.message;
          }
          return t2;
        }
        function bitmapToCanvas(e, t2, r) {
          var i2;
          return e instanceof HTMLImageElement && ((i2 = e.ownerDocument.createElement("canvas")).width = t2, i2.height = r, i2.getContext("2d").drawImage(e, 0, 0, t2, r), e = i2), e;
        }
        var MAX_LNG_LAT = Geo$1.metersToLatLng([Geo$1.half_circumference_meters, Geo$1.half_circumference_meters]), TILE_EXPONENT = Math.log(Geo$1.tile_size) / Math.LN2, ICON_READY = 1, DOM_MARKER_TYPE = 8, GROUP_TYPE = 16, TILE_MARGIN = 100, AFFECTED_BBOX_CALC_THRESHOLD = 10, ObjectSource = function() {
          _inherits(p2, MapsJsSource);
          var i2 = _createSuper(p2);
          function p2(e, t2) {
            var r;
            return _classCallCheck(this, p2), r = i2.call(this, e, t2), Thread.is_worker && (r._quad_tree = new ns.H.geo.QuadTree(), r._marker_quad_tree = new ns.H.geo.QuadTree(), r._tree_entries_by_object_id = {}, r._groups_by_id = {}, r._layersCache = new ns.H.util.Cache(100)), Thread.is_main && (r._objects_by_id = {}, r._commands = [], r._sendCommands = debounce(r._sendCommands, 100, 200), r.dispatchUpdate = r.dispatchUpdate.bind(_assertThisInitialized(r))), r;
          }
          return _createClass(p2, [{ key: "hasLabeledData", value: function() {
            return false;
          } }, { key: "onReady", value: function() {
            this._synced_at = this.provider.getInvalidations().getMark();
            var e, t2, r = this.provider.getRootGroup(), i3 = r.getObjects(true), n = [];
            for (i3.push(r), e = i3.length; e--; )
              t2 = i3[e], this._isObjectSupported(t2) && this._shouldBeStored(t2) && (this._objects_by_id[t2.getId()] = t2, n.push(t2.forWorkerMessage()));
            var o = [{ method_name: "addObjects", arguments: [n] }];
            this._sendImmediateCommands(o);
          } }, { key: "onProviderUpdate", value: function(e) {
            var t2, r, i3, n, o = e.target, a2 = e.currentTarget.getInvalidations(o.type);
            this._isObjectSupported(o) && (t2 = this._synced_at, r = o.getId(), a2.isRemove(t2) ? (delete this._objects_by_id[r], this._commands.push({ method_name: "removeObjectsByIds", arguments: [[r], true] })) : a2.isAdd(t2) ? this._shouldBeStored(o) && (this._objects_by_id[r] = o, this._commands.push({ method_name: "addObjects", arguments: [[o.forWorkerMessage()]] })) : a2.isSpatial(t2) || a2.isZOrder(t2) ? this._shouldBeStored(o) && (i3 = [{ method_name: "removeObjectsByIds", arguments: [[r], true] }, { method_name: "addObjects", arguments: [[(this._objects_by_id[r] = o).forWorkerMessage()]] }], this.has_volatile_data && !this.hasPendingCommands() ? this._sendImmediateCommands(i3) : this._commands.push(i3[0], i3[1])) : a2.isVisual(t2) ? this._shouldBeStored(o) && (n = { method_name: "updateObjectProperties", arguments: [(this._objects_by_id[r] = o).forWorkerMessage()] }, this.has_volatile_data && !this.hasPendingCommands() ? this._sendImmediateCommands([n]) : this._commands.push(n)) : a2.isVolatility(t2) && (delete this._objects_by_id[r], this._commands.push({ method_name: "removeObjectsByIds", arguments: [[r], true] }), this._shouldBeStored(o) && (this._objects_by_id[r] = o, this._commands.push({ method_name: "addObjects", arguments: [[o.forWorkerMessage()]] }))), this._commands.length && this._sendCommands()), this._synced_at = a2.getMark();
          } }, { key: "_shouldBeStored", value: function(e) {
            return e.type === GROUP_TYPE || (!e.getIcon || e.getIcon().getState() === ICON_READY) && this._hasSameVolatility(e);
          } }, { key: "_hasSameVolatility", value: function(e) {
            return e.getVolatility(true) === this.has_volatile_data;
          } }, { key: "hasPendingCommands", value: function() {
            return 0 < this._commands.length;
          } }, { key: "_sendCommands", value: function() {
            this._sendImmediateCommands(this._commands), this._commands = [];
          } }, { key: "_sendImmediateCommands", value: function(e) {
            e.length && WorkerBroker.postMessage(this.worker, this.target_name + ".executeCommands", e).then(this.dispatchUpdate);
          } }, { key: "_isObjectSupported", value: function(e) {
            return e.forWorkerMessage && e.type !== DOM_MARKER_TYPE;
          } }, { key: "getSyncedAt", value: function() {
            return this._synced_at;
          } }, { key: "getMapObjectById", value: function(e) {
            return this._objects_by_id[e];
          } }, { key: "getIconBitmapByObjectId", value: function(e, t2) {
            var r = this.getMapObjectById(e);
            if (r) {
              var i3 = r.getIcon();
              if (i3.uid === t2 && i3.getState() === ICON_READY) {
                var n = i3.getSize();
                return bitmapToCanvas(i3.getBitmap(), n.w, n.h);
              }
            }
          } }, { key: "_getRastersForMarkers", value: function(e) {
            for (var t2 = {}, r = layout("binary-tree"), i3 = 0; i3 < e.length; i3++) {
              var n = e[i3], o = n.properties.icon;
              t2[o.id] || (r.addItem({ width: o.size.w, height: o.size.h, meta: { objectId: n.id, id: o.id } }), t2[o.id] = true);
            }
            return r.export();
          } }, { key: "fetchFeaturesForTile", value: function(e) {
            var t2 = [], r = [], i3 = [], n = [], o = [], a2 = this._marker_quad_tree.intersectBoundingBox(Geo$1.getTileBoundingBox(e.coords, this.tile_size));
            e.source_data.error = null;
            for (var s = 0; s < a2.length; s++) {
              var l = { id: a2[s].$feature$.id, properties: Object.assign({}, a2[s].$feature$.properties), geometry: { type: a2[s].$feature$.geometry.type, coordinates: ArrayUtils$1.deepClone(a2[s].$feature$.geometry.coordinates) } };
              t2.push(l);
            }
            a2 = this._quad_tree.intersectBoundingBox(Geo$1.getTileBoundingBox(e.coords, this.tile_size, TILE_MARGIN));
            for (var u2 = 0; u2 < a2.length; u2++) {
              var c2, h = { id: a2[u2].$feature$.id, properties: Object.assign({}, a2[u2].$feature$.properties), geometry: { type: a2[u2].$feature$.geometry.type, coordinates: ArrayUtils$1.deepClone(a2[u2].$feature$.geometry.coordinates) } };
              h.properties.overlay ? r.push(h) : h.geometry.type.includes("LineString") ? i3.push(h) : h.geometry.type.includes("Polygon") && (n.push(h), c2 = { id: h.id, properties: h.properties, geometry: { type: h.geometry.type, coordinates: ArrayUtils$1.deepClone(h.geometry.coordinates) } }, o.push(c2));
            }
            t2.sort(p2._compareZInfo), n.sort(p2._compareZInfo), r.sort(p2._compareZInfo);
            var f2 = this.has_volatile_data ? 4096 : 0;
            o.sort(p2._compareZInfo);
            for (var d = 0; d < o.length; d++)
              o[d].properties.effectiveZIdx = f2++;
            i3.sort(p2._compareZInfo);
            for (var _ = 0; _ < i3.length; _++)
              i3[_].properties.effectiveZIdx = f2++;
            e.source_data.layers.markers = { type: "FeatureCollection", features: t2 }, e.source_data.layers.polylines = { type: "FeatureCollection", features: i3 }, e.source_data.layers.polygons = { type: "FeatureCollection", features: n }, e.source_data.layers.outlines = { type: "FeatureCollection", features: o }, e.source_data.layers.overlays = { type: "FeatureCollection", features: r };
          } }, { key: "tileTexture", value: function(e) {
            var t2 = e.source_data.layers.overlays;
            if (t2) {
              var r = this.name + "_" + e.coords.key, i3 = Tile.coordinateWithMaxZoom(e.coords, this.max_zoom), n = t2.features[0].properties.overlays_config;
              return { name: r, filtering: this.filtering, coords: i3, width: Geo$1.tile_size, height: Geo$1.tile_size, overlays_config: n, source: this.name };
            }
          } }, { key: "_load", value: function(e) {
            var t2 = Geo$1.wrapTile(e.coords, { x: true }), r = t2.z, i3 = t2.x, n = t2.y, o = "".concat(r, "_").concat(i3, "_").concat(n), a2 = this._layersCache.get(o), s = false;
            if (a2)
              e.source_data.layers = a2;
            else {
              this.fetchFeaturesForTile(e);
              var l = { maxZoom: this.max_zoom, tolerance: 1.5, extent: Geo$1.tile_scale }, u2 = e.source_data.layers.overlays;
              u2.features.length && delete e.source_data.layers.overlays;
              var c2 = e.source_data.layers.markers;
              for (var h in c2.features.length && delete e.source_data.layers.markers, e.source_data.layers) {
                var f2, d = e.source_data.layers[h];
                d.features.length && (l.buffer = h.includes("lines") ? TILE_MARGIN * Geo$1.units_per_pixel : 0, f2 = createGeoJsonTile(d, r, i3, n, l), e.source_data.layers[h] = parseGeoJSONVectorTile(f2));
              }
              e.source_data.layers.overlays = this._processOverlays(e, u2);
              for (var _ = e.source_data.layers.overlays.features.length; _--; )
                if (!e.source_data.layers.overlays.features[_].id) {
                  s = true, this._layersCache.drop(o);
                  break;
                }
              e.source_data.layers.markers = this._processMarkers(e, c2), this._postProcessTile(e), s || this._layersCache.add(o, e.source_data.layers, 1);
            }
            return e.rasters = this._getRastersForMarkers(e.source_data.layers.markers.features), Promise.resolve(e);
          } }, { key: "_processMarkers", value: function(o, e) {
            var t2 = e.features.length;
            if (t2) {
              for (var a2 = Geo$1.unitsPerMeter(o.coords.z), r = Geo$1.wrapTile(o.coords, { x: true }), s = Geo$1.metersForTile(r), l = Geo$1.isLastTile(r), u2 = Geo$1.wrapMeters(o.min), c2 = Geo$1.wrapMeters(o.max), i3 = function(e2) {
                DataSource.coordsToMeters(e2);
                var t3 = _slicedToArray(e2, 2), r2 = t3[0], i4 = t3[1], n2 = r2 >= u2.x && (l.column || r2 < c2.x) && i4 >= c2.y && (l.row || !o.coords.y || i4 < u2.y);
                return DataSource.metersToTileUnits(a2, s, e2), n2;
              }, n = [], h = 0; h < t2; h++) {
                var f2, d = e.features[h].geometry, _ = false;
                "Point" === d.type ? i3(f2 = d.coordinates) ? d.coordinates = f2 : _ = true : "MultiPoint" === d.type && (d.coordinates = d.coordinates.filter(i3), 0 === d.coordinates.length && (_ = true)), _ || n.push(e.features[h]);
              }
              e.features = n;
            }
            return e;
          } }, { key: "_processOverlays", value: function(t2, e) {
            var r = this;
            if (!e.features.length)
              return e;
            var i3 = { coords: t2.coords, min: Geo$1.metersForTile(Geo$1.wrapTile(t2.coords, { x: true })) }, n = { coords: t2.coords, source_data: { layers: { _default: { type: "FeatureCollection", features: e.features } } } }, h = Math.pow(2, t2.coords.z + TILE_EXPONENT);
            MapsJsSource.projectData(n.source_data), MapsJsSource.scaleData(n.source_data, i3);
            var o = e.features.map(function(e2) {
              var t3 = e2.geometry.coordinates[0], r2 = t3[0], i4 = t3[5 === t3.length ? 2 : 3], n2 = Math.floor(r2[0] / Geo$1.tile_scale * Geo$1.tile_size), o2 = Math.floor(r2[1] / Geo$1.tile_scale * Geo$1.tile_size), a3 = Math.floor(i4[0] / Geo$1.tile_scale * Geo$1.tile_size), s = Math.floor(i4[1] / Geo$1.tile_scale * Geo$1.tile_size) - o2, l = a3 <= n2, u2 = l ? h - (n2 - a3) : a3 - n2, c2 = [];
              return n2 <= Geo$1.tile_size && c2.push([n2, o2, u2, s]), l && 0 < a3 && c2.push([n2 - h, o2, u2, s]), { id: e2.id, properties: e2.properties, texcoords: c2 };
            }).filter(function(e2) {
              return r._isVisible(e2.properties) && r.isInMinMaxRange(e2.properties, t2.style_zoom);
            }), a2 = Geo$1.tile_scale;
            return t2.pad_scale = this.pad_scale, t2.default_winding = "CW", e.features = o.length ? [{ geometry: { type: "Polygon", coordinates: [[[0, 0], [a2, 0], [a2, a2], [0, a2], [0, 0]]] }, properties: { overlays_config: o } }] : o, e;
          } }, { key: "executeCommands", value: function(e) {
            for (var t2, r = e.length < AFFECTED_BBOX_CALC_THRESHOLD, i3 = 0; i3 < e.length; i3++) {
              var n = e[i3];
              n.arguments.push(r);
              var o = this[n.method_name].apply(this, n.arguments);
              r && (o && t2 ? t2.mergeRect(o, true, t2) : o && (t2 = o));
            }
            return t2 ? t2.forWorkerMessage() : void 0;
          } }, { key: "_getClampedGeoRectForFeature", value: function(e) {
            var t2 = e.geometry.boundingBox;
            return new ns.H.geo.Rect(MathUtils$1.clamp(t2[0], -MAX_LNG_LAT[1], MAX_LNG_LAT[1]), t2[1], MathUtils$1.clamp(t2[2], -MAX_LNG_LAT[1], MAX_LNG_LAT[1]), t2[3]);
          } }, { key: "addObjects", value: function(e, t2) {
            for (var r, i3 = 1 < arguments.length && void 0 !== t2 && t2, n = 0; n < e.length; n++) {
              var o, a2, s, l = e[n];
              "Group" === l.type ? (l.$children_ids$ = {}, this._groups_by_id[l.id] = l) : (p2._preprocessGeometry(l.geometry), o = this._getClampedGeoRectForFeature(l), i3 && (r ? r.mergeRect(o, true, r) : r = o), (s = (a2 = -1 !== l.geometry.type.indexOf("Point") ? this._marker_quad_tree : this._quad_tree).insertBoundingBox(o)).$tree = a2, s.$feature$ = l, this._tree_entries_by_object_id[l.id] = s);
            }
            for (var u2 = 0; u2 < e.length; u2++) {
              var c2 = e[u2];
              c2.properties.parent && (this._groups_by_id[c2.properties.parent].$children_ids$[c2.id] = c2.id), c2.properties.ref = { effectiveVisibility: this._isVisible(c2.properties), zInfo: this._getZInfo([], c2) };
            }
            return this._layersCache.removeAll(), r;
          } }, { key: "removeObjectsByIds", value: function(e, t2, r) {
            for (var i3, n = 2 < arguments.length && void 0 !== r && r, o = 0; o < e.length; o++) {
              var a2, s = e[o], l = void 0, u2 = void 0;
              (l = this._tree_entries_by_object_id[s]) ? (n && (a2 = this._getClampedGeoRectForFeature(l.$feature$), i3 ? i3.mergeRect(a2, true, i3) : i3 = a2), delete this._groups_by_id[l.$feature$.properties.parent].$children_ids$[s], l.$tree.remove(l), delete this._tree_entries_by_object_id[s]) : (u2 = this._groups_by_id[s]) && (u2.properties.parent && delete this._groups_by_id[u2.properties.parent].$children_ids$[s], t2 && this.removeObjectsByIds(Object.keys(u2.$children_ids$), true), delete this._groups_by_id[s]);
            }
            return this._layersCache.removeAll(), i3;
          } }, { key: "updateObjectProperties", value: function(e, t2) {
            var r, i3 = 1 < arguments.length && void 0 !== t2 && t2;
            return "Group" === e.type ? (mergeObjects(this._groups_by_id[e.id].properties, e.properties), this._groups_by_id[e.id].properties.ref.effectiveVisibility = this._isVisible(e.properties)) : (this._tree_entries_by_object_id[e.id] || this.addObjects([e]), mergeObjects(this._tree_entries_by_object_id[e.id].$feature$.properties, e.properties), this._tree_entries_by_object_id[e.id].$feature$.properties.ref.effectiveVisibility = this._isVisible(e.properties), i3 && (r = this._getClampedGeoRectForFeature(e))), r;
          } }, { key: "_getZInfo", value: function(e, t2) {
            var r = t2.properties.zIdx, i3 = t2.properties.sIdx;
            return e[0] |= void 0 !== r, e.splice(1, 0, r || 0, i3 < 0 ? t2.id : i3), 0 === t2.properties.parent ? e : this._getZInfo(e, this._groups_by_id[t2.properties.parent]);
          } }, { key: "_isVisible", value: function(e) {
            var t2 = e.visible, r = !e.parent || this._isVisible(this._groups_by_id[e.parent].properties);
            return t2 && r;
          } }, { key: "isInMinMaxRange", value: function(e, t2) {
            var r = e.min <= t2 && e.max >= t2, i3 = !e.parent || this.isInMinMaxRange(this._groups_by_id[e.parent].properties, t2);
            return r && i3;
          } }, { key: "dispose", value: function() {
            this._commands = [], _get(_getPrototypeOf(p2.prototype), "dispose", this).call(this);
          } }], [{ key: "_compareZInfo", value: function(e, t2) {
            for (var r, i3 = e.properties.ref.zInfo, n = t2.properties.ref.zInfo, o = i3.length, a2 = n.length, s = Math.min(o, a2), l = 1; l < s; l++)
              if (r = i3[l] - n[l])
                return r;
            return o - a2;
          } }, { key: "_preprocessGeometry", value: function(e) {
            var t2 = e.type;
            e.coordinates = "Point" === t2 ? p2._processPointCoordinates(e.coordinates) : "MultiPoint" === t2 ? e.coordinates.map(p2._processPointCoordinates) : "LineString" === t2 ? p2._processLineStringCoordinates(e.coordinates) : "MultiLineString" === t2 ? e.coordinates.map(p2._processLineStringCoordinates) : "Polygon" === t2 ? e.coordinates.map(p2._processPolygonCoordinates) : "MultiPolygon" === t2 ? e.coordinates.map(p2._processMultiPolygonCoordinates) : [];
          } }, { key: "_processPointCoordinates", value: function(e) {
            return [e[1], e[0], e[2]];
          } }, { key: "_processLineStringCoordinates", value: function(e) {
            return p2._latLngAltArrayToLineString(e, false);
          } }, { key: "_processPolygonCoordinates", value: function(e) {
            return p2._latLngAltArrayToLineString(e, true);
          } }, { key: "_processMultiPolygonCoordinates", value: function(e) {
            return e.map(p2._processPolygonCoordinates);
          } }, { key: "_latLngAltArrayToLineString", value: function(e, t2) {
            for (var r = [], i3 = e.length, n = 0; n < i3; n += 3)
              r.push([e[n + 1], e[n]]);
            return t2 && r.push([e[1], e[0]]), r;
          } }]), p2;
        }();
        MapsJsSource.register(ObjectSource, "ObjectSource");
        var GEOMETRY_TYPE = { POLYGON: 1, POLYLINE: 2, OUTLINE: 3 }, IconMap = function() {
          function e() {
            _classCallCheck(this, e), this._map = {};
          }
          return _createClass(e, [{ key: "set", value: function(e2, t2, r) {
            var i2;
            this._map[e2] ? this._map[e2].accumulator.add(r) : ((i2 = /* @__PURE__ */ new Set()).add(r), this._map[e2] = { value: t2, accumulator: i2 });
          } }, { key: "get", value: function(e2) {
            return this._map[e2] && this._map[e2].value;
          } }, { key: "delete", value: function(e2, t2) {
            var r = this._map[e2];
            r && r.accumulator && (r.accumulator.delete(t2), 0 === r.accumulator.size && delete this._map[e2]);
          } }]), e;
        }(), ObjectTileSource = function() {
          _inherits(n, MapsJsSource);
          var i2 = _createSuper(n);
          function n(e, t2) {
            var r;
            return _classCallCheck(this, n), r = i2.call(this, e, t2), Thread.is_worker || (r._icons = new IconMap()), r;
          }
          return _createClass(n, [{ key: "onProviderUpdate", value: function(e) {
            e.target instanceof H.map.provider.Tile ? this.dispatchUpdate(e.target, e.data) : this.dispatchUpdate(void 0, e.data);
          } }, { key: "onReady", value: function() {
            var e = this.provider;
            e.setTileCanvasRendering && e.setTileCanvasRendering(false), e.providesMarkers() && (this._onCacheDrop = this._onCacheDrop.bind(this), e.getCache().registerOnDrop(this._onCacheDrop)), this.dispatchUpdate();
          } }, { key: "dispose", value: function() {
            _get(_getPrototypeOf(n.prototype), "dispose", this).call(this);
            var e = this.provider;
            e.providesMarkers() && e.getCache().deRegisterOnDrop(this._onCacheDrop);
          } }, { key: "_onCacheDrop", value: function(e, t2) {
            this.provider.cacheFilter(e) && this._deleteIcons(e, t2.data);
          } }, { key: "_deleteIcons", value: function(e, t2) {
            for (var r = 0, i3 = t2.length; r < i3; r++) {
              var n2 = t2[r].getIcon();
              this._icons.delete(n2.uid, e);
            }
          } }, { key: "getIconBitmapByObjectId", value: function(e, t2) {
            var r = this._icons.get(t2);
            return r && r.getBitmap();
          } }, { key: "requestMarkerTile", value: function(t2) {
            var s = this;
            return new Promise(function(a2, e) {
              s.provider ? s.provider.requestTileAsPromise(t2.x, t2.y, t2.z, false).then(function(e2) {
                var t3, r, i3 = [];
                if (e2.data)
                  for (r = (t3 = e2.data).length; r--; ) {
                    var n2 = t3[r], o = n2.getIcon();
                    s._icons.set(o.uid, o, e2.key), i3.push(n2.forWorkerMessage());
                  }
                a2(i3);
              }) : a2([]);
            });
          } }, { key: "requestSpatialTile", value: function(t2) {
            var r = this;
            return new Promise(function(o, e) {
              r.provider ? r.provider.requestTileAsPromise(t2.x, t2.y, t2.z, false).then(function(e2) {
                var t3, r2 = [];
                if (e2.getObjects) {
                  t3 = e2.getObjects();
                  for (var i3 = 0; i3 < t3.length; i3++) {
                    var n2 = t3[i3];
                    r2.push({ id: n2.getId(), geometries: n2.getGeometriesForTile(e2), isClosed: n2.isClosed(), style: n2.getStyle().forWorkerMessage() });
                  }
                }
                o(r2);
              }) : o([]);
            });
          } }, { key: "_pointToArray", value: function(e) {
            var t2 = Geo$1.tile_scale / this.tile_size;
            return [e.x * t2, e.y * t2];
          } }, { key: "_getGeoJsonMultiPolygon", value: function(e) {
            for (var t2 = e.geometries, r = t2.length, i3 = [], n2 = { coordinates: i3, type: "MultiPolygon" }, o = 0; o < r; o++) {
              for (var a2 = t2[o], s = a2.paths, l = s.length, u2 = a2.interiorsIndex, c2 = a2.outlinesIndex, h = Math.min(u2, c2, l), f2 = void 0, d = void 0, d = 0; d < h; d++)
                f2 = [s[d].map(this._pointToArray, this)], i3.push(f2);
              if (1 === h)
                for (h = Math.min(c2, l), d = u2; d < h; d++)
                  f2.push(s[d].map(this._pointToArray, this));
            }
            return n2;
          } }, { key: "_getGeoJsonMultiLineString", value: function(e, t2) {
            for (var r = 1 < arguments.length && void 0 !== t2 && t2, i3 = { coordinates: [], type: "MultiLineString" }, n2 = e.geometries, o = 0; o < n2.length; o++)
              for (var a2 = n2[o], s = r ? a2.outlinesIndex : 0, l = r ? a2.paths.length : Math.min(a2.interiorsIndex, a2.outlinesIndex, a2.paths.length), u2 = s; u2 < l; u2++) {
                var c2 = a2.paths[u2].map(this._pointToArray, this);
                i3.coordinates.push(c2);
              }
            return i3;
          } }, { key: "_getGeoJsonGeometry", value: function(e, t2) {
            var r = t2 === GEOMETRY_TYPE.POLYGON ? this._getGeoJsonMultiPolygon(e) : this._getGeoJsonMultiLineString(e, t2 === GEOMETRY_TYPE.OUTLINE);
            return r.coordinates.length ? r : null;
          } }, { key: "_load", value: function(f2) {
            var d = this;
            return new Promise(function(t2, e) {
              var r = WorkerBroker.postMessage(d.target_name + ".requestMarkerTile", f2.coords).then(d._prepareTileData.bind(d, f2)), i3 = new Promise(function(h, e2) {
                WorkerBroker.postMessage(d.target_name + ".requestSpatialTile", f2.coords).then(function(e3) {
                  for (var t3 = [], r2 = [], i4 = [], n2 = 0; n2 < e3.length; n2++) {
                    var o, a2 = e3[n2], s = void 0, l = void 0, l = a2.isClosed ? (s = r2, GEOMETRY_TYPE.POLYGON) : (s = t3, GEOMETRY_TYPE.POLYLINE), u2 = d._getGeoJsonGeometry(a2, l);
                    u2 && (o = { id: a2.id, type: "Feature", properties: { height: 0, style: a2.style }, geometry: u2 }, l === GEOMETRY_TYPE.POLYLINE && (o.properties.effectiveZIdx = t3.length), s.push(o));
                    var c2 = d._getGeoJsonGeometry(a2, GEOMETRY_TYPE.OUTLINE);
                    c2 && i4.push({ id: a2.id, type: "Feature", properties: { height: 0, style: a2.style, effectiveZIdx: i4.length }, geometry: c2 });
                  }
                  f2.source_data.layers.polylines = { type: "FeatureCollection", features: t3 }, f2.source_data.layers.polygons = { type: "FeatureCollection", features: r2 }, f2.source_data.layers.outlines = { type: "FeatureCollection", features: i4 }, h(f2);
                });
              });
              Promise.all([r, i3]).then(function(e2) {
                d._postProcessTile(f2), t2(f2);
              });
            });
          } }, { key: "_prepareTileData", value: function(e, t2) {
            var r = Geo$1.wrapTile(e.coords, { x: true, y: true }), i3 = Geo$1.metersForTile(r);
            e.source_data.layers = { markers: { features: t2, type: "FeatureCollection" } };
            var n2 = { coords: r, min: i3 }, o = e.source_data, a2 = layout("binary-tree"), s = {};
            for (var l in o.layers)
              for (var u2 = o.layers[l].features.length, c2 = 0; c2 < u2; c2++) {
                var h = o.layers[l].features[c2], f2 = h.properties.icon;
                s[f2.id] || (a2.addItem({ width: f2.size.w, height: f2.size.h, meta: { objectId: h.id, id: f2.id } }), s[f2.id] = true), Geo$1.transformGeometry(h.geometry, function(e2) {
                  var t3 = e2[0];
                  e2[0] = e2[1], e2[1] = t3;
                });
              }
            return e.rasters = a2.export(), MapsJsSource.projectData(e.source_data), MapsJsSource.scaleData(e.source_data, n2), e;
          } }]), n;
        }();
        MapsJsSource.register(ObjectTileSource, "ObjectTileSource");
        var RemoteRasterTileSource = function() {
          _inherits(n, RasterTileSource);
          var i2 = _createSuper(n);
          function n(e, t2) {
            var r;
            return _classCallCheck(this, n), (r = i2.call(this, e, t2)).uid_ = e.uid, r;
          }
          return _createClass(n, [{ key: "initialize", value: function(e, t2) {
            this.provider = e, this._on_update = t2, this._onProviderUpdate = this._onProviderUpdate.bind(this), e.addEventListener("update", this._onProviderUpdate);
          } }, { key: "_onProviderUpdate", value: function() {
            this._on_update(this.name);
          } }, { key: "tileTexture", value: function(e) {
            return Object.assign(_get(_getPrototypeOf(n.prototype), "tileTexture", this).call(this, e), { uid: this.uid_, url: this.uid_ + "_" + e.coords.key, coords: e.coords });
          } }, { key: "dispose", value: function() {
            this.provider.removeEventListener("update", this._onProviderUpdate);
          } }]), n;
        }();
        function geojsonvt(e, t2) {
          return new GeoJSONVT(e, t2);
        }
        function GeoJSONVT(e, t2) {
          var r = (t2 = this.options = extend(Object.create(this.options), t2)).debug;
          if (r && console.time("preprocess data"), t2.maxZoom < 0 || 24 < t2.maxZoom)
            throw new Error("maxZoom should be in the 0-24 range");
          if (t2.promoteId && t2.generateId)
            throw new Error("promoteId and generateId cannot be used together.");
          var i2 = convert(e, t2);
          this.tiles = {}, this.tileCoords = [], r && (console.timeEnd("preprocess data"), console.log("index: maxZoom: %d, maxPoints: %d", t2.indexMaxZoom, t2.indexMaxPoints), console.time("generate tiles"), this.stats = {}, this.total = 0), (i2 = wrap(i2, t2)).length && this.splitTile(i2, 0, 0, 0), r && (i2.length && console.log("features: %d, points: %d", this.tiles[0].numFeatures, this.tiles[0].numPoints), console.timeEnd("generate tiles"), console.log("tiles generated:", this.total, JSON.stringify(this.stats)));
        }
        function toID(e, t2, r) {
          return 32 * ((1 << e) * r + t2) + e;
        }
        function extend(e, t2) {
          for (var r in t2)
            e[r] = t2[r];
          return e;
        }
        DataSource.register(RemoteRasterTileSource, "RemoteRasterTileSource"), GeoJSONVT.prototype.options = { maxZoom: 14, indexMaxZoom: 5, indexMaxPoints: 1e5, tolerance: 3, extent: 4096, buffer: 64, lineMetrics: false, promoteId: null, generateId: false, debug: 0 }, GeoJSONVT.prototype.splitTile = function(e, t2, r, i2, n, o, a2) {
          for (var s = [e, t2, r, i2], l = this.options, u2 = l.debug; s.length; ) {
            i2 = s.pop(), r = s.pop(), t2 = s.pop(), e = s.pop();
            var c2, h, f2, d, _, p2, g, m, y, v, x2, b2 = 1 << t2, T2 = toID(t2, r, i2), A2 = this.tiles[T2];
            if (A2 || (1 < u2 && console.time("creation"), A2 = this.tiles[T2] = createTile(e, t2, r, i2, l), this.tileCoords.push({ z: t2, x: r, y: i2 }), u2 && (1 < u2 && (console.log("tile z%d-%d-%d (features: %d, points: %d, simplified: %d)", t2, r, i2, A2.numFeatures, A2.numPoints, A2.numSimplified), console.timeEnd("creation")), c2 = "z" + t2, this.stats[c2] = (this.stats[c2] || 0) + 1, this.total++)), A2.source = e, n) {
              if (t2 === l.maxZoom || t2 === n)
                continue;
              var E2 = 1 << n - t2;
              if (r !== Math.floor(o / E2) || i2 !== Math.floor(a2 / E2))
                continue;
            } else if (t2 === l.indexMaxZoom || A2.numPoints <= l.indexMaxPoints)
              continue;
            A2.source = null, 0 !== e.length && (1 < u2 && console.time("clipping"), f2 = 0.5 - (h = 0.5 * l.buffer / l.extent), _ = 1 + h, y = p2 = g = m = null, v = clip(e, b2, r - h, r + (d = 0.5 + h), 0, A2.minX, A2.maxX, l), x2 = clip(e, b2, r + f2, r + _, 0, A2.minX, A2.maxX, l), e = null, v && (y = clip(v, b2, i2 - h, i2 + d, 1, A2.minY, A2.maxY, l), p2 = clip(v, b2, i2 + f2, i2 + _, 1, A2.minY, A2.maxY, l), v = null), x2 && (g = clip(x2, b2, i2 - h, i2 + d, 1, A2.minY, A2.maxY, l), m = clip(x2, b2, i2 + f2, i2 + _, 1, A2.minY, A2.maxY, l), x2 = null), 1 < u2 && console.timeEnd("clipping"), s.push(y || [], t2 + 1, 2 * r, 2 * i2), s.push(p2 || [], t2 + 1, 2 * r, 2 * i2 + 1), s.push(g || [], t2 + 1, 2 * r + 1, 2 * i2), s.push(m || [], t2 + 1, 2 * r + 1, 2 * i2 + 1));
          }
        }, GeoJSONVT.prototype.getTile = function(e, t2, r) {
          var i2 = this.options, n = i2.extent, o = i2.debug;
          if (e < 0 || 24 < e)
            return null;
          var a2 = 1 << e, s = toID(e, t2 = (t2 % a2 + a2) % a2, r);
          if (this.tiles[s])
            return transformTile(this.tiles[s], n);
          1 < o && console.log("drilling down to z%d-%d-%d", e, t2, r);
          for (var l, u2 = e, c2 = t2, h = r; !l && 0 < u2; )
            u2--, c2 = Math.floor(c2 / 2), h = Math.floor(h / 2), l = this.tiles[toID(u2, c2, h)];
          return l && l.source ? (1 < o && console.log("found parent tile z%d-%d-%d", u2, c2, h), 1 < o && console.time("drilling down"), this.splitTile(l.source, u2, c2, h, e, t2, r), 1 < o && console.timeEnd("drilling down"), this.tiles[s] ? transformTile(this.tiles[s], n) : null) : null;
        };
        var EMPTY_FEATURE_COLLECTION$1 = { type: "FeatureCollection", features: [] }, GeoJSONTileSource = function() {
          _inherits(i2, MapsJsSource);
          var r = _createSuper(i2);
          function i2(e, t2) {
            return _classCallCheck(this, i2), e.tiled = true, e.url = "", r.call(this, e, t2);
          }
          return _createClass(i2, [{ key: "fetchTile", value: function(e, t2, r2) {
            return this.provider ? this.provider.requestTileAsPromise(e, t2, r2).then(function(e2) {
              return e2.data;
            }) : Promise.resolve(EMPTY_FEATURE_COLLECTION$1);
          } }, { key: "_load", value: function(i3) {
            var n = this, o = Geo$1.wrapTile(i3.coords, { x: true, y: true }), a2 = { indexMaxZoom: 0, maxZoom: this.max_zoom, tolerance: 1.5, extent: Geo$1.tile_scale };
            return WorkerBroker.postMessage(this.target_name + ".fetchTile", o.x, o.y, o.z).then(function(e) {
              for (var t2 in i3.source_data.layers = "FeatureCollection" === e.type ? { _default: e } : e, i3.source_data.layers) {
                var r2 = geojsonvt(i3.source_data.layers[t2], a2).getTile(o.z, o.x, o.y);
                i3.source_data.layers[t2] = parseGeoJSONVectorTile(r2);
              }
              return n._postProcessTile(i3), i3;
            });
          } }, { key: "onReady", value: function() {
            this.dispatchUpdate();
          } }]), i2;
        }();
        DataSource.register(GeoJSONTileSource, "GeoJSONTileSource");
        var DEFAULT_RESPONSE = { layers: { _default: { type: "FeatureCollection", features: [{ type: "Point", geometry: {} }] } } }, SkyBoxSource = function() {
          _inherits(i2, DataSource);
          var r = _createSuper(i2);
          function i2(e, t2) {
            return _classCallCheck(this, i2), e.max_zoom = 0, r.call(this, e, t2);
          }
          return _createClass(i2, [{ key: "load", value: function(e) {
            return e.source_data = "0/0/0" === e.coords.key ? DEFAULT_RESPONSE : void 0, Promise.resolve(e);
          } }]), i2;
        }(), debugSettings;
        DataSource.register(SkyBoxSource, "SkyBox");
        var debugSettings$1 = debugSettings = { draw_label_collision_boxes: false, draw_label_texture_boxes: false, suppress_label_fade_in: false, suppress_snap_animation: false, show_hidden_labels: false, layer_stats: false };
        function mergeDebugSettings(e) {
          Object.assign(debugSettings, e);
        }
        var WorkerType = { NATIVE: 0, FAKE: 1 }, Context;
        function sliceObject(t2, e) {
          var r = {};
          return e.forEach(function(e2) {
            return r[e2] = t2[e2];
          }), r;
        }
        var Context$1 = Context = {}, context_id = 0, gl;
        Context.getContext = function(e, t2) {
          var r = false;
          null == e && ((e = document.createElement("canvas")).style.position = "absolute", e.style.top = 0, e.style.left = 0, e.style.zIndex = -1, document.body.appendChild(e), r = true);
          var i2 = e.getContext("webgl", t2) || e.getContext("experimental-webgl", t2);
          if (!i2)
            throw new Error("Couldn't create WebGL context.");
          return i2._tangram_id = context_id++, r ? (Context.resize(i2, window.innerWidth, window.innerHeight, t2.device_pixel_ratio), window.addEventListener("resize", function() {
            Context.resize(i2, window.innerWidth, window.innerHeight, t2.device_pixel_ratio);
          })) : Context.resize(i2, parseFloat(e.style.width), parseFloat(e.style.height), t2.device_pixel_ratio), i2;
        }, Context.resize = function(e, t2, r, i2) {
          e.canvas.style.width = t2 + "px", e.canvas.style.height = r + "px", e.canvas.width = Math.round(t2 * i2), e.canvas.height = Math.round(r * i2), e.bindFramebuffer(e.FRAMEBUFFER, null), e.viewport(0, 0, e.canvas.width, e.canvas.height);
        };
        var gl$1 = gl = {};
        gl.BYTE = 5120, gl.UNSIGNED_BYTE = 5121, gl.SHORT = 5122, gl.UNSIGNED_SHORT = 5123, gl.INT = 5124, gl.UNSIGNED_INT = 5125, gl.FLOAT = 5126;
        var MAX_VALUE$1 = Math.pow(2, 16) - 1, DEFAULT_SIZE = 1024, HAS_ELEMENT_INDEX_UINT = false, VertexElements = function() {
          function t2(e) {
            _classCallCheck(this, t2), this.size_ = e || DEFAULT_SIZE, this.position_ = 0, this.ArrayType_ = Uint16Array, this.buffer_ = new this.ArrayType_(this.size_), this.overflows_ = false;
          }
          return _createClass(t2, [{ key: "push", value: function(e) {
            if (!this.overflows_ || HAS_ELEMENT_INDEX_UINT) {
              if (MAX_VALUE$1 < e) {
                if (this.overflows_ = true, !HAS_ELEMENT_INDEX_UINT)
                  return;
                this.ArrayType_ === Uint16Array && (this.ArrayType_ = Uint32Array, this.buffer_ = new this.ArrayType_(this.buffer_));
              }
              this.position_ === this.size_ && this.expand_(), this.buffer_[this.position_] = e, this.position_ += 1;
            }
          } }, { key: "end", value: function() {
            if (0 === this.position_)
              return false;
            var e = this.buffer_, t3 = this.position_;
            return this.buffer_ = new this.ArrayType_(this.size_), this.position_ = 0, this.overflows_ = false, e.subarray(0, t3);
          } }, { key: "expand_", value: function() {
            this.size_ = this.size_ << 1;
            var e = new this.ArrayType_(this.size_);
            e.set(this.buffer_), this.buffer_ = e;
          } }]), t2;
        }(), _array_types;
        VertexElements.setElementIndexUint = function(e) {
          HAS_ELEMENT_INDEX_UINT = e;
        };
        var array_types = (_array_types = {}, _defineProperty(_array_types, gl$1.FLOAT, Float32Array), _defineProperty(_array_types, gl$1.BYTE, Int8Array), _defineProperty(_array_types, gl$1.UNSIGNED_BYTE, Uint8Array), _defineProperty(_array_types, gl$1.INT, Int32Array), _defineProperty(_array_types, gl$1.UNSIGNED_INT, Uint32Array), _defineProperty(_array_types, gl$1.SHORT, Int16Array), _defineProperty(_array_types, gl$1.UNSIGNED_SHORT, Uint16Array), _array_types), VertexData = function() {
          function i2(e) {
            var t2 = (1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}).prealloc, r = void 0 === t2 ? 500 : t2;
            _classCallCheck(this, i2), this.vertex_layout = e, this.vertex_elements = new VertexElements(), this.stride = this.vertex_layout.stride, 0 < i2.array_pool.length ? (this.vertex_buffer = i2.array_pool.pop(), this.byte_length = this.vertex_buffer.byteLength, this.size = Math.floor(this.byte_length / this.stride), log("trace", "VertexData: reused buffer of bytes ".concat(this.byte_length, ", ").concat(this.size, " vertices"))) : (this.size = r, this.byte_length = this.stride * this.size, this.vertex_buffer = new Uint8Array(this.byte_length)), this.offset = 0, this.vertex_count = 0, this.realloc_count = 0, this.setBufferViews(), this.setAddVertexFunction();
          }
          return _createClass(i2, [{ key: "setBufferViews", value: function() {
            var r = this;
            this.views = {}, this.views[gl$1.UNSIGNED_BYTE] = this.vertex_buffer, this.vertex_layout.dynamic_attribs.forEach(function(e) {
              var t2;
              null == r.views[e.type] && (t2 = array_types[e.type], r.views[e.type] = new t2(r.vertex_buffer.buffer));
            });
          } }, { key: "checkBufferSize", value: function() {
            var e;
            this.offset + this.stride > this.byte_length && (this.size = Math.floor(1.5 * this.size), this.size -= this.size % 4, this.byte_length = this.stride * this.size, (e = new Uint8Array(this.byte_length)).set(this.vertex_buffer), i2.array_pool.push(this.vertex_buffer), this.vertex_buffer = e, this.setBufferViews(), this.realloc_count++);
          } }, { key: "setAddVertexFunction", value: function() {
            this.vertexLayoutAddVertex = this.vertex_layout.getAddVertexFunction();
          } }, { key: "addVertex", value: function(e) {
            this.checkBufferSize(), this.vertexLayoutAddVertex(e, this.views, this.offset), this.offset += this.stride, this.vertex_count++;
          } }, { key: "end", value: function() {
            return this.vertex_buffer = this.vertex_buffer.subarray(0, this.offset), this.element_buffer = this.vertex_elements.end(), log("trace", "VertexData: ".concat(this.size, " vertices total, realloc count ").concat(this.realloc_count)), this;
          } }]), i2;
        }();
        VertexData.array_pool = [];
        var VertexLayout = function() {
          function l(e) {
            _classCallCheck(this, l), this.attribs = e, this.dynamic_attribs = this.attribs.filter(function(e2) {
              return !e2.static;
            }), this.components = [], this.index = {}, this.offset = {};
            for (var t2 = this.stride = 0, r = 0, i2 = 0; i2 < this.attribs.length; i2++) {
              var n = this.attribs[i2];
              if (null == n.static) {
                n.offset = this.stride, n.byte_size = n.size;
                var o = 0;
                switch (n.type) {
                  case gl$1.FLOAT:
                  case gl$1.INT:
                  case gl$1.UNSIGNED_INT:
                    n.byte_size *= 4, o = 2;
                    break;
                  case gl$1.SHORT:
                  case gl$1.UNSIGNED_SHORT:
                    n.byte_size *= 2, o = 1;
                }
                3 & n.byte_size && (n.byte_size += 4 - (3 & n.byte_size)), this.stride += n.byte_size;
                for (var a2 = n.offset >> o, s = 0; s < n.size; s++)
                  this.components.push({ type: n.type, shift: o, offset: a2++, index: r++ });
                this.index[n.name] = t2, t2 += n.size, this.offset[n.name] = n.offset;
              } else
                n.static = Array.isArray(n.static) ? n.static : [n.static], n.method = "vertexAttrib".concat(n.static.length, "fv");
            }
          }
          return _createClass(l, [{ key: "enable", value: function(e, t2, r) {
            for (var i2, n, o = 0; o < this.attribs.length; o++)
              i2 = this.attribs[o], -1 !== (n = t2.attribute(i2.name).location) && (null == i2.static ? (l.enabled_attribs[n] && !r || e.enableVertexAttribArray(n), e.vertexAttribPointer(n, i2.size, i2.type, i2.normalized, this.stride, i2.offset), l.enabled_attribs[n] = t2) : e[i2.method] instanceof Function && (e.enableVertexAttribArray(n), e[i2.method](n, i2.static), e.disableVertexAttribArray(n), delete l.enabled_attribs[n]));
            for (n in l.enabled_attribs)
              this.disableUnusedAttribute(e, n, t2);
          } }, { key: "disableUnusedAttribute", value: function(e, t2, r) {
            l.enabled_attribs[t2] !== r && (e.disableVertexAttribArray(t2), delete l.enabled_attribs[t2]);
          } }, { key: "createVertexData", value: function() {
            return new VertexData(this);
          } }, { key: "getAddVertexFunction", value: function() {
            return null == this.addVertex && this.createAddVertexFunction(), this.addVertex;
          } }, { key: "createAddVertexFunction", value: function() {
            var e = hashString(JSON.stringify(this.attribs));
            if (null == l.add_vertex_funcs[e]) {
              var t2, r = ["var t, o;"], i2 = _toConsumableArray(this.components);
              i2.sort(function(e2, t3) {
                return e2.type !== t3.type ? e2.type - t3.type : e2.index - t3.index;
              });
              for (var n = 0; n < i2.length; n++) {
                var o = i2[n];
                t2 !== o.type && (r.push("t = vs[".concat(o.type, "];")), r.push("o = off".concat(o.shift ? " >> " + o.shift : "", ";")), t2 = o.type), r.push("t[o + ".concat(o.offset, "] = v[").concat(o.index, "];"));
              }
              r = r.join("\n");
              var a2 = new Function("v", "vs", "off", r);
              l.add_vertex_funcs[e] = a2;
            }
            this.addVertex = l.add_vertex_funcs[e];
          } }]), l;
        }();
        VertexLayout.enabled_attribs = {}, VertexLayout.add_vertex_funcs = {};
        var tile_bounds = [{ x: 0, y: 0 }, { x: Geo$1.tile_scale, y: -Geo$1.tile_scale }], default_uvs = [0, 0, 1, 1];
        function outsideTile(e, t2, r) {
          var i2 = tile_bounds[0], n = tile_bounds[1];
          return e[0] <= i2.x + r && t2[0] <= i2.x + r || e[0] >= n.x - r && t2[0] >= n.x - r || e[1] >= i2.y - r && t2[1] >= i2.y - r || e[1] <= n.y + r && t2[1] <= n.y + r;
        }
        function isCoordOutsideTile(e, t2) {
          t2 = t2 || 0;
          var r = tile_bounds[0], i2 = tile_bounds[1];
          return e[0] <= r.x + t2 || e[0] >= i2.x - t2 || e[1] >= r.y - t2 || e[1] <= i2.y + t2;
        }
        var earcut_1 = earcut;
        function earcut(e, t2, r) {
          r = r || 2;
          var i2, n, o, a2, s, l, u2, c2 = t2 && t2.length, h = c2 ? t2[0] * r : e.length, f2 = linkedList(e, 0, h, r, true), d = [];
          if (!f2)
            return d;
          if (c2 && (f2 = eliminateHoles(e, t2, f2, r)), e.length > 80 * r) {
            i2 = o = e[0], n = a2 = e[1];
            for (var _ = r; _ < h; _ += r)
              (s = e[_]) < i2 && (i2 = s), (l = e[_ + 1]) < n && (n = l), o < s && (o = s), a2 < l && (a2 = l);
            u2 = Math.max(o - i2, a2 - n);
          }
          return earcutLinked(f2, d, r, i2, n, u2), d;
        }
        function linkedList(e, t2, r, i2, n) {
          var o, a2;
          if (n === 0 < signedArea$1(e, t2, r, i2))
            for (o = t2; o < r; o += i2)
              a2 = insertNode(o, e[o], e[o + 1], a2);
          else
            for (o = r - i2; t2 <= o; o -= i2)
              a2 = insertNode(o, e[o], e[o + 1], a2);
          return a2 && equals(a2, a2.next) && (removeNode(a2), a2 = a2.next), a2;
        }
        function filterPoints(e, t2) {
          if (!e)
            return e;
          t2 = t2 || e;
          var r, i2 = e;
          do {
            if (r = false, i2.steiner || !equals(i2, i2.next) && 0 !== area(i2.prev, i2, i2.next))
              i2 = i2.next;
            else {
              if (removeNode(i2), (i2 = t2 = i2.prev) === i2.next)
                return null;
              r = true;
            }
          } while (r || i2 !== t2);
          return t2;
        }
        function earcutLinked(e, t2, r, i2, n, o, a2) {
          if (e) {
            !a2 && o && indexCurve(e, i2, n, o);
            for (var s, l, u2 = e; e.prev !== e.next; )
              if (s = e.prev, l = e.next, o ? isEarHashed(e, i2, n, o) : isEar(e))
                t2.push(s.i / r), t2.push(e.i / r), t2.push(l.i / r), removeNode(e), e = l.next, u2 = l.next;
              else if ((e = l) === u2) {
                a2 ? 1 === a2 ? earcutLinked(e = cureLocalIntersections(e, t2, r), t2, r, i2, n, o, 2) : 2 === a2 && splitEarcut(e, t2, r, i2, n, o) : earcutLinked(filterPoints(e), t2, r, i2, n, o, 1);
                break;
              }
          }
        }
        function isEar(e) {
          var t2 = e.prev, r = e, i2 = e.next;
          if (!(0 <= area(t2, r, i2))) {
            for (var n = e.next.next; n !== e.prev; ) {
              if (pointInTriangle(t2.x, t2.y, r.x, r.y, i2.x, i2.y, n.x, n.y) && 0 <= area(n.prev, n, n.next))
                return;
              n = n.next;
            }
            return 1;
          }
        }
        function isEarHashed(e, t2, r, i2) {
          var n = e.prev, o = e, a2 = e.next;
          if (!(0 <= area(n, o, a2))) {
            for (var s = n.x < o.x ? n.x < a2.x ? n.x : a2.x : o.x < a2.x ? o.x : a2.x, l = n.y < o.y ? n.y < a2.y ? n.y : a2.y : o.y < a2.y ? o.y : a2.y, u2 = n.x > o.x ? n.x > a2.x ? n.x : a2.x : o.x > a2.x ? o.x : a2.x, c2 = n.y > o.y ? n.y > a2.y ? n.y : a2.y : o.y > a2.y ? o.y : a2.y, h = zOrder(s, l, t2, r, i2), f2 = zOrder(u2, c2, t2, r, i2), d = e.nextZ; d && d.z <= f2; ) {
              if (d !== e.prev && d !== e.next && pointInTriangle(n.x, n.y, o.x, o.y, a2.x, a2.y, d.x, d.y) && 0 <= area(d.prev, d, d.next))
                return;
              d = d.nextZ;
            }
            for (d = e.prevZ; d && d.z >= h; ) {
              if (d !== e.prev && d !== e.next && pointInTriangle(n.x, n.y, o.x, o.y, a2.x, a2.y, d.x, d.y) && 0 <= area(d.prev, d, d.next))
                return;
              d = d.prevZ;
            }
            return 1;
          }
        }
        function cureLocalIntersections(e, t2, r) {
          var i2 = e;
          do {
            var n = i2.prev, o = i2.next.next;
            !equals(n, o) && intersects(n, i2, i2.next, o) && locallyInside(n, o) && locallyInside(o, n) && (t2.push(n.i / r), t2.push(i2.i / r), t2.push(o.i / r), removeNode(i2), removeNode(i2.next), i2 = e = o), i2 = i2.next;
          } while (i2 !== e);
          return i2;
        }
        function splitEarcut(e, t2, r, i2, n, o) {
          var a2 = e;
          do {
            for (var s = a2.next.next; s !== a2.prev; ) {
              if (a2.i !== s.i && isValidDiagonal(a2, s)) {
                var l = splitPolygon(a2, s), a2 = filterPoints(a2, a2.next), l = filterPoints(l, l.next);
                return earcutLinked(a2, t2, r, i2, n, o), void earcutLinked(l, t2, r, i2, n, o);
              }
              s = s.next;
            }
            a2 = a2.next;
          } while (a2 !== e);
        }
        function eliminateHoles(e, t2, r, i2) {
          for (var n, o = [], a2 = 0, s = t2.length; a2 < s; a2++)
            (n = linkedList(e, t2[a2] * i2, a2 < s - 1 ? t2[a2 + 1] * i2 : e.length, i2, false)) === n.next && (n.steiner = true), o.push(getLeftmost(n));
          for (o.sort(compareX), a2 = 0; a2 < o.length; a2++)
            eliminateHole(o[a2], r), r = filterPoints(r, r.next);
          return r;
        }
        function compareX(e, t2) {
          return e.x - t2.x;
        }
        function eliminateHole(e, t2) {
          var r;
          (t2 = findHoleBridge(e, t2)) && filterPoints(r = splitPolygon(t2, e), r.next);
        }
        function findHoleBridge(e, t2) {
          var r, i2 = t2, n = e.x, o = e.y, a2 = -1 / 0;
          do {
            if (o <= i2.y && o >= i2.next.y) {
              var s = i2.x + (o - i2.y) * (i2.next.x - i2.x) / (i2.next.y - i2.y);
              if (s <= n && a2 < s) {
                if ((a2 = s) === n) {
                  if (o === i2.y)
                    return i2;
                  if (o === i2.next.y)
                    return i2.next;
                }
                r = i2.x < i2.next.x ? i2 : i2.next;
              }
            }
            i2 = i2.next;
          } while (i2 !== t2);
          if (!r)
            return null;
          if (n === a2)
            return r.prev;
          for (var l, u2 = r, c2 = r.x, h = r.y, f2 = 1 / 0, i2 = r.next; i2 !== u2; )
            n >= i2.x && i2.x >= c2 && pointInTriangle(o < h ? n : a2, o, c2, h, o < h ? a2 : n, o, i2.x, i2.y) && ((l = Math.abs(o - i2.y) / (n - i2.x)) < f2 || l === f2 && i2.x > r.x) && locallyInside(i2, e) && (r = i2, f2 = l), i2 = i2.next;
          return r;
        }
        function indexCurve(e, t2, r, i2) {
          for (var n = e; null === n.z && (n.z = zOrder(n.x, n.y, t2, r, i2)), n.prevZ = n.prev, n.nextZ = n.next, (n = n.next) !== e; )
            ;
          n.prevZ.nextZ = null, n.prevZ = null, sortLinked(n);
        }
        function sortLinked(e) {
          var t2, r, i2, n, o, a2, s, l, u2 = 1;
          do {
            for (r = e, o = e = null, a2 = 0; r; ) {
              for (a2++, i2 = r, t2 = s = 0; t2 < u2 && (s++, i2 = i2.nextZ); t2++)
                ;
              for (l = u2; 0 < s || 0 < l && i2; )
                0 !== s && (0 === l || !i2 || r.z <= i2.z) ? (r = (n = r).nextZ, s--) : (i2 = (n = i2).nextZ, l--), o ? o.nextZ = n : e = n, n.prevZ = o, o = n;
              r = i2;
            }
            o.nextZ = null, u2 *= 2;
          } while (1 < a2);
          return e;
        }
        function zOrder(e, t2, r, i2, n) {
          return (e = 1431655765 & ((e = 858993459 & ((e = 252645135 & ((e = 16711935 & ((e = 32767 * (e - r) / n) | e << 8)) | e << 4)) | e << 2)) | e << 1)) | (t2 = 1431655765 & ((t2 = 858993459 & ((t2 = 252645135 & ((t2 = 16711935 & ((t2 = 32767 * (t2 - i2) / n) | t2 << 8)) | t2 << 4)) | t2 << 2)) | t2 << 1)) << 1;
        }
        function getLeftmost(e) {
          for (var t2 = e, r = e; t2.x < r.x && (r = t2), (t2 = t2.next) !== e; )
            ;
          return r;
        }
        function pointInTriangle(e, t2, r, i2, n, o, a2, s) {
          return 0 <= (n - a2) * (t2 - s) - (e - a2) * (o - s) && 0 <= (e - a2) * (i2 - s) - (r - a2) * (t2 - s) && 0 <= (r - a2) * (o - s) - (n - a2) * (i2 - s);
        }
        function isValidDiagonal(e, t2) {
          return e.next.i !== t2.i && e.prev.i !== t2.i && !intersectsPolygon(e, t2) && locallyInside(e, t2) && locallyInside(t2, e) && middleInside(e, t2);
        }
        function area(e, t2, r) {
          return (t2.y - e.y) * (r.x - t2.x) - (t2.x - e.x) * (r.y - t2.y);
        }
        function equals(e, t2) {
          return e.x === t2.x && e.y === t2.y;
        }
        function intersects(e, t2, r, i2) {
          return equals(e, t2) && equals(r, i2) || equals(e, i2) && equals(r, t2) || 0 < area(e, t2, r) != 0 < area(e, t2, i2) && 0 < area(r, i2, e) != 0 < area(r, i2, t2);
        }
        function intersectsPolygon(e, t2) {
          var r = e;
          do {
            if (r.i !== e.i && r.next.i !== e.i && r.i !== t2.i && r.next.i !== t2.i && intersects(r, r.next, e, t2))
              return 1;
            r = r.next;
          } while (r !== e);
        }
        function locallyInside(e, t2) {
          return area(e.prev, e, e.next) < 0 ? 0 <= area(e, t2, e.next) && 0 <= area(e, e.prev, t2) : area(e, t2, e.prev) < 0 || area(e, e.next, t2) < 0;
        }
        function middleInside(e, t2) {
          for (var r = e, i2 = false, n = (e.x + t2.x) / 2, o = (e.y + t2.y) / 2; r.y > o != r.next.y > o && n < (r.next.x - r.x) * (o - r.y) / (r.next.y - r.y) + r.x && (i2 = !i2), (r = r.next) !== e; )
            ;
          return i2;
        }
        function splitPolygon(e, t2) {
          var r = new Node(e.i, e.x, e.y), i2 = new Node(t2.i, t2.x, t2.y), n = e.next, o = t2.prev;
          return (e.next = t2).prev = e, (r.next = n).prev = r, (i2.next = r).prev = i2, (o.next = i2).prev = o, i2;
        }
        function insertNode(e, t2, r, i2) {
          var n = new Node(e, t2, r);
          return i2 ? (n.next = i2.next, (n.prev = i2).next.prev = n, i2.next = n) : (n.prev = n).next = n, n;
        }
        function removeNode(e) {
          e.next.prev = e.prev, e.prev.next = e.next, e.prevZ && (e.prevZ.nextZ = e.nextZ), e.nextZ && (e.nextZ.prevZ = e.prevZ);
        }
        function Node(e, t2, r) {
          this.i = e, this.x = t2, this.y = r, this.prev = null, this.next = null, this.z = null, this.prevZ = null, this.nextZ = null, this.steiner = false;
        }
        function signedArea$1(e, t2, r, i2) {
          for (var n = 0, o = t2, a2 = r - i2; o < r; o += i2)
            n += (e[a2] - e[o]) * (e[o + 1] + e[a2 + 1]), a2 = o;
          return n;
        }
        earcut.deviation = function(e, t2, r, i2) {
          var n = t2 && t2.length, o = n ? t2[0] * r : e.length, a2 = Math.abs(signedArea$1(e, 0, o, r));
          if (n)
            for (var s = 0, l = t2.length; s < l; s++) {
              var u2 = t2[s] * r, c2 = s < l - 1 ? t2[s + 1] * r : e.length;
              a2 -= Math.abs(signedArea$1(e, u2, c2, r));
            }
          for (var h = 0, s = 0; s < i2.length; s += 3) {
            var f2 = i2[s] * r, d = i2[s + 1] * r, _ = i2[s + 2] * r;
            h += Math.abs((e[f2] - e[_]) * (e[1 + d] - e[1 + f2]) - (e[f2] - e[d]) * (e[1 + _] - e[1 + f2]));
          }
          return 0 === a2 && 0 === h ? 0 : Math.abs((h - a2) / a2);
        }, earcut.flatten = function(e) {
          for (var t2 = e[0][0].length, r = { vertices: [], holes: [], dimensions: t2 }, i2 = 0, n = 0; n < e.length; n++) {
            for (var o = 0; o < e[n].length; o++)
              for (var a2 = 0; a2 < t2; a2++)
                r.vertices.push(e[n][o][a2]);
            0 < n && (i2 += e[n - 1].length, r.holes.push(i2));
          }
          return r;
        };
        var up_vec3 = [0, 0, 1];
        function buildPolygons(e, t2, r, i2) {
          var n, o, a2, s, l, u2 = i2.texcoord_index, c2 = i2.texcoord_scale, h = i2.texcoord_normalize, f2 = t2.vertex_elements;
          u2 && (h = h || 1, o = (n = _slicedToArray(c2 || default_uvs, 4))[0], a2 = n[1], s = n[2], l = n[3]);
          for (var d = 0, _ = e.length, p2 = 0; p2 < _; p2++) {
            var g, m, y, v, x2, b2 = t2.vertex_count, T2 = e[p2];
            u2 && (m = (g = _slicedToArray(Geo$1.findBoundingBox(T2), 4))[0], y = g[1], v = (s - o) / (g[2] - m), x2 = (l - a2) / (g[3] - y));
            for (var A2 = 0; A2 < T2.length; A2++)
              for (var E2 = T2[A2], w = 0; w < E2.length; w++) {
                var S2 = E2[w];
                r[0] = S2[0], r[1] = S2[1], u2 && (r[u2 + 0] = ((S2[0] - m) * v + o) * h, r[u2 + 1] = ((S2[1] - y) * x2 + a2) * h), t2.addVertex(r);
              }
            for (var k = triangulatePolygon(earcut_1.flatten(T2)), P2 = 0; P2 < k.length; P2++)
              f2.push(b2 + k[P2]);
            d += k.length / 3;
          }
          return d;
        }
        function buildExtrudedPolygons(e, t2, r, i2, n, o, a2, s, l) {
          var u2 = l.remove_tile_edges, c2 = l.tile_edge_tolerance, h = l.texcoord_index, f2 = l.texcoord_scale, d = l.texcoord_normalize, _ = l.winding, p2 = t2 + (i2 || 0), g = t2 + r;
          o[2] = g;
          var m, y, v, x2, b2, T2, A2 = buildPolygons(e, n, o, { texcoord_index: h, texcoord_scale: f2, texcoord_normalize: d }), E2 = n.vertex_elements, w = n.vertex_count;
          h && (d = d || 1, y = (m = _slicedToArray(f2 || default_uvs, 4))[0], v = m[1], x2 = m[2], T2 = [[y, b2 = m[3]], [y, v], [x2, v], [x2, b2]]);
          for (var S2 = e.length, k = 0; k < S2; k++)
            for (var P2 = e[k], R2 = 0; R2 < P2.length; R2++)
              for (var M2 = P2[R2], L2 = 0; L2 < M2.length - 1; L2++)
                if (!u2 || !outsideTile(M2[L2], M2[L2 + 1], c2)) {
                  var O2 = void 0, C2 = void 0, N2 = [[M2[C2 = "CCW" === _ ? (O2 = L2) + 1 : (O2 = L2 + 1, L2)][0], M2[C2][1], g], [M2[C2][0], M2[C2][1], p2], [M2[O2][0], M2[O2][1], p2], [M2[O2][0], M2[O2][1], g]], I = Vector$1.normalize([M2[C2][0] - M2[O2][0], M2[C2][1] - M2[O2][1], 0]), B2 = Vector$1.cross(up_vec3, I);
                  o[a2 + 0] = B2[0] * s, o[a2 + 1] = B2[1] * s, o[a2 + 2] = B2[2] * s;
                  for (var z2 = 0; z2 < N2.length; z2++)
                    o[0] = N2[z2][0], o[1] = N2[z2][1], o[2] = N2[z2][2], h && (o[h + 0] = T2[z2][0] * d, o[h + 1] = T2[z2][1] * d), n.addVertex(o);
                  E2.push(w + 0), E2.push(w + 1), E2.push(w + 2), E2.push(w + 2), E2.push(w + 3), E2.push(w + 0), w += 4, A2 += 2;
                }
          return A2;
        }
        function triangulatePolygon(e) {
          return earcut_1(e.vertices, e.holes, e.dimensions);
        }
        var shaderSrc_polygonsVertex = "uniform vec2 u_resolution;uniform vec3 u_map_position;uniform vec4 u_tile_origin;uniform float u_tile_proxy_depth;uniform float u_meters_per_pixel;uniform float u_device_pixel_ratio;uniform mat4 u_model;uniform mat4 u_modelView;uniform mat3 u_normalMatrix;uniform mat3 u_inverseNormalMatrix;attribute vec4 a_position;attribute vec4 a_color;\n#ifdef TANGRAM_NORMAL_ATTRIBUTE\nattribute vec3 a_normal;\n#define TANGRAM_NORMAL a_normal\n#else\n#define TANGRAM_NORMAL vec3(0., 0., 1.)\n#endif\n#ifdef TANGRAM_EXTRUDE_LINES\nattribute vec2 a_extrude;attribute vec2 a_offset;attribute vec2 a_scaling;uniform float u_v_scale_adjust;\n#endif\nvarying vec4 v_position;varying vec4 v_local_space_position;varying vec3 v_normal;varying vec4 v_color;varying vec4 v_world_position;\n#if defined(TANGRAM_TEXTURE_COORDS) || defined(TANGRAM_EXTRUDE_LINES)\nattribute vec2 a_texcoord;varying vec2 v_texcoord;\n#endif\n#ifdef TANGRAM_MODEL_POSITION_BASE_ZOOM_VARYING\nvarying vec4 v_modelpos_base_zoom;\n#endif\n#if defined(TANGRAM_LIGHTING_VERTEX)\nvarying vec4 v_lighting;\n#endif\n#define UNPACK_SCALING(x) (x / 1024.)\n#pragma tangram: camera\n#pragma tangram: material\n#pragma tangram: lighting\n#pragma tangram: raster\n#pragma tangram: global\nvoid main(){\n#pragma tangram: setup\n#ifdef TANGRAM_TEXTURE_COORDS\nv_texcoord=a_texcoord;\n#ifdef TANGRAM_EXTRUDE_LINES\nv_texcoord.y*=u_v_scale_adjust;\n#endif\n#endif\n#ifdef TANGRAM_MODEL_POSITION_BASE_ZOOM_VARYING\nv_modelpos_base_zoom=modelPositionBaseZoom();\n#endif\nvec4 position=vec4(a_position.xy,a_position.z/TANGRAM_HEIGHT_SCALE,1.);\n#ifdef TANGRAM_EXTRUDE_LINES\nvec2 extrude=a_extrude.xy;vec2 offset=a_offset.xy;float dz=clamp(u_map_position.z-u_tile_origin.z,0.,4.);dz+=step(1.,dz)*(1.-dz)+mix(0.,2.,clamp((dz-2.)/2.,0.,1.));float mdz=(dz-0.5)*2.;extrude-=extrude*UNPACK_SCALING(a_scaling.x)*mdz;float dwdz=UNPACK_SCALING(a_scaling.y);float sdwdz=sign(step(0.,dwdz)-0.5);offset-=offset*abs(dwdz)*((1.-step(0.,sdwdz))-(dz*-sdwdz));float ssz=exp2(-dz-(u_tile_origin.z-u_tile_origin.w));extrude*=ssz;offset*=ssz;\n#ifdef TANGRAM_BLOCK_WIDTH\nfloat width=1.;\n#pragma tangram: width\nextrude*=width;\n#endif\nposition.xy+=extrude+offset;\n#endif\nv_world_position=wrapWorldPosition(u_model*position);v_local_space_position=position;position=u_modelView*position;\n#pragma tangram: position\nv_position=position;v_normal=normalize(u_normalMatrix*TANGRAM_NORMAL);v_color=a_color;\n#if defined(TANGRAM_LIGHTING_VERTEX)\nvec3 normal=v_normal;\n#pragma tangram: normal\nv_lighting=calculateLighting(position.xyz-u_eye,normal,vec4(1.));\n#endif\ncameraProjection(position);applyLayerOrder(a_position.w+u_tile_proxy_depth+1.,position);\n#if defined(SNAP_TO_PIXEL_GRID)\nsnapToPixelGrid(position);\n#endif\ngl_Position=position;}", shaderSrc_polygonsFragment = "uniform vec2 u_resolution;uniform vec3 u_map_position;uniform vec4 u_tile_origin;uniform float u_meters_per_pixel;uniform float u_device_pixel_ratio;uniform mat3 u_normalMatrix;uniform mat3 u_inverseNormalMatrix;varying vec4 v_position;varying vec4 v_local_space_position;varying vec3 v_normal;varying vec4 v_color;varying vec4 v_world_position;\n#ifdef TANGRAM_EXTRUDE_LINES\nuniform bool u_has_line_texture;uniform sampler2D u_texture;uniform float u_texture_ratio;uniform vec4 u_dash_background_color;\n#endif\n#define TANGRAM_NORMAL v_normal\n#if defined(TANGRAM_TEXTURE_COORDS) || defined(TANGRAM_EXTRUDE_LINES)\nvarying vec2 v_texcoord;\n#endif\n#ifdef TANGRAM_MODEL_POSITION_BASE_ZOOM_VARYING\nvarying vec4 v_modelpos_base_zoom;\n#endif\n#if defined(TANGRAM_LIGHTING_VERTEX)\nvarying vec4 v_lighting;\n#endif\n#pragma tangram: camera\n#pragma tangram: material\n#pragma tangram: lighting\n#pragma tangram: raster\n#pragma tangram: global\n#pragma tangram: utils\nvoid main(void){\n#pragma tangram: setup\nvec4 color=v_color;vec3 normal=TANGRAM_NORMAL;\n#ifdef TANGRAM_CROP_BY_TILE\nif(isLocalSpacePixelOutsideTile(v_local_space_position,TANGRAM_TILE_SCALE.x)){discard;}\n#endif\n#ifdef TANGRAM_RASTER_TEXTURE_COLOR\ncolor*=sampleRaster();\n#endif\n#ifdef TANGRAM_EXTRUDE_LINES\nif(u_has_line_texture){vec2 _line_st=vec2(v_texcoord.x,fract(v_texcoord.y/u_texture_ratio));vec4 _line_color=texture2D(u_texture,_line_st);if(_line_color.a<TANGRAM_ALPHA_TEST){\n#if !defined(TANGRAM_BLEND_OVERLAY) && !defined(TANGRAM_BLEND_INLAY)\nif(u_dash_background_color.a==0.){discard;}color=u_dash_background_color;\n#else\ncolor=vec4(u_dash_background_color.rgb,color.a*step(TANGRAM_EPSILON,u_dash_background_color.a));\n#endif\n}else{color*=_line_color;}}\n#endif\n#ifdef TANGRAM_RASTER_TEXTURE_NORMAL\nnormal=normalize(sampleRaster().rgb*2.-1.);\n#endif\n#if defined(TANGRAM_LIGHTING_FRAGMENT) && defined(TANGRAM_MATERIAL_NORMAL_TEXTURE)\ncalculateNormal(normal);\n#endif\n#if !defined(TANGRAM_LIGHTING_VERTEX)\n#pragma tangram: normal\n#endif\n#pragma tangram: color\n#if defined(TANGRAM_LIGHTING_FRAGMENT)\ncolor=calculateLighting(v_position.xyz-u_eye,normal,color);\n#elif defined(TANGRAM_LIGHTING_VERTEX)\ncolor*=v_lighting;\n#endif\n#pragma tangram: filter\ngl_FragColor=color;}", Polygons = Object.create(Style);
        Object.assign(Polygons, { name: "polygons", built_in: true, vertex_shader_src: shaderSrc_polygonsVertex, fragment_shader_src: shaderSrc_polygonsFragment, selection: true, init: function() {
          Style.init.apply(this, arguments), this.defines.TANGRAM_NORMAL_ATTRIBUTE = true, this.defines.TANGRAM_LAYER_ORDER = true, this.defines.TANGRAM_CROP_BY_TILE = this.crop_by_tile, this.texcoords && (this.defines.TANGRAM_TEXTURE_COORDS = true);
        }, vertexLayoutForMeshVariant: function() {
          var e;
          return this.vertex_layout || (e = [{ name: "a_position", size: 4, type: gl$1.SHORT, normalized: false }, { name: "a_normal", size: 3, type: gl$1.BYTE, normalized: true }, { name: "a_color", size: 4, type: gl$1.UNSIGNED_BYTE, normalized: true }, { name: "a_selection_color", size: 4, type: gl$1.UNSIGNED_BYTE, normalized: true }], this.texcoords && e.push({ name: "a_texcoord", size: 2, type: gl$1.UNSIGNED_SHORT, normalized: true }), this.vertex_layout = new VertexLayout(e)), this.vertex_layout;
        }, _parseFeature: function(e, t2, r) {
          var i2 = this.feature_style;
          return i2.color = this.parseColor(t2.color, r), i2.color ? (i2.z = t2.z && StyleParser.evalCachedDistanceProperty(t2.z, r) || StyleParser.defaults.z, i2.z *= Geo$1.height_scale, i2.extrude = StyleParser.evalProperty(t2.extrude, r), i2.extrude && (true === i2.extrude ? (i2.height = void 0 !== e.properties.height ? e.properties.height : StyleParser.defaults.height, i2.min_height = void 0 !== e.properties.min_height ? e.properties.min_height : StyleParser.defaults.min_height) : "number" == typeof i2.extrude ? (i2.height = i2.extrude, i2.min_height = 0) : Array.isArray(i2.extrude) && (i2.min_height = i2.extrude[0], i2.height = i2.extrude[1]), i2.height *= Geo$1.height_scale, i2.min_height *= Geo$1.height_scale), i2.tile_edges = t2.tile_edges, i2) : null;
        }, _preprocess: function(e) {
          return e.color = StyleParser.createColorPropertyCache(e.color), e.z = StyleParser.createPropertyCache(e.z, StyleParser.parseUnits), e;
        }, makeVertexTemplate: function(e) {
          var t2 = 0;
          return this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = e.z || 0, this.vertex_template[t2++] = this.scaleOrder(e.order), this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 127, this.vertex_template[t2++] = 255 * e.color[0], this.vertex_template[t2++] = 255 * e.color[1], this.vertex_template[t2++] = 255 * e.color[2], this.vertex_template[t2++] = 255 * e.color[3], this.selection && (this.vertex_template[t2++] = 255 * e.selection_color[0], this.vertex_template[t2++] = 255 * e.selection_color[1], this.vertex_template[t2++] = 255 * e.selection_color[2], this.vertex_template[t2++] = 255 * e.selection_color[3]), this.texcoords && (this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0), this.vertex_template;
        }, buildPolygons: function(e, t2, r, i2) {
          var n = this.makeVertexTemplate(t2), o = { texcoord_index: this.vertex_layout.index.a_texcoord, texcoord_normalize: 65535, remove_tile_edges: !t2.tile_edges, tile_edge_tolerance: Geo$1.tile_scale * i2.tile.pad_scale * 4, winding: i2.winding };
          return t2.extrude && t2.height ? buildExtrudedPolygons(e, t2.z, t2.height, t2.min_height, r.vertex_data, n, this.vertex_layout.index.a_normal, 127, o) : buildPolygons(e, r.vertex_data, n, o);
        } });
        var zero_vec2 = [0, 0], CAP_TYPE = { butt: 0, square: 1, round: 2 }, JOIN_TYPE = { miter: 0, bevel: 1, round: 2 }, DEFAULT = { MITER_LIMIT: 3, TEXCOORD_NORMALIZE: 1, TEXCOORD_RATIO: 1, MIN_FAN_WIDTH: 5 }, v_scale_adjust = Geo$1.tile_scale, zero_v = [0, 0], one_v = [1, 0], mid_v = [0.5, 0];
        function buildPolylines(e, t2, r, i2, n) {
          var o, a2, s = n.closed_polygon, l = n.remove_tile_edges, u2 = n.tile_edge_tolerance, c2 = n.texcoord_index, h = (n.texcoord_scale, n.texcoord_width), f2 = n.texcoord_ratio, d = n.texcoord_normalize, _ = n.extrude_index, p2 = n.offset_index, g = n.join, m = n.cap, y = n.miter_limit, v = n.offset, x2 = n.crop_by_tile, b2 = m ? CAP_TYPE[m] : CAP_TYPE.butt, T2 = g ? JOIN_TYPE[g] : JOIN_TYPE.miter;
          T2 === JOIN_TYPE.miter && (o = (y = y || DEFAULT.MITER_LIMIT) * y), c2 && (d = d || DEFAULT.TEXCOORD_NORMALIZE, a2 = 1 / (h * (f2 = f2 || DEFAULT.TEXCOORD_RATIO) * v_scale_adjust));
          for (var A2 = { closed_polygon: s, remove_tile_edges: l, tile_edge_tolerance: u2, miter_len_sq: o, join_type: T2, cap_type: b2, vertex_data: r, vertex_template: i2, half_width: t2 / 2, extrude_index: _, offset_index: p2, v_scale: a2, texcoord_index: c2, texcoord_width: h, texcoord_normalize: d, offset: v, geom_count: 0, crop_by_tile: x2 }, E2 = 0; E2 < e.length; E2++)
            buildPolyline(e[E2], A2);
          if (A2.extra_lines)
            for (var w = 0; w < A2.extra_lines.length; w++)
              buildPolyline(A2.extra_lines[w], A2);
          return A2.geom_count;
        }
        function buildPolyline(e, t2) {
          if (!(e.length < 2)) {
            var r, i2, n = t2.join_type, o = t2.cap_type, a2 = t2.closed_polygon, s = t2.remove_tile_edges, l = t2.tile_edge_tolerance, u2 = t2.v_scale, c2 = t2.miter_len_sq, h = t2.crop_by_tile, f2 = null != t2.texcoord_index, d = 0;
            if (a2 && n === JOIN_TYPE.miter) {
              var _ = getTileBoundaryIndex(e);
              if (0 !== _) {
                var p2 = permuteLine(e, _);
                return t2.extra_lines = t2.extra_lines || [], void t2.extra_lines.push(p2);
              }
            }
            var g = 0, m = e.length - 1, y = 0;
            for (A2 = e[g], E2 = e[g + 1]; Vector$1.isEqual(A2, E2); )
              if (A2 = E2, E2 = e[++g + 1], y++, g === e.length - 1)
                return;
            for (; Vector$1.isEqual(e[m], e[m - 1]); )
              if (y++, 0 === --m)
                return;
            if (!(e.length < 2 + y))
              if (i2 = Vector$1.normalize(Vector$1.perp(A2, E2)), s && outsideTile(A2, E2, l)) {
                var v = getNextNonBoundarySegment(e, g, l);
                v && (t2.extra_lines = t2.extra_lines || [], t2.extra_lines.push(v));
              } else {
                a2 ? startPolygon(A2, r = Vector$1.normalize(Vector$1.perp(e[m - 1], A2)), i2, n, t2) : (!h && isCoordOutsideTile(A2) || (addCap(A2, d, i2, o, true, t2), f2 && o !== CAP_TYPE.butt && (d += 0.5 * u2 * t2.texcoord_width)), addVertex(A2, i2, i2, 1, d, t2, 1), addVertex(A2, i2, i2, 0, d, t2, -1)), f2 && (d += u2 * Vector$1.length(Vector$1.sub(E2, A2)));
                for (var x2 = g + 1; x2 < m; x2++) {
                  var b2 = x2, T2 = x2 + 1, A2 = e[b2], E2 = e[T2];
                  if (!Vector$1.isEqual(A2, E2)) {
                    if (s && outsideTile(A2, E2, l)) {
                      addVertex(A2, i2, i2, 1, d, t2, 1), addVertex(A2, i2, i2, 0, d, t2, -1), indexPairs(1, t2);
                      var w = getNextNonBoundarySegment(e, b2 + 1, l);
                      return void (w && (t2.extra_lines = t2.extra_lines || [], t2.extra_lines.push(w)));
                    }
                    r = i2, i2 = Vector$1.normalize(Vector$1.perp(A2, E2)), n === JOIN_TYPE.miter ? addMiter(d, A2, r, i2, c2, false, t2) : addJoin(n, d, A2, r, i2, false, t2), f2 && (d += u2 * Vector$1.length(Vector$1.sub(E2, A2)));
                  }
                }
                A2 = E2, r = i2, a2 ? endPolygon(A2, r, i2 = Vector$1.normalize(Vector$1.perp(A2, e[1])), n, d, t2) : (addVertex(A2, r, i2, 1, d, t2, 1), addVertex(A2, r, i2, 0, d, t2, -1), indexPairs(1, t2), !h && isCoordOutsideTile(A2) || addCap(A2, d, r, o, false, t2));
              }
          }
        }
        function getTileBoundaryIndex(e) {
          if (isCoordOutsideTile(e[0]))
            return 0;
          for (var t2 = 0; t2 < e.length; t2++) {
            if (isCoordOutsideTile(e[e.length - 1 - t2]))
              return e.length - 1 - t2;
          }
          return 0;
        }
        function getNextNonBoundarySegment(e, t2, r) {
          for (var i2 = t2; e[i2 + 1] && outsideTile(e[i2], e[i2 + 1], r); )
            i2++;
          return 2 <= e.length - i2 && e.slice(i2);
        }
        function startPolygon(e, t2, r, i2, n) {
          void 0 === i2 || isCoordOutsideTile(e) && !n.crop_by_tile ? (addVertex(e, r, r, 1, 0, n, 1), addVertex(e, r, r, 0, 0, n, -1)) : i2 === JOIN_TYPE.miter ? addMiter(0, e, t2, r, n.miter_len_sq, true, n) : addJoin(i2, 0, e, t2, r, true, n);
        }
        function endPolygon(e, t2, r, i2, n, o) {
          var a2;
          isCoordOutsideTile(e) && !o.crop_by_tile ? (addVertex(e, t2, t2, 1, n, o, 1), addVertex(e, t2, t2, 0, n, o, -1)) : (a2 = createMiterVec(t2, r), i2 === JOIN_TYPE.miter && Vector$1.lengthSq(a2) > o.miter_len_sq && (i2 = JOIN_TYPE.bevel), i2 === JOIN_TYPE.miter ? (addVertex(e, a2, t2, 1, n, o, 1), addVertex(e, a2, t2, 0, n, o, -1)) : (addVertex(e, t2, t2, 1, n, o, 1), addVertex(e, t2, t2, 0, n, o, -1))), indexPairs(1, o);
        }
        function createMiterVec(e, t2) {
          var r = Vector$1.normalize(Vector$1.add(e, t2)), i2 = 2 / (1 + Math.abs(Vector$1.dot(e, r)));
          return Vector$1.mult(r, i2 * i2);
        }
        function addMiter(e, t2, r, i2, n, o, a2) {
          var s = createMiterVec(r, i2);
          Vector$1.lengthSq(s) > n ? addJoin(JOIN_TYPE.bevel, e, t2, r, i2, o, a2) : (addVertex(t2, s, s, 1, e, a2, 1), addVertex(t2, s, s, 0, e, a2, -1), o || indexPairs(1, a2));
        }
        function addJoin(e, t2, r, i2, n, o, a2) {
          var s = createMiterVec(i2, n), l = 0 < n[0] * i2[1] - n[1] * i2[0];
          null != a2.texcoord_index && (zero_v[1] = t2, one_v[1] = t2), l ? (addVertex(r, s, s, 1, t2, a2, 1), addVertex(r, i2, s, 0, t2, a2, -1), o || indexPairs(1, a2), addFan(r, Vector$1.neg(i2), s, Vector$1.neg(n), s, zero_v, one_v, zero_v, false, e === JOIN_TYPE.bevel, a2), addVertex(r, s, s, 1, t2, a2, 1), addVertex(r, n, s, 0, t2, a2, -1)) : (addVertex(r, i2, s, 1, t2, a2, 1), addVertex(r, s, s, 0, t2, a2, -1), o || indexPairs(1, a2), addFan(r, i2, Vector$1.neg(s), n, s, one_v, zero_v, one_v, false, e === JOIN_TYPE.bevel, a2), addVertex(r, n, s, 1, t2, a2, 1), addVertex(r, s, s, 0, t2, a2, -1));
        }
        function indexPairs(e, t2) {
          for (var r = t2.vertex_data.vertex_elements, i2 = t2.vertex_data.vertex_count - 2 * e - 2, n = 0; n < e; n++)
            r.push(i2 + 2 * n + 2), r.push(i2 + 2 * n + 1), r.push(i2 + 2 * n), r.push(i2 + 2 * n + 2), r.push(i2 + 2 * n + 3), r.push(i2 + 2 * n + 1), t2.geom_count += 2;
        }
        function addVertex(e, t2, r, i2, n, o, a2) {
          var s = o.vertex_template, l = o.vertex_data;
          s[0] = e[0], s[1] = e[1];
          var u2 = o.half_width * a2;
          s[o.extrude_index + 0] = t2[0] * u2, s[o.extrude_index + 1] = t2[1] * u2, o.offset && (s[o.offset_index + 0] = r[0] * o.offset, s[o.offset_index + 1] = r[1] * o.offset), null != o.texcoord_index && (s[o.texcoord_index + 0] = i2 * o.texcoord_normalize, s[o.texcoord_index + 1] = n * o.texcoord_normalize), l.addVertex(s);
        }
        var uvCurr = [0, 0];
        function addFan(e, t2, r, i2, n, o, a2, s, l, u2, c2) {
          for (var h = t2[0] * i2[1] - t2[1] * i2[0], f2 = Vector$1.dot(t2, i2), d = Math.atan2(h, f2); d >= Math.PI; )
            d -= 2 * Math.PI;
          if (u2)
            _ = 1;
          else {
            var _ = trianglesPerArc(d, c2.half_width);
            if (_ < 1)
              return;
          }
          var p2 = c2.vertex_data.vertex_count, g = c2.vertex_data.vertex_elements;
          addVertex(e, r, n, a2[0], a2[1], c2, 1), addVertex(e, t2, n, o[0], o[1], c2, 1);
          var m, y, v = t2, x2 = null != c2.texcoord_index;
          x2 && (l ? m = Vector$1.sub(o, a2) : (uvCurr = Vector$1.copy(o), y = Vector$1.div(Vector$1.sub(s, o), _)));
          for (var b2, T2 = d / _, A2 = d < 0 ? -1 : 1, E2 = 0 < h ? (b2 = 2, 1) : (b2 = 1, 2), w = 0; w < _; w++)
            0 === w && d < 0 && (v = Vector$1.neg(v)), v = Vector$1.rot(v, T2), x2 && (l ? (m = Vector$1.rot(m, T2), uvCurr[0] = m[0] + a2[0], uvCurr[1] = m[1] * c2.texcoord_width * c2.v_scale + a2[1]) : uvCurr = Vector$1.add(uvCurr, y)), addVertex(e, v, n, uvCurr[0], uvCurr[1], c2, A2), g.push(p2 + w + b2), g.push(p2), g.push(p2 + w + E2);
        }
        function addCap(e, t2, r, i2, n, o) {
          var a2, s = Vector$1.neg(r), l = null != o.texcoord_index;
          switch (i2) {
            case CAP_TYPE.square:
              n ? (a2 = [r[1], -r[0]], addVertex(e, Vector$1.add(r, a2), r, 1, t2, o, 1), addVertex(e, Vector$1.add(s, a2), r, 0, t2, o, 1), l && (t2 += 0.5 * o.texcoord_width * o.v_scale), addVertex(e, r, r, 1, t2, o, 1), addVertex(e, s, r, 0, t2, o, 1)) : (a2 = [-r[1], r[0]], addVertex(e, r, r, 1, t2, o, 1), addVertex(e, s, r, 0, t2, o, 1), l && (t2 += 0.5 * o.texcoord_width * o.v_scale), addVertex(e, Vector$1.add(r, a2), r, 1, t2, o, 1), addVertex(e, Vector$1.add(s, a2), r, 0, t2, o, 1)), indexPairs(1, o);
              break;
            case CAP_TYPE.round:
              var u2, c2, h = zero_v, f2 = one_v, d = mid_v;
              n ? (u2 = r, c2 = s, l && (t2 += 0.5 * o.texcoord_width * o.v_scale, h = one_v, f2 = zero_v, d = mid_v)) : (u2 = s, c2 = r), l && (zero_v[1] = t2, one_v[1] = t2, mid_v[1] = t2), addFan(e, u2, zero_vec2, c2, r, h, d, f2, true, false, o);
              break;
            case CAP_TYPE.butt:
              return;
          }
        }
        function trianglesPerArc(e, t2) {
          e < 0 && (e = -e);
          var r = t2 > 2 * DEFAULT.MIN_FAN_WIDTH ? Math.log2(t2 / DEFAULT.MIN_FAN_WIDTH) : 1;
          return Math.ceil(e / Math.PI * r);
        }
        function permuteLine(e, t2) {
          for (var r = [], i2 = 0; i2 < e.length; i2++) {
            var n = (i2 + t2) % e.length;
            0 != n && r.push(e[n]);
          }
          return r.push(r[0]), r;
        }
        var default_dash_color = [255, 255, 255, 255], default_background_color = [0, 0, 0, 0];
        function renderDashArray(e) {
          var t2 = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, r = t2.dash_color || default_dash_color, i2 = t2.background_color || default_background_color, n = e, o = t2.scale || 1;
          n.length % 2 == 1 && Array.prototype.push.apply(n, n);
          for (var a2 = true, s = [], l = 0; l < n.length; l++) {
            for (var u2 = Math.floor(n[l] * o), c2 = 0; c2 < u2; c2++)
              Array.prototype.push.apply(s, a2 ? r : i2);
            a2 = !a2;
          }
          return { pixels: s = new Uint8Array(s), length: s.length / 4 };
        }
        var Lines = Object.create(Style);
        Lines.vertex_layouts = [[], []], Lines.dash_textures = {};
        var DASH_SCALE = 20;
        function buildPolylines$1(e, t2, r, i2, n, o) {
          for (var a2 = { closed: o, vertex_data: r, vertex_template: i2, half_width: t2 / 2, vertex_layout_index: n, geom_count: 0 }, s = 0, l = e.length; s < l; s++)
            buildPolyline$1(e[s], a2);
          return a2.geom_count;
        }
        function buildPolyline$1(e, t2) {
          if (!(e.length < 2)) {
            for (var r, i2, n = [e[0]], o = 0, a2 = [], s = [], l = 1, u2 = e.length; l < u2; l++) {
              e[l][0] === e[l - 1][0] && e[l][1] === e[l - 1][1] || (n.push(e[l]), r = Vector$1.sub(e[l], e[l - 1]), i2 = Vector$1.length(r), a2.push(r), s.push([o, o + i2]), o += i2);
            }
            if (!(n.length < 2)) {
              var c2 = 0, h = a2[a2.length - 1], f2 = a2[0], d = a2[1], _ = [0, 0];
              2 < n.length && (t2.closed && (_[0] = Vector$1.signedAngleBetween(h, f2)), _[1] = Vector$1.signedAngleBetween(f2, d));
              var p2 = n[0], g = s[0];
              t2.closed ? (addVertex$1(p2, t2, c2++, g, o, _, [h, f2]), addVertex$1(p2, t2, c2++, g, o, _, [h, f2])) : (addVertex$1(p2, t2, c2++, g, o, _, [f2, f2]), addVertex$1(p2, t2, c2++, g, o, _, [f2, f2]));
              for (var m = 1, y = n.length - 1; m < y; m++)
                p2 = n[m], h = a2[m - 1], f2 = a2[m], d = a2[m + 1], addVertex$1(p2, t2, c2++, g = s[m - 1], o, _, [h, f2]), addVertex$1(p2, t2, c2++, g, o, _, [h, f2]), triangulate(t2), g = s[m], _[0] = _[1], _[1] = m !== y - 1 ? Vector$1.signedAngleBetween(f2, d) : t2.closed ? Vector$1.signedAngleBetween(f2, a2[0]) : 0, addVertex$1(p2, t2, c2++, g, o, _, [h, f2]), addVertex$1(p2, t2, c2++, g, o, _, [h, f2]);
              p2 = n[n.length - 1], g = s[s.length - 1], f2 = a2[a2.length - 1], t2.closed ? (addVertex$1(p2, t2, c2++, g, o, _, [f2, a2[0]]), addVertex$1(p2, t2, c2++, g, o, _, [f2, a2[0]])) : (addVertex$1(p2, t2, c2++, g, o, _, [f2, f2]), addVertex$1(p2, t2, c2++, g, o, _, [f2, f2])), triangulate(t2);
            }
          }
        }
        function triangulate(e) {
          var t2 = e.vertex_data.vertex_elements, r = e.vertex_data.vertex_count - 4;
          t2.push(2 + r), t2.push(1 + r), t2.push(r), t2.push(2 + r), t2.push(3 + r), t2.push(1 + r), e.geom_count += 2;
        }
        Object.assign(Lines, { name: "lines", built_in: true, vertex_shader_src: shaderSrc_polygonsVertex, fragment_shader_src: shaderSrc_polygonsFragment, selection: true, init: function() {
          Style.init.apply(this, arguments), this.styles = this.styles || {}, this.defines.TANGRAM_LAYER_ORDER = true, this.defines.TANGRAM_EXTRUDE_LINES = true, this.defines.TANGRAM_CROP_BY_TILE = this.crop_by_tile, this.defines.TANGRAM_TEXTURE_COORDS = true, this.outline_feature_style = {}, this.inline_feature_style = this.feature_style;
        }, calcDistance: function(e, t2) {
          return e && StyleParser.evalCachedDistanceProperty(e, t2) || 0;
        }, calcDistanceNextZoom: function(e, t2) {
          t2.zoom++;
          var r = this.calcDistance(e, t2);
          return t2.zoom--, r;
        }, calcWidth: function(e, t2, r) {
          var i2 = this.calcDistance(e.width, r);
          if (!(i2 < 0)) {
            var n, o = e.next_width ? this.calcDistanceNextZoom(e.next_width, r) : i2 / 2;
            return 0 === i2 && 0 === o || o < 0 ? false : (t2.width_unscaled = i2, t2.next_width_unscaled = o, e.next_width ? (n = 0.5 * (i2 + (o *= 2)), t2.width = n * r.units_per_meter_overzoom, t2.width_scale = 1 - o / n) : (t2.width = i2 * r.units_per_meter_overzoom, t2.width_scale = 0), e.texcoords && (e.inline_texcoord_width ? t2.texcoord_width = e.inline_texcoord_width : t2.texcoord_width = (t2.width_unscaled || t2.next_width_unscaled) * r.units_per_meter_overzoom / r.tile.overzoom2), true);
          }
        }, calcOffset: function(e, t2, r) {
          var i2, n;
          e.offset_precalc ? (t2.offset = e.offset_precalc, t2.offset_scale = e.offset_scale_precalc) : e.offset ? (i2 = this.calcDistance(e.offset, r), e.next_offset ? (n = 2 * this.calcDistanceNextZoom(e.next_offset, r), Math.abs(i2) >= Math.abs(n) ? (t2.offset = i2 * r.units_per_meter_overzoom, t2.offset_scale = 0 !== i2 ? 1 - n / i2 : 0) : (t2.offset = n * r.units_per_meter_overzoom, t2.offset_scale = 0 != n ? -1 * (1 - i2 / n) : 0)) : (t2.offset = i2 * r.units_per_meter_overzoom, t2.offset_scale = 0)) : (t2.offset = 0, t2.offset_scale = 0), StyleParser.evalProperty(e.offset_reverse, r) && (t2.offset *= -1);
        }, _parseFeature: function(e, t2, r) {
          var i2, n, o = this.feature_style;
          if (false !== this.calcWidth(t2, o, r) && (this.calcOffset(t2, o, r), o.color = this.parseColor(t2.color, r), o.color))
            return o.variantKey = t2.variantKey, o.z = t2.z && StyleParser.evalCachedDistanceProperty(t2.z || 0, r) || StyleParser.defaults.z, o.height = e.properties.height || StyleParser.defaults.height, o.extrude = StyleParser.evalProperty(t2.extrude, r), o.extrude && ("number" == typeof o.extrude ? o.height = o.extrude : Array.isArray(o.extrude) && (o.height = o.extrude[1])), o.extrude && o.height && (o.z += o.height), o.z *= Geo$1.height_scale, o.height *= Geo$1.height_scale, o.cap = StyleParser.evalProperty(t2.cap, r), o.join = StyleParser.evalProperty(t2.join, r), o.miter_limit = StyleParser.evalProperty(t2.miter_limit, r), o.tile_edges = t2.tile_edges, o.outline = o.outline || { width: {}, next_width: {}, preprocessed: true }, t2.outline && false !== t2.outline.visible && t2.outline.color && t2.outline.width ? (i2 = 2 * this.calcDistance(t2.outline.width, r), n = 2 * this.calcDistanceNextZoom(t2.outline.next_width, r), 0 == i2 && 0 == n || i2 < 0 || n < 0 ? (o.outline.width.value = null, o.outline.next_width.value = null, o.outline.color = null, o.outline.inline_texcoord_width = null, o.outline.texcoords = false) : (o.outline.width.value = i2 + o.width_unscaled, o.outline.next_width.value = n + o.next_width_unscaled, o.outline.inline_texcoord_width = o.texcoord_width, o.outline.offset_precalc = o.offset, o.outline.offset_scale_precalc = o.offset_scale, o.outline.color = t2.outline.color, o.outline.cap = t2.outline.cap, o.outline.join = t2.outline.join, o.outline.miter_limit = t2.outline.miter_limit, o.outline.texcoords = t2.outline.texcoords, o.outline.style = t2.outline.style, o.outline.variantKey = t2.outline.variantKey, t2.outline.order ? o.outline.order = this.parseOrder(t2.outline.order, r) : o.outline.order = o.order, o.outline.order > o.order && (o.outline.order = o.order), o.outline.order -= 0.5, o.outline.variant_order = 0)) : (o.outline.width.value = null, o.outline.next_width.value = null, o.outline.color = null, o.outline.inline_texcoord_width = null), o;
        }, _preprocess: function(e, t2) {
          var r, i2 = this.sources[t2] ? this.sources[t2].config.uid : "";
          return e.color = StyleParser.createColorPropertyCache(e.color), e.width = StyleParser.createPropertyCache(e.width, StyleParser.parseUnits), e.width && e.width.type !== StyleParser.CACHE_TYPE.STATIC && (e.next_width = StyleParser.createPropertyCache(e.width, StyleParser.parseUnits)), e.offset = e.offset && StyleParser.createPropertyCache(e.offset, StyleParser.parseUnits), e.offset && e.offset.type !== StyleParser.CACHE_TYPE.STATIC && (e.next_offset = StyleParser.createPropertyCache(e.offset, StyleParser.parseUnits)), e.z = StyleParser.createPropertyCache(e.z, StyleParser.parseUnits), e.dash = void 0 !== e.dash ? e.dash : this.dash, e.dash_key = e.dash && this.dashTextureKey(e.dash, i2), e.dash_background_color = void 0 !== e.dash_background_color ? e.dash_background_color : this.dash_background_color, e.dash_background_color = e.dash_background_color && StyleParser.parseColor(e.dash_background_color), e.texture_merged = e.dash_key || (void 0 !== e.texture ? e.texture : this.texture), e.texcoords = this.texcoords || e.texture_merged ? 1 : 0, this.addMeshVariantForDraw(this.base, e), e.outline && (e.outline.style = e.outline.style || this.name, e.outline.color = StyleParser.createColorPropertyCache(e.outline.color), e.outline.width = StyleParser.createPropertyCache(e.outline.width, StyleParser.parseUnits), e.outline.next_width = StyleParser.createPropertyCache(e.outline.width, StyleParser.parseUnits), e.outline.cap = e.outline.cap || e.cap, e.outline.join = e.outline.join || e.join, e.outline.miter_limit = e.outline.miter_limit || e.miter_limit, e.outline.offset = e.offset, (r = this.styles[e.outline.style]) ? (e.outline.dash = void 0 !== e.outline.dash ? e.outline.dash : r.dash, e.outline.texture = void 0 !== e.outline.texture ? e.outline.texture : r.texture, null != e.outline.dash ? (e.outline.dash_key = e.outline.dash && this.dashTextureKey(e.outline.dash, i2), e.outline.texture_merged = e.outline.dash_key) : null === e.outline.dash || null != e.outline.texture ? (e.outline.dash_key = null, e.outline.texture_merged = e.outline.texture) : (e.outline.dash = e.dash, e.outline.dash_key = e.outline.dash && this.dashTextureKey(e.outline.dash, i2), e.outline.texture_merged = e.outline.dash_key), e.outline.dash_background_color = void 0 !== e.outline.dash_background_color ? e.outline.dash_background_color : r.dash_background_color, e.outline.dash_background_color = void 0 !== e.outline.dash_background_color ? e.outline.dash_background_color : e.dash_background_color, e.outline.dash_background_color = e.outline.dash_background_color && StyleParser.parseColor(e.outline.dash_background_color), e.outline.texcoords = r.texcoords || e.outline.texture_merged ? 1 : 0, this.addMeshVariantForDraw(this.base, e.outline)) : (log({ level: "warn", once: true }, "Layer '".concat(e.layers[e.layers.length - 1], "': ") + "line 'outline' specifies non-existent draw style '".concat(e.outline.style, "' (or maybe the style is ") + "defined but is missing a 'base' or has another error), skipping outlines in layer"), e.outline = null)), e;
        }, dashTextureKey: function(e, t2) {
          return "__dash_" + t2 + "_" + this.scene_id + "_" + JSON.stringify(e);
        }, getDashTexture: function(e, t2) {
          var r, i2 = this.dashTextureKey(e, this.sources[t2].config.uid);
          null == Lines.dash_textures[i2] && (Lines.dash_textures[i2] = true, r = renderDashArray(e, { scale: DASH_SCALE }), this.textureManager.create(this.gl, i2, { data: r.pixels, height: r.length, width: 1, filtering: "nearest" }));
        }, endData: function(a2) {
          var s = this;
          return Style.endData.call(this, a2).then(function(n) {
            if (n) {
              n.uniforms.u_has_line_texture = false, n.uniforms.u_texture = s.textureManager.default, n.uniforms.u_v_scale_adjust = Geo$1.tile_scale;
              var o = [];
              for (var e in n.meshes)
                !function(e2) {
                  var r, t2, i2 = n.meshes[e2].variant;
                  i2.texture && ((r = n.meshes[e2].uniforms = n.meshes[e2].uniforms || {}).u_has_line_texture = true, r.u_texture = i2.texture, r.u_texture_ratio = 1, i2.dash && (r.u_v_scale_adjust = Geo$1.tile_scale * DASH_SCALE, r.u_dash_background_color = i2.dash_background_color || [0, 0, 0, 0]), i2.dash_key && null == Lines.dash_textures[i2.dash_key] && (Lines.dash_textures[i2.dash_key] = true, WorkerBroker.postMessage(s.main_thread_target + ".getDashTexture", i2.dash, a2.source)), null == s.textureManager.textures[i2.texture] ? o.push(s.textureManager.syncTexturesToWorker([i2.texture]).then(function(e3) {
                    var t3 = e3[i2.texture];
                    t3 && (r.u_texture_ratio = t3.height / t3.width);
                  })) : (t2 = s.textureManager.textures[i2.texture], r.u_texture_ratio = t2.height / t2.width));
                }(e);
              return a2.mesh_data[s.name] = n, Promise.all(o).then(function() {
                return n;
              });
            }
            return n;
          });
        }, computeVariantForDraw: function(e) {
          var t2 = e.offset ? 1 : 0;
          return e.dash_key && (t2 += e.dash_key, e.dash_background_color && (t2 += e.dash_background_color)), e.texture_merged && (t2 += e.texture_merged), t2 = hashString(t2 += "/" + e.texcoords), { key: e.variantKey = t2, order: e.variant_order, offset: e.offset ? 1 : 0, texcoords: e.texcoords, texture: e.texture_merged, dash: e.dash, dash_key: e.dash_key, dash_background_color: e.dash_background_color };
        }, vertexLayoutForMeshVariant: function(e) {
          var t2;
          return null == Lines.vertex_layouts[e.key] && (t2 = [{ name: "a_position", size: 4, type: gl$1.SHORT, normalized: false }, { name: "a_extrude", size: 2, type: gl$1.SHORT, normalized: false }, { name: "a_offset", size: 2, type: gl$1.SHORT, normalized: false, static: e.offset ? null : [0, 0] }, { name: "a_scaling", size: 2, type: gl$1.SHORT, normalized: false }, { name: "a_texcoord", size: 2, type: gl$1.UNSIGNED_SHORT, normalized: true, static: e.texcoords ? null : [0, 0] }, { name: "a_color", size: 4, type: gl$1.UNSIGNED_BYTE, normalized: true }, { name: "a_selection_color", size: 4, type: gl$1.UNSIGNED_BYTE, normalized: true }], Lines.vertex_layouts[e.key] = new VertexLayout(t2)), Lines.vertex_layouts[e.key];
        }, makeVertexTemplate: function(e, t2) {
          var r = 0;
          return this.vertex_template[r++] = 0, this.vertex_template[r++] = 0, this.vertex_template[r++] = e.z || 0, this.vertex_template[r++] = this.scaleOrder(e.order), this.vertex_template[r++] = 0, this.vertex_template[r++] = 0, t2.variant.offset && (this.vertex_template[r++] = 0, this.vertex_template[r++] = 0), this.vertex_template[r++] = 1024 * e.width_scale, this.vertex_template[r++] = 1024 * e.offset_scale, t2.variant.texcoords && (this.vertex_template[r++] = 0, this.vertex_template[r++] = 0), this.vertex_template[r++] = 255 * e.color[0], this.vertex_template[r++] = 255 * e.color[1], this.vertex_template[r++] = 255 * e.color[2], this.vertex_template[r++] = 255 * e.color[3], this.selection && (this.vertex_template[r++] = 255 * e.selection_color[0], this.vertex_template[r++] = 255 * e.selection_color[1], this.vertex_template[r++] = 255 * e.selection_color[2], this.vertex_template[r++] = 255 * e.selection_color[3]), this.vertex_template;
        }, buildLines: function(e, t2, r, i2, n) {
          var o;
          this.feature_style = this.outline_feature_style, !t2.outline || null == t2.outline.color || null == t2.outline.width.value || (o = this.styles[t2.outline.style]) && o.addFeature(i2.feature, t2.outline, i2), this.feature_style = this.inline_feature_style;
          var a2 = r.vertex_data, s = a2.vertex_layout, l = this.makeVertexTemplate(t2, r);
          return buildPolylines(e, t2.width, a2, l, { cap: t2.cap, join: t2.join, miter_limit: t2.miter_limit, extrude_index: s.index.a_extrude, offset_index: s.index.a_offset, texcoord_index: s.index.a_texcoord, texcoord_width: t2.texcoord_width, texcoord_normalize: 65535, closed_polygon: n && n.closed_polygon, remove_tile_edges: !t2.tile_edges && n && n.remove_tile_edges, tile_edge_tolerance: Geo$1.tile_scale * i2.tile.pad_scale * 2, offset: t2.offset, crop_by_tile: this.crop_by_tile });
        }, buildPolygons: function(e, t2, r, i2) {
          for (var n = 0, o = 0; o < e.length; o++)
            n += this.buildLines(e[o], t2, r, i2, { closed_polygon: true, remove_tile_edges: !this.crop_by_tile });
          return n;
        } });
        var TEX_COORDS = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
        function addVertex$1(e, t2, r, i2, n, o, a2) {
          var s, l = t2.vertex_template, u2 = t2.vertex_data;
          setAttribute(t2, "a_position", e), setAttribute(t2, "a_width", t2.half_width), t2.vertex_layout_index.a_barycentric && ((s = [0, 0, 0])[r % 3] = 1, setAttribute(t2, "a_barycentric", s)), setAttribute(t2, "a_tangents", a2[0].concat(a2[1])), setAttribute(t2, "a_segment", i2), setAttribute(t2, "a_texcoord", TEX_COORDS[r % 4]), setAttribute(t2, "a_length", n), setAttribute(t2, "a_closed", t2.closed ? 1 : 0), setAttribute(t2, "a_angles", o), u2.addVertex(l);
        }
        function setAttribute(e, t2, r) {
          var i2 = r.length, n = e.vertex_template, o = e.vertex_layout_index[t2], a2 = 0;
          if (i2)
            for (; a2 !== i2; )
              n[o + a2] = r[a2], a2++;
          else
            n[o + a2] = r;
        }
        function buildPatternBuffer(e, a2) {
          for (var s = e.reduce(function(e2, t3) {
            return e2 + t3;
          }), t2 = 0, l = [], r = 0, i2 = e.length; r <= i2; r += 2) {
            var n = Math.max(1e-4, e[r % i2]), o = Math.max(1e-4, e[(r + 1) % i2]);
            l.push(t2, t2 + n), t2 += n + o;
          }
          for (var u2 = new Uint8Array(4 * a2), c2 = 0, h = 0; h < a2; h++)
            !function(e2) {
              var t3 = s * e2 / (a2 - 1), r2 = minIdx(l.map(function(e3) {
                return Math.abs(e3 - t3);
              })), i3 = void 0, n2 = void 0, o2 = void 0, o2 = r2 % 2 == 0 ? (i3 = t3 <= l[r2] ? 1 : 0, n2 = l[r2], l[r2 + 1]) : (i3 = t3 > l[r2] ? 2 : 0, n2 = l[r2 - 1], l[r2]);
              u2[c2++] = l[r2], u2[c2++] = i3, u2[c2++] = n2, u2[c2++] = o2;
            }(h);
          return u2;
        }
        function minIdx(e) {
          for (var t2 = e[0], r = 0, i2 = 1, n = e.length; i2 < n; i2++)
            e[i2] < t2 && (t2 = e[r = i2]);
          return r;
        }
        var vertex_shader_src = "uniform vec2 u_resolution;uniform vec4 u_tile_origin;uniform float u_tile_proxy_depth;uniform float u_meters_per_pixel;uniform float u_device_pixel_ratio;uniform sampler2D u_uniforms;uniform mat4 u_model;uniform mat4 u_modelView;uniform mat3 u_normalMatrix;uniform mat3 u_inverseNormalMatrix;uniform vec3 u_map_position;uniform float u_antialias;uniform vec2 u_linecaps;uniform float u_linejoin;uniform float u_miter_limit;uniform float u_dash_index;uniform vec2 u_dash_caps;uniform float u_dash_phase;uniform float u_dash_period;attribute vec4 a_position;attribute vec4 a_color;attribute float a_width;\n#ifdef TANGRAM_DEBUG_TRIANGLES\nattribute vec3 a_barycentric;\n#endif\nattribute vec2 a_normal;attribute float a_length;attribute vec2 a_segment;attribute vec2 a_texcoord;attribute vec2 a_angles;attribute vec4 a_tangents;attribute float a_closed;varying vec4 v_position;varying vec4 v_local_space_position;varying vec3 v_normal;varying vec4 v_color;varying vec4 v_world_position;\n#ifdef TANGRAM_DEBUG_TRIANGLES\nvarying vec3 v_barycentric;\n#endif\nvarying vec2 v_segment;varying vec2 v_angles;varying vec2 v_texcoord;varying vec2 v_distances;varying vec2 v_miter;varying float v_length;varying float v_linewidth_and_closed;varying float v_joinIndicator;\n#define TANGRAM_NORMAL vec3(0., 0., 1.)\n#ifdef TANGRAM_MODEL_POSITION_BASE_ZOOM_VARYING\nvarying vec4 v_modelpos_base_zoom;\n#endif\n#if defined(TANGRAM_LIGHTING_VERTEX)\nvarying vec4 v_lighting;\n#endif\n#ifndef TANGRAM_HEIGHT_SCALE\nfloat TANGRAM_HEIGHT_SCALE=16.0;\n#endif\n#define UNPACK_SCALING(x) (x / 1024.)\n#pragma tangram: camera\n#pragma tangram: material\n#pragma tangram: lighting\n#pragma tangram: global\nconst float PI=3.141592653589793;const float THETA=15.0*PI/180.0;float cross(in vec2 v1,in vec2 v2){return v1.x*v2.y-v1.y*v2.x;}float signed_distance(in vec2 v1,in vec2 v2,in vec2 v3){return cross(v2-v1,v1-v3)/length(v2-v1);}void rotate(in vec2 v,in float angle,out vec2 result){float cosine=cos(angle);float sine=sin(angle);result=vec2(cosine*v.x-sine*v.y,sine*v.x+cosine*v.y);}void main(){\n#pragma tangram: setup\n#ifdef TANGRAM_MODEL_POSITION_BASE_ZOOM_VARYING\nv_modelpos_base_zoom=modelPositionBaseZoom();\n#endif\nfloat linewidth=a_width*2.0;v_angles=a_angles;v_segment=a_segment;v_color=a_color;v_length=a_length;v_texcoord=a_texcoord;\n#ifdef TANGRAM_DEBUG_TRIANGLES\nv_barycentric=a_barycentric;\n#endif\nv_color.a=min(linewidth,v_color.a);linewidth=max(linewidth,1.0);linewidth/=exp2(u_map_position.z-u_tile_origin.w);v_linewidth_and_closed=linewidth*(a_closed>0.0 ?-1.0 : 1.0);if(v_color.a<=0.0){gl_Position=vec4(0.0,0.0,0.0,1.0);return;}float width=ceil(1.25*u_antialias+linewidth)/2.0;vec2 t1=normalize(a_tangents.xy);vec2 t2=normalize(a_tangents.zw);float u=a_texcoord.x;u*=-1.0;float v=a_texcoord.y;vec4 position=vec4(a_position.xy,a_position.z/TANGRAM_HEIGHT_SCALE,1.0);if(t1!=t2){float angle=a_texcoord.x==1.0 ? a_angles.x : a_angles.y;vec2 t=normalize(t1+t2);vec2 o=vec2(+t.y,-t.x);float segmentLength=a_segment.y-a_segment.x;float magnitude=width/cos(angle/2.0);float sqMagnitude=magnitude*magnitude;float seg1SqMagnitude=dot(a_tangents.xy,a_tangents.xy);float seg2SqMagnitude=dot(a_tangents.zw,a_tangents.zw);if((abs(magnitude)>linewidth)&&(sqMagnitude>=min(seg1SqMagnitude,seg2SqMagnitude))){if(u==1.0){o=vec2(-t2.y,+t2.x);}else{o=vec2(-t1.y,+t1.x);}magnitude=width;angle=0.0;v_angles.x=0.0;v_angles.y=0.0;}if(u_dash_index>0.0){if((abs(angle)>THETA)){position.xy+=v*width*o/cos(angle/2.0);float s=sign(angle);if(angle<0.0){if(u==+1.0){u=v_segment.y+v*width*tan(angle/2.0);if(v==1.0){position.xy-=2.0*width*t1/sin(angle);u-=2.0*width/sin(angle);}}else{u=v_segment.x-v*width*tan(angle/2.0);if(v==1.0){position.xy+=2.0*width*t2/sin(angle);u+=2.0*width/sin(angle);}}}else{if(u==+1.0){u=v_segment.y+v*width*tan(angle/2.0);if(v==-1.0){position.xy+=2.0*width*t1/sin(angle);u+=2.0*width/sin(angle);}}else{u=v_segment.x-v*width*tan(angle/2.0);if(v==-1.0){position.xy-=2.0*width*t2/sin(angle);u-=2.0*width/sin(angle);}}}}else{position.xy+=v*width*o/cos(angle/2.0);if(u==+1.0){u=v_segment.y;}else{u=v_segment.x;}}}else{position.xy+=v*o*magnitude;if(u==+1.0){u=v_segment.y+v*width*tan(angle/2.0);}else{u=v_segment.x-v*width*tan(angle/2.0);}}v_joinIndicator=(segmentLength+v*width*tan(angle/2.0))/segmentLength;}else{v_joinIndicator=-1.0;vec2 o=vec2(+t1.y,-t1.x);position.xy+=v*width*o;if(u==-1.0){u=v_segment.x-width;position.xy-=width*t1;}else{u=v_segment.y+width;position.xy+=width*t2;}}vec2 t;vec2 curr=a_position.xy;if(a_texcoord.x>=0.0){vec2 next=curr+t2*(v_segment.y-v_segment.x);rotate(t1,+a_angles.x/2.0,t);v_miter.x=signed_distance(curr,curr+t,position.xy);rotate(t2,+a_angles.y/2.0,t);v_miter.y=signed_distance(next,next+t,position.xy);}else{vec2 prev=curr-t1*(v_segment.y-v_segment.x);rotate(t1,-a_angles.x/2.0,t);v_miter.x=signed_distance(prev,prev+t,position.xy);rotate(t2,-a_angles.y/2.0,t);v_miter.y=signed_distance(curr,curr+t,position.xy);}v_distances=vec2(u,v*width);v_world_position=wrapWorldPosition(u_model*position);v_local_space_position=position;position=u_modelView*position;\n#pragma tangram: position\nv_position=position;v_normal=normalize(u_normalMatrix*TANGRAM_NORMAL);\n#if defined(TANGRAM_LIGHTING_VERTEX)\nvec3 normal=v_normal;\n#pragma tangram: normal\nv_lighting=calculateLighting(position.xyz-u_eye,normal,vec4(1.));\n#endif\ncameraProjection(position);\n#ifdef TANGRAM_LAYER_ORDER\napplyLayerOrder(a_position.w+u_tile_proxy_depth+1.,position);\n#endif\ngl_Position=position;}", fragment_shader_src = "uniform vec2 u_resolution;uniform vec4 u_tile_origin;uniform float u_meters_per_pixel;uniform float u_device_pixel_ratio;uniform mat3 u_normalMatrix;uniform mat3 u_inverseNormalMatrix;uniform sampler2D u_dash_atlas;uniform float u_antialias;uniform vec2 u_linecaps;uniform float u_linejoin;uniform float u_miter_limit;uniform float u_dash_phase;uniform float u_dash_period;uniform float u_dash_index;uniform vec2 u_dash_caps;varying vec4 v_position;varying vec4 v_local_space_position;varying vec3 v_normal;varying vec4 v_color;varying vec4 v_world_position;\n#ifdef TANGRAM_DEBUG_TRIANGLES\nvarying vec3 v_barycentric;\n#endif\nvarying vec2 v_segment;varying vec2 v_angles;varying vec2 v_texcoord;varying vec2 v_distances;varying vec2 v_miter;varying float v_length;varying float v_linewidth_and_closed;varying float v_joinIndicator;\n#define TANGRAM_NORMAL v_normal\n#ifdef TANGRAM_MODEL_POSITION_BASE_ZOOM_VARYING\nvarying vec4 v_modelpos_base_zoom;\n#endif\n#if defined(TANGRAM_LIGHTING_VERTEX)\nvarying vec4 v_lighting;\n#endif\n#pragma tangram: camera\n#pragma tangram: material\n#pragma tangram: lighting\n#pragma tangram: global\n#pragma tangram: utils\nconst float PI=3.141592653589793;const float HALF_PI=PI/2.0;const float THETA=15.0*PI/180.0;/***Compute distance to cap.*@param{int}type The Type of the cap(see CAP_TYPE in pattern_lines)*@param{float}dx The distance of the pixel from the beginning of the line(not straight distance,but along the legs)*@param{float}dy The distance of the pixel from the midline(see v_distances in vertex shader,aka ±1*half_line_width)*@param{float}aa_radius The distance from the mid-line from where antialiasing starts.*For example for a linewidth 10px width and 2px filter radius it is 10px/2-2px=3px.*@return{float}distance*/float cap(int type,float dx,float dy,float aa_radius){float dist=0.0;dx=abs(dx);dy=abs(dy);if(type==1)dist=sqrt(dx*dx+dy*dy);else if(type==3)dist=(dx+abs(dy));else if(type==2)dist=max(abs(dy),(aa_radius+dx-abs(dy)));else if(type==4)dist=max(dx,dy);else if(type==5)dist=max(dx+aa_radius,dy);return dist;}/***Compute distance to join.*@param{int}type The type of the join(see JOIN_TYPE in pattern_lines)*@param{vec2}segment Interpolated a_segment attribute from the vertex shader*@param{vec2}texcoord Pair of u/v coordinates to identify the 4 different extruded points of the segment.*@param{vec2}distances 2 component vector where:*x is the distance of the pixel from the beginning of the line(along the legs)*y is the  distance of the pixel from the midline(see v_distances in vertex shader,±1*half_line_width)*@param{vec2}miter Miter point coordiante*@param{float}miter_limit The miter limit*@param{float}linewidth The width of the line*@return{float}computed distance*/float join(in int type,in vec2 segment,in vec2 texcoord,in vec2 distances,in vec2 miter,in float miter_limit,in float linewidth){float dx=distances.x;float result=abs(distances.y);if((dx<segment.x)||(dx>segment.y)){if(type==1){float s=dx<segment.x ? segment.x : segment.y;result=max(result,length(distances-vec2(s,0.0)));}else{float m=abs(texcoord.x>=0.0 ? miter.x : miter.y);if(type==2){result=max(result,m);}else if(type==0){result=max(result,m-miter_limit*linewidth/2.0);}}}return result;}void main(void){\n#pragma tangram: setup\nvec4 color=v_color;vec3 normal=TANGRAM_NORMAL;\n#ifdef TANGRAM_CROP_BY_TILE\nif(isLocalSpacePixelOutsideTile(v_local_space_position,TANGRAM_TILE_SCALE.x)){discard;}\n#endif\n#if defined(TANGRAM_LIGHTING_FRAGMENT) && defined(TANGRAM_MATERIAL_NORMAL_TEXTURE)\ncalculateNormal(normal);\n#endif\n#if !defined(TANGRAM_LIGHTING_VERTEX)\n#pragma tangram: normal\n#endif\n#pragma tangram: color\n#if defined(TANGRAM_LIGHTING_FRAGMENT)\ncolor=calculateLighting(v_position.xyz-u_eye,normal,color);\n#elif defined(TANGRAM_LIGHTING_VERTEX)\ncolor*=v_lighting;\n#endif\n#pragma tangram: filter\nif(v_color.a<=0.0){discard;}bool solid=(u_dash_index==0.0);bool closed=v_linewidth_and_closed<0.0;float dx=v_distances.x;float dy=v_distances.y;float linewidth=abs(v_linewidth_and_closed);float aa_radius=linewidth/2.0-u_antialias;float dist=0.0;vec2 linecaps=u_linecaps;vec2 dash_caps=u_dash_caps;float line_start=0.0;float line_stop=v_length;if(solid){dist=abs(dy);bool potentialCap=!closed&&v_joinIndicator<0.0;if(potentialCap&&dx<line_start){dist=cap(int(u_linecaps.x),abs(dx),abs(dy),aa_radius);}else if(potentialCap&&dx>line_stop){dist=cap(int(u_linecaps.y),abs(dx)-line_stop,abs(dy),aa_radius);}else{dist=join(int(u_linejoin),v_segment,v_texcoord,v_distances,v_miter,u_miter_limit,linewidth);}}else{float segment_start=v_segment.x;float segment_stop=v_segment.y;float segment_center=(segment_start+segment_stop)/2.0;float freq=u_dash_period*linewidth;float dash_phase=u_dash_phase-1e-5;float u=mod(dx+dash_phase*linewidth,freq);vec4 tex=texture2D(u_dash_atlas,vec2(u/freq,u_dash_index));float dash_center=float(tex.x)*255.0*linewidth;float dash_type=floor(float(tex.y)*255.0+0.5);float _start=float(tex.z)*255.0*linewidth;float _stop=float(tex.a)*255.0*linewidth;float dash_start=dx-u+_start;float dash_stop=dx-u+_stop;if((dash_stop<segment_start)&&(dash_caps.x!=5.0)){float u=mod(segment_start+dash_phase*linewidth,freq);vec4 tex=texture2D(u_dash_atlas,vec2(u/freq,u_dash_index));dash_center=float(tex.x)*255.0*linewidth;float _start=float(tex.z)*255.0*linewidth;float _stop=float(tex.a)*255.0*linewidth;dash_start=segment_start-u+_start;dash_stop=segment_start-u+_stop;}else if((dash_start>segment_stop)&&(dash_caps.y!=5.0)){float u=mod(segment_stop+dash_phase*linewidth,freq);vec4 tex=texture2D(u_dash_atlas,vec2(u/freq,u_dash_index));dash_center=float(tex.x)*255.0*linewidth;float _start=float(tex.z)*255.0*linewidth;float _stop=float(tex.a)*255.0*linewidth;dash_start=segment_stop-u+_start;dash_stop=segment_stop-u+_stop;}bool discontinuous=((dx<segment_center)&&abs(v_angles.x)>THETA)||((dx>=segment_center)&&abs(v_angles.y)>THETA);float d_join=join(int(u_linejoin),v_segment,v_texcoord,v_distances,v_miter,u_miter_limit,linewidth);if(closed){line_start+=linewidth/2.0;line_stop-=linewidth/2.0;}if(dash_stop<=line_start){discard;}if(dash_start>=line_stop){discard;}if(discontinuous){if((dash_start>segment_stop)){discard;}if((dash_stop<segment_start)){discard;}if(dash_caps.x==1.0){if((u>_stop)&&(dash_stop>segment_stop)&&(abs(v_angles.y)<HALF_PI)){discard;}}if(dash_caps.y==1.0){if((u<_start)&&(dash_start<segment_start)&&(abs(v_angles.x)<HALF_PI)){discard;}}if((dash_caps.x!=1.0)&&(dash_caps.x!=5.0)){if((dash_start<segment_start)&&(abs(v_angles.x)<HALF_PI)){float a=v_angles.x/2.0;float cos_a=cos(a);float sin_a=sin(a);float x=(segment_start-dx)*cos_a-dy*sin_a;float y=(segment_start-dx)*sin_a+dy*cos_a;if(x>0.0){discard;}dash_caps.x=4.0;}}if((dash_caps.y!=1.0)&&(dash_caps.y!=5.0)){if((dash_stop>segment_stop)&&(abs(v_angles.y)<HALF_PI)){float a=v_angles.y/2.0;float cos_a=cos(a);float sin_a=sin(a);float x=(dx-segment_stop)*cos_a-dy*sin_a;float y=(dx-segment_stop)*sin_a+dy*cos_a;if(x>0.0){discard;}dash_caps.y=4.0;}}}if((dx<line_start)&&(dash_start<=line_start)&&(dash_stop>line_start)){dist=cap(int(linecaps.x),dx-line_start,dy,aa_radius);}else if((dx>line_stop)&&(dash_stop>line_stop)&&(dash_start<line_stop)){dist=cap(int(linecaps.y),dx-line_stop,dy,aa_radius);}else if(dash_type==1.0){dist=cap(int(dash_caps.x),abs(dash_center-u),dy,aa_radius);if((dx>line_start)&&(dx<line_stop)){dist=max(dist,d_join);}}else if(dash_type==0.0){dist=abs(dy);}else if(dash_type==2.0){dist=cap(int(dash_caps.y),abs(u-dash_center),dy,aa_radius);if((dx>line_start)&&(dx<line_stop)){dist=max(dist,d_join);}}if((dx>line_start)&&(dx<line_stop)){if((dx<=segment_start)&&(dash_start<=segment_start)&&(dash_stop>=segment_start)){dist=d_join;float angle=HALF_PI+v_angles.x;float f=abs((segment_start-dx)*cos(angle)-dy*sin(angle));dist=max(f,dist);}else if((dx>segment_stop)&&(dash_start<=segment_stop)&&(dash_stop>=segment_stop)){dist=d_join;float angle=HALF_PI+v_angles.y;float f=abs((dx-segment_stop)*cos(angle)-dy*sin(angle));dist=max(f,dist);}else if(dx<(segment_start-linewidth/2.)){discard;}else if(dx>(segment_stop+linewidth/2.)){discard;}}else if(dx<(segment_start-linewidth/2.)){discard;}else if(dx>(segment_stop+linewidth/2.)){discard;}}dist=dist-aa_radius;if(dist>=0.0){if(u_antialias==0.0){discard;}else{color=vec4(color.rgb,exp(-dist*dist)*color.a);}}\n#ifdef TANGRAM_DEBUG_TRIANGLES\nif(any(lessThan(v_barycentric,vec3(0.0085)))){color=vec4(0.0,1.0,0.0,1.0);}\n#endif\ngl_FragColor=color;}", PatternLines = Object.create(Style), CAP_TYPE$1 = { round: 1, "arrow-tail": 2, "arrow-head": 3, square: 4, butt: 5 }, JOIN_TYPE$1 = { miter: 0, round: 1, bevel: 2 }, PATTERN_MAX_WIDTH = 1024, DEFAULT_LINE_CAP = CAP_TYPE$1.round, DEFAULT_JOIN_TYPE = JOIN_TYPE$1.miter, DEFAULT_DASH_PATTERN = [0, 0], VARIANT_UNIQUE_PROP_NAMES = "antialias join linecaps miter_limit dash_index dash dash_caps dash_phase".split(" ");
        function getHashForStyle(e) {
          for (var t2 = [], r = 0, i2 = VARIANT_UNIQUE_PROP_NAMES.length; r < i2; r++) {
            var n = e[VARIANT_UNIQUE_PROP_NAMES[r]];
            Array.isArray(n) ? t2.push(n.join("_")) : "boolean" == typeof n ? t2.push(n ? 1 : 0) : n && t2.push(n.toString());
          }
          return t2.join("/");
        }
        Object.assign(PatternLines, { name: "pattern-lines", built_in: true, vertex_shader_src, fragment_shader_src, selection: true, init: function() {
          Style.init.apply(this, arguments), this.defines.TANGRAM_LAYER_ORDER = true, this.defines.TANGRAM_CROP_BY_TILE = this.crop_by_tile, this.defines.TANGRAM_DEBUG_TRIANGLES = false, this.defines.TANGRAM_DEBUG_NO_TEXTURE_FLOAT_SUPPORT = false, this.styles = this.styles || {}, PatternLines.vertex_layouts = [];
        }, calcDistance: function(e, t2) {
          return e && StyleParser.evalCachedDistanceProperty(e, t2) || 0;
        }, calcDash: function(e, t2) {
          var r = StyleParser.evalProperty(e.dash, t2), i2 = 0;
          return r && ((r = Array.isArray(r) && r.length ? r : DEFAULT_DASH_PATTERN).length % 2 == 1 && (r = r.concat(r)), i2 = +(i2 = r.reduce(function(e2, t3) {
            return e2 + t3;
          })) || 0), { dash: r, dash_period: i2 };
        }, calcWidth: function(e, t2, r) {
          var i2 = this.calcDistance(e.width, r);
          return !(i2 < 0) && (t2.width = i2 * r.units_per_meter_overzoom, true);
        }, getCapType: function(e, t2, r) {
          var i2 = StyleParser.evalProperty(e, t2);
          return void 0 !== CAP_TYPE$1[i2] ? CAP_TYPE$1[i2] : r;
        }, _parseFeature: function(e, t2, r) {
          if (false !== this.calcWidth(t2, this.feature_style, r)) {
            var i2 = this.parseColor(t2.color, r);
            if (i2 && 0 !== i2[3]) {
              var n = this.getCapType(t2.cap, r, DEFAULT_LINE_CAP), o = StyleParser.evalProperty(t2.join, r), a2 = +StyleParser.evalProperty(t2.miter_limit, r), s = this.calcDash(t2, r), l = s.dash, u2 = s.dash_period, c2 = Object.assign({ color: i2, antialias: t2.antialias, linecaps: [this.getCapType(t2.tail_cap, r, n), this.getCapType(t2.head_cap, r, n)], join: void 0 !== JOIN_TYPE$1[o] ? JOIN_TYPE$1[o] : DEFAULT_JOIN_TYPE, miter_limit: 0 <= a2 ? a2 : 3, dash_index: 0 === u2 ? 0 : 1, dash: l, dash_caps: [this.getCapType(t2.tail_cap, r, n), this.getCapType(t2.head_cap, r, n)], dash_phase: +StyleParser.evalProperty(t2.dash_phase, r) || 0, dash_period: u2 }, this.feature_style);
              return c2.z = t2.z && StyleParser.evalCachedDistanceProperty(t2.z || 0, r) || StyleParser.defaults.z, c2.z *= Geo$1.height_scale, c2.extrude = StyleParser.evalProperty(t2.extrude, r), c2.extrude && (true === c2.extrude ? (c2.height = void 0 !== e.properties.height ? e.properties.height : StyleParser.defaults.height, c2.min_height = void 0 !== e.properties.min_height ? e.properties.min_height : StyleParser.defaults.min_height) : "number" == typeof c2.extrude ? (c2.height = c2.extrude, c2.min_height = 0) : Array.isArray(c2.extrude) && (c2.min_height = c2.extrude[0], c2.height = c2.extrude[1]), c2.height *= Geo$1.height_scale, c2.min_height *= Geo$1.height_scale), this.addMeshVariantForDraw(this.base, c2), c2;
            }
          }
        }, _preprocess: function(e) {
          e.color = StyleParser.createColorPropertyCache(e.color), e.width = StyleParser.createPropertyCache(e.width, StyleParser.parseUnits), e.width && e.width.type !== StyleParser.CACHE_TYPE.STATIC && (e.next_width = StyleParser.createPropertyCache(e.width, StyleParser.parseUnits)), e.z = StyleParser.createPropertyCache(e.z, StyleParser.parseUnits);
          var t2 = +e.antialias;
          return e.antialias = isNaN(t2) ? 0 : t2, e;
        }, buildRasterTextures: function(e, t2) {
          var r = [];
          for (var i2 in t2.meshes) {
            var n, o = this.getMeshVariantTypeForDraw({ variantKey: i2 }), a2 = o.uniforms, s = o.pattern;
            a2.u_dash_index && (n = "__dash_" + s.join("_") + "_" + e.key + "_" + e.id, r.push({ name: n, data: buildPatternBuffer(s, PATTERN_MAX_WIDTH) }), a2.u_dash_atlas = n, t2.meshes[i2].textures = [n]), t2.meshes[i2].uniforms = a2;
          }
          return t2.uniforms = t2.uniforms || {}, r.length ? WorkerBroker.postMessage(this.main_thread_target + ".loadTextures", r).then(function(e2) {
            return t2;
          }) : Promise.resolve(t2);
        }, loadTextures: function(e) {
          for (var t2 = [], r = 0; r < e.length; r++) {
            var i2 = e[r], n = (n = this.textureManager.textures[i2.name]) || this.textureManager.create(this.gl, i2.name, { filtering: "nearest", repeat: true, width: PATTERN_MAX_WIDTH, height: 1, data: i2.data });
            t2.push(n.loading);
          }
          return Promise.all(t2).then(function(e2) {
            return e2.map(function(e3) {
              return e3.retain(), e3.name;
            });
          });
        }, computeVariantForDraw: function(e) {
          var t2 = getHashForStyle(e);
          return { key: e.variantKey = t2, order: e.variant_order, uniforms: { u_antialias: e.antialias, u_linecaps: e.linecaps, u_linejoin: e.join, u_miter_limit: e.miter_limit, u_dash_index: e.dash_index, u_dash_caps: e.dash_caps, u_dash_phase: e.dash_phase, u_dash_period: e.dash_period }, pattern: e.dash };
        }, vertexLayoutForMeshVariant: function(e) {
          var t2;
          return null == PatternLines.vertex_layouts[e.key] && (t2 = [{ name: "a_position", size: 4, type: gl$1.SHORT, normalized: false }, { name: "a_color", size: 4, type: gl$1.UNSIGNED_BYTE, normalized: true }, { name: "a_width", size: 1, type: gl$1.FLOAT, normalized: false }, { name: "a_tangents", size: 4, type: gl$1.FLOAT, normalized: false }, { name: "a_segment", size: 2, type: gl$1.FLOAT, normalized: false }, { name: "a_angles", size: 2, type: gl$1.FLOAT, normalized: false }, { name: "a_texcoord", size: 2, type: gl$1.FLOAT, normalized: true }, { name: "a_length", size: 1, type: gl$1.FLOAT, normalized: false }, { name: "a_closed", size: 1, type: gl$1.FLOAT, normalized: false }, { name: "a_selection_color", size: 4, type: gl$1.UNSIGNED_BYTE, normalized: true }], this.defines.TANGRAM_DEBUG_TRIANGLES && t2.push({ name: "a_barycentric", size: 3, type: gl$1.SHORT, normalized: false }), PatternLines.vertex_layouts[e.key] = new VertexLayout(t2)), PatternLines.vertex_layouts[e.key];
        }, makeVertexTemplate: function(e) {
          var t2 = 0;
          return this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = e.z + e.height || 0, this.vertex_template[t2++] = this.scaleOrder(e.order), this.vertex_template[t2++] = 255 * e.color[0], this.vertex_template[t2++] = 255 * e.color[1], this.vertex_template[t2++] = 255 * e.color[2], this.vertex_template[t2++] = 255 * e.color[3], this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.selection && (this.vertex_template[t2++] = 255 * e.selection_color[0], this.vertex_template[t2++] = 255 * e.selection_color[1], this.vertex_template[t2++] = 255 * e.selection_color[2], this.vertex_template[t2++] = 255 * e.selection_color[3]), this.defines.TANGRAM_DEBUG_TRIANGLES && (this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0, this.vertex_template[t2++] = 0), this.vertex_template;
        }, buildLines: function(e, t2, r, i2, n) {
          var o = 4 < arguments.length && void 0 !== n && n, a2 = r.vertex_data, s = a2.vertex_layout, l = this.makeVertexTemplate(t2, r);
          return buildPolylines$1(e, t2.width, a2, l, s.index, o);
        }, buildPolygons: function(e, t2, r, i2) {
          for (var n = 0, o = 0, a2 = e.length; o < a2; o++)
            n += this.buildLines(e[o], t2, r, i2, true);
          return n;
        } });
        var STICK_WIDTH = 1;
        function buildQuadsForPoints(e, t2, r, i2) {
          var n, o, a2, s, l, u2, c2 = i2.quad, h = i2.quad_normalize, f2 = i2.offset, d = i2.offsets, _ = i2.offsets_alt, p2 = i2.pre_angles, g = i2.pre_angles_alt, m = i2.angle, y = i2.angles, v = i2.angles_alt, x2 = i2.is_flat, b2 = i2.elevate_by_altitude, T2 = i2.build_stick_points, A2 = i2.color, E2 = i2.stick_color, w = i2.curve, S2 = i2.texcoord_scale, k = i2.texcoord_normalize, P2 = i2.pre_angles_normalize, R2 = i2.angles_normalize, M2 = i2.offsets_normalize, h = h || 1, L2 = c2[0] / 2 * h, O2 = c2[1] / 2 * h, C2 = [[-L2, -O2], [L2, -O2], [L2, O2], [-L2, O2]], N2 = t2.vertex_elements, I = t2.vertex_count, B2 = t2.vertex_layout.index, z2 = B2.a_texcoord, U2 = B2.a_position, F2 = B2.a_shape, G = B2.a_offset, D2 = B2.a_offsets, $ = B2.a_offsets_alt, j = B2.a_pre_angles, V = B2.a_pre_angles_alt, W2 = B2.a_angles, Y2 = B2.a_angles_alt, q = B2.a_is_flat, X2 = B2.a_is_stick, Z2 = B2.a_color;
          z2 && (k = k || 1, u2 = [[o = (n = _slicedToArray(S2 || default_uvs, 4))[0], a2 = n[1]], [s = n[2], a2], [s, l = n[3]], [o, l]]);
          for (var K2 = 0, J2 = e.length, Q = 0; Q < J2; Q++) {
            var ee2 = e[Q];
            if (T2) {
              for (var te2 = STICK_WIDTH / 2 * h, re2 = +h, ie2 = [[-te2, 0], [+te2, 0], [+te2, re2], [-te2, re2]], ne2 = 0; ne2 < 4; ne2++)
                z2 && (r[z2 + 0] = u2[ne2][0] * k, r[z2 + 1] = u2[ne2][1] * k), r[U2 + 0] = ee2[0], r[U2 + 1] = ee2[1], b2 && (r[U2 + 2] = MathUtils$1.clamp(ee2[2], 0, 32767)), r[F2 + 0] = ie2[ne2][0], r[F2 + 1] = ie2[ne2][1], r[F2 + 2] = 0, r[Z2 + 0] = E2[0], r[Z2 + 1] = E2[1], r[Z2 + 2] = E2[2], r[Z2 + 3] = E2[3], r[X2 + 0] = 255, t2.addVertex(r);
              N2.push(I + 0), N2.push(I + 1), N2.push(I + 2), N2.push(I + 2), N2.push(I + 3), N2.push(I + 0), I += 4, K2 += 2;
            }
            for (var oe2 = 0; oe2 < 4; oe2++)
              z2 && (r[z2 + 0] = u2[oe2][0] * k, r[z2 + 1] = u2[oe2][1] * k), r[U2 + 0] = ee2[0], r[U2 + 1] = ee2[1], b2 && (r[U2 + 2] = MathUtils$1.clamp(ee2[2], 0, 32767)), r[F2 + 0] = C2[oe2][0], r[F2 + 1] = C2[oe2][1], r[F2 + 2] = m, r[Z2 + 0] = A2[0], r[Z2 + 1] = A2[1], r[Z2 + 2] = A2[2], r[Z2 + 3] = A2[3], r[G + 0] = f2[0], r[G + 1] = f2[1], r[q + 0] = x2 ? 255 : 0, T2 && (r[X2 + 0] = 0), w && (r[j + 0] = P2 * p2[0], r[j + 1] = P2 * p2[1], r[j + 2] = P2 * p2[2], r[j + 3] = P2 * p2[3], r[W2 + 0] = R2 * y[0], r[W2 + 1] = R2 * y[1], r[W2 + 2] = R2 * y[2], r[W2 + 3] = R2 * y[3], r[D2 + 0] = M2 * d[0], r[D2 + 1] = M2 * d[1], r[D2 + 2] = M2 * d[2], r[D2 + 3] = M2 * d[3], _ && (r[$ + 0] = M2 * _[0], r[$ + 1] = M2 * _[1], r[$ + 2] = M2 * _[2], r[$ + 3] = M2 * _[3], r[V + 0] = P2 * g[0], r[V + 1] = P2 * g[1], r[V + 2] = P2 * g[2], r[V + 3] = P2 * g[3], r[Y2 + 0] = R2 * v[0], r[Y2 + 1] = R2 * v[1], r[Y2 + 2] = R2 * v[2], r[Y2 + 3] = R2 * v[3])), t2.addVertex(r);
            N2.push(I + 0), N2.push(I + 1), N2.push(I + 2), N2.push(I + 2), N2.push(I + 3), N2.push(I + 0), I += 4, K2 += 2;
          }
          return K2;
        }
        var id$2 = 0, Label = { id_prefix: "", nextLabelId: function() {
          return "".concat(Label.id_prefix, "/").concat(id$2++);
        } };
        function textLayoutToJSON(e) {
          return { priority: e.priority, collide: e.collide, repeat_distance: e.repeat_distance, repeat_group: e.repeat_group, buffer: e.buffer, italic: e.italic };
        }
        var lefts = ["left", "top-left", "bottom-left"], rights = ["right", "top-right", "bottom-right"], tops = ["top", "top-left", "top-right"], bottoms = ["bottom", "bottom-left", "bottom-right"], PointAnchor, PointAnchor$1 = PointAnchor = { computeOffset: function(e, t2, r, i2) {
          var n = 3 < arguments.length && void 0 !== i2 ? i2 : null;
          if (!r || "center" === r)
            return e;
          var o = [e[0], e[1]], n = n || this.default_buffer;
          return this.isLeftAnchor(r) ? (o[0] -= t2[0] / 2, "left" === r && (o[0] -= n[0])) : this.isRightAnchor(r) && (o[0] += t2[0] / 2, "right" === r && (o[0] += n[1])), this.isTopAnchor(r) ? (o[1] -= t2[1] / 2, "top" === r && (o[1] -= n[2])) : this.isBottomAnchor(r) && (o[1] += t2[1] / 2, "bottom" === r && (o[1] += n[3])), o;
        }, alignForAnchor: function(e) {
          if (e && "center" !== e) {
            if (this.isLeftAnchor(e))
              return "right";
            if (this.isRightAnchor(e))
              return "left";
          }
          return "center";
        }, isLeftAnchor: function(e) {
          return -1 < lefts.indexOf(e);
        }, isRightAnchor: function(e) {
          return -1 < rights.indexOf(e);
        }, isTopAnchor: function(e) {
          return -1 < tops.indexOf(e);
        }, isBottomAnchor: function(e) {
          return -1 < bottoms.indexOf(e);
        }, default_buffer: [2.5, 2.5, 1.5, 0.75], zero_buffer: [0, 0, 0, 0] };
        function encircleLine(e, t2, r, i2, n) {
          var o = [], a2 = r - e, s = i2 - t2, l = MathUtils$1.getLineLength(e, t2, r, i2), u2 = 2 * n;
          if ((c2 = l / u2) <= 1)
            o.push(e + a2 / 2, t2 + s / 2, n);
          else {
            var c2, h = u2 / l, f2 = a2 * h, d = s * h;
            (c2 = l / n / 2) % 1 && o.push(r - f2 / 2, i2 - d / 2, n), c2 |= 0;
            for (var _ = e + f2 / 2, p2 = t2 + d / 2; c2--; )
              o.push(_, p2, n), _ += f2, p2 += d;
          }
          return o;
        }
        var LabelPoint = function() {
          function n(e, t2, r, i2) {
            _classCallCheck(this, n), this.id = Label.nextLabelId(), this.position = [e[0], e[1]], void 0 !== e[2] && this.position.push(e[2]), this.size = t2, this.layout = i2, this.anchor = Array.isArray(this.layout.anchor) ? this.layout.anchor[0] : this.layout.anchor, this.placed = null, this.type = "point", this.parent = this.layout.parent, this.offset = this.computeOffset(), this.align = this.layout.align || PointAnchor$1.alignForAnchor(this.anchor), this._is_flat = r;
          }
          return _createClass(n, [{ key: "toJSON", value: function() {
            return { id: this.id, type: this.type, is_flat: this._is_flat, position: this.position, size: this.size, offset: this.offset, align: this.align, sides: this.getSides(), breach: !this.inTileBounds(), layout: textLayoutToJSON(this.layout) };
          } }, { key: "inTileBounds", value: function() {
            var e = this.getAABB(), t2 = e.left, r = e.top, i2 = e.right, n2 = e.bottom;
            return Utils$1.pointInTile([t2, r]) && Utils$1.pointInTile([i2, n2]);
          } }, { key: "isFlat", value: function() {
            return this._is_flat;
          } }, { key: "setAnchor", value: function(e) {
            this._circles = void 0, this._aabb = void 0, this.anchor = e, this.offset = this.computeOffset();
          } }, { key: "computeOffset", value: function() {
            var e, t2 = [this.layout.offset[0], this.layout.offset[1]];
            return this.parent && (e = this.parent, t2 = PointAnchor$1.computeOffset(t2, e.size, e.anchor, PointAnchor$1.zero_buffer), t2 = PointAnchor$1.computeOffset(t2, e.size, this.anchor, PointAnchor$1.zero_buffer), e.offset !== StyleParser.zeroPair && (t2 === StyleParser.zeroPair ? t2 = e.offset : (t2[0] += e.offset[0], t2[1] += e.offset[1]))), PointAnchor$1.computeOffset(t2, this.size, this.anchor);
          } }, { key: "getBoundingCircles", value: function() {
            return this.angle ? (this._circles || (e = this.layout.units_per_pixel, n2 = -(r = (t2 = this.size[0] / 2 * e) * Math.cos(this.angle)), o = -(i2 = t2 * Math.sin(this.angle)), s = (a2 = _slicedToArray(this.position, 2))[0], l = a2[1], r += s, i2 += l *= -1, n2 += s, o += l, u2 = this.size[1] / 2 * e, this._circles = encircleLine(r, i2, n2, o, u2)), this._circles) : [];
            var e, t2, r, i2, n2, o, a2, s, l, u2;
          } }, { key: "getAABB", value: function() {
            var e, t2, r, i2, n2;
            return this._aabb || (e = this.layout.units_per_pixel, t2 = (this.size[0] / 2 + this.layout.buffer[0]) * e, r = (this.size[1] / 2 + this.layout.buffer[1]) * e, i2 = this.position[0] + this.offset[0] * e, n2 = this.position[1] - this.offset[1] * e, this._aabb = { left: i2 - t2, top: n2 + r, right: i2 + t2, bottom: n2 - r }), this._aabb;
          } }, { key: "getSides", value: function() {
            var e = this.getAABB(), t2 = e.left, r = e.top, i2 = e.right, n2 = (r + e.bottom) / 2;
            return [t2, n2, i2, n2];
          } }]), n;
        }();
        LabelPoint.PLACEMENT = { VERTEX: 0, MIDPOINT: 1, SPACED: 2, CENTROID: 3 };
        var PLACEMENT = LabelPoint.PLACEMENT, default_spacing = 80, TextSettings;
        function placePointsOnLine(e, t2, r, i2) {
          var n = [], o = i2.placement, a2 = Math.max(t2[0], t2[1]) * i2.placement_min_length_ratio * i2.units_per_pixel;
          switch (o) {
            case PLACEMENT.SPACED:
              var s = getPositionsAndAngles(e, a2, i2);
              if (!s)
                return [];
              for (var l = s.positions, u2 = s.angles, c2 = 0; c2 < l.length; c2++) {
                var h, f2 = l[c2], d = u2[c2];
                true !== i2.tile_edges && isCoordOutsideTile(f2) || ((h = new LabelPoint(f2, t2, r, i2)).angle = d, n.push(h));
              }
              break;
            case PLACEMENT.VERTEX:
              for (var _, p2, g, m = 0; m < e.length - 1; m++)
                _ = e[m], p2 = e[m + 1], true !== i2.tile_edges && isCoordOutsideTile(_) || ((g = new LabelPoint(_, t2, r, i2)).angle = getAngle(_, p2, i2.angle), n.push(g));
              (g = new LabelPoint(p2, t2, r, i2)).angle = getAngle(_, p2, i2.angle), n.push(g);
              break;
            case PLACEMENT.MIDPOINT:
              for (var y = 0; y < e.length - 1; y++) {
                var v, x2 = e[y], b2 = e[y + 1], T2 = [0.5 * (x2[0] + b2[0]), 0.5 * (x2[1] + b2[1])];
                true !== i2.tile_edges && isCoordOutsideTile(T2) || (!a2 || norm(x2, b2) > a2) && ((v = new LabelPoint(T2, t2, r, i2)).angle = getAngle(x2, b2, i2.angle), n.push(v));
              }
          }
          return n;
        }
        function getPositionsAndAngles(e, t2, r) {
          var i2 = r.units_per_pixel, n = (r.placement_spacing || default_spacing) * i2, o = getLineLength(e);
          if (o <= t2)
            return false;
          for (var a2 = Math.max(Math.floor(o / n), 1), s = [], l = [], u2 = 0.5 * (o - (a2 - 1) * n), c2 = 0; c2 < a2; c2++) {
            var h = interpolateLine(e, u2, t2, r), f2 = h.position, d = h.angle;
            null != f2 && null != d && (s.push(f2), l.push(d)), u2 += n;
          }
          return { positions: s, angles: l };
        }
        function getAngle(e, t2) {
          var r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : 0;
          return "auto" === r ? Math.atan2(t2[0] - e[0], t2[1] - e[1]) : r;
        }
        function getLineLength(e) {
          for (var t2 = 0, r = 0; r < e.length - 1; r++)
            t2 += norm(e[r], e[r + 1]);
          return t2;
        }
        function norm(e, t2) {
          return Math.sqrt(Math.pow(e[0] - t2[0], 2) + Math.pow(e[1] - t2[1], 2));
        }
        function interpolateLine(e, t2, r, i2) {
          for (var n, o, a2 = 0, s = 0; s < e.length - 1; s++) {
            var l = e[s], u2 = e[s + 1], c2 = norm(l, u2);
            if (!(c2 <= r) && t2 < (a2 += c2)) {
              n = interpolateSegment(l, u2, a2 - t2), o = getAngle(l, u2, i2.angle);
              break;
            }
          }
          return { position: n, angle: o };
        }
        function interpolateSegment(e, t2, r) {
          var i2 = r / norm(e, t2);
          return [i2 * e[0] + (1 - i2) * t2[0], i2 * e[1] + (1 - i2) * t2[1]];
        }
        var TextSettings$1 = TextSettings = { key: function(e) {
          return [e.style, e.weight, e.family, e.px_size, e.fill, e.stroke, e.stroke_width, e.transform, e.text_wrap, e.max_lines, e.supersample, e.background_color, e.outline_color, e.outline_width, e.padding, Utils$1.device_pixel_ratio].join("/");
        }, defaults: { style: "normal", weight: null, size: "12px", px_size: 12, family: "Helvetica", fill: "white", text_wrap: 15, max_lines: 5, align: "center", stroke: null, stroke_width: 0, background_color: null, outline_color: null, outline_width: 0, padding: [0, 0, 0, 0] }, compute: function(e, t2, r) {
          var i2 = {};
          if (t2.font = t2.font || this.defaults, i2.can_articulate = t2.can_articulate, i2.fill = t2.font.fill && Utils$1.toCSSColor(StyleParser.evalCachedColorProperty(t2.font.fill, r)) || this.defaults.fill, i2.style = t2.font.style || this.defaults.style, i2.weight = t2.font.weight || this.defaults.weight, t2.font.family ? (i2.family = t2.font.family, i2.family !== this.defaults.family && (i2.family += ", " + this.defaults.family)) : i2.family = this.defaults.family, i2.transform = t2.font.transform, i2.size = t2.font.size || this.defaults.size, i2.supersample = t2.supersample_text ? 1.5 : 1, i2.px_size = StyleParser.evalCachedProperty(t2.font.px_size, r) * i2.supersample, 0 !== i2.px_size) {
            t2.font.stroke && t2.font.stroke.color && (i2.stroke = Utils$1.toCSSColor(StyleParser.evalCachedColorProperty(t2.font.stroke.color, r) || this.defaults.stroke), i2.stroke_width = StyleParser.evalCachedProperty(t2.font.stroke.width, r) || this.defaults.stroke_width), i2.font_css = this.fontCSS(i2);
            var n = t2.text_wrap;
            return null == n && "line" !== Geo$1.geometryType(e.geometry.type) && (n = true), true === n && (n = this.defaults.text_wrap), i2.text_wrap = n, i2.max_lines = t2.max_lines || this.defaults.max_lines, i2.background_color = t2.background && t2.background.color && !t2.can_articulate ? Utils$1.toCSSColor(StyleParser.evalCachedColorProperty(t2.background.color, r)) : this.defaults.background_color, i2.outline_color = t2.outline && t2.outline.color && !t2.can_articulate ? Utils$1.toCSSColor(StyleParser.evalCachedColorProperty(t2.outline.color, r)) : this.defaults.outline_color, i2.outline_width = t2.outline && t2.outline.width && !t2.can_articulate ? StyleParser.evalCachedProperty(t2.outline.width, r) : this.defaults.outline_width, i2.padding = t2.padding && !t2.can_articulate ? StyleParser.evalCachedProperty(t2.padding, r) : this.defaults.padding, i2;
          }
        }, fontCSS: function(e) {
          return [e.style, e.weight, e.px_size + "px", e.family].filter(function(e2) {
            return e2;
          }).join(" ");
        } }, fontfaceobserver_standalone = createCommonjsModule(function(e) {
          function n(e2, t3) {
            document.addEventListener ? e2.addEventListener("scroll", t3, false) : e2.attachEvent("scroll", t3);
          }
          function v(e2) {
            this.a = document.createElement("div"), this.a.setAttribute("aria-hidden", "true"), this.a.appendChild(document.createTextNode(e2)), this.b = document.createElement("span"), this.c = document.createElement("span"), this.h = document.createElement("span"), this.f = document.createElement("span"), this.g = -1, this.b.style.cssText = "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;", this.c.style.cssText = "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;", this.f.style.cssText = "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;", this.h.style.cssText = "display:inline-block;width:200%;height:200%;font-size:16px;max-width:none;", this.b.appendChild(this.h), this.c.appendChild(this.f), this.a.appendChild(this.b), this.a.appendChild(this.c);
          }
          function x2(e2, t3) {
            e2.a.style.cssText = "max-width:none;min-width:20px;min-height:20px;display:inline-block;overflow:hidden;position:absolute;width:auto;margin:0;padding:0;top:-999px;left:-999px;white-space:nowrap;font:" + t3 + ";";
          }
          function o(e2) {
            var t3 = e2.a.offsetWidth, r2 = t3 + 100;
            return e2.f.style.width = r2 + "px", e2.c.scrollLeft = r2, e2.b.scrollLeft = e2.b.scrollWidth + 100, e2.g !== t3 && (e2.g = t3, 1);
          }
          function b2(e2, t3) {
            function r2() {
              var e3 = i3;
              o(e3) && e3.a.parentNode && t3(e3.g);
            }
            var i3 = e2;
            n(e2.b, r2), n(e2.c, r2), o(e2);
          }
          function t2(e2, t3) {
            var r2 = t3 || {};
            this.family = e2, this.style = r2.style || "normal", this.weight = r2.weight || "normal", this.stretch = r2.stretch || "normal";
          }
          function T2(e2, t3) {
            return [e2.style, e2.weight, function() {
              if (null === r) {
                var e3 = document.createElement("div");
                try {
                  e3.style.font = "condensed 100px sans-serif";
                } catch (e4) {
                }
                r = "" !== e3.style.font;
              }
              return r;
            }() ? e2.stretch : "", "100px", t3].join(" ");
          }
          var A2, i2, r, a2;
          a2 = r = i2 = A2 = null, t2.prototype.load = function(e2, t3) {
            var _ = this, p2 = e2 || "BESbswy", g = 0, m = t3 || 3e3, y = (/* @__PURE__ */ new Date()).getTime();
            return new Promise(function(f2, d) {
              var e3, t4, r2;
              null === a2 && (a2 = !!document.fonts), (e3 = a2) && (null === i2 && (i2 = /OS X.*Version\/10\..*Safari/.test(navigator.userAgent) && /Apple/.test(navigator.vendor)), e3 = !i2), e3 ? (e3 = new Promise(function(r3, e4) {
                !function t5() {
                  (/* @__PURE__ */ new Date()).getTime() - y >= m ? e4() : document.fonts.load(T2(_, '"' + _.family + '"'), p2).then(function(e5) {
                    1 <= e5.length ? r3() : setTimeout(t5, 25);
                  }, function() {
                    e4();
                  });
                }();
              }), t4 = new Promise(function(e4, t5) {
                g = setTimeout(t5, m);
              }), Promise.race([t4, e3]).then(function() {
                clearTimeout(g), f2(_);
              }, function() {
                d(_);
              })) : (r2 = function() {
                function t5() {
                  var e4;
                  (e4 = -1 != o2 && -1 != a3 || -1 != o2 && -1 != s || -1 != a3 && -1 != s) && ((e4 = o2 != a3 && o2 != s && a3 != s) || (null === A2 && (e4 = /AppleWebKit\/([0-9]+)(?:\.([0-9]+))/.exec(window.navigator.userAgent), A2 = !!e4 && (parseInt(e4[1], 10) < 536 || 536 === parseInt(e4[1], 10) && parseInt(e4[2], 10) <= 11)), e4 = A2 && (o2 == l && a3 == l && s == l || o2 == u2 && a3 == u2 && s == u2 || o2 == c2 && a3 == c2 && s == c2)), e4 = !e4), e4 && (h.parentNode && h.parentNode.removeChild(h), clearTimeout(g), f2(_));
                }
                var r3 = new v(p2), i3 = new v(p2), n2 = new v(p2), o2 = -1, a3 = -1, s = -1, l = -1, u2 = -1, c2 = -1, h = document.createElement("div");
                h.dir = "ltr", x2(r3, T2(_, "sans-serif")), x2(i3, T2(_, "serif")), x2(n2, T2(_, "monospace")), h.appendChild(r3.a), h.appendChild(i3.a), h.appendChild(n2.a), document.body.appendChild(h), l = r3.a.offsetWidth, u2 = i3.a.offsetWidth, c2 = n2.a.offsetWidth, function H2() {
                  var e4;
                  (/* @__PURE__ */ new Date()).getTime() - y >= m ? (h.parentNode && h.parentNode.removeChild(h), d(_)) : (true !== (e4 = document.hidden) && void 0 !== e4 || (o2 = r3.a.offsetWidth, a3 = i3.a.offsetWidth, s = n2.a.offsetWidth, t5()), g = setTimeout(H2, 50));
                }(), b2(r3, function(e4) {
                  o2 = e4, t5();
                }), x2(r3, T2(_, '"' + _.family + '",sans-serif')), b2(i3, function(e4) {
                  a3 = e4, t5();
                }), x2(i3, T2(_, '"' + _.family + '",serif')), b2(n2, function(e4) {
                  s = e4, t5();
                }), x2(n2, T2(_, '"' + _.family + '",monospace'));
              }, document.body ? r2() : document.addEventListener ? document.addEventListener("DOMContentLoaded", function e4() {
                document.removeEventListener("DOMContentLoaded", e4), r2();
              }) : document.attachEvent("onreadystatechange", function e4() {
                "interactive" != document.readyState && "complete" != document.readyState || (document.detachEvent("onreadystatechange", e4), r2());
              }));
            });
          }, e.exports = t2;
        }), FontManager = { fonts_loaded: Promise.resolve(), last_loaded: null, loadFonts: function(i2) {
          var n = this, e = JSON.stringify(i2) === this.last_loaded;
          return i2 && !e && function() {
            var r = [];
            for (var e2 in i2)
              !function(t2) {
                Array.isArray(i2[t2]) ? i2[t2].forEach(function(e3) {
                  return r.push(n.loadFontFace(t2, e3));
                }) : r.push(n.loadFontFace(t2, i2[t2]));
              }(e2);
            n.last_loaded = JSON.stringify(i2), n.fonts_loaded = Promise.all(r.filter(function(e3) {
              return e3;
            }));
          }(), this.fonts_loaded;
        }, loadFontFace: function(e, t2) {
          if (null != t2 && ("object" === _typeof(t2) || "external" === t2)) {
            var r = { family: e }, i2 = Promise.resolve();
            "object" === _typeof(t2) && (Object.assign(r, t2), "string" == typeof t2.url && (i2 = this.injectFontFace(r)));
            var n = new fontfaceobserver_standalone(e, r);
            return i2.then(function() {
              return n.load();
            }).then(function() {
              log("debug", "Font face '".concat(e, "' is available"), r);
            }, function() {
              log("debug", "Font face '".concat(e, "' is NOT available"), r);
            });
          }
        }, injectFontFace: function(e) {
          var n = this, o = e.family, t2 = e.url, a2 = e.weight, s = e.style;
          void 0 === this.supports_native_font_loading && (this.supports_native_font_loading = void 0 !== window.FontFace);
          var r = Promise.resolve(t2);
          return "blob:" === t2.slice(0, 5) && (r = Utils$1.io(t2, 6e4, "arraybuffer").then(function(e2) {
            var t3 = new Uint8Array(e2);
            if (n.supports_native_font_loading)
              return t3;
            for (var r2 = "", i2 = 0; i2 < t3.length; i2++)
              r2 += String.fromCharCode(t3[i2]);
            return "data:font/opentype;base64," + btoa(r2);
          })), r.then(function(e2) {
            var t3, r2, i2;
            n.supports_native_font_loading ? ("string" == typeof e2 ? t3 = new FontFace(o, "url(".concat(encodeURI(e2), ")"), { weight: a2, style: s }) : e2 instanceof Uint8Array && (t3 = new FontFace(o, e2, { weight: a2, style: s })), document.fonts.add(t3), log("trace", "Adding FontFace to document.fonts:", t3)) : (r2 = "\n                    @font-face {\n                        font-family: '".concat(o, "';\n                        font-weight: ").concat(a2 || "normal", ";\n                        font-style: ").concat(s || "normal", ";\n                        src: url(").concat(encodeURI(e2), ");\n                    }\n                "), (i2 = document.createElement("style")).appendChild(document.createTextNode("")), document.head.appendChild(i2), i2.sheet.insertRule(r2, 0), log("trace", "Injecting CSS font face:", r2));
          });
        } }, CanvasText = function() {
          function S2() {
            _classCallCheck(this, S2), this.vertical_text_buffer = 1, this.horizontal_text_buffer = 1, this.layout = layout("binary-tree");
          }
          return _createClass(S2, [{ key: "createCanvas", value: function(e, t2) {
            var r = document.createElement("canvas");
            return e && t2 && (r.width = e, r.height = t2), r.style.backgroundColor = "transparent", r;
          } }, { key: "setFont", value: function(e, t2) {
            var r = t2.font_css, i2 = t2.fill, n = t2.stroke, o = t2.stroke_width, a2 = t2.px_size, s = t2.supersample;
            this.px_size = a2;
            var l = Utils$1.device_pixel_ratio * s;
            n && 0 < o && (e.strokeStyle = n, e.lineWidth = o * l), e.fillStyle = i2, e.textBaseline = "bottom", e.font = r, e.miterLimit = 2;
          } }, { key: "textSizes", value: function(e, t2, r) {
            var i2 = this;
            return FontManager.loadFonts().then(function() {
              return Task.add({ type: "textSizes", run: i2.processTextSizesTask.bind(i2), texts: t2, tile_id: e, cursor: { ctx: r, styles: Object.keys(t2), texts: null, style_idx: null, text_idx: null } });
            });
          } }, { key: "processTextSizesTask", value: function(e) {
            var t2 = e.cursor, r = e.texts, i2 = t2.ctx;
            for (t2.style_idx = t2.style_idx || 0; t2.style_idx < t2.styles.length; ) {
              var n = t2.styles[t2.style_idx];
              null == t2.text_idx && (t2.text_idx = 0, t2.texts = Object.keys(r[n]));
              for (var o = r[n], a2 = true; t2.text_idx < t2.texts.length; ) {
                var s = t2.texts[t2.text_idx], l = o[s], u2 = l.text_settings;
                if (a2 && (this.setFont(i2, u2), a2 = false), l.size = this.textSize(i2, n, s, u2).size, u2.can_articulate) {
                  var c2 = false, h = false;
                  if (isTextRTL(s) && (isTextNeutral(s) ? c2 = true : h = true), l.isRTL = c2, l.no_curving = h || isTextCurveBlacklisted(s), l.vertical_buffer = this.vertical_text_buffer + u2.outline_width + (u2.padding[0] + u2.padding[2]) / 2, l.segment_sizes = [], !l.no_curving) {
                    var f2 = splitLabelText(s, c2);
                    l.segments = f2;
                    for (var d = 0; d < f2.length; d++)
                      l.segment_sizes.push(this.textSize(i2, n, f2[d], u2).size);
                  }
                }
                if (t2.text_idx++, !Task.shouldContinue(e))
                  return false;
              }
              t2.text_idx = null, t2.style_idx++;
            }
            return Task.finish(e, { texts: r }), true;
          } }, { key: "textSize", value: function(e, t2, r, i2) {
            var n = i2.transform, o = i2.text_wrap, a2 = i2.max_lines, s = i2.stroke_width, l = void 0 === s ? 0 : s, u2 = i2.supersample, c2 = i2.padding, h = i2.outline_width, f2 = i2.can_articulate;
            if (S2.cache.text[t2] = S2.cache.text[t2] || {}, S2.cache.text[t2][r])
              return S2.cache.stats.text_hits++, S2.cache.text[t2][r];
            S2.cache.stats.text_misses++, S2.cache.text_count++;
            var d = Utils$1.device_pixel_ratio * u2, _ = this.applyTextTransform(r, n), p2 = d * (this.vertical_text_buffer + h + (c2[0] + c2[2]) / 2), g = d * (this.horizontal_text_buffer + h + l + (c2[1] + c2[3]) / 2), m = 2 * d, y = this.px_size + m, v = MultiLine.parse(_, o, a2, y, e), x2 = v.height, b2 = v.width, T2 = v.lines, A2 = [b2 / d, x2 / d];
            f2 || (A2[0] += 2 * g / d, A2[1] += 2 * p2 / d);
            var E2 = [b2 + 2 * g, x2 + 2 * p2], w = [E2[0] / d, E2[1] / d];
            return S2.cache.text[t2][r] = { lines: T2, size: { collision_size: A2, texture_size: E2, logical_size: w, line_height: y } }, S2.cache.text[t2][r];
          } }, { key: "drawTextMultiLine", value: function(e, t2, r, i2, n, o) {
            var a2 = _slicedToArray(r, 2), s = a2[0], l = a2[1], u2 = Utils$1.device_pixel_ratio * n.supersample, c2 = n.stroke_width || 0, h = n.stroke;
            n.background_color && (e.fillStyle = n.background_color, e.fillRect(s, l, i2.texture_size[0], i2.texture_size[1]));
            var f2 = n.outline_width * u2, d = n.outline_color;
            f2 && d && (e.strokeStyle = d, e.lineWidth = f2, e.strokeRect(s + f2 / 2, l + f2 / 2, i2.texture_size[0] - f2, i2.texture_size[1] - f2)), (n.background_color || f2 && d) && this.setFont(e, n);
            for (var _, p2, g, m, y = i2.line_height, v = l, x2 = 0; x2 < t2.length; x2++) {
              var b2 = t2[x2];
              this.drawTextLine(e, b2, [s, v], i2, n, o), v += y;
            }
            debugSettings$1.draw_label_collision_boxes && (e.save(), _ = u2 * (this.horizontal_text_buffer + n.outline_width + c2 + (n.padding[1] + n.padding[3]) / 2), p2 = u2 * (this.vertical_text_buffer + n.outline_width + (n.padding[0] + n.padding[2]) / 2), g = i2.collision_size, e.strokeStyle = "blue", e.lineWidth = 2, e.strokeRect(s + _, l + p2, u2 * g[0], u2 * g[1]), "curved" === o && h && 0 < c2 && e.strokeRect(s + i2.texture_size[0] + _, l + p2, u2 * g[0], u2 * g[1]), e.restore()), debugSettings$1.draw_label_texture_boxes && (e.save(), m = i2.texture_size, e.strokeStyle = "green", e.lineWidth = 2, e.strokeRect(s + 2, l + 2, m[0] - 4, m[1] - 4), "curved" === o && h && 0 < c2 && e.strokeRect(s + 2 + i2.texture_size[0], l + 2, m[0] - 4, m[1] - 4), e.restore());
          } }, { key: "drawTextLine", value: function(e, t2, r, i2, n, o) {
            var a2, s = _slicedToArray(r, 2), l = s[0], u2 = s[1], c2 = n.stroke, h = n.stroke_width, f2 = void 0 === h ? 0 : h, d = n.transform, _ = n.align, p2 = n.supersample, g = n.padding, m = n.outline_width, y = Utils$1.device_pixel_ratio * p2, _ = _ || "center", v = i2.texture_size, x2 = i2.line_height, b2 = y * (this.vertical_text_buffer + m), T2 = y * (this.horizontal_text_buffer + m + f2), A2 = this.applyTextTransform(t2.text, d);
            "left" === _ ? a2 = l + T2 + g[3] * y : "center" === _ ? a2 = l + v[0] / 2 - t2.width / 2 - (g[1] - g[3]) * y / 2 : "right" === _ && (a2 = l + v[0] - t2.width - T2 - g[1] * y);
            var E2, w = u2 + b2 + x2 + g[0] * y;
            c2 && 0 < f2 && (E2 = "curved" === o ? v[0] : 0, e.strokeText(A2, a2 + E2, w)), e.fillText(A2, a2, w);
          } }, { key: "rasterize", value: function(e, t2, r, i2, n, o) {
            return Task.removeForTile(r), Task.add({ type: "rasterizeLabels", run: this.processRasterizeTask.bind(this), cancel: S2.returnNoTextures, pause_factor: 2, user_moving_view: false, texts: e, textures: t2, texture_prefix: i2, gl: n, tile_id: r, texture_manager: o, cursor: { styles: Object.keys(e), texts: null, style_idx: 0, text_idx: null, texture_idx: 0, texture_names: [] } });
          } }, { key: "processRasterizeTask", value: function(e) {
            if (!Task.shouldContinue(e))
              return false;
            for (var t2 = e.cursor, r = e.texts, i2 = e.textures; t2.texture_idx < e.textures.length; ) {
              for (var n = false, o = i2[t2.texture_idx], a2 = this.createCanvas.apply(this, _toConsumableArray(o.texture_size)), s = a2.getContext("2d"); t2.style_idx < t2.styles.length; ) {
                var l = t2.styles[t2.style_idx];
                null == t2.text_idx && (t2.text_idx = 0, t2.texts = Object.keys(r[l]));
                for (var u2 = r[l], c2 = true; t2.text_idx < t2.texts.length; ) {
                  var h = t2.texts[t2.text_idx], f2 = u2[h], d = f2.text_settings;
                  if (c2 && (this.setFont(s, d), c2 = false), d.can_articulate) {
                    f2.texcoords = f2.texcoords || {};
                    for (var _ = 0; _ < f2.type.length; _++) {
                      var p2 = f2.type[_];
                      switch (p2) {
                        case "straight":
                          if (f2.textures[_] !== t2.texture_idx)
                            continue;
                          var g, m, y, v, x2 = f2.isRTL ? h.split().reverse().join() : h, b2 = o.texcoord_cache[l][x2], T2 = void 0;
                          b2.texcoord ? T2 = b2.texcoord : (g = b2.texture_position, y = (m = this.textSize(s, l, x2, d)).size, v = m.lines, this.drawTextMultiLine(s, v, g, y, d, p2), T2 = e.texture_manager.getTexcoordsForSprite(g, y.texture_size, o.texture_size), b2.texcoord = T2), f2.texcoords[p2] = { texcoord: T2, texture_id: b2.texture_id };
                          break;
                        case "curved":
                          var A2 = f2.segments;
                          f2.texcoords.curved = [], f2.texcoords_stroke = [];
                          for (var E2, w, S3, k, P2, R2, M2, L2, O2 = 0; O2 < A2.length; O2++) {
                            f2.textures[_][O2] === t2.texture_idx && (E2 = A2[O2], k = S3 = void 0, (w = o.texcoord_cache[l][E2]).texcoord && w.texcoord_stroke ? (S3 = w.texcoord, k = w.texcoord_stroke) : (P2 = w.texture_position, M2 = (R2 = this.textSize(s, l, E2, d)).size, L2 = R2.lines, this.drawTextMultiLine(s, L2, P2, M2, d, p2), S3 = e.texture_manager.getTexcoordsForSprite(P2, M2.texture_size, o.texture_size), k = d.stroke && 0 < d.stroke_width ? e.texture_manager.getTexcoordsForSprite([P2[0] + M2.texture_size[0], P2[1]], M2.texture_size, o.texture_size) : (n = true, e.texture_manager.getTexcoordsForSprite([o.texture_size[0], o.texture_size[1]], [0, 0], o.texture_size)), w.texcoord = S3, w.texcoord_stroke = k), f2.texcoords_stroke.push(k), f2.texcoords.curved.push({ texcoord: S3, texture_id: w.texture_id }));
                          }
                      }
                    }
                  } else {
                    var C2 = this.textSize(s, l, h, d).lines;
                    for (var N2 in f2.align)
                      f2.align[N2].texture_id === t2.texture_idx && (this.drawTextMultiLine(s, C2, f2.align[N2].texture_position, f2.size, { stroke: d.stroke, stroke_width: d.stroke_width, transform: d.transform, supersample: d.supersample, align: N2, background_color: d.background_color, outline_width: d.outline_width, outline_color: d.outline_color, padding: d.padding, fill: d.fill, font_css: d.font_css, px_size: d.px_size }), f2.align[N2].texcoords = e.texture_manager.getTexcoordsForSprite(f2.align[N2].texture_position, f2.size.texture_size, o.texture_size));
                  }
                  t2.text_idx++;
                }
                t2.text_idx = null, t2.style_idx++;
              }
              true === n && (s.fillStyle = "rgba(0, 0, 0, 0)", s.fillRect(a2.width - 1, a2.height - 1, 1, 1));
              var I = e.texture_prefix + t2.texture_idx;
              e.texture_manager.create(e.gl, I, { element: a2, filtering: "linear", UNPACK_PREMULTIPLY_ALPHA_WEBGL: true }), t2.texture_names.push(I), t2.texture_idx++, t2.style_idx = 0, a2.width = 0, a2.height = 0;
            }
            return Task.finish(e, t2.texture_names), true;
          } }, { key: "setTextureTextPositions", value: function(e) {
            var t2 = { texture_id: 0, texcoord_cache: {} }, r = [];
            for (var i2 in e) {
              var n = e[i2];
              for (var o in n) {
                var a2 = n[o], s = a2.text_settings, l = s.can_articulate, u2 = s.stroke, c2 = s.stroke_width;
                if (l) {
                  a2.textures = [], t2.texcoord_cache[i2] = t2.texcoord_cache[i2] || {};
                  for (var h = 0; h < a2.type.length; h++) {
                    switch (a2.type[h]) {
                      case "straight":
                        var f2, d = a2.isRTL ? o.split().reverse().join() : o;
                        t2.texcoord_cache[i2][d] || (f2 = a2.size.texture_size, t2.texcoord_cache[i2][d] = {}, this.placeText(f2[0], f2[1], { can_articulate: l, style: i2, word: d })), a2.textures[h] = t2.texture_id;
                        break;
                      case "curved":
                        a2.textures[h] = [];
                        for (var _ = 0; _ < a2.segment_sizes.length; _++) {
                          var p2, g, m = a2.segments[_];
                          t2.texcoord_cache[i2][m] || (g = (p2 = a2.segment_sizes[_].texture_size)[0], u2 && 0 < c2 && (g *= 2), t2.texcoord_cache[i2][m] = {}, this.placeText(g, p2[1], { can_articulate: l, style: i2, word: m })), a2.textures[h].push(t2.texture_id);
                        }
                    }
                  }
                } else {
                  var y = a2.size.texture_size;
                  this.placeText(y[0], y[1], { can_articulate: l, text_info: a2 });
                }
              }
            }
            var v = this.layout.export(), x2 = v.items, b2 = v.width, T2 = v.height;
            t2.texcoord_cache = {};
            for (var A2 = 0, E2 = x2.length; A2 < E2; A2++) {
              var w = x2[A2], S3 = w.x, k = w.y;
              if (!w.meta.can_articulate) {
                var P2 = w.meta.text_info;
                for (var R2 in P2.align)
                  P2.align[R2].texture_id = t2.texture_id, P2.align[R2].texture_position = [S3, k];
              } else {
                var M2 = w.meta, L2 = M2.style, O2 = M2.word;
                t2.texcoord_cache[L2] = t2.texcoord_cache[L2] || {}, t2.texcoord_cache[L2][O2] || (t2.texcoord_cache[L2][O2] = { texture_id: t2.texture_id, texture_position: [S3, k] });
              }
            }
            return 0 < b2 && 0 < T2 && (r[t2.texture_id] = { texture_size: [b2, T2], texcoord_cache: t2.texcoord_cache }), r;
          } }, { key: "placeText", value: function(e, t2, r) {
            this.layout.addItem({ width: e + this.vertical_text_buffer, height: t2 + this.vertical_text_buffer, meta: r });
          } }, { key: "applyTextTransform", value: function(e, t2) {
            return "capitalize" === t2 ? e.replace(/\w\S*/g, function(e2) {
              return e2.charAt(0).toUpperCase() + e2.substr(1);
            }) : "uppercase" === t2 ? e.toUpperCase() : "lowercase" === t2 ? e.toLowerCase() : e;
          } }], [{ key: "fontPixelSize", value: function(e) {
            if (null != e) {
              var t2 = _slicedToArray((e = "string" == typeof e ? e : String(e)).match(S2.font_size_re) || [], 3), r = t2[1], i2 = t2[2];
              return "em" === (i2 = i2 || "px") ? r *= 16 : "pt" === i2 ? r /= 0.75 : "%" === i2 && (r /= 6.25), r = StyleParser.parsePositiveNumber(r), r *= Utils$1.device_pixel_ratio;
            }
          } }, { key: "pruneTextCache", value: function() {
            S2.cache.text_count > S2.cache.text_count_max && (S2.cache.text = {}, S2.cache.text_count = 0, log("debug", "CanvasText: pruning text cache")), Object.keys(S2.cache.segment).length > S2.cache.segment_count_max && (S2.cache.segment = {}, log("debug", "CanvasText: pruning segment cache"));
          } }]), S2;
        }();
        CanvasText.font_size_re = /((?:[0-9]*\.)?[0-9]+)\s*(px|pt|em|%)?/, CanvasText.cache = { text: {}, text_count: 0, text_count_max: 2e3, segment: {}, segment_count_max: 2e3, stats: { text_hits: 0, text_misses: 0, segment_hits: 0, segment_misses: 0 } }, CanvasText.EMPTY_TEXTURES_ARR = [], CanvasText.returnNoTextures = function() {
          return CanvasText.EMPTY_TEXTURES_ARR;
        };
        var rtlDirCheck = new RegExp("[֑-߿‏‫‮יִ-﷽ﹰ-ﻼ]");
        function isTextRTL(e) {
          return rtlDirCheck.test(e);
        }
        var neutral_chars = "\0-/:-@[-`{-¿×÷ʹ-˿ -⯿‐-\u2029‬ -⯿", neutralDirCheck = new RegExp("[" + neutral_chars + "]+");
        function isTextNeutral(e) {
          return neutralDirCheck.test(e);
        }
        var markRTL = "‏", arabic_range = new RegExp("^[" + neutral_chars + "؀-ۿ]+"), arabic_splitters = new RegExp("[" + neutral_chars + "آ-إاد-زوٱ-ٷڈ-ڙۄ-ۋۏےۓۮۯ]"), arabic_vowels = new RegExp("^[ؐ-ًؚ-ٰٟۖ-ۜ۟-۪ۤۧۨ-ۭ]+"), accents_and_vowels = "[̀-֑ͯ-ׇֽֿׁׂׅׄަ-ްऀ-ःऺ-ौॎॏ॑-ॗॢॣঁ-ঃ়া-ৌৗৢৣਁ-ਃ਼-ੌੑઁ-ઃ઼ા-ૌૢૣଁ-ଃ଼ା-ୌୖୗୢୣஂா-்ௗఀ-ఃా-ౌౕౖౢౣಁ-ಃ಼ಾ-ೌೕೖೢೣഁ-ഃാ-ൌൎൗൢൣංඃ්-ෟෲෳัิ-ฺ็-๎ັິ-ຼ່-ໍ༹༘༙༵༷༾༿ཱ-ྃ྆྇ྍ-ྼ࿆ါ-း်-ှၖ-ၙၞ-ၠၢ-ၤၧ-ၭၱ-ၴႂ-ႍႏႚ-ႝ឴-៑៓ᩕ-ᩞᩡ-᩼᷀-᷿⃐-⃿]", combo_characters = "[्্੍્୍్್്྄္្᩠᩿]", graphemeRegex = new RegExp("^.(?:" + accents_and_vowels + "+)?(" + combo_characters + "\\W(?:" + accents_and_vowels + "+)?)*"), curve_blacklist = { Mongolian: "᠀-᢯" }, curve_blacklist_range = Object.keys(curve_blacklist).map(function(e) {
          return curve_blacklist[e];
        }).join(""), curve_blacklist_test = new RegExp("[" + curve_blacklist_range + "]");
        function isTextCurveBlacklisted(e) {
          return curve_blacklist_test.test(e);
        }
        var default_segment_length = 2;
        function splitLabelText(e, t2) {
          var r = t2 ? 1 : default_segment_length;
          if (e.length < r)
            return [e];
          var i2 = e;
          if (CanvasText.cache.segment[i2])
            return CanvasText.cache.stats.segment_hits++, CanvasText.cache.segment[i2];
          var n = [];
          if (arabic_range.exec(e)) {
            n = e.split(arabic_splitters);
            for (var o, a2 = -1, s = 0; s < n.length - 1; s++) {
              0 < s && ((o = arabic_vowels.exec(n[s])) && (n[s] = n[s].substring(o[0].length), n[s - 1] += o[0], a2 += o[0].length)), a2 += 1 + n[s].length, n[s] += e.slice(a2, a2 + 1);
            }
            e = "";
          }
          for (; e.length; ) {
            for (var l = "", u2 = e, c2 = 0; c2 < r && u2.length; c2++) {
              var h = (graphemeRegex.exec(u2) || u2)[0];
              l += h, u2 = u2.substring(h.length);
            }
            n.push(l), e = e.substring(l.length);
          }
          return t2 && n.reverse(), CanvasText.cache.stats.segment_misses++, CanvasText.cache.segment[i2] = n;
        }
        var MultiLine = function() {
          function _(e) {
            var t2 = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 1 / 0, r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : 1 / 0;
            _classCallCheck(this, _), this.width = 0, this.height = 0, this.lines = [], this.max_lines = t2, this.text_wrap = r, this.context = e;
          }
          return _createClass(_, [{ key: "createLine", value: function(e) {
            return this.lines.length < this.max_lines && new Line(e, this.text_wrap);
          } }, { key: "push", value: function(e) {
            if (this.lines.length < this.max_lines) {
              var t2 = this.context.measureText(e.text).width;
              return (e.width = t2) > this.width && (this.width = Math.ceil(t2)), this.lines.push(e), this.height += e.height, true;
            }
            return this.addEllipsis(), false;
          } }, { key: "advance", value: function(e, t2) {
            return !!this.push(e) && this.createLine(t2);
          } }, { key: "addEllipsis", value: function() {
            var e = this.lines[this.lines.length - 1], t2 = Math.ceil(this.context.measureText(_.ellipsis).width);
            e.append(_.ellipsis), e.width += t2, e.width > this.width && (this.width = e.width);
          } }, { key: "finish", value: function(e) {
            e ? this.push(e) : this.addEllipsis();
          } }], [{ key: "parse", value: function(e, t2, r, i2, n) {
            for (var o = "number" == typeof t2 ? e.split(" ") : [e], a2 = new _(n, r, t2), s = a2.createLine(i2), l = 0; l < o.length; l++) {
              for (var u2 = o[l].split("\n"), c2 = 0 === l, h = 0; h < u2.length && s; h++) {
                var f2 = u2[h];
                isTextRTL(f2) && isTextNeutral(f2[f2.length - 1]) && (f2 += markRTL);
                var d = c2 ? f2 : " " + f2;
                if (t2 && 0 < l && s.exceedsTextwrap(d)) {
                  if (!(s = a2.advance(s, i2)))
                    break;
                  s.append(f2), c2 = true;
                } else
                  s.append(d);
                h < u2.length - 1 && (s = a2.advance(s, i2), c2 = true);
              }
              l === o.length - 1 && a2.finish(s);
            }
            return a2;
          } }]), _;
        }();
        MultiLine.ellipsis = "...";
        var Line = function() {
          function r() {
            var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 0, t2 = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 0;
            _classCallCheck(this, r), this.chars = 0, this.text = "", this.height = Math.ceil(e), this.text_wrap = t2;
          }
          return _createClass(r, [{ key: "append", value: function(e) {
            this.chars += e.length, this.text += e;
          } }, { key: "exceedsTextwrap", value: function(e) {
            return e.length + this.chars > this.text_wrap;
          } }]), r;
        }(), TextLabels = { resetText: function() {
          this.texts = {};
        }, freeText: function(e) {
          delete this.texts[e.id];
        }, parseTextFeature: function(e, t2, r, i2) {
          var n = this.parseTextSource(e, t2, r);
          if (null != n && "" !== n) {
            var o = TextSettings$1.compute(e, t2, r);
            if (o) {
              var a2 = TextSettings$1.key(o);
              this.texts[i2.id] = this.texts[i2.id] || {};
              var s = this.texts[i2.id][a2] = this.texts[i2.id][a2] || {};
              if (n instanceof Object) {
                var l = [], u2 = n.left + "-" + n.right;
                for (var c2 in n) {
                  var h, f2 = n[c2];
                  f2 && (h = this.computeTextLayout({}, e, t2, r, i2, f2, o, u2, c2), s[f2] || (s[f2] = { text_settings: o, ref: 0 }), l.push({ draw: t2, text: f2, text_settings_key: a2, layout: h }));
                }
                return 0 < l.length && l;
              }
              var d = this.computeTextLayout({}, e, t2, r, i2, n, o);
              return s[n] || (s[n] = { text_settings: o, ref: 0 }), { draw: t2, text: n, text_settings_key: a2, layout: d };
            }
          }
        }, parseTextSource: function(e, t2, r) {
          var i2, n = t2.text_source || "name";
          if (null != n && "object" === _typeof(n))
            for (var o in i2 = {}, n)
              i2[o] = this.parseTextSourceValue(n[o], e, r);
          else
            i2 = this.parseTextSourceValue(n, e, r);
          return i2;
        }, parseTextSourceValue: function(e, t2, r) {
          var i2;
          if (Array.isArray(e)) {
            for (var n = 0; n < e.length; n++)
              if ("string" == typeof e[n] ? i2 = t2.properties[e[n]] : "function" == typeof e[n] && (i2 = e[n](r)), i2)
                return i2;
          } else
            "string" == typeof e ? i2 = t2.properties[e] : e instanceof Function && (i2 = e(r));
          return i2;
        }, prepareTextLabels: function(r, e, i2) {
          var n = this;
          return 0 === Object.keys(this.texts[r.id] || {}).length ? Promise.resolve([]) : WorkerBroker.postMessage(this.main_thread_target + ".calcTextSizes", r.id, this.texts[r.id]).then(function(e2) {
            var t2 = e2.texts;
            return r.canceled ? (log("trace", "Style ".concat(n.name, ": stop tile build because tile was canceled: ").concat(r.key, ", post-calcTextSizes()")), []) : (n.texts[r.id] = t2 || [], t2 ? n.buildTextLabels(r, i2) : (Collision.abortTile(r.id), []));
          });
        }, collideAndRenderTextLabels: function(t2, r, e) {
          var n = this;
          return this.prepareTextLabels(t2, r, e).then(function(e2) {
            return 0 === e2.length ? (Collision.collide([], r, t2.id), Promise.resolve({})) : Collision.collide(e2, r, t2.id).then(function(e3) {
              if (t2.canceled)
                return log("trace", "stop tile build because tile was canceled: ".concat(t2.key, ", post-collide()")), {};
              var i2 = n.texts[t2.id];
              return null == i2 || 0 === e3.length ? {} : (n.cullTextStyles(i2, e3), e3.forEach(function(e4) {
                var t3 = e4.text_settings_key, r2 = i2[t3] && i2[t3][e4.text];
                r2.text_settings.can_articulate ? (r2.type || (r2.type = []), -1 === r2.type.indexOf(e4.label.type) && r2.type.push(e4.label.type)) : (r2.align = r2.align || {}, r2.align[e4.label.align] = {});
              }), { labels: e3, texts: i2, textures: [] });
            });
          });
        }, cullTextStyles: function(e, t2) {
          for (var r = 0; r < t2.length; r++) {
            var i2 = t2[r];
            e[i2.text_settings_key][i2.text].ref++;
          }
          for (var n in e)
            for (var o in e[n])
              e[n][o].ref < 1 && delete e[n][o];
          for (var a2 in e)
            0 === Object.keys(e[a2]).length && delete e[a2];
        }, calcTextSizes: function(e, t2) {
          return this._canvas_text || (this._canvas_text = new CanvasText(), this._canvas_ctx_for_sizes = this._canvas_text.createCanvas().getContext("2d")), this._canvas_text.textSizes(e, t2, this._canvas_ctx_for_sizes);
        }, preprocessText: function(e) {
          if (e && e.font && "object" === _typeof(e.font))
            return e.font.fill = StyleParser.createPropertyCache(e.font.fill), e.font.stroke && (e.font.stroke.color = StyleParser.createPropertyCache(e.font.stroke.color)), e.background && e.background.color && (e.background.color = StyleParser.createPropertyCache(e.background.color)), e.outline && (e.outline.color && (e.outline.color = StyleParser.createPropertyCache(e.outline.color)), e.outline.width && (e.outline.width = StyleParser.createPropertyCache(e.outline.width, StyleParser.parsePositiveNumber))), e.padding && (Array.isArray(e.padding) ? 2 === e.padding.length && (e.padding = [e.padding[0], e.padding[1], e.padding[0], e.padding[1]]) : e.padding = Array(4).fill(e.padding), e.padding = StyleParser.createPropertyCache(e.padding, function(e2) {
              return e2.map(StyleParser.parsePositiveNumber);
            })), e.font.px_size = StyleParser.createPropertyCache(e.font.size || TextSettings$1.defaults.size, CanvasText.fontPixelSize), e.font.stroke && null != e.font.stroke.width && (e.font.stroke.width = StyleParser.createPropertyCache(e.font.stroke.width, StyleParser.parsePositiveNumber)), e.offset = StyleParser.createPropertyCache(e.offset, function(e2) {
              return Array.isArray(e2) && e2.map(StyleParser.parseNumber);
            }), e.buffer = StyleParser.createPropertyCache(e.buffer, function(e2) {
              return (Array.isArray(e2) ? e2 : [e2, e2]).map(StyleParser.parsePositiveNumber);
            }), e.repeat_distance = StyleParser.createPropertyCache(e.repeat_distance || Geo$1.tile_size, StyleParser.parsePositiveNumber), e;
        }, computeTextLayout: function(e, t2, r, i2, n, o, a2, s, l) {
          var u2 = e || {};
          return (u2 = this.computeLayout(u2, t2, r, i2, n)).repeat_distance && (s && (u2.repeat_group += "/" + s), u2.repeat_group += "/" + o), u2.subdiv = n.overzoom2, u2.align = r.align, u2.italic = "normal" !== a2.style, "right" === l ? u2.orientation = 1 : "left" === l && (u2.orientation = -1), u2;
        } };
        function degToRad(e) {
          return e * Math.PI / 180;
        }
        var PI_OVER_180 = Math.PI / 180, HORIZON_THRESHOLD_MULTIPLIER = 0.75, ZOOM_FOR_BOUNDS_EPSILON = 1e-3, NEAR_PLANE = 1, LookAtManipulator = function() {
          function r(e, t2) {
            _classCallCheck(this, r), this._min_zoom = H.util.constants.DEFAULT_MIN_ZOOM_LEVEL, this._max_zoom = H.util.constants.DEFAULT_MAX_ZOOM_LEVEL, this._viewport = e, this._center_offset = [], this._center_offset_normalized = [], this._viewport_aspect_ratio = 1, this._focal_length = [[16, 2], [17, 2.5], [18, 3], [19, 4], [20, 6]], this._view_matrix = new Float64Array(16), this._projection_matrix = new Float64Array(16), this._heading_matrix = new Float64Array(16), this._tilt_matrix = new Float64Array(16), this._transformation_matrix = new Float64Array(16), this._camera_matrix = new Float64Array(16), this._lookAtData = { position: [0, 0, 0], zoom: 0, tile_level: 0, tetragon: void 0, bounds: void 0, unpadded_bounds: void 0, distance: void 0, tilt: 0, incline: 0, heading: 180 }, this._zoom_direction = 0, this._horizon = 0, this.handleViewportUpdate(true), t2 ? this.setLookAtData(t2) : this._updateMatrices(), ShaderProgram.replaceBlock("camera", "\n            uniform mat4 u_projection;\n            uniform vec3 u_eye;\n            uniform vec2 u_center_offset;\n\n            void cameraProjection (inout vec4 position) {\n                position = u_projection * position;\n            }");
          }
          return _createClass(r, [{ key: "getZoomForBounds", value: function(a2, e, s, l) {
            var t2, u2 = this.clone(), c2 = this._max_zoom, h = this._min_zoom, f2 = (c2 - h) / 2, d = c2 - f2, _ = e, r2 = MathUtils$1.getBBoxCenter(MathUtils$1.getBBox(a2));
            void 0 === _ ? _ = r2 : (t2 = r2[0] - _[0], Math.abs(t2) > Geo$1.half_circumference_meters + 1e-8 && (_[0] += Math.round(t2 / Geo$1.circumference_meters) * Geo$1.circumference_meters));
            for (; ZOOM_FOR_BOUNDS_EPSILON < f2; )
              !function() {
                u2.setLookAtData({ zoom: d, position: _, tilt: s, heading: l });
                var e2, t3, r3, i2, n, o = u2.getLookAtData().bounds;
                a2.every(function(e3) {
                  return MathUtils$1.isPointInsidePolygon(e3, o);
                }) ? h = d : (t3 = (e2 = _slicedToArray(MathUtils$1.getBBox(o), 4))[0], r3 = e2[1], i2 = e2[2], n = e2[3], i2 - t3 + 1e-8 >= Geo$1.circumference_meters && n - r3 + 1e-8 >= Geo$1.circumference_meters ? h = d : c2 = d), d = c2 - (f2 = (c2 - h) / 2);
              }();
            return h;
          } }, { key: "setZoomConstraints", value: function(e, t2) {
            this._min_zoom = e, this._max_zoom = t2, this.setLookAtData(this.getLookAtData());
          } }, { key: "setLookAtData", value: function(e, t2) {
            var r2, i2, n, o, a2, s = e.position, l = e.zoom;
            s === r2 && e.bounds !== r2 && (s = MathUtils$1.getBBoxCenter(MathUtils$1.getBBox(e.bounds))), l === r2 && e.bounds !== r2 && (l = this.getZoomForBounds(e.bounds, s, e.tilt, e.heading)), t2 !== r2 && (i2 = s || this.screenToWorld(t2)), l !== r2 && (l = MathUtils$1.clamp(l, this._min_zoom, this._max_zoom), (n = Utils$1.zoomToTileLevel(l)) !== (o = this._lookAtData.tile_level) && (this._zoom_direction = o < n ? 1 : -1), this._lookAtData.zoom = l, this._lookAtData.tile_level = n), e.tilt !== r2 && (this._lookAtData.tilt = e.tilt), e.heading !== r2 && (this._lookAtData.heading = e.heading), t2 !== r2 ? (this._updateMatrices(), a2 = this.screenToWorld(t2), this._lookAtData.position[0] -= a2[0] - i2[0], this._lookAtData.position[1] -= a2[1] - i2[1]) : s && (this._lookAtData.position = s), this._lookAtData.position[2] = 0, this._lookAtData.position[1] = MathUtils$1.clamp(this._lookAtData.position[1], -Geo$1.half_circumference_meters, Geo$1.half_circumference_meters), this._updateMatrices(), this._updateVisibleBounds();
          } }, { key: "getZoomDirection", value: function() {
            return this._zoom_direction;
          } }, { key: "resetZoomDirection", value: function() {
            this._zoom_direction = 0;
          } }, { key: "getLookAtData", value: function() {
            return this._lookAtData;
          } }, { key: "handleViewportUpdate", value: function(e) {
            var t2 = 0 < arguments.length && void 0 !== e && e, r2 = this._viewport, i2 = r2.width, n = r2.height;
            this._viewport_aspect_ratio = i2 / n;
            var o = this._viewport.center.x - (i2 / 2 << 0), a2 = this._viewport.center.y - (n / 2 << 0);
            this._center_offset[0] = o, this._center_offset[1] = a2, this._center_offset_normalized[0] = o / i2, this._center_offset_normalized[1] = a2 / -n, t2 || (this._updateMatrices(), this._updateVisibleBounds());
          } }, { key: "setupMatrices", value: function(e, t2) {
            mat4.multiply(e.model_view32, this._view_matrix, e.model), t2.uniform("Matrix4fv", "u_modelView", e.model_view32), mat3.normalFromMat4(e.normal32, e.model_view32), mat3.invert(e.inverse_normal32, e.normal32), t2.uniform("Matrix3fv", "u_normalMatrix", e.normal32), t2.uniform("Matrix3fv", "u_inverseNormalMatrix", e.inverse_normal32);
          } }, { key: "_updateMatrices", value: function() {
            var e = this._viewport.height * Geo$1.metersPerPixel(this._lookAtData.zoom), t2 = Utils$1.interpolate(this._lookAtData.zoom, this._focal_length);
            this._lookAtData.distance = e / 2 * t2;
            var r2 = this._lookAtData.position[0], i2 = this._lookAtData.position[1];
            mat4.lookAt(this._view_matrix, vec3.fromValues(r2, i2, 0), vec3.fromValues(r2, i2, -1), vec3.fromValues(0, 1, 0)), this._heading_matrix = mat4.identity(this._heading_matrix);
            var n = 180 - this._lookAtData.heading;
            n *= PI_OVER_180, this._heading_matrix[0] = Math.cos(n), this._heading_matrix[1] = -Math.sin(n), this._heading_matrix[4] = Math.sin(n), this._heading_matrix[5] = Math.cos(n), this._tilt_matrix = mat4.identity(this._tilt_matrix), n = 0 < (n = this._lookAtData.tilt ? this._lookAtData.tilt * PI_OVER_180 : 0) ? -n : n, this._tilt_matrix[5] = Math.cos(n), this._tilt_matrix[6] = Math.sin(n), this._tilt_matrix[9] = -Math.sin(n), this._tilt_matrix[10] = Math.cos(n), mat4.multiply(this._transformation_matrix, this._tilt_matrix, this._heading_matrix), mat4.multiply(this._view_matrix, this._transformation_matrix, this._view_matrix);
            var o = 2 * Math.atan(1 / t2), a2 = 2 * this._lookAtData.distance;
            this._depth_buffer_adjustment = 2 / Math.log(a2 / NEAR_PLANE), mat4.perspective(this._projection_matrix, o, this._viewport_aspect_ratio, NEAR_PLANE, a2), this._projection_matrix[8] = 2 * -this._center_offset_normalized[0], this._projection_matrix[9] = 2 * -this._center_offset_normalized[1], mat4.translate(this._projection_matrix, this._projection_matrix, vec3.fromValues(0, 0, -this._lookAtData.distance)), this._camera_matrix = mat4.multiply(this._camera_matrix, this._projection_matrix, this._view_matrix);
          } }, { key: "_updateVisibleBounds", value: function() {
            var e, t2, r2, i2, n, o = this._viewport, a2 = o.width, s = o.height, l = o.padding, u2 = degToRad(this._lookAtData.tilt);
            this._horizon = Math.max((l.top + s) / 2 - Math.cos(u2) * (l.top * (1 - Math.sin(u2)) + s * HORIZON_THRESHOLD_MULTIPLIER), 0), this._lookAtData.tetragon = [this.screenToWorld([0, this._horizon]), this.screenToWorld([a2, this._horizon]), this.screenToWorld([a2, s]), this.screenToWorld([0, s])], this._lookAtData.unpadded_bounds = this._clipAgainstGeoBounds(this._lookAtData.tetragon), 0 === l.left && 0 === l.top && 0 === l.right && 0 === l.bottom ? this._lookAtData.bounds = this._lookAtData.unpadded_bounds : (e = l.left, t2 = Math.max(this._horizon, l.top), r2 = a2 - l.right, i2 = s - l.bottom, n = [this.screenToWorld([e, t2]), this.screenToWorld([r2, t2]), this.screenToWorld([r2, i2]), this.screenToWorld([e, i2])], this._lookAtData.bounds = this._clipAgainstGeoBounds(n));
          } }, { key: "_clipAgainstGeoBounds", value: function(e) {
            var t2, r2 = _slicedToArray(MathUtils$1.getBBox(e), 4), i2 = r2[0], n = r2[1], o = r2[2], a2 = r2[3], s = Geo$1.half_circumference_meters, l = [[i2 - 1, +s], [o + 1, +s], [o + 1, -s], [i2 - 1, -s]], u2 = MathUtils$1.clipPolygon(l, e)[0], c2 = _slicedToArray(MathUtils$1.getBBox(u2), 4), i2 = c2[0], n = c2[1], o = c2[2], a2 = c2[3];
            o - i2 >= Geo$1.circumference_meters && (u2 = [[(t2 = (o - i2) / 2) - s, a2], [t2 + s, a2], [t2 + s, n], [t2 - s, n]]);
            var h = [];
            return u2 && (h = MathUtils$1.splitLegs(u2, s)), h;
          } }, { key: "applyPxOffset", value: function(e) {
            var t2 = _slicedToArray(e, 2), r2 = t2[0], i2 = t2[1], n = Math.PI - this._lookAtData.heading * PI_OVER_180, o = Geo$1.metersPerPixel(this._lookAtData.zoom);
            this._lookAtData.position[0] += (r2 * Math.cos(n) + i2 * Math.sin(n)) * o, this._lookAtData.position[1] -= (i2 * Math.cos(n) - r2 * Math.sin(n)) * o, this._lookAtData.position[1] = MathUtils$1.clamp(this._lookAtData.position[1], -Geo$1.half_circumference_meters, Geo$1.half_circumference_meters), this._updateMatrices(), this._updateVisibleBounds();
          } }, { key: "screenToWorld", value: function(e) {
            var t2 = _slicedToArray(e, 2), r2 = t2[0], i2 = t2[1], n = this._viewport, o = n.width, a2 = n.height;
            return 0 === o || 0 === a2 ? [0, 0] : (r2 -= o / 2, i2 -= a2 / 2, this._clipCoordsToWorldPlaneCoords([2 * (r2 + o / 2) / o - 1, 1 - 2 * (i2 + a2 / 2) / a2, -1, 1]));
          } }, { key: "_clipToScreenCoords", value: function(e) {
            var t2 = this._viewport, r2 = t2.width, i2 = t2.height;
            return [(0.5 * e[0] + 0.5) * r2, i2 - (0.5 * e[1] + 0.5) * i2];
          } }, { key: "_isScreenPointInViewPort", value: function(e) {
            var t2 = this._viewport, r2 = t2.width, i2 = t2.height;
            return 0 <= e[0] && e[0] <= r2 && 0 <= e[1] && e[1] <= i2;
          } }, { key: "worldToScreen", value: function(e, t2) {
            var r2, i2, n, o, a2, s, l = 1 < arguments.length && void 0 !== t2 && t2;
            return e[2] || (e[2] = 0), l ? (r2 = this._worldToClipCoords(e), a2 = this._clipToScreenCoords(r2)) : (i2 = Math.sign(this._lookAtData.position[0]), n = Math.trunc(this._lookAtData.position[0] / Geo$1.circumference_meters + i2 / 2), e[0] += Geo$1.circumference_meters * n, o = this._worldToClipCoords(e), s = a2 = this._clipToScreenCoords(o), this._isScreenPointInViewPort(a2) || (o = this._worldToClipCoords([e[0] + Geo$1.circumference_meters, e[1], e[2]]), a2 = this._clipToScreenCoords(o), this._isScreenPointInViewPort(a2) || (o = this._worldToClipCoords([e[0] - Geo$1.circumference_meters, e[1], e[2]]), a2 = this._clipToScreenCoords(o)), this._isScreenPointInViewPort(a2) || (a2 = s))), a2;
          } }, { key: "getHorizon", value: function() {
            return this._horizon;
          } }, { key: "_clipCoordsToWorldPlaneCoords", value: function(e) {
            var t2 = [], r2 = this._lookAtData.distance, i2 = this._lookAtData.position, n = [0, 0, r2, 0], o = 0, a2 = r2 * Math.sin(PI_OVER_180 * this._lookAtData.tilt) * Math.cos(PI_OVER_180 * this._lookAtData.heading), s = r2 * Math.sin(PI_OVER_180 * this._lookAtData.tilt) * Math.sin(PI_OVER_180 * this._lookAtData.heading), l = new Float64Array(16), u2 = new Float64Array(16);
            return mat4.invert(l, this._projection_matrix), vec4.transformMat4(t2, e, l), t2[2] = -1, t2[3] = 0, mat4.invert(u2, this._view_matrix), vec4.transformMat4(t2, t2, u2), vec4.normalize(t2, t2), vec4.transformMat4(n, n, this._transformation_matrix), 0 !== t2[2] && (o = -n[2] / t2[2]), vec4.scale(t2, t2, o), [i2[0] + (t2[0] + s), i2[1] + (t2[1] + a2)];
          } }, { key: "_worldToClipCoords", value: function(e) {
            var t2 = [e[0], e[1], e[2], 1];
            return vec4.transformMat4(t2, t2, this._view_matrix), vec4.transformMat4(t2, t2, this._projection_matrix), vec4.scale(t2, t2, 1 / t2[3]), t2;
          } }, { key: "setupProgram", value: function(e) {
            e.uniform("Matrix4fv", "u_projection", this._projection_matrix), e.uniform("3f", "u_eye", [0, 0, this._lookAtData.distance]), e.uniform("2fv", "u_center_offset", this._center_offset_normalized), e.uniform("1f", "u_tilt", this._lookAtData.tilt * PI_OVER_180), e.uniform("1f", "u_heading", this._lookAtData.heading * PI_OVER_180), e.uniform("1f", "u_near_plane", NEAR_PLANE), e.uniform("1f", "u_depth_buffer_adjustment", this._depth_buffer_adjustment);
          } }, { key: "getTransformationMatrix", value: function() {
            return this._transformation_matrix;
          } }, { key: "getCameraMatrix", value: function() {
            return this._camera_matrix;
          } }, { key: "clone", value: function() {
            var e = new r(this._viewport, this._lookAtData);
            return e.setZoomConstraints(this._min_zoom, this._max_zoom), e;
          } }, { key: "getViewport", value: function() {
            return this._viewport;
          } }]), r;
        }();
        function getX(e) {
          return void 0 === e.x ? e[0] : e.x;
        }
        function getY(e) {
          return void 0 === e.y ? e[1] : e.y;
        }
        function xAscendingComparator(e, t2) {
          return getX(e) - getX(t2);
        }
        function yAscendingComparator(e, t2) {
          return getY(e) - getY(t2);
        }
        function sortByX(e) {
          return e.sort(xAscendingComparator);
        }
        function sortByY(e) {
          return e.sort(yAscendingComparator);
        }
        function getMinMax(e, t2) {
          for (var r, i2 = e[0], n = i2, o = 0; o < e.length; o += 1)
            t2(r = e[o], i2) < 0 ? i2 = r : 0 < t2(r, n) && (n = r);
          return [i2, n];
        }
        function groupByCoord(i2, e) {
          return Object.values(e.reduce(function(e2, t2) {
            var r = t2[+i2];
            return e2[r] || (e2[r] = []), e2[r].push(t2), e2;
          }, {}));
        }
        function groupByX(e) {
          return groupByCoord(false, e);
        }
        function groupByY(e) {
          return groupByCoord(true, e);
        }
        function createTileRangeByCoord(e, t2, r) {
          var i2 = +e, n = t2[i2], o = r[i2];
          if (o < n)
            return [];
          var a2 = [t2];
          if (o < n)
            return a2;
          for (var s = t2[(1 + i2) % 2], l = e ? function(e2) {
            return a2.push([s, e2]);
          } : function(e2) {
            return a2.push([e2, s]);
          }, u2 = n + 1; u2 < o; u2 += 1)
            l(u2);
          return a2.push(r), a2;
        }
        function createTileRangeByX(e, t2) {
          return createTileRangeByCoord(false, e, t2);
        }
        function createTileRangeByY(e, t2) {
          return createTileRangeByCoord(true, e, t2);
        }
        function deduplicate(e) {
          var r = {}, i2 = [];
          return e.forEach(function(e2) {
            var t2 = e2.key || (Array.isArray(e2) ? "".concat(e2[0], "/").concat(e2[1]) : "".concat(e2.x, "/").concat(e2.y));
            r[t2] || (r[t2] = true, i2.push(e2));
          }), i2;
        }
        function flat(e) {
          return e.reduce(function(e2, t2) {
            return e2.concat(t2);
          });
        }
        function applyMargin(e, a2) {
          if (a2 <= 0)
            return e;
          var t2, r = function(e2) {
            var t3 = _slicedToArray(getMinMax(e2, xAscendingComparator), 2), r2 = t3[0], i3 = t3[1], n = [r2[0] - a2, r2[1]], o = [i3[0] + a2, i3[1]];
            return e2.concat(createTileRangeByX(n, r2), createTileRangeByX(i3, o));
          }, i2 = function(e2) {
            var t3 = _slicedToArray(getMinMax(e2, yAscendingComparator), 2), r2 = t3[0], i3 = t3[1], n = [r2[0], r2[1] - a2], o = [i3[0], i3[1] + a2];
            return e2.concat(createTileRangeByY(n, r2), createTileRangeByY(i3, o));
          };
          return deduplicate((t2 = groupByY(flat(groupByX(e).map(i2))), flat(t2.map(r))));
        }
        function constructTiles(e, n, o) {
          return e.map(function(e2) {
            var t2 = _slicedToArray(e2, 2), r = t2[0], i2 = t2[1];
            return Tile.coord(Geo$1.wrapTile({ x: r, y: i2, z: n }, { x: !o, y: true }));
          });
        }
        function getTileGrid(t2, e, r) {
          function i2(e2) {
            return Object.values(Geo$1.metersToExactTileCoords(e2, t2.tile_level));
          }
          return deduplicate(constructTiles(applyMargin(rasterizeTetragon(i2(t2.tetragon[0]), i2(t2.tetragon[1]), i2(t2.tetragon[3]), i2(t2.tetragon[2])), e), t2.tile_level, r));
        }
        function rasterizeTetragon(e, t2, r, i2) {
          var n = rasterizeTriangle(t2, e, r), o = rasterizeTriangle(r, i2, t2);
          return deduplicate(n.concat(o));
        }
        function rasterizeTriangle(e, t2, r) {
          var i2 = _slicedToArray(sliceTriangle.apply(void 0, _toConsumableArray(sortByY([e, t2, r]))), 2), n = i2[0], o = i2[1];
          return deduplicate(rasterizeBottomFlatTriangle.apply(void 0, _toConsumableArray(n)).concat(rasterizeTopFlatTriangle.apply(void 0, _toConsumableArray(o))));
        }
        function sliceTriangle(e, t2, r) {
          var i2 = _slicedToArray(e, 2), n = i2[0], o = i2[1], a2 = _slicedToArray(t2, 2), s = a2[0], l = a2[1], u2 = _slicedToArray(r, 2), c2 = u2[0], h = u2[1], f2 = n + (l - o) / (h - o) * (c2 - n);
          return [[[n, o]].concat(_toConsumableArray(sortByX([[s, l], [f2, l]]))), [].concat(_toConsumableArray(sortByX([[s, l], [f2, l]])), [[c2, h]])];
        }
        function rasterizeBottomFlatTriangle(e, t2, r) {
          var i2 = _slicedToArray(e, 2), n = i2[0], o = i2[1], a2 = _slicedToArray(t2, 2), s = a2[0], l = a2[1];
          return scanFlatTriangle(n, s, _slicedToArray(r, 1)[0], o, l);
        }
        function rasterizeTopFlatTriangle(e, t2, r) {
          var i2 = _slicedToArray(e, 2), n = i2[0], o = i2[1], a2 = _slicedToArray(t2, 1)[0], s = _slicedToArray(r, 2);
          return scanFlatTriangle(s[0], n, a2, s[1], o);
        }
        var scanStepStatic = 0.125;
        function getScanStep(e, t2) {
          return scanStepStatic * (t2 - e) / (Math.ceil(t2) - Math.floor(e));
        }
        function scanFlatTriangle(e, t2, r, i2, n) {
          var o = Math.min(e, t2), a2 = Math.max(e, r), s = Math.min(i2, n), l = Math.max(i2, n);
          if (Math.floor(i2) === Math.floor(n))
            return scanRow(o, a2, i2);
          if (l - s < scanStepStatic)
            return scanRectangle([o, s], [a2, l]);
          function u2(e2) {
            _ = _.concat(scanRow(p2, g, Math.floor(e2))), p2 += f2, g += d;
          }
          var c2 = getScanStep(s, l), h = (l - s) / c2, f2 = (t2 - e) / h, d = (r - e) / h, _ = [], p2 = e, g = e;
          if (i2 < n)
            for (var m = s; m <= l; m += c2)
              u2(m);
          else
            for (var y = l; s <= y; y -= c2)
              u2(y);
          return deduplicate(_);
        }
        function xCoordsToPoints(e, t2) {
          return e.map(function(e2) {
            return [e2, t2];
          });
        }
        function createCoordRange(e, t2) {
          var r = Math.floor(e), i2 = Math.floor(t2);
          if (i2 < r)
            return [];
          if (r === i2)
            return [r];
          for (var n = [], o = r; o <= i2; o += 1)
            n.push(o);
          return n;
        }
        function scanRow(e, t2, r) {
          return xCoordsToPoints(createCoordRange(e, t2), r);
        }
        function scanRectangle(e, t2) {
          var r = _slicedToArray(e, 2), i2 = r[0], n = r[1], o = _slicedToArray(t2, 2), a2 = o[0], s = o[1], l = createCoordRange(i2, a2), u2 = xCoordsToPoints(l, n), c2 = xCoordsToPoints(l, s);
          return u2.concat(c2);
        }
        var VIEW_PAN_SNAP_TIME = 0.5, Z_PRECISION = 1e5, View = function() {
          function o(e, t2) {
            _classCallCheck(this, o), subscribeMixin(this), this.scene = e, this.createMatrices(), this.bounds = null, this.center_tile = null, this.panning = false, this.panning_stop_at = 0, this.pan_snap_timer = 0, this.user_input_at = 0, this.user_input_timeout = 50, this.user_input_active = false, this.size = {}, this.buffer = 0, this.wrap = false !== t2.wrapView, this.preserve_tiles_within_zoom = 1, this.lookAtManipulator = new LookAtManipulator(t2.viewport), this._viewport = t2.viewport, this._offset_buffer = [0, 0], this.handleViewportUpdate(true);
          }
          return _createClass(o, [{ key: "update", value: function() {
            this.pan_snap_timer = (/* @__PURE__ */ new Date() - this.panning_stop_at) / 1e3, this.user_input_active = /* @__PURE__ */ new Date() - this.user_input_at < this.user_input_timeout, this.scene.tile_manager.updateTilesVisibilityCounters();
          } }, { key: "handleViewportUpdate", value: function(e) {
            var t2 = 0 < arguments.length && void 0 !== e && e, r = this._viewport, i2 = r.width, n = r.height;
            this.size.css = { width: i2, height: n }, this.size.device = { width: Math.round(i2 * Utils$1.device_pixel_ratio), height: Math.round(n * Utils$1.device_pixel_ratio) }, this.lookAtManipulator.handleViewportUpdate(), t2 || this.updateBounds();
          } }, { key: "setLookAtData", value: function(e, t2) {
            o._setLookAtDataForManipulator(this.lookAtManipulator, e, t2), this.updateBounds();
          } }, { key: "getLookAtData", value: function(e) {
            var t2 = 0 < arguments.length && void 0 !== e && e;
            return o._getLookAtDataFromManipulator(this.lookAtManipulator, t2);
          } }, { key: "getBestLookAtData", value: function(e, t2, r) {
            var i2 = 2 < arguments.length && void 0 !== r && r, n = this.lookAtManipulator.clone();
            return o._setLookAtDataForManipulator(n, e, t2), o._getLookAtDataFromManipulator(n, i2);
          } }, { key: "getTileLevel", value: function() {
            return this.lookAtManipulator.getLookAtData().tile_level;
          } }, { key: "applyPxOffset", value: function(e) {
            var t2 = this._offset_buffer;
            t2[0] += e[0], t2[1] += e[1];
            var r, i2, n = Math.abs(t2[0]), o2 = Math.abs(t2[1]);
            (1 <= n || 1 <= o2) && (r = ~~t2[0], i2 = ~~t2[1], this.lookAtManipulator.applyPxOffset([n < 1 ? 0 : r, o2 < 1 ? 0 : i2]), 1 <= n && (t2[0] -= r), 1 <= o2 && (t2[1] -= i2), this.updateBounds());
          } }, { key: "setPanning", value: function(e) {
            this.panning = e, this.panning || (this.panning_stop_at = +/* @__PURE__ */ new Date());
          } }, { key: "markUserInput", value: function() {
            this.user_input_at = +/* @__PURE__ */ new Date();
          } }, { key: "ready", value: function() {
            return "number" == typeof this.size.css.width && "number" == typeof this.size.css.height;
          } }, { key: "updateBounds", value: function() {
            var e, t2;
            this.markUserInput(), this.ready() && (this.center_tile = Geo$1.tileForMeters(this.lookAtManipulator.getLookAtData().position, this.lookAtManipulator.getLookAtData().tile_level), e = this.lookAtManipulator.screenToWorld([0, this.size.css.height]), t2 = this.lookAtManipulator.screenToWorld([this.size.css.width, 0]), this.bounds = { sw: { x: e[0], y: e[1] }, ne: { x: t2[0], y: t2[1] } }, this.scene.tile_manager.updateTilesForView(true), this.trigger("move"), this.scene.requestRedraw());
          } }, { key: "getTileGridFlatForBBox", value: function(e, t2, r, i2, n, o2) {
            var a2, s = 4 < arguments.length && void 0 !== n ? n : 0, l = !(5 < arguments.length && void 0 !== o2) || o2, u2 = this.lookAtManipulator.getLookAtData().tile_level, c2 = Geo$1.tileForMeters([t2, e], u2), h = Geo$1.tileForMeters([i2, r], u2);
            c2.x -= s, c2.y -= s, h.x += s, h.y += s, false === l && (a2 = (1 << u2) - 1, c2.x = Math.min(Math.max(0, c2.x), a2), c2.y = Math.min(Math.max(0, c2.y), a2), h.x = Math.min(Math.max(0, h.x), a2), h.y = Math.min(Math.max(0, h.y), a2));
            for (var f2 = [], d = {}, _ = c2.x; _ <= h.x; _++)
              for (var p2 = c2.y; p2 <= h.y; p2++) {
                var g = Tile.coord(Geo$1.wrapTile({ x: _, y: p2, z: u2 }, { x: !l, y: true }));
                d[g.key] || (d[g.key] = true, f2.push(g));
              }
            return f2;
          } }, { key: "getTileGridFlat", value: function() {
            return this.getTileGridFlatForBBox(this.bounds.ne.y, this.bounds.sw.x, this.bounds.sw.y, this.bounds.ne.x, this.buffer, this.wrap);
          } }, { key: "getTileGridDistorted", value: function() {
            return getTileGrid(this.lookAtManipulator.getLookAtData(), this.buffer, this.wrap);
          } }, { key: "findVisibleTileCoordinates", value: function() {
            if (!this.bounds)
              return [];
            var e = this.lookAtManipulator.getLookAtData(), t2 = e.tilt, r = e.heading;
            return 0 === t2 && 180 === r ? this.getTileGridFlat() : this.getTileGridDistorted();
          } }, { key: "createMatrices", value: function() {
            this.matrices = {}, this.matrices.model = new Float64Array(16), this.matrices.model32 = new Float32Array(16), this.matrices.model_view = new Float64Array(16), this.matrices.model_view32 = new Float32Array(16), this.matrices.normal = new Float64Array(9), this.matrices.normal32 = new Float32Array(9), this.matrices.inverse_normal32 = new Float32Array(9);
          } }, { key: "setupTile", value: function(e, t2) {
            e.setupProgram(this.matrices, t2), this.lookAtManipulator.setupMatrices(this.matrices, t2);
          } }, { key: "setupProgram", value: function(e) {
            var t2 = this.lookAtManipulator.getLookAtData();
            e.uniform("2fv", "u_resolution", [this.size.device.width, this.size.device.height]), e.uniform("3fv", "u_map_position", [t2.position[0], t2.position[1], Math.trunc(t2.zoom * Z_PRECISION) / Z_PRECISION]), e.uniform("1f", "u_meters_per_pixel", Geo$1.metersPerPixel(t2.zoom)), e.uniform("1f", "u_device_pixel_ratio", Utils$1.device_pixel_ratio), e.uniform("1f", "u_view_pan_snap_timer", this.pan_snap_timer), e.uniform("1i", "u_view_panning", this.panning), e.uniform("1f", "u_horizon", this.lookAtManipulator.getHorizon() / (this.size.css.height / 2)), this.lookAtManipulator.setupProgram(e);
          } }, { key: "isAnimating", value: function() {
            return this.pan_snap_timer <= VIEW_PAN_SNAP_TIME;
          } }, { key: "xyToGeo", value: function(e, t2) {
            var r = this.lookAtManipulator.screenToWorld([e, t2]), i2 = _slicedToArray(Geo$1.metersToLatLng(r), 2), n = i2[0];
            return { lat: i2[1], lng: n };
          } }, { key: "geoToPixel", value: function(e) {
            var t2 = Geo$1.latLngToMeters([e.lng, e.lat]);
            t2.push(e.alt || 0);
            var r = this.lookAtManipulator.worldToScreen(t2);
            return { x: Math.floor(r[0]), y: Math.floor(r[1]) };
          } }, { key: "geoToMeters", value: function(e) {
            var t2 = _slicedToArray(Geo$1.latLngToMeters([e.lng, e.lat]), 2);
            return { x: t2[0], y: t2[1], z: e.alt || 0 };
          } }, { key: "metersToGeo", value: function(e) {
            var t2 = _slicedToArray(Geo$1.metersToLatLng([e.x, e.y]), 2), r = t2[0];
            return { lat: t2[1], lng: r, alt: e.z || 0 };
          } }, { key: "setZoomConstraints", value: function(e, t2) {
            this.lookAtManipulator.setZoomConstraints(e, t2);
          } }], [{ key: "_setLookAtDataForManipulator", value: function(e, t2, r) {
            var i2 = t2.position, n = t2.zoom, o2 = t2.tilt, a2 = t2.heading, s = t2.bounds, l = { zoom: n, tilt: o2, heading: a2 };
            if (i2 && "number" == typeof i2.lng && "number" == typeof i2.lat && (l.position = Geo$1.latLngToMeters([i2.lng, i2.lat])), s) {
              var u2 = s.getExterior().getLatLngAltArray(), c2 = u2.length / 3, h = Array(c2);
              if (s.getBoundingBox().isCDB())
                for (var f2 = u2[1], d = 0, _ = 0; _ < c2; _++) {
                  var p2, g = u2[3 * _ + 1];
                  0 < _ && (p2 = g - f2, 180 < Math.abs(p2) && (d += f2 < g ? -360 : 360)), f2 = g, h[_] = Geo$1.latLngToMeters([g + d, u2[3 * _]]);
                }
              else
                for (var m = 0; m < c2; m++)
                  h[m] = Geo$1.latLngToMeters([u2[3 * m + 1], u2[3 * m]]);
              l.bounds = h;
            }
            e.setLookAtData(l, r);
          } }, { key: "_getLookAtDataFromManipulator", value: function(e, t2) {
            var r = 1 < arguments.length && void 0 !== t2 && t2, i2 = e.getLookAtData(), n = i2.heading, o2 = i2.incline, a2 = i2.tilt, s = i2.zoom, l = i2.position, u2 = i2.bounds, c2 = i2.unpadded_bounds, h = _slicedToArray(Geo$1.metersToLatLng(l), 2), f2 = h[0], d = h[1], _ = new H.geo.LineString();
            return (r ? c2 : u2).forEach(function(e2) {
              var t3 = Geo$1.metersToLatLng(e2);
              _.pushLatLngAlt(t3[1], t3[0], 0);
            }), { heading: n, incline: o2, tilt: a2, zoom: s, bounds: new H.geo.Polygon(_), position: { lat: d, lng: f2, alt: l[2] } };
          } }]), o;
        }(), shaderSrc_pointsVertex = "uniform vec2 u_resolution;uniform vec3 u_map_position;uniform vec4 u_tile_origin;uniform float u_tile_proxy_depth;uniform bool u_tile_fade_in;uniform float u_meters_per_pixel;uniform float u_device_pixel_ratio;uniform float u_visible_time;uniform bool u_view_panning;uniform float u_tilt;uniform mat4 u_model;uniform mat4 u_modelView;uniform mat3 u_normalMatrix;uniform mat3 u_inverseNormalMatrix;uniform float u_heading;uniform float u_near_plane;uniform float u_depth_buffer_adjustment;attribute vec4 a_position;attribute vec4 a_shape;attribute vec4 a_color;attribute vec2 a_texcoord;attribute vec2 a_offset;uniform float u_point_type;attribute float a_is_flat;\n#ifdef TANGRAM_IS_TEXT_STYLE\nattribute vec4 a_offsets_alt;attribute vec4 a_pre_angles_alt;attribute vec4 a_angles_alt;attribute vec4 a_offsets;attribute vec4 a_pre_angles;attribute vec4 a_angles;\n#endif\n#ifdef TANGRAM_POINT_DRAW_STICK\nattribute float a_is_stick;attribute float a_stick_height;varying float v_is_stick;\n#endif\nvarying vec4 v_color;varying vec2 v_texcoord;varying vec4 v_world_position;varying float v_alpha_factor;\n#ifdef TANGRAM_HAS_SHADER_POINTS\nattribute float a_outline_edge;attribute vec4 a_outline_color;varying float v_outline_edge;varying vec4 v_outline_color;varying float v_aa_offset;\n#endif\n#ifdef TANGRAM_SHOW_HIDDEN_LABELS\nvarying float v_label_hidden;\n#endif\n#define PI 3.14159265359\n#define TANGRAM_NORMAL vec3(0., 0., 1.)\n#pragma tangram: camera\n#pragma tangram: material\n#pragma tangram: lighting\n#pragma tangram: raster\n#pragma tangram: global\nvec2 rotate2D(vec2 _st,float _angle){return mat2(cos(_angle),-sin(_angle),sin(_angle),cos(_angle))*_st;}vec3 rotateX3D(vec3 _st,float _angle){return mat3(1.,0.,0.,0.,cos(_angle),sin(_angle),0.,-sin(_angle),cos(_angle))*_st;}vec3 rotateZ3D(vec3 _st,float _angle){return mat3(cos(_angle),sin(_angle),0.,-sin(_angle),cos(_angle),0.,0.,0.,1.)*_st;}\n#ifdef TANGRAM_IS_TEXT_STYLE\nfloat mix4linear(float a,float b,float c,float d,float x){return mix(mix(a,b,3.*x),mix(b,mix(c,d,3.*(max(x,.66)-.66)),3.*(clamp(x,.33,.66)-.33)),step(0.33,x));}\n#endif\nvoid main(){\n#pragma tangram: setup\n#ifndef TANGRAM_SHOW_HIDDEN_LABELS\nif(a_shape.w==0.){gl_Position=vec4(0.,0.,0.,1.);return;}\n#else\nif(a_shape.w==0.){v_label_hidden=1.;}else{v_label_hidden=0.;}\n#endif\nv_alpha_factor=1.0;v_color=a_color;v_texcoord=a_texcoord;\n#ifdef TANGRAM_HAS_SHADER_POINTS\nv_outline_color=a_outline_color;v_outline_edge=a_outline_edge;if(u_point_type==TANGRAM_POINT_TYPE_SHADER){v_outline_color=a_outline_color;v_outline_edge=a_outline_edge;float size=abs(a_shape.x/128.);v_texcoord=sign(a_shape.xy)*(size+1.0)/size;size+=2.0;v_aa_offset=2.0/size;}\n#endif\nvec4 position=u_modelView*vec4(a_position.xyz,1.);vec4 shape=vec4(a_shape.xy,0.,0.);vec2 offset=vec2(a_offset.x,-a_offset.y);\n#ifdef TANGRAM_POINT_DRAW_STICK\nv_is_stick=a_is_stick;float scaled_stick_height=(sin(u_tilt+(1.5*PI))+1.0)*a_stick_height;offset.y+=(1.0-a_is_stick)*scaled_stick_height;\n#endif\nfloat zoom=clamp(u_map_position.z-u_tile_origin.z,0.,1.);float theta=a_shape.z/4096.;float heading=u_heading;float delta=(heading-PI);float new_theta=theta-delta;float reversed=abs(new_theta)>PI/2. ? 1. : 0.;if(a_is_flat==1.0){\n#ifdef TANGRAM_IS_TEXT_STYLE\nif(a_offsets[0]!=0.){vec4 angles_scaled;vec4 pre_angles_scaled;vec4 offsets_scaled;if(reversed==1.){offsets_scaled=a_offsets_alt*4.;angles_scaled=(PI/16384.)*a_angles_alt;pre_angles_scaled=(PI/128.)*a_pre_angles_alt;}else{offsets_scaled=a_offsets*4.;angles_scaled=(PI/16384.)*a_angles;pre_angles_scaled=(PI/128.)*a_pre_angles;}float pre_angle=mix4linear(pre_angles_scaled[0],pre_angles_scaled[1],pre_angles_scaled[2],pre_angles_scaled[3],zoom);float angle=mix4linear(angles_scaled[0],angles_scaled[1],angles_scaled[2],angles_scaled[3],zoom);float offset_curve=mix4linear(offsets_scaled[0],offsets_scaled[1],offsets_scaled[2],offsets_scaled[3],zoom);shape.xy=rotate2D(shape.xy,pre_angle+PI*reversed);shape.x+=offset_curve;shape.xy=rotate2D(shape.xy,angle);shape.xy+=rotate2D(offset,theta);}else{shape.xy=rotate2D(shape.xy+offset*256.,theta+(PI*reversed));}\n#else\nshape.xy=rotate2D(shape.xy+offset*256.,theta);\n#endif\nshape.xy/=pow(2.,4.+(u_map_position.z-u_tile_origin.w));shape=u_modelView*shape;position+=shape;}else{shape.xy/=256.;\n#ifdef TANGRAM_POINT_DRAW_STICK\nshape.y*=1.0+(scaled_stick_height-1.0)*a_is_stick;\n#endif\nshape.xy=rotate2D(shape.xy+offset,theta);}\n#ifdef TANGRAM_FADE_IN_RATE\nif(u_tile_fade_in){v_alpha_factor*=clamp(u_visible_time*TANGRAM_FADE_IN_RATE,0.,1.);}\n#endif\n#ifdef TANGRAM_FADE_ON_ZOOM_OUT\nv_alpha_factor*=clamp(1.+TANGRAM_FADE_ON_ZOOM_OUT_RATE*(u_map_position.z-u_tile_origin.z),0.,1.);\n#endif\nv_world_position=u_model*position;v_world_position.xy+=shape.xy*u_meters_per_pixel;v_world_position=wrapWorldPosition(v_world_position);\n#pragma tangram: position\ncameraProjection(position);\n#ifdef TANGRAM_LAYER_ORDER\napplyLayerOrder(a_position.w+u_tile_proxy_depth+1.,position);/***Due to the precision loss on depth buffer,we had a z-fighting of translucent points when the distance to the camera was big.*For more information about the problem see: https:*For more information about the fix see: https:*position.z=(2.0*log(position.w/u_near_plane)/log(u_far_plane/u_near_plane)-1.0)*position.w;*/position.z=(log(position.w/u_near_plane)*u_depth_buffer_adjustment-1.0)*position.w;\n#endif\nif(a_is_flat!=1.){position.xy+=shape.xy*position.w*2.*u_device_pixel_ratio/u_resolution;}\n#ifdef TANGRAM_HAS_SHADER_POINTS\nif(u_point_type==TANGRAM_POINT_TYPE_SHADER){position.xy+=sign(shape.xy)*position.w*u_device_pixel_ratio/u_resolution;}\n#endif\nif(!u_view_panning){snapToPixelGrid(position);}gl_Position=position;}", shaderSrc_pointsFragment = "uniform vec2 u_resolution;uniform vec3 u_map_position;uniform vec4 u_tile_origin;uniform float u_meters_per_pixel;uniform float u_device_pixel_ratio;uniform float u_visible_time;uniform mat3 u_normalMatrix;uniform mat3 u_inverseNormalMatrix;uniform sampler2D u_texture;uniform float u_point_type;uniform bool u_apply_color_blocks;varying vec4 v_color;varying vec2 v_texcoord;varying vec4 v_world_position;varying float v_alpha_factor;\n#ifdef TANGRAM_HAS_SHADER_POINTS\nvarying vec4 v_outline_color;varying float v_outline_edge;varying float v_aa_offset;\n#endif\n#ifdef TANGRAM_SHOW_HIDDEN_LABELS\nvarying float v_label_hidden;\n#endif\n#ifdef TANGRAM_POINT_DRAW_STICK\nvarying float v_is_stick;\n#endif\n#define TANGRAM_NORMAL vec3(0., 0., 1.)\n#pragma tangram: camera\n#pragma tangram: material\n#pragma tangram: lighting\n#pragma tangram: raster\n#pragma tangram: global\n#ifdef TANGRAM_HAS_SHADER_POINTS\nfloat _tangram_antialias(float l,float R){float low=R-v_aa_offset;float high=R+v_aa_offset;return 1.-smoothstep(low,high,l);}\n#endif\nvoid mixTextureColor(inout vec4 color){\n#ifdef TANGRAM_HAS_SHADER_POINTS\nif(u_point_type==TANGRAM_POINT_TYPE_TEXTURE){color*=texture2D(u_texture,v_texcoord);}else if(u_point_type==TANGRAM_POINT_TYPE_LABEL){color=texture2D(u_texture,v_texcoord);color.rgb/=max(color.a,0.001);}else if(u_point_type==TANGRAM_POINT_TYPE_SHADER){float outline_edge=v_outline_edge;vec4 outlineColor=v_outline_color;float l=length(v_texcoord);float outer_alpha=_tangram_antialias(l,1.);float fill_alpha=_tangram_antialias(l,1.-v_outline_edge*0.5)*color.a;float stroke_alpha=(outer_alpha-_tangram_antialias(l,1.-v_outline_edge))*outlineColor.a;\n#ifdef TANGRAM_BLEND_ADD\ncolor.a=stroke_alpha+fill_alpha;color.rgb=color.rgb*fill_alpha+outlineColor.rgb*stroke_alpha;\n#else\ncolor.a=stroke_alpha+fill_alpha*(1.-stroke_alpha);color.rgb=mix(color.rgb*fill_alpha,outlineColor.rgb,stroke_alpha)/max(color.a,0.001);\n#endif\n}\n#else\ncolor=texture2D(u_texture,v_texcoord);color.rgb/=max(color.a,0.001);\n#endif\nif(u_apply_color_blocks){\n#pragma tangram: color\n#pragma tangram: filter\n}color.a*=v_alpha_factor;\n#ifdef TANGRAM_SHOW_HIDDEN_LABELS\nif(v_label_hidden>0.){color.a*=0.5;color.rgb=vec3(1.,0.,0.);}\n#endif\n#if !defined(TANGRAM_BLEND_OVERLAY) && !defined(TANGRAM_BLEND_INLAY) && !defined(TANGRAM_BLEND_ADD)\nif(color.a<TANGRAM_ALPHA_TEST){discard;}\n#endif\n}void main(void){\n#pragma tangram: setup\nvec4 color=v_color;\n#ifdef TANGRAM_POINT_DRAW_STICK\nif(v_is_stick==0.0){mixTextureColor(color);}\n#else\nmixTextureColor(color);\n#endif\ngl_FragColor=color;}", PLACEMENT$1 = LabelPoint.PLACEMENT, pre_angles_normalize = 128 / Math.PI, angles_normalize = 16384 / Math.PI, offsets_normalize = 64, texcoord_normalize = 65535, Points = Object.create(Style), TANGRAM_POINT_TYPE_TEXTURE = 1, TANGRAM_POINT_TYPE_LABEL = 2, TANGRAM_POINT_TYPE_SHADER = 3, DEFAULT_POINT_SIZE = 16;
        Object.assign(Points, TextLabels), Object.assign(Points, { name: "points", built_in: true, vertex_shader_src: shaderSrc_pointsVertex, fragment_shader_src: shaderSrc_pointsFragment, selection: true, collision: true, blend: "overlay", init: function(e) {
          var t2 = 0 < arguments.length && void 0 !== e ? e : {};
          Style.init.call(this, t2), this.setupDefines(), this.defines.TANGRAM_HAS_SHADER_POINTS = true, this.defines.TANGRAM_POINT_TYPE_TEXTURE = TANGRAM_POINT_TYPE_TEXTURE, this.defines.TANGRAM_POINT_TYPE_LABEL = TANGRAM_POINT_TYPE_LABEL, this.defines.TANGRAM_POINT_TYPE_SHADER = TANGRAM_POINT_TYPE_SHADER, this.defines.TANGRAM_POINT_DRAW_STICK = !!this.stick, this.collision_group_points = this.name + "-points", this.collision_group_text = this.name + "-text", this.reset();
        }, setupDefines: function() {
          "overlay" !== this.blend && (this.defines.TANGRAM_LAYER_ORDER = true), this.defines.TANGRAM_FADE_ON_ZOOM_OUT = true, this.defines.TANGRAM_FADE_ON_ZOOM_OUT_RATE = 2, debugSettings$1.suppress_label_fade_in || this.suppress_fade ? (this.fade_in_time = 0, this.defines.TANGRAM_FADE_IN_RATE = null) : (this.fade_in_time = 0.15, this.defines.TANGRAM_FADE_IN_RATE = 1 / this.fade_in_time), debugSettings$1.suppress_snap_animation || (this.defines.TANGRAM_VIEW_PAN_SNAP_RATE = 1 / VIEW_PAN_SNAP_TIME), debugSettings$1.show_hidden_labels && (this.defines.TANGRAM_SHOW_HIDDEN_LABELS = true);
        }, reset: function() {
          this.queues = {}, this.resetText(), this.texture_missing_sprites = {};
        }, addFeature: function(e, t2, r) {
          var i2, n, o, a2 = r.tile, s = {};
          if (s.color = this.parseColor(t2.color, r), s.texture = t2.texture, s.label_texture = null, s.color || s.texture) {
            if (this.hasSprites(s)) {
              if (!(i2 = this.parseSprite(s, t2, r)))
                return;
              s.texcoords = i2.texcoords;
            }
            if (s.size = t2.size, s.size) {
              if (s.size = StyleParser.evalCachedPointSizeProperty(t2.size, i2, r), null == s.size)
                return void log({ level: "warn", once: true }, "Layer '".concat(t2.layers[t2.layers.length - 1], "': ") + "'size' includes % and/or ratio-based scaling (".concat(JSON.stringify(t2.size.value), "); ") + "these can only applied to sprites, but no sprite was specified, skipping features in layer");
              "number" == typeof s.size && (s.size = [s.size, s.size]);
            } else
              s.size = i2 && i2.css_size || [DEFAULT_POINT_SIZE, DEFAULT_POINT_SIZE];
            t2.outline && (s.outline_width = StyleParser.evalCachedProperty(t2.outline.width, r) || StyleParser.defaults.outline.width, s.outline_color = this.parseColor(t2.outline.color, r)), s.outline_edge_pct = 0, s.outline_width && s.outline_color && (n = s.outline_width, s.size[0] += n, s.size[1] += n, s.outline_edge_pct = n / Math.min(s.size[0], s.size[1]) * 2), s.size[0] = Math.min(s.size[0], 256), s.size[1] = Math.min(s.size[1], 256), s.placement = t2.placement, s.placement_min_length_ratio = StyleParser.evalCachedProperty(t2.placement_min_length_ratio, r), s.placement === PLACEMENT$1.SPACED && t2.placement_spacing && (s.placement_spacing = StyleParser.evalCachedProperty(t2.placement_spacing, r)), s.angle = StyleParser.evalProperty(t2.angle, r) || 0, s.elevate_by_altitude = !!t2.elevate_by_altitude, s.z = t2.z ? MathUtils$1.clamp(StyleParser.evalCachedDistanceProperty(t2.z, r), 0, 32767) : StyleParser.defaults.z, s.flat = t2.flat, s.tile_edges = t2.tile_edges, this.computeLayout(s, e, t2, r, a2), t2.stick && !s.flat && (o = StyleParser.parseNumber(StyleParser.evalProperty(t2.stick.height, r)), s.stick = { color: this.parseColor(t2.stick.color, r) || StyleParser.defaults.color, height: o ? Math.max(o, 0) : 0 });
            var l = t2.text && false !== StyleParser.evalProperty(t2.text.visible, r) && this.parseTextFeature(e, t2.text, r, a2);
            Array.isArray(l) && log({ level: "warn", once: !(l = null) }, "Layer '".concat(t2.layers[t2.layers.length - 1], "': ") + "cannot use boundary labels (e.g. 'text_source: { left: ..., right: ... }') for 'text' labels attached to 'points'; " + "provided 'text_source' value was ".concat(JSON.stringify(t2.text.text_source))), l && (l.layout.parent = s, l.layout.priority = t2.text.priority ? Math.max(l.layout.priority, s.priority + 0.5) : s.priority + 0.5, l.layout.move_into_tile = false, Collision.addStyle(this.collision_group_text, a2.id)), this.queueFeature({ feature: e, draw: t2, context: r, style: s, text_feature: l }, a2), Collision.addStyle(this.collision_group_points, a2.id);
          }
        }, hasSprites: function(e) {
          return e.texture && this.textureManager.textures[e.texture] && this.textureManager.textures[e.texture].sprites;
        }, getSpriteInfo: function(e, t2) {
          var r = this.textureManager.textures[e.texture].sprites[t2] && this.textureManager.getSpriteInfo(e.texture, t2);
          return t2 && !r ? (this.texture_missing_sprites[e.texture] = this.texture_missing_sprites[e.texture] || {}, this.texture_missing_sprites[e.texture][t2] || (log("debug", "Style: in style '".concat(this.name, "', could not find sprite '").concat(t2, "' for texture '").concat(e.texture, "'")), this.texture_missing_sprites[e.texture][t2] = true)) : r && (r.sprite = t2), r;
        }, parseSprite: function(e, t2, r) {
          var i2 = StyleParser.evalProperty(t2.sprite, r);
          return this.getSpriteInfo(e, i2) || this.getSpriteInfo(e, t2.sprite_default);
        }, queueFeature: function(e, t2) {
          this.tile_data[t2.id] && this.queues[t2.id] || this.startData(t2), this.queues[t2.id] = this.queues[t2.id] || [], this.queues[t2.id].push(e);
        }, endData: function(i2) {
          var u2 = this;
          if (i2.canceled)
            return log("trace", "Style ".concat(this.name, ": stop tile build because tile was canceled: ").concat(i2.key)), Promise.resolve();
          var e = this.queues[i2.id];
          delete this.queues[i2.id];
          var c2 = [], h = [];
          return e.forEach(function(e2) {
            for (var t2 = e2.style, r = e2.feature, i3 = r.geometry, n = u2.buildLabels(t2.size, i3, t2), o = 0; o < n.length; o++) {
              var a2, s = n[o], l = { feature: r, draw: e2.draw, context: e2.context, style: t2, label: s };
              h.push(l), e2.text_feature && (a2 = { feature: r, draw: e2.text_feature.draw, context: e2.context, text: e2.text_feature.text, text_settings_key: e2.text_feature.text_settings_key, layout: e2.text_feature.layout, point_label: s, linked: l }, c2.push(a2), e2.draw.text.optional || (l.linked = a2));
            }
          }), Promise.all([Collision.collide(h, this.collision_group_points, i2.id).then(function(e2) {
            e2.forEach(function(e3) {
              u2.feature_style = e3.style, u2.feature_style.label = e3.label, u2.feature_style.linked = e3.linked, Style.addFeature.call(u2, e3.feature, e3.draw, e3.context);
            });
          }), this.collideAndRenderTextLabels(i2, this.collision_group_text, c2)]).then(function(e2) {
            var t2 = _slicedToArray(e2, 2)[1], r = t2.labels, n = t2.texts;
            return r && n && r.forEach(function(e3) {
              var t3 = e3.text_settings_key, r2 = n[t3] && n[t3][e3.text], i3 = u2.feature_style;
              i3.label = e3.label, i3.linked = e3.linked, i3.size = r2.size.logical_size, i3.angle = 0, e3.label.text_data = { text_info: r2, text_settings_key: t3, text: e3.text }, i3.label_texture = u2.textureManager.default, Style.addFeature.call(u2, e3.feature, e3.draw, e3.context);
            }), u2.freeText(i2), Style.endData.call(u2, i2);
          });
        }, _preprocess: function(t2) {
          t2.color = StyleParser.createColorPropertyCache(t2.color), t2.texture = void 0 !== t2.texture ? t2.texture : this.texture, t2.outline && (t2.outline.color = StyleParser.createColorPropertyCache(t2.outline.color), t2.outline.width = StyleParser.createPropertyCache(t2.outline.width, StyleParser.parsePositiveNumber)), t2.z = StyleParser.createPropertyCache(t2.z, StyleParser.parseUnits);
          try {
            t2.size = StyleParser.createPointSizePropertyCache(t2.size);
          } catch (e) {
            return log({ level: "warn", once: true }, "Layer '".concat(t2.layers[t2.layers.length - 1], "': ") + "".concat(e, " (").concat(JSON.stringify(t2.size), "), skipping features in layer")), null;
          }
          return t2.offset = StyleParser.createPropertyCache(t2.offset, function(e) {
            return Array.isArray(e) && e.map(StyleParser.parseNumber);
          }), t2.buffer = StyleParser.createPropertyCache(t2.buffer, function(e) {
            return (Array.isArray(e) ? e : [e, e]).map(StyleParser.parsePositiveNumber);
          }), t2.repeat_distance = StyleParser.createPropertyCache(t2.repeat_distance, StyleParser.parseNumber), null == t2.repeat_group && (t2.repeat_group = t2.layers.join("-")), t2.placement = PLACEMENT$1[t2.placement && t2.placement.toUpperCase()], null == t2.placement && (t2.placement = PLACEMENT$1.VERTEX), t2.placement_spacing = null != t2.placement_spacing ? t2.placement_spacing : 80, t2.placement_spacing = StyleParser.createPropertyCache(t2.placement_spacing, StyleParser.parsePositiveNumber), t2.placement_min_length_ratio = null != t2.placement_min_length_ratio ? t2.placement_min_length_ratio : 1, t2.placement_min_length_ratio = StyleParser.createPropertyCache(t2.placement_min_length_ratio, StyleParser.parsePositiveNumber), "number" == typeof t2.angle ? t2.angle = t2.angle * Math.PI / 180 : t2.angle = t2.angle || 0, t2.text = this.preprocessText(t2.text), t2.text && (t2.text.variantKey = t2.variantKey, t2.text.group = t2.group, t2.text.layers = t2.layers, t2.text.order = t2.order, t2.text.repeat_group = t2.text.repeat_group || t2.repeat_group, t2.text.anchor = t2.text.anchor || this.default_anchor, t2.text.optional = "boolean" == typeof t2.text.optional && t2.text.optional, t2.text.interactive = t2.text.interactive || t2.interactive), t2.stick && (t2.stick.color = StyleParser.createColorPropertyCache(t2.stick.color)), t2;
        }, default_anchor: ["bottom", "top", "right", "left"], computeLayout: function(e, t2, r, i2, n) {
          var o = e || {};
          o.id = t2, o.units_per_pixel = n.units_per_pixel || 1, o.collide = false !== r.collide, o.anchor = r.anchor, o.offset = StyleParser.evalCachedProperty(r.offset, i2) || StyleParser.zeroPair, o.buffer = StyleParser.evalCachedProperty(r.buffer, i2) || StyleParser.zeroPair, o.repeat_distance = StyleParser.evalCachedProperty(r.repeat_distance, i2), o.repeat_distance && (o.repeat_distance *= o.units_per_pixel, o.repeat_scale = 1, "function" == typeof r.repeat_group ? o.repeat_group = r.repeat_group(i2) : o.repeat_group = r.repeat_group);
          var a2 = r.priority;
          return null != a2 ? "function" == typeof a2 && (a2 = a2(i2)) : a2 = -1 >>> 0, o.priority = a2, o;
        }, buildTextLabels: function(e, t2) {
          for (var r = [], i2 = 0; i2 < t2.length; i2++) {
            var n = t2[i2], o = this.texts[e.id][n.text_settings_key][n.text].size.collision_size;
            n.label = new LabelPoint(n.point_label.position, o, n.point_label.isFlat(), n.layout), r.push(n);
          }
          return r;
        }, buildLabels: function(e, t2, r) {
          var i2 = !!r.flat, n = [];
          if ("Point" === t2.type)
            n.push(new LabelPoint(t2.coordinates, e, i2, r));
          else if ("MultiPoint" === t2.type)
            for (var o = t2.coordinates, a2 = 0; a2 < o.length; ++a2) {
              var s = o[a2];
              n.push(new LabelPoint(s, e, i2, r));
            }
          else if ("LineString" === t2.type)
            for (var l = placePointsOnLine(t2.coordinates, e, i2, r), u2 = 0; u2 < l.length; ++u2)
              n.push(l[u2]);
          else if ("MultiLineString" === t2.type)
            for (var c2 = t2.coordinates, h = 0; h < c2.length; h++)
              for (var f2 = placePointsOnLine(c2[h], e, i2, r), d = 0; d < f2.length; ++d)
                n.push(f2[d]);
          else if ("Polygon" === t2.type)
            if (r.placement === PLACEMENT$1.CENTROID) {
              var _ = Geo$1.centroid(t2.coordinates);
              n.push(new LabelPoint(_, e, i2, r));
            } else
              for (var p2 = t2.coordinates, g = 0; g < p2.length; g++)
                for (var m = placePointsOnLine(p2[g], e, i2, r), y = 0; y < m.length; ++y)
                  n.push(m[y]);
          else if ("MultiPolygon" === t2.type)
            if (r.placement === PLACEMENT$1.CENTROID) {
              var v = Geo$1.multiCentroid(t2.coordinates);
              n.push(new LabelPoint(v, e, i2, r));
            } else
              for (var x2 = t2.coordinates, b2 = 0; b2 < x2.length; b2++)
                for (var T2 = x2[b2], A2 = 0; A2 < T2.length; A2++)
                  for (var E2 = placePointsOnLine(T2[A2], e, i2, r), w = 0; w < E2.length; ++w)
                    n.push(E2[w]);
          return n;
        }, makeVertexTemplate: function(e, t2) {
          var r, i2 = e.color || StyleParser.defaults.color, n = t2.vertex_data.vertex_layout;
          return this.fillVertexTemplate(n, "a_position", 0, { size: 2 }), this.fillVertexTemplate(n, "a_position", e.z || 0, { size: 1, offset: 2 }), this.fillVertexTemplate(n, "a_position", this.scaleOrder(e.order), { size: 1, offset: 3 }), this.fillVertexTemplate(n, "a_shape", 0, { size: 4 }), this.fillVertexTemplate(n, "a_shape", e.label.layout.collide ? 0 : 1, { size: 1, offset: 3 }), this.fillVertexTemplate(n, "a_texcoord", 0, { size: 2 }), this.fillVertexTemplate(n, "a_offset", 0, { size: 2 }), this.fillVertexTemplate(n, "a_color", Vector$1.mult(i2, 255), { size: 4 }), this.defines.TANGRAM_HAS_SHADER_POINTS && t2.variant.shader_point && (r = e.outline_color || StyleParser.defaults.outline.color, this.fillVertexTemplate(n, "a_outline_color", Vector$1.mult(r, 255), { size: 4 }), this.fillVertexTemplate(n, "a_outline_edge", e.outline_edge_pct || StyleParser.defaults.outline.width, { size: 1 })), this.selection && this.fillVertexTemplate(n, "a_selection_color", Vector$1.mult(e.selection_color, 255), { size: 4 }), this.fillVertexTemplate(n, "a_is_flat", 0, { size: 1 }), this.defines.TANGRAM_POINT_DRAW_STICK && e.stick && (this.fillVertexTemplate(n, "a_is_stick", 0, { size: 1 }), this.fillVertexTemplate(n, "a_stick_height", e.stick.height, { size: 1 })), this.vertex_template;
        }, buildQuad: function(e, t2, r, i2, n, o, a2, s, l, u2, c2, h, f2, d, _, p2, g, m, y) {
          return t2[0] <= 0 || t2[1] <= 0 ? 0 : buildQuadsForPoints(e, _, p2, { quad: t2, quad_normalize: 256, offset: s, offsets: l, offsets_alt: u2, pre_angles: o, pre_angles_alt: a2, angle: 4096 * r, angles: i2, angles_alt: n, is_flat: f2, elevate_by_altitude: d, build_stick_points: g, stick_color: g && Vector$1.mult(m, 255), color: Vector$1.mult(y || StyleParser.defaults.color, 255), curve: h, texcoord_scale: c2, texcoord_normalize, pre_angles_normalize, angles_normalize, offsets_normalize });
        }, build: function(e, t2, r) {
          var i2 = e.label;
          return "curved" === i2.type ? this.buildCurvedLabel(i2, e, t2, r) : this.buildStraightLabel(i2, e, t2, r);
        }, buildStraightLabel: function(e, t2, r, i2) {
          var n, o = this.makeVertexTemplate(t2, r), a2 = e.angle || t2.angle, s = "point" !== e.type ? (n = t2.size[e.type], default_uvs) : (n = t2.size, t2.texcoords || default_uvs);
          r.uniforms = r.uniforms || {}, t2.label_texture ? (r.uniforms.u_texture = t2.label_texture, r.uniforms.u_point_type = TANGRAM_POINT_TYPE_LABEL, r.uniforms.u_apply_color_blocks = false) : (t2.texture ? (r.uniforms.u_texture = t2.texture, r.uniforms.u_point_type = TANGRAM_POINT_TYPE_TEXTURE) : (r.uniforms.u_texture = this.textureManager.default, r.uniforms.u_point_type = TANGRAM_POINT_TYPE_SHADER), r.uniforms.u_apply_color_blocks = true);
          var l = e.offset, u2 = this.defines.TANGRAM_POINT_DRAW_STICK && !t2.label_texture && t2.stick && 0 < t2.stick.height, c2 = this.buildQuad([e.position], n, a2, null, null, null, null, l, null, null, s, false, e.isFlat(), t2.elevate_by_altitude, r.vertex_data, o, u2, u2 && t2.stick.color, t2.color), h = t2.linked && t2.linked.label.id;
          return this.trackLabel(e, h, r, c2, i2, u2), c2;
        }, buildCurvedLabel: function(e, t2, r, i2) {
          for (var n = this.makeVertexTemplate(t2, r), o = e.angle, a2 = 0, s = 0; s < 2; s++)
            for (var l = 0; l < e.num_segments; l++) {
              var u2 = t2.size[e.type][l], c2 = default_uvs, h = this.getTileMesh(i2.tile, this.getMeshVariantTypeForDraw(t2));
              h.uniforms = h.uniforms || {}, h.uniforms.u_texture = t2.label_texture, h.uniforms.u_point_type = TANGRAM_POINT_TYPE_LABEL, h.uniforms.u_apply_color_blocks = false;
              var f2 = e.offset || [0, 0], d = e.position, _ = e.angles[l], p2 = e.offsets[l], g = e.pre_angles[l], m = e.num_segments - l - 1, y = e.alt_angles[m], v = e.alt_pre_angles[m], x2 = e.alt_offsets[m], b2 = this.buildQuad([d], u2, o, _, y, g, v, f2, p2, x2, c2, true, e.isFlat(), t2.elevate_by_altitude, h.vertex_data, n, false, false, t2.color);
              a2 += b2;
              var T2 = t2.linked && t2.linked.label.id;
              this.trackLabel(e, T2, r, b2, i2, false);
            }
          return a2;
        }, trackLabel: function(e, t2, r, i2, n, o) {
          var a2 = 5 < arguments.length && void 0 !== o && o;
          r.labels = r.labels || {}, r.labels.collision = r.labels.collision || {}, r.labels["non-collision"] = r.labels["non-collision"] || {};
          var s = e.layout.collide ? r.labels.collision : r.labels["non-collision"];
          s[e.id] = s[e.id] || { container: { label: e.text_data ? Object.assign(e.toJSON(), { text_data: e.text_data }) : e.toJSON(), linked: t2 }, ranges: [] };
          var l = 2 * i2, u2 = r.vertex_data.offset - r.vertex_data.stride * l;
          s[e.id].ranges.push([u2, l, a2]);
        }, buildLines: function(e, t2, r, i2) {
          return this.build(t2, r, i2);
        }, buildPoints: function(e, t2, r, i2) {
          return this.build(t2, r, i2);
        }, buildPolygons: function(e, t2, r, i2) {
          return this.build(t2, r, i2);
        }, vertexLayoutForMeshVariant: function(e) {
          var t2;
          return this.vertex_layout || (t2 = [{ name: "a_position", size: 4, type: gl$1.SHORT, normalized: false }, { name: "a_shape", size: 4, type: gl$1.SHORT, normalized: false }, { name: "a_texcoord", size: 2, type: gl$1.UNSIGNED_SHORT, normalized: true }, { name: "a_offset", size: 2, type: gl$1.SHORT, normalized: false }, { name: "a_color", size: 4, type: gl$1.UNSIGNED_BYTE, normalized: true }, { name: "a_outline_color", size: 4, type: gl$1.UNSIGNED_BYTE, normalized: true, static: [0, 0, 0, 0] }, { name: "a_outline_edge", size: 1, type: gl$1.FLOAT, normalized: false, static: 0 }, { name: "a_selection_color", size: 4, type: gl$1.UNSIGNED_BYTE, normalized: true }, { name: "a_is_flat", size: 1, type: gl$1.UNSIGNED_BYTE, normalized: true }], this.defines && this.defines.TANGRAM_POINT_DRAW_STICK && t2.push({ name: "a_is_stick", size: 1, type: gl$1.UNSIGNED_BYTE, normalized: true }, { name: "a_stick_height", size: 1, type: gl$1.FLOAT, normalized: false }), this.vertex_layout = new VertexLayout(t2), (t2 = t2.map(function(e2) {
            return Object.assign({}, e2);
          })).forEach(function(e2) {
            "a_outline_color" !== e2.name && "a_outline_edge" !== e2.name || (e2.static = null);
          }), this.vertex_layout_shader_point = new VertexLayout(t2)), e.shader_point ? this.vertex_layout_shader_point : this.vertex_layout;
        }, computeVariantForDraw: function(e) {
          var t2 = e.label_texture || e.texture || this.default_mesh_variant.key;
          return { key: t2, shader_point: t2 === this.default_mesh_variant.key, order: e.label_texture ? 1 : 0 };
        }, makeMesh: function(e, t2, r) {
          var i2 = 2 < arguments.length && void 0 !== r ? r : {}, i2 = Object.assign({}, i2, { fade_in_time: this.fade_in_time });
          return Style.makeMesh.call(this, e, t2, i2);
        } });
        var STOPS = [0, 0.33, 0.66, 0.99], LINE_EXCEED_STRAIGHT = 1.5, LINE_EXCEED_STRAIGHT_NO_CURVE = 1.8, LINE_EXCEED_STAIGHT_LOOSE = 2.3, STRAIGHT_ANGLE_TOLERANCE = 0.1, CURVE_MIN_TOTAL_COST = 1.3, CURVE_MIN_AVG_COST = 0.4, CURVE_MAX_ANGLE = 1, ORIENTED_LABEL_OFFSET_FACTOR = 1.2, VERTICAL_ANGLE_TOLERANCE = 0.01, LabelLine = { create: function(e, t2, r, i2, n) {
          for (var o = [{ type: "straight", tolerance: n.no_curving ? LINE_EXCEED_STRAIGHT_NO_CURVE : LINE_EXCEED_STRAIGHT }, { type: "curved" }, { type: "straight", tolerance: LINE_EXCEED_STAIGHT_LOOSE }], a2 = 0; a2 < o.length; a2++) {
            var s = o[a2], l = void 0;
            if ("straight" === s.type ? l = new LabelLineStraight(t2, r, i2, n, s.tolerance) : "curved" === s.type && !n.no_curving && 2 < r.length && (l = new LabelLineCurved(e, r, i2, n)), l && !l.throw_away)
              return l;
          }
          return false;
        } }, LabelLineBase = function() {
          function r(e, t2) {
            _classCallCheck(this, r), this.id = Label.nextLabelId(), this.layout = t2, this.position = [], this.angle = 0, this.offset = t2.offset.slice(), this.unit_scale = this.layout.units_per_pixel, this.type = "", this.throw_away = false, this._is_flat = e, this._circles = void 0, this.placed = null;
          }
          return _createClass(r, [{ key: "toJSON", value: function() {
            return { id: this.id, type: this.type, is_flat: this._is_flat, position: this.position, size: this.size, offset: this.offset, angle: this.angle, breach: this.breach, layout: textLayoutToJSON(this.layout), circles: this.getBoundingCircles() };
          } }, { key: "inTileBounds", value: function() {
            var e = this.getAABB(), t2 = e.left, r2 = e.top, i2 = e.right, n = e.bottom;
            return Utils$1.pointInTile([t2, r2]) && Utils$1.pointInTile([i2, n]);
          } }, { key: "getAABBForSegment", value: function(e, t2, r2, i2) {
            var n, o = this.unit_scale, a2 = t2 / 2, s = r2 / 2, l = _slicedToArray(e, 2), u2 = l[0], c2 = l[1];
            0 === this.offset[0] && 0 === this.offset[1] || (u2 += (n = Vector$1.rot(this.offset, this.angle))[0] * o, c2 -= n[1] * o);
            var h = [[Math.cos(i2), -Math.sin(i2)], [Math.sin(i2), Math.cos(i2)]], f2 = Vector$1.multMatrix(h, [-a2, -s]), d = Vector$1.multMatrix(h, [a2, -s]), _ = Vector$1.multMatrix(h, [a2, s]), p2 = Vector$1.multMatrix(h, [-a2, s]);
            return { left: u2 + Math.min(f2[0], d[0], _[0], p2[0]), top: c2 + Math.max(f2[1], d[1], _[1], p2[1]), right: u2 + Math.max(f2[0], d[0], _[0], p2[0]), bottom: c2 + Math.min(f2[1], d[1], _[1], p2[1]) };
          } }, { key: "isFlat", value: function() {
            return this._is_flat;
          } }, { key: "getBoundingCircles", value: function() {
          } }, { key: "getAABB", value: function() {
          } }], [{ key: "splitLineByOrientation", value: function(e) {
            for (var t2 = [e[0]], r2 = 0, i2 = 0, n = 0, o = t2, a2 = false, s = 1; s < e.length; s++) {
              var l = e[s], u2 = e[s - 1], c2 = Vector$1.length(Vector$1.sub(l, u2));
              l[0] > u2[0] ? 1 === n ? (t2.push(l), i2 < (r2 += c2) && (o = t2, i2 = r2, a2 = false)) : (t2 = [u2, l], i2 < (r2 = c2) && (o = t2, i2 = r2, a2 = false), n = 1) : l[0] < u2[0] ? -1 === n ? (t2.unshift(l), i2 < (r2 += c2) && (o = t2, i2 = r2, a2 = true)) : (t2 = [l, u2], i2 < (r2 = c2) && (o = t2, i2 = r2, a2 = true), n = -1) : (-1 === n ? t2.unshift(l) : (t2.push(l), n = 1), i2 < (r2 += c2) && (o = t2, i2 = r2, a2 = -1 === n));
            }
            return [o, a2];
          } }]), r;
        }(), LabelLineStraight = function() {
          _inherits(s, LabelLineBase);
          var a2 = _createSuper(s);
          function s(e, t2, r, i2, n) {
            var o;
            return _classCallCheck(this, s), (o = a2.call(this, r, i2)).type = "straight", o.size = e, o.throw_away = !o.fit(e, t2, i2, n), o;
          }
          return _createClass(s, [{ key: "fit", value: function(e, t2, r, i2) {
            var n, o = this.unit_scale, a3 = _slicedToArray(LabelLineBase.splitLineByOrientation(t2), 2);
            t2 = a3[0], n = a3[1], "number" == typeof r.orientation && (this.offset[1] += ORIENTED_LABEL_OFFSET_FACTOR * (e[1] - r.vertical_buffer), n && (this.offset[1] *= -1), -1 === r.orientation && (this.offset[1] *= -1));
            for (var s2 = getLineLengths(t2), l = e[0] * o, u2 = 0; u2 < t2.length - 1; u2++)
              for (var c2 = t2[u2], h = 0, f2 = 0, d = u2 + 1, _ = void 0; d < t2.length; ) {
                var p2 = t2[d - 1], g = t2[d], m = getAngleForSegment(p2, g);
                if (d !== u2 + 1 && (h += getAbsAngleDiff(m, _)), Math.abs(h) > STRAIGHT_ANGLE_TOLERANCE)
                  break;
                if (calcFitness(f2 += s2[d - 1], l) < i2) {
                  var y = Vector$1.mult(Vector$1.add(c2, g), 0.5);
                  return this.angle = -m, Math.abs(this.angle - Math.PI / 2) < VERTICAL_ANGLE_TOLERANCE && (this.angle = -Math.PI / 2, "number" == typeof r.orientation && (this.offset[1] *= -1)), this.position = y, this.breach = !this.inTileBounds(), true;
                }
                _ = m, d++;
              }
            return false;
          } }, { key: "getBoundingCircles", value: function() {
            var e, t2, r, i2, n, o, a3, s2, l, u2, c2, h, f2, d;
            return this._circles || (e = this.unit_scale, n = -(r = (t2 = this.size[0] / 2 * e) * Math.cos(this.angle)), o = -(i2 = t2 * Math.sin(this.angle)), a3 = this.offset[0] * e, s2 = this.offset[1] * e, u2 = (l = _slicedToArray(this.position, 2))[0], c2 = l[1], c2 *= -1, a3 && (h = [r, i2], Vector$1.normalize(h), h[0] *= a3, h[1] *= a3, u2 += h[0], c2 += h[1]), s2 && (f2 = [i2, -r], Vector$1.normalize(f2), f2[0] *= s2, f2[1] *= s2, u2 -= f2[0], c2 -= f2[1]), r += u2, i2 += c2, n += u2, o += c2, d = this.size[1] / 2 * e, this._circles = encircleLine(r, i2, n, o, d)), this._circles;
          } }, { key: "getAABB", value: function() {
            var e, t2, r, i2, n;
            return this._aabb || (e = this.unit_scale, t2 = this.size, r = this.layout.buffer, i2 = (t2[0] + 2 * r[0]) * e, n = (t2[1] + 2 * r[1]) * e, this._aabb = this.getAABBForSegment(this.position, i2, n, this.angle)), this._aabb;
          } }]), s;
        }(), LabelLineCurved = function() {
          _inherits(j, LabelLineBase);
          var o = _createSuper(j);
          function j(e, t2, r, i2) {
            var n;
            return _classCallCheck(this, j), (n = o.call(this, r, i2)).type = "curved", n.positions = [], n.angles = [], n._aabbs = [], n.pre_angles = [], n.offsets = [], n.num_segments = e.length, n.sizes = e, n.alt_angles = [], n.alt_pre_angles = [], n.alt_offsets = [], n.throw_away = !n.fit(n.sizes, t2, i2), n;
          }
          return _createClass(j, [{ key: "toJSON", value: function() {
            return { id: this.id, type: this.type, is_flat: this._is_flat, position: this.position, breach: this.breach, layout: textLayoutToJSON(this.layout), circles: this.getBoundingCircles() };
          } }, { key: "fit", value: function(e, t2, r) {
            var i2, n = this.unit_scale, o2 = Math.max.apply(Math, _toConsumableArray(e.map(function(e2) {
              return e2[1];
            }))), a2 = o2 * n, s = _slicedToArray(LabelLineBase.splitLineByOrientation(t2), 2);
            t2 = s[0], i2 = s[1], "number" == typeof r.orientation && (this.offset[1] += ORIENTED_LABEL_OFFSET_FACTOR * (o2 - r.vertical_buffer), i2 && (this.offset[1] *= -1), -1 === r.orientation && (this.offset[1] *= -1));
            var l = getLineLengths(t2), u2 = e.map(function(e2) {
              return e2[0] * n;
            }), c2 = l.reduce(function(e2, t3) {
              return e2 + t3;
            }, 0), h = u2.reduce(function(e2, t3) {
              return e2 + t3;
            }, 0);
            if (c2 < h)
              return false;
            var f2 = t2.length - 1;
            if (f2 < 2)
              return false;
            var d = j.curvaturePlacement(t2, c2, l, h, 0, f2), _ = t2[d];
            if (-1 === d || f2 - d < 2)
              return false;
            this.position = _;
            for (var p2 = 0; p2 < u2.length; p2++) {
              this.positions[p2] = [], this.offsets[p2] = [], this.angles[p2] = [], this.pre_angles[p2] = [];
              for (var g = 0; g < STOPS.length; g++) {
                var m = STOPS[g], y = _slicedToArray(j.scaleLine(m, t2), 2), v = y[0], x2 = y[1], _ = v[d], b2 = j.placeAtIndex(d, v, x2, u2), T2 = b2.positions, A2 = b2.offsets, E2 = b2.angles, w = b2.pre_angles, S2 = A2.map(function(e2) {
                  return Math.sqrt(e2[0] * e2[0] + e2[1] * e2[1]) / n;
                });
                if (0 === m) {
                  this.angle = 1 / E2.length * E2.reduce(function(e2, t3) {
                    return e2 + t3;
                  });
                  for (var k = 0; k < T2.length; k++) {
                    var P2 = T2[k], R2 = w[k], M2 = u2[k], L2 = R2 + E2[k];
                    this._aabbs.push(this.getAABBForSegment(P2, M2, a2, L2));
                  }
                }
                this.positions[p2].push(T2[p2]), this.offsets[p2].push(S2[p2]), this.angles[p2].push(E2[p2]), this.pre_angles[p2].push(w[p2]);
              }
            }
            for (var u2 = e.slice().reverse().map(function(e2) {
              return e2[0] * n;
            }), O2 = 0; O2 < u2.length; O2++) {
              this.alt_offsets[O2] = [], this.alt_angles[O2] = [], this.alt_pre_angles[O2] = [];
              for (var C2 = 0; C2 < STOPS.length; C2++) {
                var N2 = STOPS[C2], I = _slicedToArray(j.scaleLine(N2, t2), 2), B2 = I[0], z2 = I[1];
                _ = B2[d];
                var U2 = j.placeAtIndex(d, B2, z2, u2), F2 = U2.offsets, G = U2.angles, D2 = U2.pre_angles, $ = F2.map(function(e2) {
                  return Math.sqrt(e2[0] * e2[0] + e2[1] * e2[1]) / n;
                });
                0 === N2 && (this.alt_angle = 1 / G.length * G.reduce(function(e2, t3) {
                  return e2 + t3;
                })), this.alt_offsets[O2].push($[O2]), this.alt_angles[O2].push(G[O2]), this.alt_pre_angles[O2].push(D2[O2]);
              }
            }
            return true;
          } }, { key: "getBoundingCircles", value: function() {
            if (!this._circles) {
              for (var e = [], t2 = this.unit_scale, r = 0; r < this.positions.length; r++) {
                var i2 = this.sizes[r], n = this.angles[r][0], o2 = this.positions[r][0], a2 = i2[0] / 2 * t2, s = a2 * Math.cos(n), l = a2 * Math.sin(n), u2 = -s, c2 = -l, h = _slicedToArray(o2, 2), f2 = h[0], d = h[1], _ = encircleLine(s += f2, l += d *= -1, u2 += f2, c2 += d, i2[1] / 2 * t2);
                Array.prototype.push.apply(e, _);
              }
              this._circles = e;
            }
            return this._circles;
          } }, { key: "getAABB", value: function() {
            if (!this._aabb) {
              for (var e = 1 / 0, t2 = -1 / 0, r = -1 / 0, i2 = 1 / 0, n = 0; n < this._aabbs.length; n++)
                var o2 = this._aabbs[n], e = Math.min(e, o2.left), t2 = Math.max(t2, o2.top), r = Math.max(r, o2.right), i2 = Math.min(i2, o2.bottom);
              this._aabb = { left: e, top: t2, right: r, bottom: i2 };
            }
            return this._aabb;
          } }], [{ key: "curvaturePlacement", value: function(e, t2, r, i2, n, o2) {
            n = n || 0, o2 = o2 || e.length - 1;
            for (var a2 = [], s = n + 1; s < o2; s++) {
              var l = e[s - 1], u2 = e[s], c2 = e[s + 1], h = Vector$1.perp(u2, l), f2 = Vector$1.perp(c2, u2), d = Vector$1.angleBetween(h, f2);
              CURVE_MAX_ANGLE < d && (d = 1 / 0), a2.push(d);
            }
            a2.push(1 / 0);
            for (var _ = [], p2 = [], g = n, m = 0, y = 0; y < n; y++)
              m += r[y];
            for (; m + i2 < t2; ) {
              for (var v = m + i2, x2 = m, b2 = g, T2 = 0; b2 < o2 && x2 + r[b2] < v && (T2 += a2[b2]) !== 1 / 0; )
                x2 += r[b2], b2++;
              if (0 === T2)
                return g;
              var A2 = T2 / (b2 - g);
              _.push(T2), p2.push(A2), m += r[g], g++;
            }
            if (0 === _.length)
              return -1;
            var E2 = Math.min.apply(null, _), w = p2[_.indexOf(E2)];
            return E2 < CURVE_MIN_TOTAL_COST && w < CURVE_MIN_AVG_COST ? _.indexOf(E2) : -1;
          } }, { key: "scaleLine", value: function(n, o2) {
            var a2 = [o2[0]], s = [];
            return o2.forEach(function(e, t2) {
              var r, i2;
              t2 !== o2.length - 1 && (r = Vector$1.sub(o2[t2 + 1], o2[t2]), i2 = Vector$1.mult(r, 1 + n), a2.push(Vector$1.add(a2[t2], i2)), s.push(Vector$1.length(i2)));
            }), [a2, s];
          } }, { key: "placeAtIndex", value: function(e, t2, r, i2) {
            var n = t2[e], o2 = _slicedToArray(j.getIndicesAndOffsets(e, r, i2), 2), a2 = o2[0], s = o2[1], l = j.getPositionsFromIndicesAndOffsets(t2, a2, s), u2 = _slicedToArray(j.getAnglesFromIndicesAndOffsets(n, a2, t2, l), 3);
            return { positions: l, offsets: u2[0], angles: u2[1], pre_angles: u2[2] };
          } }, { key: "getIndicesAndOffsets", value: function(e, t2, r) {
            for (var i2 = r.length, n = [], o2 = [], a2 = 0, s = 0, l = 0; a2 < i2; ) {
              for (var u2 = r[a2]; a2 < i2 && s + 0.5 * u2 <= l + t2[e]; ) {
                var c2 = s - l + 0.5 * u2;
                o2.push(c2), n.push(e), s += u2, u2 = r[++a2];
              }
              l += t2[e], e++;
            }
            return [n, o2];
          } }, { key: "getPositionsFromIndicesAndOffsets", value: function(e, t2, r) {
            for (var i2 = [], n = 0; n < t2.length; n++) {
              var o2 = t2[n], a2 = r[n], s = getAngleForSegment(e[o2], e[o2 + 1]), l = Vector$1.rot([a2, 0], s), u2 = Vector$1.add(e[o2], l);
              i2.push(u2);
            }
            return i2;
          } }, { key: "getAnglesFromIndicesAndOffsets", value: function(e, t2, r, i2) {
            for (var n = [], o2 = [], a2 = [], s = 0; s < i2.length; s++) {
              var l, u2, c2 = i2[s], h = t2[s], f2 = Vector$1.sub(c2, e), d = -Vector$1.angle(f2), _ = getTextAngleForSegment(r[h], r[h + 1]) - d;
              0 < s && (l = n[s - 1], u2 = o2[s - 1], Math.abs(d - l) > Math.PI && (d += l < d ? -2 * Math.PI : 2 * Math.PI), Math.abs(u2 - _) > Math.PI && (_ += u2 < _ ? -2 * Math.PI : 2 * Math.PI)), n.push(d), o2.push(_), a2.push(f2);
            }
            return [a2, n, o2];
          } }]), j;
        }();
        function calcFitness(e, t2) {
          return t2 / e;
        }
        function getAngleForSegment(e, t2) {
          var r = Vector$1.sub(t2, e);
          return Vector$1.angle(r);
        }
        function getTextAngleForSegment(e, t2) {
          return -getAngleForSegment(e, t2);
        }
        function getLineLengths(e) {
          for (var t2 = [], r = 0; r < e.length - 1; r++) {
            var i2 = e[r], n = e[r + 1], o = Math.hypot(i2[0] - n[0], i2[1] - n[1]);
            t2.push(o);
          }
          return t2;
        }
        function getAbsAngleDiff(e, t2) {
          for (var r, i2 = t2 < e ? (r = t2, e) : (r = e, t2); i2 - r > Math.PI; )
            r += 2 * Math.PI;
          return Math.abs(i2 - r);
        }
        var TextStyle = Object.create(Points);
        Object.assign(TextStyle, { name: "text", super: Points, built_in: true, init: function(e) {
          var t2 = 0 < arguments.length && void 0 !== e ? e : {};
          Style.init.call(this, t2), this.setupDefines(), this.defines.TANGRAM_HAS_SHADER_POINTS = false, this.defines.TANGRAM_IS_TEXT_STYLE = true, this.reset();
        }, makeVertexTemplate: function(e, t2) {
          this.super.makeVertexTemplate.apply(this, arguments);
          var r = t2.vertex_data.vertex_layout;
          return this.fillVertexTemplate(r, "a_pre_angles", 0, { size: 4 }), this.fillVertexTemplate(r, "a_offsets", 0, { size: 4 }), this.fillVertexTemplate(r, "a_angles", 0, { size: 4 }), this.fillVertexTemplate(r, "a_offsets_alt", 0, { size: 4 }), this.fillVertexTemplate(r, "a_pre_angles_alt", 0, { size: 4 }), this.fillVertexTemplate(r, "a_angles_alt", 0, { size: 4 }), this.vertex_template;
        }, reset: function() {
          this.queues = {}, this.resetText();
        }, addFeature: function(t2, e, r) {
          var i2 = this, n = r.tile, o = t2.geometry.type;
          e.can_articulate = "LineString" === o || "MultiLineString" === o, e.supersample_text = "LineString" === o || "MultiLineString" === o;
          var a2 = this.parseTextFeature(t2, e, r, n);
          a2 && (a2 instanceof Array ? a2.forEach(function(e2) {
            e2.feature = t2, e2.context = r, e2.layout.vertex = false, i2.queueFeature(e2, n);
          }) : (a2.feature = t2, a2.context = r, a2.layout.vertex = false, this.queueFeature(a2, n)), Collision.addStyle(this.name, n.id));
        }, endData: function(n) {
          var o = this, e = this.queues[n.id];
          return delete this.queues[n.id], this.collideAndRenderTextLabels(n, this.name, e).then(function(e2) {
            var t2 = e2.labels, r = e2.texts;
            return t2 && r && (o.texts[n.id] = r, t2.forEach(function(e3) {
              var t3 = e3.text_settings_key, r2 = o.texts[n.id][t3] && o.texts[n.id][t3][e3.text], i2 = o.feature_style;
              i2.label = e3.label, e3.label.text_data = { text_info: r2, text_settings_key: t3, text: e3.text }, i2.label_texture = o.textureManager.default, r2.text_settings.can_articulate ? (i2.size = {}, "straight" === e3.label.type ? i2.size.straight = r2.size.logical_size : i2.size.curved = r2.segment_sizes.map(function(e4) {
                return e4.logical_size;
              })) : i2.size = r2.size.logical_size, Style.addFeature.call(o, e3.feature, e3.draw, e3.context);
            })), o.freeText(n), Style.endData.call(o, n).then(function(e3) {
              if (e3) {
                for (var t3 in e3.meshes)
                  e3.meshes[t3].uniforms.u_apply_color_blocks = true;
                n.mesh_data[o.name] = e3;
              }
              return e3;
            });
          });
        }, _preprocess: function(e) {
          return this.preprocessText(e);
        }, buildTextLabels: function(e, t2) {
          for (var r = [], i2 = 0; i2 < t2.length; i2++) {
            var n, o = t2[i2], a2 = this.texts[e.id][o.text_settings_key][o.text], s = void 0;
            o.layout.vertical_buffer = a2.vertical_buffer, s = a2.text_settings.can_articulate ? (n = a2.segment_sizes.map(function(e2) {
              return e2.collision_size;
            }), o.layout.no_curving = a2.no_curving, this.buildLabels(n, o.feature.geometry, o.layout, a2.size.collision_size)) : this.buildLabels(a2.size.collision_size, o.feature.geometry, o.layout);
            for (var l = 0; l < s.length; l++) {
              var u2 = Object.create(o);
              u2.label = s[l], r.push(u2);
            }
          }
          return r;
        }, buildLabels: function(e, t2, r, i2) {
          var n, o, a2 = "Point" !== t2.type, s = [];
          if ("LineString" === t2.type)
            Array.prototype.push.apply(s, this.buildLineLabels(t2.coordinates, e, a2, r, i2));
          else if ("MultiLineString" === t2.type)
            for (var l = t2.coordinates, u2 = 0; u2 < l.length; ++u2)
              Array.prototype.push.apply(s, this.buildLineLabels(l[u2], e, a2, r, i2));
          else if ("Point" === t2.type)
            s.push(new LabelPoint(t2.coordinates, e, a2, r));
          else if ("MultiPoint" === t2.type)
            for (var c2 = t2.coordinates, h = 0; h < c2.length; ++h)
              s.push(new LabelPoint(c2[h], e, a2, r));
          else {
            "Polygon" === t2.type ? (n = Geo$1.centroid(t2.coordinates), s.push(new LabelPoint(n, e, a2, r))) : "MultiPolygon" === t2.type && (o = Geo$1.multiCentroid(t2.coordinates), s.push(new LabelPoint(o, e, a2, r)));
          }
          return s;
        }, buildLineLabels: function(e, t2, r, i2, n) {
          var o, a2 = [], s = Math.min(i2.subdiv, e.length - 1);
          if (1 < s)
            for (var l = (e.length - 1) / s, u2 = 0; u2 < s; u2++) {
              var c2 = Math.floor(u2 * l), h = Math.floor((u2 + 1) * l) + 1, f2 = e.slice(c2, h), d = LabelLine.create(t2, n, f2, r, i2);
              d && a2.push(d);
            }
          return a2.length < s && ((o = LabelLine.create(t2, n, e, r, i2)) && a2.push(o)), a2;
        }, vertexLayoutForMeshVariant: function() {
          var e;
          return this.vertex_layout || (e = [{ name: "a_position", size: 4, type: gl$1.SHORT, normalized: false }, { name: "a_shape", size: 4, type: gl$1.SHORT, normalized: false }, { name: "a_texcoord", size: 2, type: gl$1.UNSIGNED_SHORT, normalized: true }, { name: "a_offset", size: 2, type: gl$1.SHORT, normalized: false }, { name: "a_color", size: 4, type: gl$1.UNSIGNED_BYTE, normalized: true }, { name: "a_angles", size: 4, type: gl$1.SHORT, normalized: false }, { name: "a_offsets", size: 4, type: gl$1.UNSIGNED_SHORT, normalized: false }, { name: "a_pre_angles", size: 4, type: gl$1.BYTE, normalized: false }, { name: "a_selection_color", size: 4, type: gl$1.UNSIGNED_BYTE, normalized: true }, { name: "a_is_flat", size: 1, type: gl$1.UNSIGNED_BYTE, normalized: true }, { name: "a_offsets_alt", size: 4, type: gl$1.UNSIGNED_SHORT, normalized: false }, { name: "a_pre_angles_alt", size: 4, type: gl$1.BYTE, normalized: false }, { name: "a_angles_alt", size: 4, type: gl$1.SHORT, normalized: false }], this.vertex_layout = new VertexLayout(e)), this.vertex_layout;
        }, getMeshVariantTypeForDraw: Points.getMeshVariantTypeForDraw }), TextStyle.texture_id = 0;
        var RasterStyle = Object.create(Polygons);
        Object.assign(RasterStyle, { name: "raster", super: Polygons, built_in: true, init: function() {
          this.raster = this.raster || "color", this.super.init.apply(this, arguments), this.selection = false, this.defines.SNAP_TO_PIXEL_GRID = true;
        }, _preprocess: function(e) {
          return e.color = e.color || StyleParser.defaults.color, this.super._preprocess.apply(this, arguments);
        } });
        var CustomIcons = Object.create(Points);
        Object.assign(CustomIcons, { name: "custom_icons", collision: false, init: function(e) {
          var t2 = 0 < arguments.length && void 0 !== e ? e : {};
          Points.init.call(this, t2);
        }, loadTexture: function(e, t2, r) {
          var i2, n = e.width, o = e.height, a2 = e.items, s = document.createElement("canvas"), l = Utils$1.device_pixel_ratio, u2 = this.sources[t2], c2 = { sprites: {} };
          if (s.width = n * l, s.height = o * l, u2) {
            var h, f2 = a2.length, d = s.getContext("2d");
            for (d.scale(l, l); h = a2[--f2]; ) {
              var _, p2 = u2.getIconBitmapByObjectId(h.meta.objectId, h.meta.id);
              p2 && ((_ = isTainting(p2)) ? log("error", _) : (d.drawImage(p2, h.x, h.y, h.width, h.height), c2.sprites[h.meta.id] = [h.x, h.y, h.width, h.height]));
            }
          }
          return c2.element = s, (i2 = this.textureManager.create(this.gl, r, c2)).retain(), i2.loading.then(function(e2) {
            return e2.name;
          });
        }, buildRasterTextures: function(e, t2) {
          return WorkerBroker.postMessage(this.main_thread_target + ".loadTexture", e.rasters, e.source, e.texture_name).then(function(e2) {
            return t2.textures.push(e2), t2;
          });
        }, addFeature: function(e, t2, r) {
          var i2 = r.tile.rasters, n = {};
          i2.items.forEach(function(e2) {
            n[e2.meta.id] = [e2.x, e2.y, e2.width, e2.height];
          });
          var o = "".concat(r.tile.source, "_dyn_").concat(r.tile.coords.key, "_").concat(this.generation, "_").concat(r.tile.id);
          t2.texture = r.tile.texture_name = o;
          var a2 = Object.assign({}, DEFAULT_TEXTURE_INFO, { name: o, width: i2.width, height: i2.height, sprites: n, manager: this.textureManager });
          Texture.prototype.calculateSprites.apply(a2), this.textureManager.textures[o] = a2, Points.addFeature.apply(this, arguments), delete this.textureManager.textures[o];
        } });
        var DEFAULT_TEXTURE_INFO = { filtering: "linear", density: 1, valid: true, power_of_2: false, texcoords: {}, sizes: {}, css_sizes: {}, aspects: {} }, OverlayStyle = Object.create(Polygons);
        Object.assign(OverlayStyle, { name: "overlays", super: Polygons, init: function(e) {
          var t2 = 0 < arguments.length && void 0 !== e ? e : {};
          this.selection = t2.selection || true, this.raster = this.raster || "color", this.super.init.apply(this, arguments);
        }, setupRasters: function() {
          if (!Thread.is_main)
            return false;
          if (this.super.setupRasters.call(this))
            return true;
          var e = false;
          for (var t2 in this.sources)
            if (this.sources[t2] instanceof ObjectSource) {
              e = true;
              break;
            }
          return !!e && (this.defines.TANGRAM_MODEL_POSITION_BASE_ZOOM_VARYING = true, this.replaceShaderBlock("raster", shaderSrc_rasters, "Raster"), true);
        }, loadTextures: function(a2, e) {
          var s, l, u2, c2 = this.sources[e], t2 = a2.name;
          if (a2.overlays_config.forEach(function(e2) {
            var t3, r2 = e2.texcoords, i3 = e2.id, n = c2.getMapObjectById(i3), o = n.getBitmap();
            o && ((t3 = isTainting(o = bitmapToCanvas(o, o.width, o.height))) ? log("error", t3) : (s || ((s = document.createElement("canvas")).width = a2.width, s.height = a2.height, l = s.getContext("2d")), l.save(), l.globalAlpha = n.getOpacity(), r2.forEach(function(e3) {
              return l.drawImage(o, e3[0], e3[1], e3[2], e3[3]);
            }), l.restore(), u2 = true));
          }), u2) {
            a2.element = s;
            var r = {};
            return r[t2] = a2, this.super.loadTextures.call(this, r);
          }
          var i2 = this.textureManager.textures[this.textureManager.default];
          return Promise.resolve([{ name: i2.name, width: i2.width, height: i2.height, loaded: i2.loaded }]);
        }, buildRasterTextures: function(e, r) {
          var t2 = this.sources[e.source].tileTexture(e);
          return t2 ? WorkerBroker.postMessage(this.main_thread_target + ".loadTextures", t2, e.source).then(function(e2) {
            if (!e2 || e2.length < 1)
              return r;
            if (e2.some(function(e3) {
              return !e3.loaded;
            }))
              return null;
            var t3 = e2[0].name;
            return r.uniforms = r.uniforms || {}, r.textures = r.textures || [], r.uniforms.u_raster = t3, r.uniforms.u_raster_offset = [0, 0, 1], r.textures.push(t3), r;
          }) : Promise.resolve(r);
        } });
        var shaderSrc_Vertex = "uniform float u_horizon;uniform float u_tilt;uniform float u_zoom;attribute vec2 a_position;attribute float a_is_sky;attribute float a_is_top;attribute vec4 a_color;varying vec4 v_color;const float SIN_THRESHOLD_ANGLE=0.96126069082;void main(){v_color=a_color;float sin_tilt=sin(u_tilt);float sky_bottom_alpha=1.-max(sin_tilt-SIN_THRESHOLD_ANGLE,0.)*3.;if((a_position.y==1.&&a_is_sky==0.)||(a_position.y==0.&&a_is_sky==1.)){v_color.w=sky_bottom_alpha;}float fog_height=max((22.-u_zoom)*0.04,0.)*(sin_tilt-.7);float position_z=u_zoom<17. ? .942 : .9418;gl_Position=vec4(a_position.x,a_is_sky*(a_position.y+a_is_top)+1.0-u_horizon-(1.0-a_is_sky)*(1.0-a_position.y)*fog_height,position_z,1.0);}", shaderSrc_Fragment = "varying vec4 v_color;void main(void){gl_FragColor=v_color;}", STYLE_NAME = "skybox", SkyBox = Object.create(Style), positions = [-1, 0, 1, 0, -1, 1, -1, 1, 1, 0, 1, 1, -1, 0, 1, 0, -1, 1, -1, 1, 1, 0, 1, 1];
        Object.assign(SkyBox, { name: STYLE_NAME, built_in: true, vertex_shader_src: shaderSrc_Vertex, fragment_shader_src: shaderSrc_Fragment, selection: false, blend: "inlay", blend_order: 1, init: function() {
          Style.init.apply(this, arguments), this.selection = false;
        }, _preprocess: function(e) {
          return e.color = { top: StyleParser.createColorPropertyCache(e.color.zenith), bottom: StyleParser.createColorPropertyCache(e.color.horizon), fog: StyleParser.createColorPropertyCache(e.color.fog) }, e;
        }, vertexLayoutForMeshVariant: function() {
          var e;
          return this.vertex_layout || (e = [{ name: "a_position", size: 2, type: gl$1.FLOAT, normalized: false }, { name: "a_is_sky", size: 1, type: gl$1.FLOAT, normalized: true }, { name: "a_color", size: 4, type: gl$1.UNSIGNED_BYTE, normalized: true }, { name: "a_is_top", size: 1, type: gl$1.FLOAT, normalized: true }], this.vertex_layout = new VertexLayout(e)), this.vertex_layout;
        }, makeVertexTemplate: function() {
          var e = 0;
          return this.vertex_template[e++] = 0, this.vertex_template[1] = 0, this.vertex_template;
        }, parseFeature: function(e, t2, r) {
          var i2 = this.feature_style;
          return t2.color && t2.color.top && t2.color.bottom && (i2.color_top = this.parseColor(t2.color.top, r), i2.color_bottom = this.parseColor(t2.color.bottom, r), i2.color_fog = this.parseColor(t2.color.fog || "white", r), Array.isArray(i2.color_fog) && (i2.color_fog = i2.color_fog.slice(), i2.color_fog[3] = 0)), i2;
        }, buildGeometry: function(e, t2, r) {
          for (var i2 = this.makeVertexTemplate(t2), n = r.vertex_data, o = r.vertex_data.vertex_layout, a2 = n.vertex_layout.index.a_position, s = { top: t2.color_top, bottom: t2.color_bottom }, l = { top: t2.color_bottom, bottom: t2.color_fog }, u2 = 0, c2 = positions.length - 1; u2 < c2; u2 += 2) {
            i2[a2 + 0] = positions[u2], i2[a2 + 1] = positions[u2 + 1];
            var h = u2 < 12, f2 = 0 < positions[u2 + 1], d = h ? s : l;
            this.fillVertexTemplate(o, "a_is_sky", h ? 1 : 0, { size: 1 }), this.fillVertexTemplate(o, "a_is_top", f2 ? 1 : 0, { size: 1 }), this.fillVertexTemplate(o, "a_color", Vector$1.mult(f2 ? d.top : d.bottom, 255), { size: 4 }), n.addVertex(i2);
          }
          return 4;
        } });
        var shaderSrc_accessors = "#ifdef TANGRAM_VERTEX_SHADER\nvec4 modelPosition(){return vec4(a_position.xyz/TANGRAM_TILE_SCALE*exp2(u_tile_origin.z-u_tile_origin.w),1.)+vec4(0.,1.,0.,0.);}vec4 modelPositionBaseZoom(){return vec4(a_position.xyz/TANGRAM_TILE_SCALE,1.)+vec4(0.,1.,0.,0.);}\n#endif\nvec4 worldPosition(){return v_world_position;}\n#ifdef TANGRAM_VERTEX_SHADER\nvec4 wrapWorldPosition(vec4 world_position){\n#if defined(TANGRAM_WORLD_POSITION_WRAP)\nvec2 anchor=u_tile_origin.xy-mod(u_tile_origin.xy,TANGRAM_WORLD_POSITION_WRAP);world_position.xy-=anchor;\n#endif\nreturn world_position;}\n#endif\n#if defined(TANGRAM_VERTEX_SHADER)\nvec3 worldNormal(){return TANGRAM_NORMAL;}\n#elif defined(TANGRAM_FRAGMENT_SHADER)\nvec3 worldNormal(){return u_inverseNormalMatrix*TANGRAM_NORMAL;}\n#endif\n", shaderSrc_layerOrder = "void applyLayerOrder(float layer,inout vec4 position){position.z-=layer*TANGRAM_LAYER_DELTA*position.w;}", shaderSrc_selectionGlobals = "\n#if defined(TANGRAM_FEATURE_SELECTION) && defined(TANGRAM_VERTEX_SHADER)\nattribute vec4 a_selection_color;varying vec4 v_selection_color;uniform vec4 u_selection_discard0;uniform vec4 u_selection_discard1;uniform vec4 u_selection_discard2;uniform vec4 u_selection_discard3;uniform vec4 u_selection_discard4;uniform vec4 u_selection_discard5;uniform vec4 u_selection_discard6;uniform vec4 u_selection_discard7;uniform vec4 u_selection_discard8;uniform vec4 u_selection_discard9;\n#endif\n", shaderSrc_selectionVertex = "\n#if defined(TANGRAM_FEATURE_SELECTION) && defined(TANGRAM_VERTEX_SHADER)\nif(a_selection_color.rgb==vec3(0.)||a_selection_color==u_selection_discard0||a_selection_color==u_selection_discard1||a_selection_color==u_selection_discard2||a_selection_color==u_selection_discard3||a_selection_color==u_selection_discard4||a_selection_color==u_selection_discard5||a_selection_color==u_selection_discard6||a_selection_color==u_selection_discard7||a_selection_color==u_selection_discard8||a_selection_color==u_selection_discard9){gl_Position=vec4(0.,0.,0.,1.);return;}v_selection_color=a_selection_color;\n#endif\n", shaderSrc_utils = "#ifndef UTILS\n#define UTILS\nbool isLocalSpacePixelOutsideTile(vec4 pixel_local_space_position,float tile_scale){return pixel_local_space_position.x<0.||pixel_local_space_position.x>=tile_scale||pixel_local_space_position.y>0.||pixel_local_space_position.y<=-tile_scale;}\n#endif\n", shaderSrc_snapToPixelGrid = "uniform float u_view_pan_snap_timer;void snapToPixelGrid(inout vec4 position){vec2 position_fract=fract((((position.xy/position.w)+1.)*.5)*u_resolution);vec2 position_snap=position.xy+((step(0.5,position_fract)-position_fract)*position.w*2./u_resolution);\n#ifdef TANGRAM_VIEW_PAN_SNAP_RATE\nposition.xy=mix(position.xy,position_snap,clamp(u_view_pan_snap_timer*TANGRAM_VIEW_PAN_SNAP_RATE,0.,1.));\n#else\nposition.xy=position_snap;\n#endif\n}", StyleManager = function() {
          function e() {
            _classCallCheck(this, e), this.styles = {}, this.base_styles = {}, this.register(Object.create(Polygons)), this.register(Object.create(Lines)), this.register(Object.create(PatternLines)), this.register(Object.create(Points)), this.register(Object.create(TextStyle)), this.register(Object.create(RasterStyle)), this.register(Object.create(CustomIcons)), this.register(Object.create(OverlayStyle)), this.register(Object.create(SkyBox));
          }
          return _createClass(e, [{ key: "init", value: function() {
            ShaderProgram.removeBlock("global"), ShaderProgram.removeBlock("setup"), ShaderProgram.addBlock("global", shaderSrc_accessors), ShaderProgram.addBlock("global", shaderSrc_layerOrder), ShaderProgram.addBlock("global", shaderSrc_selectionGlobals), ShaderProgram.addBlock("global", shaderSrc_snapToPixelGrid), ShaderProgram.replaceBlock("utils", shaderSrc_utils), ShaderProgram.replaceBlock("setup", shaderSrc_selectionVertex), ShaderProgram.defines.TANGRAM_EPSILON = 1e-5, ShaderProgram.defines.TANGRAM_LAYER_DELTA = 1 / 16384, ShaderProgram.defines.TANGRAM_TILE_SCALE = "vec3(".concat(Geo$1.tile_scale, "., ").concat(Geo$1.tile_scale, "., u_meters_per_pixel * ").concat(Geo$1.tile_size, ".)"), ShaderProgram.defines.TANGRAM_HEIGHT_SCALE = Geo$1.height_scale, ShaderProgram.defines.TANGRAM_ALPHA_TEST = 0.1, Lines.dash_textures = {};
          } }, { key: "destroy", value: function(r) {
            var i2 = this;
            Object.keys(this.styles).forEach(function(e2) {
              var t2 = i2.styles[e2];
              t2.gl === r && (log("trace", "StyleManager.destroy: destroying render style ".concat(t2.name)), t2.base && i2.remove(t2.name), t2.destroy());
            });
          } }, { key: "register", value: function(e2) {
            this.styles[e2.name] = e2, this.base_styles[e2.name] = e2;
          } }, { key: "remove", value: function(e2) {
            delete this.styles[e2];
          } }, { key: "mix", value: function(t2, r) {
            if (t2.mixed)
              return t2;
            t2.mixed = {};
            var e2 = [];
            t2.mix && (Array.isArray(t2.mix) ? e2.push.apply(e2, _toConsumableArray(t2.mix)) : e2.push(t2.mix), (e2 = e2.map(function(e3) {
              return r[e3];
            }).filter(function(e3) {
              return e3 && e3 !== t2;
            })).forEach(function(e3) {
              return t2.mixed[e3.name] = true;
            })), e2.push(t2), t2.animated = e2.some(function(e3) {
              return e3 && e3.animated;
            }), t2.texcoords = e2.some(function(e3) {
              return e3 && e3.texcoords;
            }), t2.base = e2.map(function(e3) {
              return e3.base;
            }).filter(function(e3) {
              return e3;
            }).pop(), t2.lighting = e2.map(function(e3) {
              return e3.lighting;
            }).filter(function(e3) {
              return null != e3;
            }).pop(), t2.texture = e2.map(function(e3) {
              return e3.texture;
            }).filter(function(e3) {
              return e3;
            }).pop(), t2.raster = e2.map(function(e3) {
              return e3.raster;
            }).filter(function(e3) {
              return null != e3;
            }).pop(), t2.dash = e2.map(function(e3) {
              return e3.dash;
            }).filter(function(e3) {
              return null != e3;
            }).pop(), t2.dash_background_color = e2.map(function(e3) {
              return e3.dash_background_color;
            }).filter(function(e3) {
              return null != e3;
            }).pop(), e2.some(function(e3) {
              return e3.hasOwnProperty("blend") && e3.blend;
            }) && (t2.blend = e2.map(function(e3) {
              return e3.hasOwnProperty("blend") && e3.blend;
            }).filter(function(e3) {
              return e3;
            }).pop()), t2.blend_order = e2.map(function(e3) {
              return e3.blend_order;
            }).filter(function(e3) {
              return null != e3;
            }).pop(), t2.defines = Object.assign.apply(Object, [{}].concat(_toConsumableArray(e2.map(function(e3) {
              return e3.defines;
            }).filter(function(e3) {
              return e3;
            })))), t2.material = Object.assign.apply(Object, [{}].concat(_toConsumableArray(e2.map(function(e3) {
              return e3.material;
            }).filter(function(e3) {
              return e3;
            }))));
            var i2 = e2.map(function(e3) {
              return e3.draw;
            }).filter(function(e3) {
              return e3;
            });
            return 0 < i2.length && (t2.draw = mergeObjects.apply(void 0, [{}].concat(_toConsumableArray(i2)))), this.mixShaders(t2, r, e2), t2;
          } }, { key: "mixShaders", value: function(e2, r, t2) {
            var a2 = {}, i2 = t2.map(function(e3) {
              return e3.shaders;
            }).filter(function(e3) {
              return e3;
            });
            if (a2.defines = Object.assign.apply(Object, [{}].concat(_toConsumableArray(i2.map(function(e3) {
              return e3.defines;
            }).filter(function(e3) {
              return e3;
            })))), a2.uniforms = {}, a2._uniforms = e2.shaders && e2.shaders.uniforms || {}, a2._uniform_scopes = {}, t2.filter(function(e3) {
              return e3.shaders && e3.shaders.uniforms;
            }).forEach(function(e3) {
              for (var t3 in e3.shaders.uniforms)
                !function(t4) {
                  a2._uniform_scopes[t4] = e3.name, Object.defineProperty(a2.uniforms, t4, { enumerable: true, configurable: true, get: function() {
                    return void 0 !== a2._uniforms[t4] ? a2._uniforms[t4] : r[a2._uniform_scopes[t4]].shaders.uniforms !== a2.uniforms ? r[a2._uniform_scopes[t4]].shaders.uniforms[t4] : void 0;
                  }, set: function(e4) {
                    a2._uniforms[t4] = e4;
                  } });
                }(t3);
            }), a2.extensions = Object.keys(i2.map(function(e3) {
              return e3.extensions;
            }).filter(function(e3) {
              return e3;
            }).reduce(function(t3, e3) {
              return "string" == typeof e3 ? t3[e3] = true : e3.forEach(function(e4) {
                return t3[e4] = true;
              }), t3;
            }, {}) || {}), e2.shaders && e2.shaders.blocks)
              for (var n in e2.shaders.block_scopes = e2.shaders.block_scopes || {}, e2.shaders.blocks) {
                var o, s = e2.shaders.blocks[n];
                e2.shaders.block_scopes[n] = e2.shaders.block_scopes[n] || [], Array.isArray(s) ? (o = e2.shaders.block_scopes[n]).push.apply(o, _toConsumableArray(s.map(function() {
                  return e2.name;
                }))) : e2.shaders.block_scopes[n].push(e2.name);
              }
            var l = {};
            return i2.forEach(function(e3) {
              if (e3.blocks) {
                a2.blocks = a2.blocks || {}, a2.block_scopes = a2.block_scopes || {};
                var t3 = {};
                for (var r2 in e3.blocks) {
                  var i3 = e3.blocks[r2], n2 = e3.block_scopes[r2];
                  a2.blocks[r2] = a2.blocks[r2] || [], a2.block_scopes[r2] = a2.block_scopes[r2] || [], i3 = Array.isArray(i3) ? i3 : [i3], n2 = Array.isArray(n2) ? n2 : [n2];
                  for (var o2 = 0; o2 < i3.length; o2++)
                    l[n2[o2]] || (t3[n2[o2]] = true, a2.blocks[r2].push(i3[o2]), a2.block_scopes[r2].push(n2[o2]));
                }
                Object.assign(l, t3);
              }
            }), Object.assign(e2.mixed, l), e2.shaders = a2, e2;
          } }, { key: "create", value: function(e2, t2, r) {
            var i2 = 2 < arguments.length && void 0 !== r ? r : {}, n = mergeObjects({}, t2);
            return n.name = e2, (n = this.mix(n, i2)).base && this.base_styles[n.base] ? this.styles[e2] = n = Object.assign(Object.create(this.base_styles[n.base]), n) : n.base = null, n;
          } }, { key: "build", value: function(r) {
            var i2 = this, e2 = Object.keys(r).sort(function(e3, t3) {
              return i2.inheritanceDepth(e3, r) - i2.inheritanceDepth(t3, r);
            });
            for (var t2 in this.styles)
              this.base_styles[t2] ? this.styles[t2].reset() : delete this.styles[t2];
            var n = {};
            return e2.forEach(function(e3) {
              n[e3] = i2.create(e3, r[e3], n);
            }), this.styles;
          } }, { key: "initStyles", value: function(e2) {
            var t2 = 0 < arguments.length && void 0 !== e2 ? e2 : {};
            for (var r in this.styles)
              this.styles[r].init(t2);
          } }, { key: "inheritanceDepth", value: function(t2, r) {
            for (var i2 = this, e2 = 0; ; ) {
              var n = r[t2];
              if (!n)
                break;
              if (!n.mix)
                break;
              if (e2++, Array.isArray(n.mix)) {
                e2 += Math.max.apply(Math, _toConsumableArray(n.mix.map(function(e3) {
                  if (t2 !== e3)
                    return i2.inheritanceDepth(e3, r);
                })));
                break;
              }
              if (t2 === n.mix)
                break;
              t2 = n.mix;
            }
            return e2;
          } }]), e;
        }();
        function isNothing(e) {
          return null == e;
        }
        function isObject$2(e) {
          return "object" == typeof e && null !== e;
        }
        function toArray(e) {
          return Array.isArray(e) ? e : isNothing(e) ? [] : [e];
        }
        function extend$1(e, t2) {
          var r, i2, n, o;
          if (t2)
            for (r = 0, i2 = (o = Object.keys(t2)).length; r < i2; r += 1)
              e[n = o[r]] = t2[n];
          return e;
        }
        function repeat(e, t2) {
          for (var r = "", i2 = 0; i2 < t2; i2 += 1)
            r += e;
          return r;
        }
        function isNegativeZero(e) {
          return 0 === e && Number.NEGATIVE_INFINITY === 1 / e;
        }
        var isNothing_1 = isNothing, isObject_1 = isObject$2, toArray_1 = toArray, repeat_1 = repeat, isNegativeZero_1 = isNegativeZero, extend_1 = extend$1, common = { isNothing: isNothing_1, isObject: isObject_1, toArray: toArray_1, repeat: repeat_1, isNegativeZero: isNegativeZero_1, extend: extend_1 };
        function YAMLException(e, t2) {
          Error.call(this), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack || "", this.name = "YAMLException", this.reason = e, this.mark = t2, this.message = (this.reason || "(unknown reason)") + (this.mark ? " " + this.mark.toString() : "");
        }
        YAMLException.prototype = Object.create(Error.prototype), YAMLException.prototype.constructor = YAMLException, YAMLException.prototype.toString = function(e) {
          var t2 = this.name + ": ";
          return t2 += this.reason || "(unknown reason)", !e && this.mark && (t2 += " " + this.mark.toString()), t2;
        };
        var exception = YAMLException;
        function Mark(e, t2, r, i2, n) {
          this.name = e, this.buffer = t2, this.position = r, this.line = i2, this.column = n;
        }
        Mark.prototype.getSnippet = function(e, t2) {
          var r, i2, n, o, a2;
          if (!this.buffer)
            return null;
          for (e = e || 4, t2 = t2 || 75, r = "", i2 = this.position; 0 < i2 && -1 === "\0\r\n\u2028\u2029".indexOf(this.buffer.charAt(i2 - 1)); )
            if (--i2, this.position - i2 > t2 / 2 - 1) {
              r = " ... ", i2 += 5;
              break;
            }
          for (n = "", o = this.position; o < this.buffer.length && -1 === "\0\r\n\u2028\u2029".indexOf(this.buffer.charAt(o)); )
            if ((o += 1) - this.position > t2 / 2 - 1) {
              n = " ... ", o -= 5;
              break;
            }
          return a2 = this.buffer.slice(i2, o), common.repeat(" ", e) + r + a2 + n + "\n" + common.repeat(" ", e + this.position - i2 + r.length) + "^";
        }, Mark.prototype.toString = function(e) {
          var t2, r = "";
          return this.name && (r += 'in "' + this.name + '" '), r += "at line " + (this.line + 1) + ", column " + (this.column + 1), e || (t2 = this.getSnippet()) && (r += ":\n" + t2), r;
        };
        var mark = Mark, TYPE_CONSTRUCTOR_OPTIONS = ["kind", "resolve", "construct", "instanceOf", "predicate", "represent", "defaultStyle", "styleAliases"], YAML_NODE_KINDS = ["scalar", "sequence", "mapping"];
        function compileStyleAliases(e) {
          var r = {};
          return null !== e && Object.keys(e).forEach(function(t2) {
            e[t2].forEach(function(e2) {
              r[String(e2)] = t2;
            });
          }), r;
        }
        function Type(t2, e) {
          if (e = e || {}, Object.keys(e).forEach(function(e2) {
            if (-1 === TYPE_CONSTRUCTOR_OPTIONS.indexOf(e2))
              throw new exception('Unknown option "' + e2 + '" is met in definition of "' + t2 + '" YAML type.');
          }), this.tag = t2, this.kind = e.kind || null, this.resolve = e.resolve || function() {
            return true;
          }, this.construct = e.construct || function(e2) {
            return e2;
          }, this.instanceOf = e.instanceOf || null, this.predicate = e.predicate || null, this.represent = e.represent || null, this.defaultStyle = e.defaultStyle || null, this.styleAliases = compileStyleAliases(e.styleAliases || null), -1 === YAML_NODE_KINDS.indexOf(this.kind))
            throw new exception('Unknown kind "' + this.kind + '" is specified for "' + t2 + '" YAML type.');
        }
        var type = Type;
        function compileList(e, t2, i2) {
          var n = [];
          return e.include.forEach(function(e2) {
            i2 = compileList(e2, t2, i2);
          }), e[t2].forEach(function(r) {
            i2.forEach(function(e2, t3) {
              e2.tag === r.tag && n.push(t3);
            }), i2.push(r);
          }), i2.filter(function(e2, t3) {
            return -1 === n.indexOf(t3);
          });
        }
        function compileMap() {
          var e, t2, r = {};
          function i2(e2) {
            r[e2.tag] = e2;
          }
          for (e = 0, t2 = arguments.length; e < t2; e += 1)
            arguments[e].forEach(i2);
          return r;
        }
        function Schema(e) {
          this.include = e.include || [], this.implicit = e.implicit || [], this.explicit = e.explicit || [], this.implicit.forEach(function(e2) {
            if (e2.loadKind && "scalar" !== e2.loadKind)
              throw new exception("There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.");
          }), this.compiledImplicit = compileList(this, "implicit", []), this.compiledExplicit = compileList(this, "explicit", []), this.compiledTypeMap = compileMap(this.compiledImplicit, this.compiledExplicit);
        }
        Schema.DEFAULT = null, Schema.create = function(e, t2) {
          var r, i2;
          switch (arguments.length) {
            case 1:
              r = Schema.DEFAULT, i2 = e;
              break;
            case 2:
              r = e, i2 = t2;
              break;
            default:
              throw new exception("Wrong number of arguments for Schema.create function");
          }
          if (r = common.toArray(r), i2 = common.toArray(i2), !r.every(function(e2) {
            return e2 instanceof Schema;
          }))
            throw new exception("Specified list of super schemas (or a single Schema object) contains a non-Schema object.");
          if (!i2.every(function(e2) {
            return e2 instanceof type;
          }))
            throw new exception("Specified list of YAML types (or a single Type object) contains a non-Type object.");
          return new Schema({ include: r, explicit: i2 });
        };
        var schema = Schema, str = new type("tag:yaml.org,2002:str", { kind: "scalar", construct: function(e) {
          return null !== e ? e : "";
        } }), seq = new type("tag:yaml.org,2002:seq", { kind: "sequence", construct: function(e) {
          return null !== e ? e : [];
        } }), map = new type("tag:yaml.org,2002:map", { kind: "mapping", construct: function(e) {
          return null !== e ? e : {};
        } }), failsafe = new schema({ explicit: [str, seq, map] });
        function resolveYamlNull(e) {
          if (null === e)
            return true;
          var t2 = e.length;
          return 1 === t2 && "~" === e || 4 === t2 && ("null" === e || "Null" === e || "NULL" === e);
        }
        function constructYamlNull() {
          return null;
        }
        function isNull$1(e) {
          return null === e;
        }
        var _null = new type("tag:yaml.org,2002:null", { kind: "scalar", resolve: resolveYamlNull, construct: constructYamlNull, predicate: isNull$1, represent: { canonical: function() {
          return "~";
        }, lowercase: function() {
          return "null";
        }, uppercase: function() {
          return "NULL";
        }, camelcase: function() {
          return "Null";
        } }, defaultStyle: "lowercase" });
        function resolveYamlBoolean(e) {
          if (null === e)
            return false;
          var t2 = e.length;
          return 4 === t2 && ("true" === e || "True" === e || "TRUE" === e) || 5 === t2 && ("false" === e || "False" === e || "FALSE" === e);
        }
        function constructYamlBoolean(e) {
          return "true" === e || "True" === e || "TRUE" === e;
        }
        function isBoolean$1(e) {
          return "[object Boolean]" === Object.prototype.toString.call(e);
        }
        var bool = new type("tag:yaml.org,2002:bool", { kind: "scalar", resolve: resolveYamlBoolean, construct: constructYamlBoolean, predicate: isBoolean$1, represent: { lowercase: function(e) {
          return e ? "true" : "false";
        }, uppercase: function(e) {
          return e ? "TRUE" : "FALSE";
        }, camelcase: function(e) {
          return e ? "True" : "False";
        } }, defaultStyle: "lowercase" });
        function isHexCode(e) {
          return 48 <= e && e <= 57 || 65 <= e && e <= 70 || 97 <= e && e <= 102;
        }
        function isOctCode(e) {
          return 48 <= e && e <= 55;
        }
        function isDecCode(e) {
          return 48 <= e && e <= 57;
        }
        function resolveYamlInteger(e) {
          if (null === e)
            return false;
          var t2, r = e.length, i2 = 0, n = false;
          if (!r)
            return false;
          if ("-" !== (t2 = e[i2]) && "+" !== t2 || (t2 = e[++i2]), "0" === t2) {
            if (i2 + 1 === r)
              return true;
            if ("b" === (t2 = e[++i2])) {
              for (i2++; i2 < r; i2++)
                if ("_" !== (t2 = e[i2])) {
                  if ("0" !== t2 && "1" !== t2)
                    return false;
                  n = true;
                }
              return n;
            }
            if ("x" === t2) {
              for (i2++; i2 < r; i2++)
                if ("_" !== (t2 = e[i2])) {
                  if (!isHexCode(e.charCodeAt(i2)))
                    return false;
                  n = true;
                }
              return n;
            }
            for (; i2 < r; i2++)
              if ("_" !== (t2 = e[i2])) {
                if (!isOctCode(e.charCodeAt(i2)))
                  return false;
                n = true;
              }
            return n;
          }
          for (; i2 < r; i2++)
            if ("_" !== (t2 = e[i2])) {
              if (":" === t2)
                break;
              if (!isDecCode(e.charCodeAt(i2)))
                return false;
              n = true;
            }
          return !!n && (":" !== t2 || /^(:[0-5]?[0-9])+$/.test(e.slice(i2)));
        }
        function constructYamlInteger(e) {
          var t2, r, i2 = e, n = 1, o = [];
          return -1 !== i2.indexOf("_") && (i2 = i2.replace(/_/g, "")), "-" !== (t2 = i2[0]) && "+" !== t2 || ("-" === t2 && (n = -1), t2 = (i2 = i2.slice(1))[0]), "0" === i2 ? 0 : "0" === t2 ? "b" === i2[1] ? n * parseInt(i2.slice(2), 2) : "x" === i2[1] ? n * parseInt(i2, 16) : n * parseInt(i2, 8) : -1 !== i2.indexOf(":") ? (i2.split(":").forEach(function(e2) {
            o.unshift(parseInt(e2, 10));
          }), i2 = 0, r = 1, o.forEach(function(e2) {
            i2 += e2 * r, r *= 60;
          }), n * i2) : n * parseInt(i2, 10);
        }
        function isInteger(e) {
          return "[object Number]" === Object.prototype.toString.call(e) && e % 1 == 0 && !common.isNegativeZero(e);
        }
        var int_1 = new type("tag:yaml.org,2002:int", { kind: "scalar", resolve: resolveYamlInteger, construct: constructYamlInteger, predicate: isInteger, represent: { binary: function(e) {
          return "0b" + e.toString(2);
        }, octal: function(e) {
          return "0" + e.toString(8);
        }, decimal: function(e) {
          return e.toString(10);
        }, hexadecimal: function(e) {
          return "0x" + e.toString(16).toUpperCase();
        } }, defaultStyle: "decimal", styleAliases: { binary: [2, "bin"], octal: [8, "oct"], decimal: [10, "dec"], hexadecimal: [16, "hex"] } }), YAML_FLOAT_PATTERN = new RegExp("^(?:[-+]?(?:[0-9][0-9_]*)\\.[0-9_]*(?:[eE][-+][0-9]+)?|\\.[0-9_]+(?:[eE][-+][0-9]+)?|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");
        function resolveYamlFloat(e) {
          return null !== e && !!YAML_FLOAT_PATTERN.test(e);
        }
        function constructYamlFloat(e) {
          var t2, r = e.replace(/_/g, "").toLowerCase(), i2 = "-" === r[0] ? -1 : 1, n = [];
          return 0 <= "+-".indexOf(r[0]) && (r = r.slice(1)), ".inf" === r ? 1 == i2 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY : ".nan" === r ? NaN : 0 <= r.indexOf(":") ? (r.split(":").forEach(function(e2) {
            n.unshift(parseFloat(e2, 10));
          }), r = 0, t2 = 1, n.forEach(function(e2) {
            r += e2 * t2, t2 *= 60;
          }), i2 * r) : i2 * parseFloat(r, 10);
        }
        var SCIENTIFIC_WITHOUT_DOT = /^[-+]?[0-9]+e/;
        function representYamlFloat(e, t2) {
          var r;
          if (isNaN(e))
            switch (t2) {
              case "lowercase":
                return ".nan";
              case "uppercase":
                return ".NAN";
              case "camelcase":
                return ".NaN";
            }
          else if (Number.POSITIVE_INFINITY === e)
            switch (t2) {
              case "lowercase":
                return ".inf";
              case "uppercase":
                return ".INF";
              case "camelcase":
                return ".Inf";
            }
          else if (Number.NEGATIVE_INFINITY === e)
            switch (t2) {
              case "lowercase":
                return "-.inf";
              case "uppercase":
                return "-.INF";
              case "camelcase":
                return "-.Inf";
            }
          else if (common.isNegativeZero(e))
            return "-0.0";
          return r = e.toString(10), SCIENTIFIC_WITHOUT_DOT.test(r) ? r.replace("e", ".e") : r;
        }
        function isFloat(e) {
          return "[object Number]" === Object.prototype.toString.call(e) && (e % 1 != 0 || common.isNegativeZero(e));
        }
        var float_1$1 = new type("tag:yaml.org,2002:float", { kind: "scalar", resolve: resolveYamlFloat, construct: constructYamlFloat, predicate: isFloat, represent: representYamlFloat, defaultStyle: "lowercase" }), json = new schema({ include: [failsafe], implicit: [_null, bool, int_1, float_1$1] }), core = new schema({ include: [json] }), YAML_TIMESTAMP_REGEXP = new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?)?$");
        function resolveYamlTimestamp(e) {
          return null !== e && null !== YAML_TIMESTAMP_REGEXP.exec(e);
        }
        function constructYamlTimestamp(e) {
          var t2, r, i2, n, o, a2, s, l = 0, u2 = null, c2 = YAML_TIMESTAMP_REGEXP.exec(e);
          if (null === c2)
            throw new Error("Date resolve error");
          if (t2 = +c2[1], r = c2[2] - 1, i2 = +c2[3], !c2[4])
            return new Date(Date.UTC(t2, r, i2));
          if (n = +c2[4], o = +c2[5], a2 = +c2[6], c2[7]) {
            for (l = c2[7].slice(0, 3); l.length < 3; )
              l += "0";
            l = +l;
          }
          return c2[9] && (u2 = 6e4 * (60 * +c2[10] + +(c2[11] || 0)), "-" === c2[9] && (u2 = -u2)), s = new Date(Date.UTC(t2, r, i2, n, o, a2, l)), u2 && s.setTime(s.getTime() - u2), s;
        }
        function representYamlTimestamp(e) {
          return e.toISOString();
        }
        var timestamp = new type("tag:yaml.org,2002:timestamp", { kind: "scalar", resolve: resolveYamlTimestamp, construct: constructYamlTimestamp, instanceOf: Date, represent: representYamlTimestamp });
        function resolveYamlMerge(e) {
          return "<<" === e || null === e;
        }
        var merge = new type("tag:yaml.org,2002:merge", { kind: "scalar", resolve: resolveYamlMerge }), NodeBuffer = bufferEs6.Buffer, BASE64_MAP = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=\n\r";
        function resolveYamlBinary(e) {
          if (null === e)
            return false;
          for (var t2, r = 0, i2 = e.length, n = BASE64_MAP, o = 0; o < i2; o++)
            if (!(64 < (t2 = n.indexOf(e.charAt(o))))) {
              if (t2 < 0)
                return false;
              r += 6;
            }
          return r % 8 == 0;
        }
        function constructYamlBinary(e) {
          for (var t2, r = e.replace(/[\r\n=]/g, ""), i2 = r.length, n = BASE64_MAP, o = 0, a2 = [], s = 0; s < i2; s++)
            s % 4 == 0 && s && (a2.push(o >> 16 & 255), a2.push(o >> 8 & 255), a2.push(255 & o)), o = o << 6 | n.indexOf(r.charAt(s));
          return 0 == (t2 = i2 % 4 * 6) ? (a2.push(o >> 16 & 255), a2.push(o >> 8 & 255), a2.push(255 & o)) : 18 == t2 ? (a2.push(o >> 10 & 255), a2.push(o >> 2 & 255)) : 12 == t2 && a2.push(o >> 4 & 255), NodeBuffer ? new NodeBuffer(a2) : a2;
        }
        function representYamlBinary(e) {
          for (var t2, r = "", i2 = 0, n = e.length, o = BASE64_MAP, a2 = 0; a2 < n; a2++)
            a2 % 3 == 0 && a2 && (r += o[i2 >> 18 & 63], r += o[i2 >> 12 & 63], r += o[i2 >> 6 & 63], r += o[63 & i2]), i2 = (i2 << 8) + e[a2];
          return 0 == (t2 = n % 3) ? (r += o[i2 >> 18 & 63], r += o[i2 >> 12 & 63], r += o[i2 >> 6 & 63], r += o[63 & i2]) : 2 == t2 ? (r += o[i2 >> 10 & 63], r += o[i2 >> 4 & 63], r += o[i2 << 2 & 63], r += o[64]) : 1 == t2 && (r += o[i2 >> 2 & 63], r += o[i2 << 4 & 63], r += o[64], r += o[64]), r;
        }
        function isBinary(e) {
          return NodeBuffer && NodeBuffer.isBuffer(e);
        }
        var binary = new type("tag:yaml.org,2002:binary", { kind: "scalar", resolve: resolveYamlBinary, construct: constructYamlBinary, predicate: isBinary, represent: representYamlBinary }), _hasOwnProperty = Object.prototype.hasOwnProperty, _toString = Object.prototype.toString;
        function resolveYamlOmap(e) {
          if (null === e)
            return true;
          for (var t2, r, i2, n = [], o = e, a2 = 0, s = o.length; a2 < s; a2 += 1) {
            if (t2 = o[a2], i2 = false, "[object Object]" !== _toString.call(t2))
              return false;
            for (r in t2)
              if (_hasOwnProperty.call(t2, r)) {
                if (i2)
                  return false;
                i2 = true;
              }
            if (!i2)
              return false;
            if (-1 !== n.indexOf(r))
              return false;
            n.push(r);
          }
          return true;
        }
        function constructYamlOmap(e) {
          return null !== e ? e : [];
        }
        var omap = new type("tag:yaml.org,2002:omap", { kind: "sequence", resolve: resolveYamlOmap, construct: constructYamlOmap }), _toString$1 = Object.prototype.toString;
        function resolveYamlPairs(e) {
          if (null === e)
            return true;
          for (var t2, r, i2 = e, n = new Array(i2.length), o = 0, a2 = i2.length; o < a2; o += 1) {
            if (t2 = i2[o], "[object Object]" !== _toString$1.call(t2))
              return false;
            if (1 !== (r = Object.keys(t2)).length)
              return false;
            n[o] = [r[0], t2[r[0]]];
          }
          return true;
        }
        function constructYamlPairs(e) {
          if (null === e)
            return [];
          for (var t2, r, i2 = e, n = new Array(i2.length), o = 0, a2 = i2.length; o < a2; o += 1)
            t2 = i2[o], r = Object.keys(t2), n[o] = [r[0], t2[r[0]]];
          return n;
        }
        var pairs = new type("tag:yaml.org,2002:pairs", { kind: "sequence", resolve: resolveYamlPairs, construct: constructYamlPairs }), _hasOwnProperty$1 = Object.prototype.hasOwnProperty;
        function resolveYamlSet(e) {
          if (null === e)
            return true;
          var t2, r = e;
          for (t2 in r)
            if (_hasOwnProperty$1.call(r, t2) && null !== r[t2])
              return false;
          return true;
        }
        function constructYamlSet(e) {
          return null !== e ? e : {};
        }
        var set$2 = new type("tag:yaml.org,2002:set", { kind: "mapping", resolve: resolveYamlSet, construct: constructYamlSet }), default_safe = new schema({ include: [core], implicit: [timestamp, merge], explicit: [binary, omap, pairs, set$2] });
        function resolveJavascriptUndefined() {
          return true;
        }
        function constructJavascriptUndefined() {
        }
        function representJavascriptUndefined() {
          return "";
        }
        function isUndefined$1(e) {
          return void 0 === e;
        }
        var _undefined = new type("tag:yaml.org,2002:js/undefined", { kind: "scalar", resolve: resolveJavascriptUndefined, construct: constructJavascriptUndefined, predicate: isUndefined$1, represent: representJavascriptUndefined });
        function resolveJavascriptRegExp(e) {
          if (null === e)
            return false;
          if (0 === e.length)
            return false;
          var t2 = e, r = /\/([gim]*)$/.exec(e), i2 = "";
          if ("/" === t2[0]) {
            if (r && (i2 = r[1]), 3 < i2.length)
              return false;
            if ("/" !== t2[t2.length - i2.length - 1])
              return false;
          }
          return true;
        }
        function constructJavascriptRegExp(e) {
          var t2 = e, r = /\/([gim]*)$/.exec(e), i2 = "";
          return "/" === t2[0] && (r && (i2 = r[1]), t2 = t2.slice(1, t2.length - i2.length - 1)), new RegExp(t2, i2);
        }
        function representJavascriptRegExp(e) {
          var t2 = "/" + e.source + "/";
          return e.global && (t2 += "g"), e.multiline && (t2 += "m"), e.ignoreCase && (t2 += "i"), t2;
        }
        function isRegExp$1(e) {
          return "[object RegExp]" === Object.prototype.toString.call(e);
        }
        var regexp = new type("tag:yaml.org,2002:js/regexp", { kind: "scalar", resolve: resolveJavascriptRegExp, construct: constructJavascriptRegExp, predicate: isRegExp$1, represent: representJavascriptRegExp }), esprima;
        try {
          var _require = commonjsRequire, esprima = _require("esprima");
        } catch (e) {
          "undefined" != typeof window && (esprima = window.esprima);
        }
        function resolveJavascriptFunction(e) {
          if (null === e)
            return false;
          try {
            var t2 = "(" + e + ")", r = esprima.parse(t2, { range: true });
            return "Program" !== r.type || 1 !== r.body.length || "ExpressionStatement" !== r.body[0].type || "FunctionExpression" !== r.body[0].expression.type ? false : true;
          } catch (e2) {
            return false;
          }
        }
        function constructJavascriptFunction(e) {
          var t2, r = "(" + e + ")", i2 = esprima.parse(r, { range: true }), n = [];
          if ("Program" !== i2.type || 1 !== i2.body.length || "ExpressionStatement" !== i2.body[0].type || "FunctionExpression" !== i2.body[0].expression.type)
            throw new Error("Failed to resolve function");
          return i2.body[0].expression.params.forEach(function(e2) {
            n.push(e2.name);
          }), t2 = i2.body[0].expression.body.range, new Function(n, r.slice(t2[0] + 1, t2[1] - 1));
        }
        function representJavascriptFunction(e) {
          return e.toString();
        }
        function isFunction$1(e) {
          return "[object Function]" === Object.prototype.toString.call(e);
        }
        var _function = new type("tag:yaml.org,2002:js/function", { kind: "scalar", resolve: resolveJavascriptFunction, construct: constructJavascriptFunction, predicate: isFunction$1, represent: representJavascriptFunction }), default_full = schema.DEFAULT = new schema({ include: [default_safe], explicit: [_undefined, regexp, _function] }), _hasOwnProperty$2 = Object.prototype.hasOwnProperty, CONTEXT_FLOW_IN = 1, CONTEXT_FLOW_OUT = 2, CONTEXT_BLOCK_IN = 3, CONTEXT_BLOCK_OUT = 4, CHOMPING_CLIP = 1, CHOMPING_STRIP = 2, CHOMPING_KEEP = 3, PATTERN_NON_PRINTABLE = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/, PATTERN_NON_ASCII_LINE_BREAKS = /[\x85\u2028\u2029]/, PATTERN_FLOW_INDICATORS = /[,\[\]\{\}]/, PATTERN_TAG_HANDLE = /^(?:!|!!|![a-z\-]+!)$/i, PATTERN_TAG_URI = /^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;
        function is_EOL(e) {
          return 10 === e || 13 === e;
        }
        function is_WHITE_SPACE(e) {
          return 9 === e || 32 === e;
        }
        function is_WS_OR_EOL(e) {
          return 9 === e || 32 === e || 10 === e || 13 === e;
        }
        function is_FLOW_INDICATOR(e) {
          return 44 === e || 91 === e || 93 === e || 123 === e || 125 === e;
        }
        function fromHexCode(e) {
          var t2;
          return 48 <= e && e <= 57 ? e - 48 : 97 <= (t2 = 32 | e) && t2 <= 102 ? t2 - 97 + 10 : -1;
        }
        function escapedHexLen(e) {
          return 120 === e ? 2 : 117 === e ? 4 : 85 === e ? 8 : 0;
        }
        function fromDecimalCode(e) {
          return 48 <= e && e <= 57 ? e - 48 : -1;
        }
        function simpleEscapeSequence(e) {
          return 48 === e ? "\0" : 97 === e ? "\x07" : 98 === e ? "\b" : 116 === e || 9 === e ? "	" : 110 === e ? "\n" : 118 === e ? "\v" : 102 === e ? "\f" : 114 === e ? "\r" : 101 === e ? "\x1B" : 32 === e ? " " : 34 === e ? '"' : 47 === e ? "/" : 92 === e ? "\\" : 78 === e ? "" : 95 === e ? " " : 76 === e ? "\u2028" : 80 === e ? "\u2029" : "";
        }
        function charFromCodepoint(e) {
          return e <= 65535 ? String.fromCharCode(e) : String.fromCharCode(55296 + (e - 65536 >> 10), 56320 + (e - 65536 & 1023));
        }
        for (var simpleEscapeCheck = new Array(256), simpleEscapeMap = new Array(256), i = 0; i < 256; i++)
          simpleEscapeCheck[i] = simpleEscapeSequence(i) ? 1 : 0, simpleEscapeMap[i] = simpleEscapeSequence(i);
        function State$1(e, t2) {
          this.input = e, this.filename = t2.filename || null, this.schema = t2.schema || default_full, this.onWarning = t2.onWarning || null, this.legacy = t2.legacy || false, this.json = t2.json || false, this.listener = t2.listener || null, this.implicitTypes = this.schema.compiledImplicit, this.typeMap = this.schema.compiledTypeMap, this.length = e.length, this.position = 0, this.line = 0, this.lineStart = 0, this.lineIndent = 0, this.documents = [];
        }
        function generateError(e, t2) {
          return new exception(t2, new mark(e.filename, e.input, e.position, e.line, e.position - e.lineStart));
        }
        function throwError(e, t2) {
          throw generateError(e, t2);
        }
        function throwWarning(e, t2) {
          e.onWarning && e.onWarning.call(null, generateError(e, t2));
        }
        var directiveHandlers = { YAML: function(e, t2, r) {
          var i2, n, o;
          null !== e.version && throwError(e, "duplication of %YAML directive"), 1 !== r.length && throwError(e, "YAML directive accepts exactly one argument"), null === (i2 = /^([0-9]+)\.([0-9]+)$/.exec(r[0])) && throwError(e, "ill-formed argument of the YAML directive"), n = parseInt(i2[1], 10), o = parseInt(i2[2], 10), 1 !== n && throwError(e, "unacceptable YAML version of the document"), e.version = r[0], e.checkLineBreaks = o < 2, 1 !== o && 2 !== o && throwWarning(e, "unsupported YAML version of the document");
        }, TAG: function(e, t2, r) {
          var i2, n;
          2 !== r.length && throwError(e, "TAG directive accepts exactly two arguments"), i2 = r[0], n = r[1], PATTERN_TAG_HANDLE.test(i2) || throwError(e, "ill-formed tag handle (first argument) of the TAG directive"), _hasOwnProperty$2.call(e.tagMap, i2) && throwError(e, 'there is a previously declared suffix for "' + i2 + '" tag handle'), PATTERN_TAG_URI.test(n) || throwError(e, "ill-formed tag prefix (second argument) of the TAG directive"), e.tagMap[i2] = n;
        } };
        function captureSegment(e, t2, r, i2) {
          var n, o, a2, s;
          if (t2 < r) {
            if (s = e.input.slice(t2, r), i2)
              for (n = 0, o = s.length; n < o; n += 1)
                9 === (a2 = s.charCodeAt(n)) || 32 <= a2 && a2 <= 1114111 || throwError(e, "expected valid JSON character");
            else
              PATTERN_NON_PRINTABLE.test(s) && throwError(e, "the stream contains non-printable characters");
            e.result += s;
          }
        }
        function mergeMappings(e, t2, r, i2) {
          var n, o, a2, s;
          for (common.isObject(r) || throwError(e, "cannot merge mappings; the provided source object is unacceptable"), a2 = 0, s = (n = Object.keys(r)).length; a2 < s; a2 += 1)
            o = n[a2], _hasOwnProperty$2.call(t2, o) || (t2[o] = r[o], i2[o] = true);
        }
        function storeMappingPair(e, t2, r, i2, n, o) {
          var a2, s;
          if (n = String(n), null === t2 && (t2 = {}), "tag:yaml.org,2002:merge" === i2)
            if (Array.isArray(o))
              for (a2 = 0, s = o.length; a2 < s; a2 += 1)
                mergeMappings(e, t2, o[a2], r);
            else
              mergeMappings(e, t2, o, r);
          else
            e.json || _hasOwnProperty$2.call(r, n) || !_hasOwnProperty$2.call(t2, n) || throwError(e, "duplicated mapping key"), t2[n] = o, delete r[n];
          return t2;
        }
        function readLineBreak(e) {
          var t2 = e.input.charCodeAt(e.position);
          10 === t2 ? e.position++ : 13 === t2 ? (e.position++, 10 === e.input.charCodeAt(e.position) && e.position++) : throwError(e, "a line break is expected"), e.line += 1, e.lineStart = e.position;
        }
        function skipSeparationSpace(e, t2, r) {
          for (var i2 = 0, n = e.input.charCodeAt(e.position); 0 !== n; ) {
            for (; is_WHITE_SPACE(n); )
              n = e.input.charCodeAt(++e.position);
            if (t2 && 35 === n)
              for (; 10 !== (n = e.input.charCodeAt(++e.position)) && 13 !== n && 0 !== n; )
                ;
            if (!is_EOL(n))
              break;
            for (readLineBreak(e), n = e.input.charCodeAt(e.position), i2++, e.lineIndent = 0; 32 === n; )
              e.lineIndent++, n = e.input.charCodeAt(++e.position);
          }
          return -1 !== r && 0 !== i2 && e.lineIndent < r && throwWarning(e, "deficient indentation"), i2;
        }
        function testDocumentSeparator(e) {
          var t2 = e.position, r = e.input.charCodeAt(t2);
          return 45 !== r && 46 !== r || r !== e.input.charCodeAt(t2 + 1) || r !== e.input.charCodeAt(t2 + 2) || (t2 += 3, 0 !== (r = e.input.charCodeAt(t2)) && !is_WS_OR_EOL(r)) ? void 0 : 1;
        }
        function writeFoldedLines(e, t2) {
          1 === t2 ? e.result += " " : 1 < t2 && (e.result += common.repeat("\n", t2 - 1));
        }
        function readPlainScalar(e, t2, r) {
          var i2, n, o, a2, s, l, u2, c2 = e.kind, h = e.result, f2 = e.input.charCodeAt(e.position);
          if (!is_WS_OR_EOL(f2) && !is_FLOW_INDICATOR(f2) && 35 !== f2 && 38 !== f2 && 42 !== f2 && 33 !== f2 && 124 !== f2 && 62 !== f2 && 39 !== f2 && 34 !== f2 && 37 !== f2 && 64 !== f2 && 96 !== f2 && (63 !== f2 && 45 !== f2 || !(is_WS_OR_EOL(i2 = e.input.charCodeAt(e.position + 1)) || r && is_FLOW_INDICATOR(i2)))) {
            for (e.kind = "scalar", e.result = "", n = o = e.position, a2 = false; 0 !== f2; ) {
              if (58 === f2) {
                if (is_WS_OR_EOL(i2 = e.input.charCodeAt(e.position + 1)) || r && is_FLOW_INDICATOR(i2))
                  break;
              } else if (35 === f2) {
                if (is_WS_OR_EOL(e.input.charCodeAt(e.position - 1)))
                  break;
              } else {
                if (e.position === e.lineStart && testDocumentSeparator(e) || r && is_FLOW_INDICATOR(f2))
                  break;
                if (is_EOL(f2)) {
                  if (s = e.line, l = e.lineStart, u2 = e.lineIndent, skipSeparationSpace(e, false, -1), e.lineIndent >= t2) {
                    a2 = true, f2 = e.input.charCodeAt(e.position);
                    continue;
                  }
                  e.position = o, e.line = s, e.lineStart = l, e.lineIndent = u2;
                  break;
                }
              }
              a2 && (captureSegment(e, n, o, false), writeFoldedLines(e, e.line - s), n = o = e.position, a2 = false), is_WHITE_SPACE(f2) || (o = e.position + 1), f2 = e.input.charCodeAt(++e.position);
            }
            if (captureSegment(e, n, o, false), e.result)
              return 1;
            e.kind = c2, e.result = h;
          }
        }
        function readSingleQuotedScalar(e, t2) {
          var r, i2, n = e.input.charCodeAt(e.position);
          if (39 === n) {
            for (e.kind = "scalar", e.result = "", e.position++, r = i2 = e.position; 0 !== (n = e.input.charCodeAt(e.position)); )
              if (39 === n) {
                if (captureSegment(e, r, e.position, true), 39 !== (n = e.input.charCodeAt(++e.position)))
                  return 1;
                r = i2 = e.position, e.position++;
              } else
                is_EOL(n) ? (captureSegment(e, r, i2, true), writeFoldedLines(e, skipSeparationSpace(e, false, t2)), r = i2 = e.position) : e.position === e.lineStart && testDocumentSeparator(e) ? throwError(e, "unexpected end of the document within a single quoted scalar") : (e.position++, i2 = e.position);
            throwError(e, "unexpected end of the stream within a single quoted scalar");
          }
        }
        function readDoubleQuotedScalar(e, t2) {
          var r, i2, n, o, a2, s = e.input.charCodeAt(e.position);
          if (34 === s) {
            for (e.kind = "scalar", e.result = "", e.position++, r = i2 = e.position; 0 !== (s = e.input.charCodeAt(e.position)); ) {
              if (34 === s)
                return captureSegment(e, r, e.position, true), e.position++, 1;
              if (92 === s) {
                if (captureSegment(e, r, e.position, true), is_EOL(s = e.input.charCodeAt(++e.position)))
                  skipSeparationSpace(e, false, t2);
                else if (s < 256 && simpleEscapeCheck[s])
                  e.result += simpleEscapeMap[s], e.position++;
                else if (0 < (a2 = escapedHexLen(s))) {
                  for (n = a2, o = 0; 0 < n; n--)
                    0 <= (a2 = fromHexCode(s = e.input.charCodeAt(++e.position))) ? o = (o << 4) + a2 : throwError(e, "expected hexadecimal character");
                  e.result += charFromCodepoint(o), e.position++;
                } else
                  throwError(e, "unknown escape sequence");
                r = i2 = e.position;
              } else
                is_EOL(s) ? (captureSegment(e, r, i2, true), writeFoldedLines(e, skipSeparationSpace(e, false, t2)), r = i2 = e.position) : e.position === e.lineStart && testDocumentSeparator(e) ? throwError(e, "unexpected end of the document within a double quoted scalar") : (e.position++, i2 = e.position);
            }
            throwError(e, "unexpected end of the stream within a double quoted scalar");
          }
        }
        function readFlowCollection(e, t2) {
          var r, i2, n, o, a2, s, l, u2, c2, h = true, f2 = e.tag, d = e.anchor, _ = {}, p2 = e.input.charCodeAt(e.position);
          if (91 === p2)
            s = !(n = 93), i2 = [];
          else {
            if (123 !== p2)
              return;
            n = 125, s = true, i2 = {};
          }
          for (null !== e.anchor && (e.anchorMap[e.anchor] = i2), p2 = e.input.charCodeAt(++e.position); 0 !== p2; ) {
            if (skipSeparationSpace(e, true, t2), (p2 = e.input.charCodeAt(e.position)) === n)
              return e.position++, e.tag = f2, e.anchor = d, e.kind = s ? "mapping" : "sequence", e.result = i2, 1;
            h || throwError(e, "missed comma between flow collection entries"), c2 = null, o = a2 = false, 63 === p2 && is_WS_OR_EOL(e.input.charCodeAt(e.position + 1)) && (o = a2 = true, e.position++, skipSeparationSpace(e, true, t2)), r = e.line, composeNode(e, t2, CONTEXT_FLOW_IN, false, true), u2 = e.tag, l = e.result, skipSeparationSpace(e, true, t2), p2 = e.input.charCodeAt(e.position), !a2 && e.line !== r || 58 !== p2 || (o = true, p2 = e.input.charCodeAt(++e.position), skipSeparationSpace(e, true, t2), composeNode(e, t2, CONTEXT_FLOW_IN, false, true), c2 = e.result), s ? storeMappingPair(e, i2, _, u2, l, c2) : o ? i2.push(storeMappingPair(e, null, _, u2, l, c2)) : i2.push(l), skipSeparationSpace(e, true, t2), 44 === (p2 = e.input.charCodeAt(e.position)) ? (h = true, p2 = e.input.charCodeAt(++e.position)) : h = false;
          }
          throwError(e, "unexpected end of the stream within a flow collection");
        }
        function readBlockScalar(e, t2) {
          var r, i2, n, o = CHOMPING_CLIP, a2 = false, s = t2, l = 0, u2 = false, c2 = e.input.charCodeAt(e.position);
          if (124 === c2)
            i2 = false;
          else {
            if (62 !== c2)
              return;
            i2 = true;
          }
          for (e.kind = "scalar", e.result = ""; 0 !== c2; )
            if (43 === (c2 = e.input.charCodeAt(++e.position)) || 45 === c2)
              CHOMPING_CLIP === o ? o = 43 === c2 ? CHOMPING_KEEP : CHOMPING_STRIP : throwError(e, "repeat of a chomping mode identifier");
            else {
              if (!(0 <= (n = fromDecimalCode(c2))))
                break;
              0 === n ? throwError(e, "bad explicit indentation width of a block scalar; it cannot be less than one") : a2 ? throwError(e, "repeat of an indentation width identifier") : (s = t2 + n - 1, a2 = true);
            }
          if (is_WHITE_SPACE(c2)) {
            for (; is_WHITE_SPACE(c2 = e.input.charCodeAt(++e.position)); )
              ;
            if (35 === c2)
              for (; !is_EOL(c2 = e.input.charCodeAt(++e.position)) && 0 !== c2; )
                ;
          }
          for (; 0 !== c2; ) {
            for (readLineBreak(e), e.lineIndent = 0, c2 = e.input.charCodeAt(e.position); (!a2 || e.lineIndent < s) && 32 === c2; )
              e.lineIndent++, c2 = e.input.charCodeAt(++e.position);
            if (!a2 && e.lineIndent > s && (s = e.lineIndent), is_EOL(c2))
              l++;
            else {
              if (e.lineIndent < s) {
                o === CHOMPING_KEEP ? e.result += common.repeat("\n", l) : o === CHOMPING_CLIP && a2 && (e.result += "\n");
                break;
              }
              for (i2 ? is_WHITE_SPACE(c2) ? (u2 = true, e.result += common.repeat("\n", l + 1)) : u2 ? (u2 = false, e.result += common.repeat("\n", l + 1)) : 0 === l ? a2 && (e.result += " ") : e.result += common.repeat("\n", l) : e.result += a2 ? common.repeat("\n", l + 1) : common.repeat("\n", l), a2 = true, l = 0, r = e.position; !is_EOL(c2) && 0 !== c2; )
                c2 = e.input.charCodeAt(++e.position);
              captureSegment(e, r, e.position, false);
            }
          }
          return 1;
        }
        function readBlockSequence(e, t2) {
          var r, i2, n = e.tag, o = e.anchor, a2 = [], s = false;
          for (null !== e.anchor && (e.anchorMap[e.anchor] = a2), i2 = e.input.charCodeAt(e.position); 0 !== i2 && 45 === i2 && is_WS_OR_EOL(e.input.charCodeAt(e.position + 1)); )
            if (s = true, e.position++, skipSeparationSpace(e, true, -1) && e.lineIndent <= t2)
              a2.push(null), i2 = e.input.charCodeAt(e.position);
            else if (r = e.line, composeNode(e, t2, CONTEXT_BLOCK_IN, false, true), a2.push(e.result), skipSeparationSpace(e, true, -1), i2 = e.input.charCodeAt(e.position), (e.line === r || e.lineIndent > t2) && 0 !== i2)
              throwError(e, "bad indentation of a sequence entry");
            else if (e.lineIndent < t2)
              break;
          return !!s && (e.tag = n, e.anchor = o, e.kind = "sequence", e.result = a2, true);
        }
        function readBlockMapping(e, t2, r) {
          var i2, n, o, a2, s = e.tag, l = e.anchor, u2 = {}, c2 = {}, h = null, f2 = null, d = null, _ = false, p2 = false;
          for (null !== e.anchor && (e.anchorMap[e.anchor] = u2), a2 = e.input.charCodeAt(e.position); 0 !== a2; ) {
            if (i2 = e.input.charCodeAt(e.position + 1), o = e.line, 63 !== a2 && 58 !== a2 || !is_WS_OR_EOL(i2)) {
              if (!composeNode(e, r, CONTEXT_FLOW_OUT, false, true))
                break;
              if (e.line === o) {
                for (a2 = e.input.charCodeAt(e.position); is_WHITE_SPACE(a2); )
                  a2 = e.input.charCodeAt(++e.position);
                if (58 === a2)
                  is_WS_OR_EOL(a2 = e.input.charCodeAt(++e.position)) || throwError(e, "a whitespace character is expected after the key-value separator within a block mapping"), _ && (storeMappingPair(e, u2, c2, h, f2, null), h = f2 = d = null), n = _ = !(p2 = true), h = e.tag, f2 = e.result;
                else {
                  if (!p2)
                    return e.tag = s, e.anchor = l, 1;
                  throwError(e, "can not read an implicit mapping pair; a colon is missed");
                }
              } else {
                if (!p2)
                  return e.tag = s, e.anchor = l, 1;
                throwError(e, "can not read a block mapping entry; a multiline key may not be an implicit key");
              }
            } else
              63 === a2 ? (_ && (storeMappingPair(e, u2, c2, h, f2, null), h = f2 = d = null), n = _ = p2 = true) : _ ? n = !(_ = false) : throwError(e, "incomplete explicit mapping pair; a key node is missed"), e.position += 1, a2 = i2;
            if ((e.line === o || e.lineIndent > t2) && (composeNode(e, t2, CONTEXT_BLOCK_OUT, true, n) && (_ ? f2 = e.result : d = e.result), _ || (storeMappingPair(e, u2, c2, h, f2, d), h = f2 = d = null), skipSeparationSpace(e, true, -1), a2 = e.input.charCodeAt(e.position)), e.lineIndent > t2 && 0 !== a2)
              throwError(e, "bad indentation of a mapping entry");
            else if (e.lineIndent < t2)
              break;
          }
          return _ && storeMappingPair(e, u2, c2, h, f2, null), p2 && (e.tag = s, e.anchor = l, e.kind = "mapping", e.result = u2), p2;
        }
        function readTagProperty(e) {
          var t2, r, i2, n = false, o = false, a2 = e.input.charCodeAt(e.position);
          if (33 === a2) {
            if (null !== e.tag && throwError(e, "duplication of a tag property"), 60 === (a2 = e.input.charCodeAt(++e.position)) ? (n = true, a2 = e.input.charCodeAt(++e.position)) : 33 === a2 ? (o = true, r = "!!", a2 = e.input.charCodeAt(++e.position)) : r = "!", t2 = e.position, n) {
              for (; 0 !== (a2 = e.input.charCodeAt(++e.position)) && 62 !== a2; )
                ;
              e.position < e.length ? (i2 = e.input.slice(t2, e.position), a2 = e.input.charCodeAt(++e.position)) : throwError(e, "unexpected end of the stream within a verbatim tag");
            } else {
              for (; 0 !== a2 && !is_WS_OR_EOL(a2); )
                33 === a2 && (o ? throwError(e, "tag suffix cannot contain exclamation marks") : (r = e.input.slice(t2 - 1, e.position + 1), PATTERN_TAG_HANDLE.test(r) || throwError(e, "named tag handle cannot contain such characters"), o = true, t2 = e.position + 1)), a2 = e.input.charCodeAt(++e.position);
              i2 = e.input.slice(t2, e.position), PATTERN_FLOW_INDICATORS.test(i2) && throwError(e, "tag suffix cannot contain flow indicator characters");
            }
            return i2 && !PATTERN_TAG_URI.test(i2) && throwError(e, "tag name cannot contain such characters: " + i2), n ? e.tag = i2 : _hasOwnProperty$2.call(e.tagMap, r) ? e.tag = e.tagMap[r] + i2 : "!" === r ? e.tag = "!" + i2 : "!!" === r ? e.tag = "tag:yaml.org,2002:" + i2 : throwError(e, 'undeclared tag handle "' + r + '"'), 1;
          }
        }
        function readAnchorProperty(e) {
          var t2, r = e.input.charCodeAt(e.position);
          if (38 === r) {
            for (null !== e.anchor && throwError(e, "duplication of an anchor property"), r = e.input.charCodeAt(++e.position), t2 = e.position; 0 !== r && !is_WS_OR_EOL(r) && !is_FLOW_INDICATOR(r); )
              r = e.input.charCodeAt(++e.position);
            return e.position === t2 && throwError(e, "name of an anchor node must contain at least one character"), e.anchor = e.input.slice(t2, e.position), 1;
          }
        }
        function readAlias(e) {
          var t2, r, i2 = e.input.charCodeAt(e.position);
          if (42 === i2) {
            for (i2 = e.input.charCodeAt(++e.position), t2 = e.position; 0 !== i2 && !is_WS_OR_EOL(i2) && !is_FLOW_INDICATOR(i2); )
              i2 = e.input.charCodeAt(++e.position);
            return e.position === t2 && throwError(e, "name of an alias node must contain at least one character"), r = e.input.slice(t2, e.position), e.anchorMap.hasOwnProperty(r) || throwError(e, 'unidentified alias "' + r + '"'), e.result = e.anchorMap[r], skipSeparationSpace(e, true, -1), 1;
          }
        }
        function composeNode(e, t2, r, i2, n) {
          var o, a2, s, l, u2, c2, h, f2, d = 1, _ = false, p2 = false;
          if (null !== e.listener && e.listener("open", e), e.tag = null, e.anchor = null, e.kind = null, e.result = null, o = a2 = s = CONTEXT_BLOCK_OUT === r || CONTEXT_BLOCK_IN === r, i2 && skipSeparationSpace(e, true, -1) && (_ = true, e.lineIndent > t2 ? d = 1 : e.lineIndent === t2 ? d = 0 : e.lineIndent < t2 && (d = -1)), 1 === d)
            for (; readTagProperty(e) || readAnchorProperty(e); )
              skipSeparationSpace(e, true, -1) ? (_ = true, s = o, e.lineIndent > t2 ? d = 1 : e.lineIndent === t2 ? d = 0 : e.lineIndent < t2 && (d = -1)) : s = false;
          if (s = s && (_ || n), 1 !== d && CONTEXT_BLOCK_OUT !== r || (h = CONTEXT_FLOW_IN === r || CONTEXT_FLOW_OUT === r ? t2 : t2 + 1, f2 = e.position - e.lineStart, 1 === d ? s && (readBlockSequence(e, f2) || readBlockMapping(e, f2, h)) || readFlowCollection(e, h) ? p2 = true : (a2 && readBlockScalar(e, h) || readSingleQuotedScalar(e, h) || readDoubleQuotedScalar(e, h) ? p2 = true : readAlias(e) ? (p2 = true, null === e.tag && null === e.anchor || throwError(e, "alias node should not have any properties")) : readPlainScalar(e, h, CONTEXT_FLOW_IN === r) && (p2 = true, null === e.tag && (e.tag = "?")), null !== e.anchor && (e.anchorMap[e.anchor] = e.result)) : 0 === d && (p2 = s && readBlockSequence(e, f2))), null !== e.tag && "!" !== e.tag)
            if ("?" === e.tag) {
              for (l = 0, u2 = e.implicitTypes.length; l < u2; l += 1)
                if ((c2 = e.implicitTypes[l]).resolve(e.result)) {
                  e.result = c2.construct(e.result), e.tag = c2.tag, null !== e.anchor && (e.anchorMap[e.anchor] = e.result);
                  break;
                }
            } else
              _hasOwnProperty$2.call(e.typeMap, e.tag) ? (c2 = e.typeMap[e.tag], null !== e.result && c2.kind !== e.kind && throwError(e, "unacceptable node kind for !<" + e.tag + '> tag; it should be "' + c2.kind + '", not "' + e.kind + '"'), c2.resolve(e.result) ? (e.result = c2.construct(e.result), null !== e.anchor && (e.anchorMap[e.anchor] = e.result)) : throwError(e, "cannot resolve a node with !<" + e.tag + "> explicit tag")) : throwError(e, "unknown tag !<" + e.tag + ">");
          return null !== e.listener && e.listener("close", e), null !== e.tag || null !== e.anchor || p2;
        }
        function readDocument(e) {
          var t2, r, i2, n, o = e.position, a2 = false;
          for (e.version = null, e.checkLineBreaks = e.legacy, e.tagMap = {}, e.anchorMap = {}; 0 !== (n = e.input.charCodeAt(e.position)) && (skipSeparationSpace(e, true, -1), n = e.input.charCodeAt(e.position), !(0 < e.lineIndent || 37 !== n)); ) {
            for (a2 = true, n = e.input.charCodeAt(++e.position), t2 = e.position; 0 !== n && !is_WS_OR_EOL(n); )
              n = e.input.charCodeAt(++e.position);
            for (i2 = [], (r = e.input.slice(t2, e.position)).length < 1 && throwError(e, "directive name must not be less than one character in length"); 0 !== n; ) {
              for (; is_WHITE_SPACE(n); )
                n = e.input.charCodeAt(++e.position);
              if (35 === n) {
                for (; 0 !== (n = e.input.charCodeAt(++e.position)) && !is_EOL(n); )
                  ;
                break;
              }
              if (is_EOL(n))
                break;
              for (t2 = e.position; 0 !== n && !is_WS_OR_EOL(n); )
                n = e.input.charCodeAt(++e.position);
              i2.push(e.input.slice(t2, e.position));
            }
            0 !== n && readLineBreak(e), _hasOwnProperty$2.call(directiveHandlers, r) ? directiveHandlers[r](e, r, i2) : throwWarning(e, 'unknown document directive "' + r + '"');
          }
          skipSeparationSpace(e, true, -1), 0 === e.lineIndent && 45 === e.input.charCodeAt(e.position) && 45 === e.input.charCodeAt(e.position + 1) && 45 === e.input.charCodeAt(e.position + 2) ? (e.position += 3, skipSeparationSpace(e, true, -1)) : a2 && throwError(e, "directives end mark is expected"), composeNode(e, e.lineIndent - 1, CONTEXT_BLOCK_OUT, false, true), skipSeparationSpace(e, true, -1), e.checkLineBreaks && PATTERN_NON_ASCII_LINE_BREAKS.test(e.input.slice(o, e.position)) && throwWarning(e, "non-ASCII line breaks are interpreted as content"), e.documents.push(e.result), e.position === e.lineStart && testDocumentSeparator(e) ? 46 === e.input.charCodeAt(e.position) && (e.position += 3, skipSeparationSpace(e, true, -1)) : e.position < e.length - 1 && throwError(e, "end of the stream or a document separator is expected");
        }
        function loadDocuments(e, t2) {
          t2 = t2 || {}, 0 !== (e = String(e)).length && (10 !== e.charCodeAt(e.length - 1) && 13 !== e.charCodeAt(e.length - 1) && (e += "\n"), 65279 === e.charCodeAt(0) && (e = e.slice(1)));
          var r = new State$1(e, t2);
          for (r.input += "\0"; 32 === r.input.charCodeAt(r.position); )
            r.lineIndent += 1, r.position += 1;
          for (; r.position < r.length - 1; )
            readDocument(r);
          return r.documents;
        }
        function loadAll(e, t2, r) {
          for (var i2 = loadDocuments(e, r), n = 0, o = i2.length; n < o; n += 1)
            t2(i2[n]);
        }
        function load(e, t2) {
          var r = loadDocuments(e, t2);
          if (0 !== r.length) {
            if (1 === r.length)
              return r[0];
            throw new exception("expected a single document in the stream, but found more");
          }
        }
        function safeLoadAll(e, t2, r) {
          loadAll(e, t2, common.extend({ schema: default_safe }, r));
        }
        function safeLoad(e, t2) {
          return load(e, common.extend({ schema: default_safe }, t2));
        }
        var loadAll_1 = loadAll, load_1 = load, safeLoadAll_1 = safeLoadAll, safeLoad_1 = safeLoad, loader = { loadAll: loadAll_1, load: load_1, safeLoadAll: safeLoadAll_1, safeLoad: safeLoad_1 }, _toString$2 = Object.prototype.toString, _hasOwnProperty$3 = Object.prototype.hasOwnProperty, CHAR_TAB = 9, CHAR_LINE_FEED = 10, CHAR_CARRIAGE_RETURN = 13, CHAR_SPACE = 32, CHAR_EXCLAMATION = 33, CHAR_DOUBLE_QUOTE = 34, CHAR_SHARP = 35, CHAR_PERCENT = 37, CHAR_AMPERSAND = 38, CHAR_SINGLE_QUOTE = 39, CHAR_ASTERISK = 42, CHAR_COMMA = 44, CHAR_MINUS = 45, CHAR_COLON = 58, CHAR_GREATER_THAN = 62, CHAR_QUESTION = 63, CHAR_COMMERCIAL_AT = 64, CHAR_LEFT_SQUARE_BRACKET = 91, CHAR_RIGHT_SQUARE_BRACKET = 93, CHAR_GRAVE_ACCENT = 96, CHAR_LEFT_CURLY_BRACKET = 123, CHAR_VERTICAL_LINE = 124, CHAR_RIGHT_CURLY_BRACKET = 125, ESCAPE_SEQUENCES = { 0: "\\0", 7: "\\a", 8: "\\b", 9: "\\t", 10: "\\n", 11: "\\v", 12: "\\f", 13: "\\r", 27: "\\e", 34: '\\"', 92: "\\\\", 133: "\\N", 160: "\\_", 8232: "\\L", 8233: "\\P" }, DEPRECATED_BOOLEANS_SYNTAX = ["y", "Y", "yes", "Yes", "YES", "on", "On", "ON", "n", "N", "no", "No", "NO", "off", "Off", "OFF"];
        function compileStyleMap(e, t2) {
          var r, i2, n, o, a2, s, l;
          if (null === t2)
            return {};
          for (r = {}, n = 0, o = (i2 = Object.keys(t2)).length; n < o; n += 1)
            a2 = i2[n], s = String(t2[a2]), "!!" === a2.slice(0, 2) && (a2 = "tag:yaml.org,2002:" + a2.slice(2)), (l = e.compiledTypeMap[a2]) && _hasOwnProperty$3.call(l.styleAliases, s) && (s = l.styleAliases[s]), r[a2] = s;
          return r;
        }
        function encodeHex(e) {
          var t2, r, i2 = e.toString(16).toUpperCase();
          if (e <= 255)
            t2 = "x", r = 2;
          else if (e <= 65535)
            t2 = "u", r = 4;
          else {
            if (!(e <= 4294967295))
              throw new exception("code point within a string may not be greater than 0xFFFFFFFF");
            t2 = "U", r = 8;
          }
          return "\\" + t2 + common.repeat("0", r - i2.length) + i2;
        }
        function State$2(e) {
          this.schema = e.schema || default_full, this.indent = Math.max(1, e.indent || 2), this.skipInvalid = e.skipInvalid || false, this.flowLevel = common.isNothing(e.flowLevel) ? -1 : e.flowLevel, this.styleMap = compileStyleMap(this.schema, e.styles || null), this.sortKeys = e.sortKeys || false, this.lineWidth = e.lineWidth || 80, this.noRefs = e.noRefs || false, this.implicitTypes = this.schema.compiledImplicit, this.explicitTypes = this.schema.compiledExplicit, this.tag = null, this.result = "", this.duplicates = [], this.usedDuplicates = null;
        }
        function indentString(e, t2) {
          for (var r, i2 = common.repeat(" ", t2), n = 0, o = -1, a2 = "", s = e.length; n < s; )
            n = -1 === (o = e.indexOf("\n", n)) ? (r = e.slice(n), s) : (r = e.slice(n, o + 1), o + 1), r.length && "\n" !== r && (a2 += i2), a2 += r;
          return a2;
        }
        function generateNextLine(e, t2) {
          return "\n" + common.repeat(" ", e.indent * t2);
        }
        function testImplicitResolving(e, t2) {
          for (var r = 0, i2 = e.implicitTypes.length; r < i2; r += 1)
            if (e.implicitTypes[r].resolve(t2))
              return 1;
        }
        function StringBuilder(e) {
          this.source = e, this.result = "", this.checkpoint = 0;
        }
        function writeScalar(e, t2, r, i2) {
          var n, o, a2, s, l, u2, c2, h, f2, d, _, p2, g, m, y, v, x2, b2, T2, A2;
          if (0 !== t2.length)
            if (-1 === DEPRECATED_BOOLEANS_SYNTAX.indexOf(t2)) {
              for (n = true, o = t2.length ? t2.charCodeAt(0) : 0, a2 = CHAR_SPACE === o || CHAR_SPACE === t2.charCodeAt(t2.length - 1), CHAR_MINUS !== o && CHAR_QUESTION !== o && CHAR_COMMERCIAL_AT !== o && CHAR_GRAVE_ACCENT !== o || (n = false), l = s = a2 || -1 < e.flowLevel && e.flowLevel <= r ? (a2 && (n = false), false) : !i2, u2 = true, c2 = new StringBuilder(t2), h = false, d = f2 = 0, _ = e.indent * r, -1 === (p2 = e.lineWidth) && (p2 = 9007199254740991), _ < 40 ? p2 -= _ : p2 = 40, m = 0; m < t2.length; m++) {
                if (g = t2.charCodeAt(m), n) {
                  if (simpleChar(g))
                    continue;
                  n = false;
                }
                u2 && g === CHAR_SINGLE_QUOTE && (u2 = false), y = ESCAPE_SEQUENCES[g], v = needsHexEscape(g), (y || v) && (g !== CHAR_LINE_FEED && g !== CHAR_DOUBLE_QUOTE && g !== CHAR_SINGLE_QUOTE ? l = s = false : g === CHAR_LINE_FEED && (u2 = !(h = true), 0 < m && t2.charCodeAt(m - 1) === CHAR_SPACE && (s = l = false), s && (x2 = m - f2, f2 = m, d < x2 && (d = x2))), g !== CHAR_DOUBLE_QUOTE && (u2 = false), c2.takeUpTo(m), c2.escapeChar());
              }
              if (n && testImplicitResolving(e, t2) && (n = false), b2 = "", (s || l) && (T2 = 0, t2.charCodeAt(t2.length - 1) === CHAR_LINE_FEED && (T2 += 1, t2.charCodeAt(t2.length - 2) === CHAR_LINE_FEED && (T2 += 1)), 0 === T2 ? b2 = "-" : 2 === T2 && (b2 = "+")), (l && d < p2 || null !== e.tag) && (s = false), h || (l = false), n)
                e.dump = t2;
              else if (u2)
                e.dump = "'" + t2 + "'";
              else if (s)
                A2 = fold(t2, p2), e.dump = ">" + b2 + "\n" + indentString(A2, _);
              else if (l)
                b2 || (t2 = t2.replace(/\n$/, "")), e.dump = "|" + b2 + "\n" + indentString(t2, _);
              else {
                if (!c2)
                  throw new Error("Failed to dump scalar value");
                c2.finish(), e.dump = '"' + c2.result + '"';
              }
            } else
              e.dump = "'" + t2 + "'";
          else
            e.dump = "''";
        }
        function fold(e, t2) {
          var r, i2 = "", n = 0, o = e.length, a2 = /\n+$/.exec(e);
          for (a2 && (o = a2.index + 1); n < o; )
            n = o < (r = e.indexOf("\n", n)) || -1 === r ? (i2 && (i2 += "\n\n"), i2 += foldLine(e.slice(n, o), t2), o) : (i2 && (i2 += "\n\n"), i2 += foldLine(e.slice(n, r), t2), r + 1);
          return a2 && "\n" !== a2[0] && (i2 += a2[0]), i2;
        }
        function foldLine(e, t2) {
          if ("" === e)
            return e;
          for (var r, i2, n = /[^\s] [^\s]/g, o = "", a2 = 0, s = 0, l = n.exec(e); l; )
            t2 < (r = l.index) - s && (i2 = a2 !== s ? a2 : r, o && (o += "\n"), o += e.slice(s, i2), s = i2 + 1), a2 = r + 1, l = n.exec(e);
          return o && (o += "\n"), s !== a2 && e.length - s > t2 ? o += e.slice(s, a2) + "\n" + e.slice(a2 + 1) : o += e.slice(s), o;
        }
        function simpleChar(e) {
          return CHAR_TAB !== e && CHAR_LINE_FEED !== e && CHAR_CARRIAGE_RETURN !== e && CHAR_COMMA !== e && CHAR_LEFT_SQUARE_BRACKET !== e && CHAR_RIGHT_SQUARE_BRACKET !== e && CHAR_LEFT_CURLY_BRACKET !== e && CHAR_RIGHT_CURLY_BRACKET !== e && CHAR_SHARP !== e && CHAR_AMPERSAND !== e && CHAR_ASTERISK !== e && CHAR_EXCLAMATION !== e && CHAR_VERTICAL_LINE !== e && CHAR_GREATER_THAN !== e && CHAR_SINGLE_QUOTE !== e && CHAR_DOUBLE_QUOTE !== e && CHAR_PERCENT !== e && CHAR_COLON !== e && !ESCAPE_SEQUENCES[e] && !needsHexEscape(e);
        }
        function needsHexEscape(e) {
          return !(32 <= e && e <= 126 || 133 === e || 160 <= e && e <= 55295 || 57344 <= e && e <= 65533 || 65536 <= e && e <= 1114111);
        }
        function writeFlowSequence(e, t2, r) {
          for (var i2 = "", n = e.tag, o = 0, a2 = r.length; o < a2; o += 1)
            writeNode(e, t2, r[o], false, false) && (0 !== o && (i2 += ", "), i2 += e.dump);
          e.tag = n, e.dump = "[" + i2 + "]";
        }
        function writeBlockSequence(e, t2, r, i2) {
          for (var n = "", o = e.tag, a2 = 0, s = r.length; a2 < s; a2 += 1)
            writeNode(e, t2 + 1, r[a2], true, true) && (i2 && 0 === a2 || (n += generateNextLine(e, t2)), n += "- " + e.dump);
          e.tag = o, e.dump = n || "[]";
        }
        function writeFlowMapping(e, t2, r) {
          for (var i2, n, o, a2 = "", s = e.tag, l = Object.keys(r), u2 = 0, c2 = l.length; u2 < c2; u2 += 1)
            o = "", 0 !== u2 && (o += ", "), n = r[i2 = l[u2]], writeNode(e, t2, i2, false, false) && (1024 < e.dump.length && (o += "? "), o += e.dump + ": ", writeNode(e, t2, n, false, false) && (a2 += o += e.dump));
          e.tag = s, e.dump = "{" + a2 + "}";
        }
        function writeBlockMapping(e, t2, r, i2) {
          var n, o, a2, s, l, u2, c2 = "", h = e.tag, f2 = Object.keys(r);
          if (true === e.sortKeys)
            f2.sort();
          else if ("function" == typeof e.sortKeys)
            f2.sort(e.sortKeys);
          else if (e.sortKeys)
            throw new exception("sortKeys must be a boolean or a function");
          for (n = 0, o = f2.length; n < o; n += 1)
            u2 = "", i2 && 0 === n || (u2 += generateNextLine(e, t2)), s = r[a2 = f2[n]], writeNode(e, t2 + 1, a2, true, true, true) && ((l = null !== e.tag && "?" !== e.tag || e.dump && 1024 < e.dump.length) && (e.dump && CHAR_LINE_FEED === e.dump.charCodeAt(0) ? u2 += "?" : u2 += "? "), u2 += e.dump, l && (u2 += generateNextLine(e, t2)), writeNode(e, t2 + 1, s, true, l) && (e.dump && CHAR_LINE_FEED === e.dump.charCodeAt(0) ? u2 += ":" : u2 += ": ", c2 += u2 += e.dump));
          e.tag = h, e.dump = c2 || "{}";
        }
        function detectType(e, t2, r) {
          for (var i2, n, o, a2 = r ? e.explicitTypes : e.implicitTypes, s = 0, l = a2.length; s < l; s += 1)
            if (((n = a2[s]).instanceOf || n.predicate) && (!n.instanceOf || "object" == typeof t2 && t2 instanceof n.instanceOf) && (!n.predicate || n.predicate(t2))) {
              if (e.tag = r ? n.tag : "?", n.represent) {
                if (o = e.styleMap[n.tag] || n.defaultStyle, "[object Function]" === _toString$2.call(n.represent))
                  i2 = n.represent(t2, o);
                else {
                  if (!_hasOwnProperty$3.call(n.represent, o))
                    throw new exception("!<" + n.tag + '> tag resolver accepts not "' + o + '" style');
                  i2 = n.represent[o](t2, o);
                }
                e.dump = i2;
              }
              return 1;
            }
        }
        function writeNode(e, t2, r, i2, n, o) {
          e.tag = null, e.dump = r, detectType(e, r, false) || detectType(e, r, true);
          var a2 = _toString$2.call(e.dump);
          i2 = i2 && (e.flowLevel < 0 || e.flowLevel > t2);
          var s, l, u2 = "[object Object]" === a2 || "[object Array]" === a2;
          if (u2 && (l = -1 !== (s = e.duplicates.indexOf(r))), (null !== e.tag && "?" !== e.tag || l || 2 !== e.indent && 0 < t2) && (n = false), l && e.usedDuplicates[s])
            e.dump = "*ref_" + s;
          else {
            if (u2 && l && !e.usedDuplicates[s] && (e.usedDuplicates[s] = true), "[object Object]" === a2)
              i2 && 0 !== Object.keys(e.dump).length ? (writeBlockMapping(e, t2, e.dump, n), l && (e.dump = "&ref_" + s + e.dump)) : (writeFlowMapping(e, t2, e.dump), l && (e.dump = "&ref_" + s + " " + e.dump));
            else if ("[object Array]" === a2)
              i2 && 0 !== e.dump.length ? (writeBlockSequence(e, t2, e.dump, n), l && (e.dump = "&ref_" + s + e.dump)) : (writeFlowSequence(e, t2, e.dump), l && (e.dump = "&ref_" + s + " " + e.dump));
            else {
              if ("[object String]" !== a2) {
                if (e.skipInvalid)
                  return;
                throw new exception("unacceptable kind of an object to dump " + a2);
              }
              "?" !== e.tag && writeScalar(e, e.dump, t2, o);
            }
            null !== e.tag && "?" !== e.tag && (e.dump = "!<" + e.tag + "> " + e.dump);
          }
          return 1;
        }
        function getDuplicateReferences(e, t2) {
          var r, i2, n = [], o = [];
          for (inspectNode(e, n, o), r = 0, i2 = o.length; r < i2; r += 1)
            t2.duplicates.push(n[o[r]]);
          t2.usedDuplicates = new Array(i2);
        }
        function inspectNode(e, t2, r) {
          var i2, n, o;
          if (null !== e && "object" == typeof e)
            if (-1 !== (n = t2.indexOf(e)))
              -1 === r.indexOf(n) && r.push(n);
            else if (t2.push(e), Array.isArray(e))
              for (n = 0, o = e.length; n < o; n += 1)
                inspectNode(e[n], t2, r);
            else
              for (n = 0, o = (i2 = Object.keys(e)).length; n < o; n += 1)
                inspectNode(e[i2[n]], t2, r);
        }
        function dump(e, t2) {
          var r = new State$2(t2 = t2 || {});
          return r.noRefs || getDuplicateReferences(e, r), writeNode(r, 0, e, true, true) ? r.dump + "\n" : "";
        }
        function safeDump(e, t2) {
          return dump(e, common.extend({ schema: default_safe }, t2));
        }
        StringBuilder.prototype.takeUpTo = function(e) {
          var t2;
          if (e < this.checkpoint)
            throw (t2 = new Error("position should be > checkpoint")).position = e, t2.checkpoint = this.checkpoint, t2;
          return this.result += this.source.slice(this.checkpoint, e), this.checkpoint = e, this;
        }, StringBuilder.prototype.escapeChar = function() {
          var e = this.source.charCodeAt(this.checkpoint), t2 = ESCAPE_SEQUENCES[e] || encodeHex(e);
          return this.result += t2, this.checkpoint += 1, this;
        }, StringBuilder.prototype.finish = function() {
          this.source.length > this.checkpoint && this.takeUpTo(this.source.length);
        };
        var dump_1 = dump, safeDump_1 = safeDump, dumper = { dump: dump_1, safeDump: safeDump_1 };
        function deprecated(e) {
          return function() {
            throw new Error("Function " + e + " is deprecated and cannot be used.");
          };
        }
        var Type$1 = type, Schema$1 = schema, FAILSAFE_SCHEMA = failsafe, JSON_SCHEMA = json, CORE_SCHEMA = core, DEFAULT_SAFE_SCHEMA = default_safe, DEFAULT_FULL_SCHEMA = default_full, load$1 = loader.load, loadAll$1 = loader.loadAll, safeLoad$1 = loader.safeLoad, safeLoadAll$1 = loader.safeLoadAll, dump$1 = dumper.dump, safeDump$1 = dumper.safeDump, YAMLException$1 = exception, MINIMAL_SCHEMA = failsafe, SAFE_SCHEMA = default_safe, DEFAULT_SCHEMA = default_full, scan = deprecated("scan"), parse = deprecated("parse"), compose = deprecated("compose"), addConstructor = deprecated("addConstructor"), jsYaml = { Type: Type$1, Schema: Schema$1, FAILSAFE_SCHEMA, JSON_SCHEMA, CORE_SCHEMA, DEFAULT_SAFE_SCHEMA, DEFAULT_FULL_SCHEMA, load: load$1, loadAll: loadAll$1, safeLoad: safeLoad$1, safeLoadAll: safeLoadAll$1, dump: dump$1, safeDump: safeDump$1, YAMLException: YAMLException$1, MINIMAL_SCHEMA, SAFE_SCHEMA, DEFAULT_SCHEMA, scan, parse, compose, addConstructor }, jsYaml$1 = jsYaml, SceneBundle = function() {
          function i2(e, t2) {
            var r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
            _classCallCheck(this, i2), this.url = e, !t2 || isRelativeURL(t2) && !isRelativeURL(this.url) ? this.path = pathForURL(this.url) : this.path = t2, this.path_for_parent = t2 || this.path, this.parent = r, this.container = null, this.parent && (this.parent.container ? this.container = this.parent.container : this.parent.isContainer() && (this.container = this.parent));
          }
          return _createClass(i2, [{ key: "load", value: function() {
            return loadResource(this.url);
          } }, { key: "resourceFor", value: function(e) {
            return { url: this.urlFor(e), path: this.pathFor(e), type: this.typeFor(e) };
          } }, { key: "urlFor", value: function(e) {
            return isGlobal(e) ? e : isRelativeURL(e) && this.container ? this.parent.urlFor(this.path_for_parent + e) : addBaseURL(e, this.path);
          } }, { key: "pathFor", value: function(e) {
            return pathForURL(e);
          } }, { key: "typeFor", value: function(e) {
            return extensionForURL(e);
          } }, { key: "isContainer", value: function() {
            return false;
          } }]), i2;
        }();
        function createSceneBundle(e, t2, r) {
          return new SceneBundle(e, t2, r);
        }
        function isGlobal(e) {
          return !(!e || "global." !== e.slice(0, 7));
        }
        function parseResource(e) {
          var t2;
          try {
            t2 = jsYaml$1.safeLoad(e, { json: true });
          } catch (e2) {
            throw e2;
          }
          return t2;
        }
        function loadResource(e) {
          return new Promise(function(r, i2) {
            "string" == typeof e ? Utils$1.io(e).then(function(e2) {
              try {
                var t2 = parseResource(e2);
                r(t2);
              } catch (e3) {
                i2(e3);
              }
            }, i2) : (e = Object.assign({}, e), r(e));
          });
        }
        function notNull(e) {
          return null != e;
        }
        function wrap$1(e) {
          return "(" + e + ")";
        }
        function maybeQuote(e) {
          return "string" == typeof e ? '"' + e + '"' : e;
        }
        function lookUp(e) {
          return "$" === e[0] ? "context['" + e.substring(1) + "']" : "context.feature.properties['" + e + "']";
        }
        function nullValue(e, t2) {
          return " true ";
        }
        function propertyEqual(e, t2) {
          return wrap$1(maybeQuote(t2) + " === " + lookUp(e));
        }
        function propertyOr(t2, e) {
          return wrap$1(e.map(function(e2) {
            return propertyEqual(t2, e2);
          }).join(" || "));
        }
        function printNested(e, t2) {
          return wrap$1(e.filter(notNull).map(function(e2) {
            return wrap$1(e2.join(" && "));
          }).join(" " + t2 + " "));
        }
        function any(e, t2, r) {
          return t2 && 0 < t2.length ? printNested(t2.map(function(e2) {
            return parseFilter(e2, r);
          }), "||") : "true";
        }
        function all(e, t2, r) {
          return t2 && 0 < t2.length ? printNested(t2.map(function(e2) {
            return parseFilter(e2, r);
          }), "&&") : "true";
        }
        function not(e, t2, r) {
          return "!" + wrap$1(parseFilter(t2, r).join(" && "));
        }
        function none(e, t2, r) {
          return "!" + wrap$1(any(null, t2, r));
        }
        function propertyMatchesBoolean(e, t2) {
          return wrap$1(lookUp(e) + (t2 ? " != " : " == ") + "null");
        }
        function rangeMatch(e, t2, r) {
          var i2, n, o = [], a2 = r && "function" == typeof r.rangeTransform && r.rangeTransform;
          return t2.max && (i2 = a2 ? a2(t2.max) : t2.max, o.push(lookUp(e) + " < " + i2)), t2.min && (n = a2 ? n = a2(t2.min) : t2.min, o.push(lookUp(e) + " >= " + n)), wrap$1(o.join(" && "));
        }
        function parseFilter(e, t2) {
          var r = [];
          if ("function" == typeof e)
            return [wrap$1(e.toString() + "(context)")];
          if (Array.isArray(e))
            return [any(null, e, t2)];
          if (null == e)
            return ["true"];
          for (var i2 = Object.keys(e), n = 0; n < i2.length; n++) {
            var o = i2[n], a2 = e[o], s = _typeof(a2);
            if ("string" === s || "number" === s)
              r.push(propertyEqual(o, a2));
            else if ("boolean" === s)
              r.push(propertyMatchesBoolean(o, a2));
            else if ("not" === o)
              r.push(not(o, a2, t2));
            else if ("any" === o)
              r.push(any(o, a2, t2));
            else if ("all" === o)
              r.push(all(o, a2, t2));
            else if ("none" === o)
              r.push(none(o, a2, t2));
            else if (Array.isArray(a2))
              r.push(propertyOr(o, a2));
            else if ("object" === s && null != a2)
              (a2.max || a2.min) && r.push(rangeMatch(o, a2, t2));
            else {
              if (null != a2)
                throw new Error("Unknown Query syntax: " + a2);
              r.push(nullValue(o, a2));
            }
          }
          return 0 === i2.length ? ["true"] : r;
        }
        function filterToString(e) {
          return wrap$1(e.join(" && "));
        }
        function buildFilter(e, t2) {
          return null == e ? function() {
            return true;
          } : new Function("context", "return " + filterToString(parseFilter(e, t2)) + ";");
        }
        var reserved = ["filter", "draw", "visible", "enabled", "data"], layer_cache = {};
        function cacheKey(e) {
          if (1 < e.length) {
            for (var t2 = e[0], r = 1; r < e.length; r++)
              t2 += "/" + e[r];
            return t2;
          }
          return e[0];
        }
        function mergeTrees(e, r) {
          for (var i2, t2 = 0, n = 0; n < e.length; n++)
            e[n].length > t2 && (t2 = e[n].length);
          if (0 === t2)
            return null;
          for (var o = { visible: true }, a2 = 0; a2 < t2; a2++)
            (function(t3) {
              if (i2 = [], e.forEach(function(e2) {
                e2[t3] && e2[t3][r] && -1 === i2.indexOf(e2[t3][r]) && i2.push(e2[t3][r]);
              }), 0 === i2.length)
                return;
              i2.sort(function(e2, t4) {
                return (e2 && e2.layer_name) > (t4 && t4.layer_name) ? 1 : -1;
              }), mergeObjects.apply(void 0, [o].concat(_toConsumableArray(i2))), delete o.layer_name;
            })(a2);
          return false === o.visible ? null : o;
        }
        var blacklist = ["any", "all", "not", "none"], Layer = function() {
          function h(e) {
            var t2, r = e.layer, i2 = e.name, n = e.parent, o = e.draw, a2 = e.visible, s = e.enabled, l = e.filter, u2 = e.styles;
            if (_classCallCheck(this, h), this.id = h.id++, this.config_data = r.data, this.parent = n, this.name = i2, this.full_name = this.parent ? this.parent.full_name + ":" + this.name : this.name, this.draw = o, this.filter = l, this.styles = u2, this.is_built = false, s = void 0 === s ? a2 : s, this.parent && false === this.parent.visible ? this.enabled = false : this.enabled = false !== s, this.draw)
              for (var c2 in this.draw) {
                this.draw[c2] = null == this.draw[c2] ? {} : this.draw[c2], "object" !== _typeof(this.draw[c2]) ? (t2 = "Draw group '".concat(c2, "' for layer ").concat(this.full_name, " is invalid, must be an object, "), log("warn", t2 += "but was set to `".concat(c2, ": ").concat(this.draw[c2], "` instead")), delete this.draw[c2]) : this.draw[c2].layer_name = this.full_name;
              }
          }
          return _createClass(h, [{ key: "build", value: function() {
            log("trace", "Building layer '".concat(this.full_name, "'")), this.buildFilter(), this.buildDraw(), this.is_built = true;
          } }, { key: "buildDraw", value: function() {
            this.draw = Utils$1.stringsToFunctions(this.draw, StyleParser.wrapFunction), this.calculatedDraw = calculateDraw(this);
          } }, { key: "buildFilter", value: function() {
            this.filter_original = this.filter, this.filter = Utils$1.stringsToFunctions(this.filter, StyleParser.wrapFunction);
            var e = _typeof(this.filter);
            if (null == this.filter || "object" === e || "function" === e)
              try {
                this.buildZooms(), this.buildPropMatches(), null != this.filter && ("function" == typeof this.filter || 0 < Object.keys(this.filter).length) ? this.filter = buildFilter(this.filter, FilterOptions) : this.filter = null;
              } catch (e2) {
                var t2 = "Filter for layer ".concat(this.full_name, " is invalid, `filter: ").concat(JSON.stringify(this.filter), "` ");
                log("warn", t2 += "failed with error '".concat(e2.message, "', stack trace: ").concat(e2.stack));
              }
            else {
              var r = "Filter for layer ".concat(this.full_name, " is invalid, filter value must be an object or function, ");
              log("warn", r += "but was set to `filter: ".concat(this.filter, "` instead"));
            }
          } }, { key: "buildZooms", value: function() {
            var e = this.filter && this.filter.$zoom, t2 = _typeof(e);
            if (null != e && "function" !== t2) {
              if (this.zooms = {}, "number" === t2)
                this.zooms[e] = true;
              else if (Array.isArray(e))
                for (var r = 0; r < e.length; r++)
                  this.zooms[e[r]] = true;
              else if ("object" === t2 && (null != e.min || null != e.max))
                for (var i2 = e.min || 0, n = e.max || 25, o = i2; o < n; o++)
                  this.zooms[o] = true;
              delete this.filter.$zoom;
            }
          } }, { key: "buildPropMatches", value: function() {
            var n = this;
            this.filter && !Array.isArray(this.filter) && "function" != typeof this.filter && Object.keys(this.filter).forEach(function(e) {
              if (-1 === blacklist.indexOf(e)) {
                var t2 = n.filter[e], r = _typeof(t2), i2 = Array.isArray(t2);
                if (!i2 && "string" !== r && "number" !== r)
                  return;
                "$" === e[0] ? (n.context_prop_matches = n.context_prop_matches || [], n.context_prop_matches.push([e.substring(1), i2 ? t2 : [t2]])) : (n.feature_prop_matches = n.feature_prop_matches || [], n.feature_prop_matches.push([e, i2 ? t2 : [t2]])), delete n.filter[e];
              }
            });
          } }, { key: "doPropMatches", value: function(e) {
            if (this.feature_prop_matches)
              for (var t2 = 0; t2 < this.feature_prop_matches.length; t2++) {
                var r = this.feature_prop_matches[t2], i2 = e.feature.properties[r[0]];
                if (null == i2 || -1 === r[1].indexOf(i2))
                  return false;
              }
            if (this.context_prop_matches)
              for (var n = 0; n < this.context_prop_matches.length; n++) {
                var o = this.context_prop_matches[n], a2 = e[o[0]];
                if (null == a2 || -1 === o[1].indexOf(a2))
                  return false;
              }
            return true;
          } }, { key: "doesMatch", value: function(t2) {
            if (!this.enabled)
              return false;
            if (this.is_built || this.build(), null != this.zooms && !this.zooms[t2.zoom])
              return false;
            if (!this.doPropMatches(t2))
              return false;
            var e;
            if (this.filter instanceof Function)
              try {
                e = this.filter(t2);
              } catch (e2) {
                var r = "Filter for this ".concat(this.full_name, ": `filter: ").concat(this.filter_original, "` ");
                log("error", r += "failed with error '".concat(e2.message, "', stack trace: ").concat(e2.stack), t2.feature);
              }
            else
              e = null == this.filter;
            return !!e && (this.children_to_parse && (parseLayerChildren(this, this.children_to_parse, this.styles), delete this.children_to_parse), true);
          } }]), h;
        }();
        Layer.id = 0;
        var LayerLeaf = function() {
          _inherits(i2, Layer);
          var r = _createSuper(i2);
          function i2(e) {
            var t2;
            return _classCallCheck(this, i2), (t2 = r.call(this, e)).is_leaf = true, t2;
          }
          return i2;
        }(), LayerTree = function() {
          _inherits(i2, Layer);
          var r = _createSuper(i2);
          function i2(e) {
            var t2;
            return _classCallCheck(this, i2), (t2 = r.call(this, e)).is_tree = true, t2.layers = e.layers || [], t2;
          }
          return _createClass(i2, [{ key: "addLayer", value: function(e) {
            this.layers.push(e);
          } }, { key: "buildDrawGroups", value: function(e) {
            var t2 = [], r2 = [];
            if (matchFeature(e, [this], t2, r2), 0 < t2.length) {
              var i3 = cacheKey(r2);
              if (void 0 === layer_cache[i3]) {
                for (var n = t2.map(function(e2) {
                  return e2 && false !== e2.visible && e2.calculatedDraw;
                }), o = {}, a2 = 0; a2 < n.length; a2++) {
                  var s = n[a2];
                  if (s)
                    for (var l = 0; l < s.length; l++) {
                      var u2 = s[l];
                      for (var c2 in u2)
                        o[c2] = true;
                    }
                }
                for (var h in o)
                  layer_cache[i3] = layer_cache[i3] || {}, layer_cache[i3][h] = mergeTrees(n, h), layer_cache[i3][h] ? (layer_cache[i3][h].key = i3 + "/" + h, layer_cache[i3][h].layers = t2.map(function(e2) {
                    return e2 && e2.full_name;
                  }), layer_cache[i3][h].group = h) : delete layer_cache[i3][h];
                layer_cache[i3] && 0 === Object.keys(layer_cache[i3]).length && (layer_cache[i3] = null);
              }
              return layer_cache[i3];
            }
          } }]), i2;
        }(), FilterOptions = { rangeTransform: function(e) {
          return "string" == typeof e && "px2" === e.trim().slice(-3) ? "".concat(parseFloat(e), " * context.meters_per_pixel_sq") : e;
        } }, SceneLoader;
        function isReserved(e) {
          return -1 < reserved.indexOf(e);
        }
        function isEmpty(e) {
          return 0 === Object.keys(e).length;
        }
        function groupProps(e) {
          var t2 = {}, r = {};
          for (var i2 in e)
            isReserved(i2) ? t2[i2] = e[i2] : r[i2] = e[i2];
          return [t2, r];
        }
        function calculateDraw(e) {
          var t2, r = [];
          return e.parent && (t2 = e.parent.calculatedDraw || [], r.push.apply(r, _toConsumableArray(t2))), r.push(e.draw), r;
        }
        function parseLayerNode(e, t2, r, i2) {
          var n = { name: e, layer: t2 = null == t2 ? {} : t2, parent: r, styles: i2 }, o = _slicedToArray(groupProps(t2), 2), a2 = o[0], s = o[1], l = isEmpty(s), u2 = l && null != r ? LayerLeaf : LayerTree, c2 = new u2(Object.assign(n, a2));
          return c2.enabled && (r && r.addLayer(c2), c2.children_to_parse = l ? null : s), c2;
        }
        function parseLayerChildren(e, t2, r) {
          for (var i2 in t2) {
            var n, o = t2[i2];
            "object" !== _typeof(o) || Array.isArray(o) ? (n = "Layer value must be an object: cannot create layer '".concat(i2, ": ").concat(JSON.stringify(o), "'"), n += ", under parent layer '".concat(e.full_name, "'."), r[e.name] && (n += " The parent name '".concat(e.name, "' is also the name of a style, did you mean to create a 'draw' group"), e.parent && (n += " under '".concat(e.parent.name, "'")), n += " instead?"), log("warn", n)) : parseLayerNode(i2, o, e, r);
          }
        }
        function parseLayers(e, t2) {
          layer_cache = {};
          var r = {};
          for (var i2 in e) {
            var n = e[i2];
            n && (r[i2] = parseLayerNode(i2, n, null, t2));
          }
          return r;
        }
        function matchFeature(e, t2, r, i2) {
          var n = false;
          if (0 !== t2.length) {
            for (var o = 0; o < t2.length; o++) {
              var a2 = t2[o];
              a2.is_leaf ? a2.doesMatch(e) && (n = true, r.push(a2), i2.push(a2.id)) : a2.is_tree && a2.doesMatch(e) && (n = true, matchFeature(e, a2.layers, r, i2) || (r.push(a2), i2.push(a2.id)));
            }
            return n;
          }
        }
        var GLOBAL_PROP_RGX = /^global\.(.+)$/, SceneLoader$1 = SceneLoader = { loadScene: function(e, t2) {
          var i2 = this, r = 1 < arguments.length && void 0 !== t2 ? t2 : {}, n = r.path, o = r.type, a2 = [];
          return this.loadSceneRecursive({ url: e, path: n, type: o }, null, a2).then(function(e2) {
            return i2.finalize(e2);
          }).then(function(e2) {
            var t3 = e2.config, r2 = e2.bundle;
            return t3 ? (0 < a2.length && a2.forEach(function(e3) {
              var t4 = "Failed to import scene: ".concat(e3.url);
              log("error", t4, e3), i2.trigger("error", { type: "scene_import", message: t4, error: e3, url: e3.url });
            }), { config: t3, bundle: r2 }) : Promise.reject(a2[0]);
          });
        }, loadSceneRecursive: function(e, t2, r) {
          var i2 = this, n = e.url, o = e.path, a2 = e.type, s = 2 < arguments.length && void 0 !== r ? r : [];
          if (!n)
            return Promise.resolve({});
          var l = createSceneBundle(n, o, t2, a2);
          return l.load().then(function(r2) {
            if (null == r2.import)
              return i2.normalize(r2, l), { config: r2, bundle: l };
            Array.isArray(r2.import) || (r2.import = [r2.import]);
            var t3 = [];
            return r2.import.forEach(function(e2) {
              "object" === _typeof(e2) && (e2 = createObjectURL(new Blob([JSON.stringify(e2)]))), t3.push(l.resourceFor(e2));
            }), delete r2.import, Promise.all(t3.map(function(e2) {
              return i2.loadSceneRecursive(e2, l, s);
            })).then(function(e2) {
              e2.forEach(function(e3) {
                return i2.normalize(e3.config, e3.bundle);
              });
              var t4 = e2.map(function(e3) {
                return e3.config;
              });
              return r2 = mergeObjects.apply(void 0, _toConsumableArray(t4).concat([r2])), i2.normalize(r2, l), { config: r2, bundle: l };
            });
          }).catch(function(e2) {
            return e2.url = n, s.push(e2), {};
          });
        }, normalize: function(e, t2) {
          return this.normalizeDataSources(e, t2), this.normalizeFonts(e, t2), this.normalizeTextures(e, t2), this.hoistTextures(e, t2), { config: e, bundle: t2 };
        }, normalizeDataSources: function(e, t2) {
          for (var r in e.sources = e.sources || {}, e.sources)
            this.normalizeDataSource(e.sources[r], t2);
          return e;
        }, normalizeDataSource: function(e, t2) {
          if (e.url && (e.url = t2.urlFor(e.url)), e.scripts)
            for (var r in Array.isArray(e.scripts) && (e.scripts = e.scripts.reduce(function(e2, t3) {
              return e2[t3] = t3, e2;
            }, {})), e.scripts)
              e.scripts[r] = t2.urlFor(e.scripts[r]);
          return e;
        }, normalizeFonts: function(e, t2) {
          for (var r in e.fonts = e.fonts || {}, e.fonts) {
            var i2;
            Array.isArray(e.fonts[r]) ? e.fonts[r].forEach(function(e2) {
              e2.url = e2.url && t2.urlFor(e2.url);
            }) : (i2 = e.fonts[r]).url = i2.url && t2.urlFor(i2.url);
          }
          return e;
        }, normalizeTextures: function(e, t2) {
          if (e.textures = e.textures || {}, e.textures)
            for (var r in e.textures) {
              var i2 = e.textures[r];
              i2.url && (i2.url = t2.urlFor(i2.url));
            }
        }, hoistTextures: function(i2, n) {
          var o = this;
          if (i2.styles) {
            for (var e in i2.styles)
              !function(e2) {
                var r2 = i2.styles[e2], t3 = r2.texture;
                "string" != typeof t3 || i2.textures[t3] || (r2.texture = o.hoistTexture(t3, i2, n)), r2.material && ["emission", "ambient", "diffuse", "specular", "normal"].forEach(function(e3) {
                  var t4 = null != r2.material[e3] && r2.material[e3].texture;
                  "string" != typeof t4 || i2.textures[t4] || (r2.material[e3].texture = o.hoistTexture(t4, i2, n));
                });
              }(e);
          }
          if (this.hoistStyleShaderUniformTextures(i2, n, { include_globals: false }), i2.layers)
            for (var t2 = [i2.layers]; 0 < t2.length; ) {
              var r = t2.pop();
              if ("object" === _typeof(r) && !Array.isArray(r))
                for (var a2 in r)
                  if ("draw" === a2) {
                    var s, l, u2 = r[a2];
                    for (var c2 in u2) {
                      u2[c2].texture && ("string" != typeof (s = u2[c2].texture) || i2.textures[s] || (u2[c2].texture = this.hoistTexture(s, i2, n))), u2[c2].outline && u2[c2].outline.texture && ("string" != typeof (l = u2[c2].outline.texture) || i2.textures[l] || (u2[c2].outline.texture = this.hoistTexture(l, i2, n)));
                    }
                  } else {
                    if (isReserved(a2))
                      continue;
                    t2.push(r[a2]);
                  }
            }
        }, hoistStyleShaderUniformTextures: function(o, a2, e) {
          var s = this, l = e.include_globals;
          if (o.styles)
            for (var t2 in o.styles) {
              var r = o.styles[t2];
              r.shaders && r.shaders.uniforms && GLSL.parseUniforms(r.shaders.uniforms).forEach(function(e2) {
                var t3 = e2.type, r2 = e2.value, i2 = e2.key, n = e2.uniforms;
                "sampler2D" !== t3 || "string" != typeof r2 || o.textures[r2] || !l && isGlobal(r2) || (n[i2] = s.hoistTexture(r2, o, a2));
              });
            }
        }, hoistTexture: function(e, t2, r) {
          var i2 = isGlobal(e), n = i2 ? e : r.urlFor(e), o = i2 ? "texture-".concat(n) : n;
          return t2.textures[o] = { url: n }, o;
        }, applyGlobalProperties: function(e) {
          if (!e.global || 0 === Object.keys(e.global).length)
            return e;
          var o = flattenProperties(e.global);
          return function e2(t2) {
            if ("string" == typeof t2) {
              var r = function e3(t3, r2, i3) {
                var n2 = 2 < arguments.length && void 0 !== i3 ? i3 : [];
                if (-1 < n2.indexOf(t3))
                  log({ level: "warn", once: true }, "Global properties: cyclical reference detected", n2);
                else {
                  n2.push(t3);
                  var o2 = GLOBAL_PROP_RGX.exec(t3);
                  if (o2) {
                    var a2 = o2[1];
                    if (a2) {
                      var s = r2[a2];
                      if (void 0 !== s)
                        return "string" == typeof s && GLOBAL_PROP_RGX.exec(s) ? e3(s, r2, n2) : s;
                      log({ level: "warn", once: true }, "Global property not found: " + t3);
                    } else
                      log({ level: "warn", once: true }, "Invalid global property reference: " + t3);
                  }
                }
              }(t2, o);
              void 0 !== r && (t2 = r);
            } else if (Array.isArray(t2))
              for (var i2 = 0; i2 < t2.length; i2++)
                t2[i2] = e2(t2[i2]);
            else if ("object" === _typeof(t2))
              for (var n in t2)
                t2[n] = e2(t2[n]);
            return t2;
          }(e);
        }, finalize: function(e) {
          var t2 = e.config, r = e.bundle;
          return t2 ? (t2.global = t2.global || {}, t2.scene = t2.scene || {}, t2.cameras = t2.cameras || {}, t2.lights = t2.lights || {}, t2.styles = t2.styles || {}, t2.layers = t2.layers || {}, t2.camera && (t2.cameras.default = t2.camera), 0 === Object.keys(t2.cameras).length && (t2.cameras.default = {}), 0 !== Object.keys(t2.lights).length && !Object.keys(t2.lights).every(function(e2) {
            return false === t2.lights[e2].visible;
          }) || (t2.lights.default_light = { type: "directional" }), { config: t2, bundle: r }) : {};
        } };
        function flattenProperties(e) {
          var t2 = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : ".", r = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : {}, i2 = (i2 = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null) ? i2 + t2 : "";
          for (var n in e) {
            var o = i2 + n, a2 = e[n];
            "object" !== _typeof(r[o] = a2) || Array.isArray(a2) || flattenProperties(a2, t2, o, r);
          }
          return r;
        }
        subscribeMixin(SceneLoader);
        var TilePyramid = function() {
          function e() {
            _classCallCheck(this, e), this.coords = {}, this.max_proxy_descendant_depth = 6, this.max_proxy_ancestor_depth = 10;
          }
          return _createClass(e, [{ key: "sourceTiles", value: function(e2, t2) {
            return this.coords[e2.key] && this.coords[e2.key].sources && this.coords[e2.key].sources[t2.name];
          } }, { key: "addTile", value: function(e2) {
            var t2 = e2.coords.key, r = this.coords[t2];
            (r = r || (this.coords[t2] = { descendants: 0 })).sources || (r.sources = {}), r.sources[e2.source.name] || (r.sources[e2.source.name] = {});
            for (var i2 = (r.sources[e2.source.name][e2.style_zoom] = e2).coords.z - 1; 0 <= i2; i2--) {
              var n = Tile.coordinateAtZoom(e2.coords, i2);
              this.coords[n.key] || (this.coords[n.key] = { descendants: 0 }), this.coords[n.key].descendants++;
            }
          } }, { key: "removeTile", value: function(e2) {
            var t2 = this.sourceTiles(e2.coords, e2.source), r = e2.coords.key;
            t2 && (delete t2[e2.style_zoom], 0 === Object.keys(t2).length && (delete this.coords[r].sources[e2.source.name], 0 === Object.keys(this.coords[r].sources).length && (delete this.coords[r].sources, 0 === this.coords[r].descendants && delete this.coords[r])));
            for (var i2 = e2.coords.z - 1; 0 <= i2; i2--) {
              var n = Tile.coordinateAtZoom(e2.coords, i2);
              this.coords[n.key] && 0 < this.coords[n.key].descendants && (this.coords[n.key].descendants--, 0 !== this.coords[n.key].descendants || this.coords[n.key].sources || delete this.coords[n.key]);
            }
          } }, { key: "getAncestor", value: function(e2, t2) {
            var r = e2.coords, i2 = e2.style_zoom, n = e2.source, o = 1 < arguments.length && void 0 !== t2 ? t2 : 1;
            if (!(o > this.max_proxy_ancestor_depth)) {
              if (i2 > n.max_coord_zoom) {
                var a2 = this.sourceTiles(r, n);
                if (a2) {
                  for (var s = i2 - 1; s >= n.max_coord_zoom; s--)
                    if (a2[s] && a2[s].loaded)
                      return a2[s];
                }
                i2 = n.max_coord_zoom;
              }
              i2--;
              var l = Tile.coordinateAtZoom(r, r.z - 1), u2 = this.sourceTiles(l, n);
              return u2 && u2[i2] && u2[i2].loaded ? u2[i2] : 0 < l.z ? this.getAncestor({ coords: l, style_zoom: i2, source: n }, o + 1) : void 0;
            }
          } }, { key: "getDescendants", value: function(e2, t2) {
            var r = e2.coords, i2 = e2.style_zoom, n = e2.source, o = 1 < arguments.length && void 0 !== t2 ? t2 : 1, a2 = [];
            if (i2 >= n.max_coord_zoom) {
              var s = this.sourceTiles(r, n);
              if (s) {
                for (var l = Math.max(Geo$1.default_view_max_zoom, i2 + this.max_proxy_descendant_depth), u2 = i2 + 1; u2 <= l; u2++)
                  if (s[u2] && s[u2].loaded)
                    return a2.push(s[u2]), a2;
              }
              return a2;
            }
            if (this.coords[r.key] && 0 < this.coords[r.key].descendants) {
              i2++;
              for (var c2 = Tile.childrenForCoordinate(r), h = 0; h < c2.length; h++) {
                var f2 = c2[h], d = this.sourceTiles(f2, n);
                d && d[i2] && d[i2].loaded ? a2.push(d[i2]) : o <= this.max_proxy_descendant_depth && f2.z <= n.max_coord_zoom && a2.push.apply(a2, _toConsumableArray(this.getDescendants({ coords: f2, source: n, style_zoom: i2 }, o + 1)));
              }
            }
            return a2;
          } }]), e;
        }(), LabelMainPass = function() {
          function o(e, t2, r, i2) {
            _classCallCheck(this, o), Object.assign(this, e), this.placed = null, this._tile = i2;
            var n = Geo$1.unitsPerMeter(i2.coords.z) * Math.pow(2, r - i2.style_zoom);
            this.layout = Object.assign({}, e.layout), this.layout.repeat_scale = 0.75, this.layout.repeat_distance = this.layout.repeat_distance || 0, this.layout.repeat_distance /= n, this.position = Geo$1.tileSpaceToMeters(this.position, i2.coords.z, i2.min), this._worldToScreen = t2, this._screenSpaceBoundingBox = void 0, this._boundingCircles = void 0;
          }
          return _createClass(o, [{ key: "getTile", value: function() {
            return this._tile;
          } }, { key: "isFlat", value: function() {
            return this.is_flat;
          } }, { key: "getScreenSpaceBoundingBox", value: function() {
            var e, t2, r, i2, n, o2, a2;
            return this._screenSpaceBoundingBox || ((e = this._worldToScreen(this.position, true))[0] += this.offset[0], e[1] += this.offset[1], t2 = this.size[0] / 2 + this.layout.buffer[0], r = this.size[1] / 2 + this.layout.buffer[1], i2 = e[0] - t2, n = e[0] + t2, o2 = e[1] - r, a2 = e[1] + r, this._screenSpaceBoundingBox = { left: i2, bottom: a2, right: n, top: o2 }), this._screenSpaceBoundingBox;
          } }, { key: "getBoundingCircles", value: function() {
            return this._boundingCircles || (this._boundingCircles = "point" === this.type ? this._convertSidesToScreenSpaceCircles() : this._convertCirclesToScreenSpace()), this._boundingCircles;
          } }, { key: "_convertSidesToScreenSpaceCircles", value: function() {
            var e = this._tile.coords.z, t2 = this._tile.min, r = Geo$1.tileSpaceToMeters([this.sides[0], this.sides[1]], e, t2), i2 = Geo$1.tileSpaceToMeters([this.sides[2], this.sides[3]], e, t2), n = _slicedToArray(this._worldToScreen(r, true), 2), o2 = n[0], a2 = n[1], s = _slicedToArray(this._worldToScreen(i2, true), 2);
            return encircleLine(o2, a2, s[0], s[1], this.size[1] / 2 + this.layout.buffer[1]);
          } }, { key: "_convertCirclesToScreenSpace", value: function() {
            for (var e = [], t2 = this.circles, r = this._tile.coords.z, i2 = this._tile.min, n = 0; n < t2.length - 2; n += 3) {
              var o2 = Geo$1.tileSpaceToMeters([t2[n], -t2[n + 1]], r, i2), a2 = t2[n + 2] / Geo$1.unitsPerMeter(r), s = [o2[0] + a2, o2[1]], l = this._worldToScreen(o2, true), u2 = this._worldToScreen(s, true), c2 = MathUtils$1.getLineLength(l[0], l[1], u2[0], u2[1]);
              e.push(l[0], l[1], c2);
            }
            return e;
          } }]), o;
        }(), labelsMainPass = { mainThreadLabelCollisionPass }, visible = {}, prev_visible = {}, IS_LITTLE_ENDIAN = 120 === new Uint8Array(new Uint32Array([305419896]).buffer)[0];
        function _createContainer(e, t2, r, i2, n) {
          var o = e.container, a2 = o.label, s = o.linked, l = e.ranges;
          return { label: new LabelMainPass(a2, r, i2, n), linked: s, ranges: l, mesh: t2 };
        }
        function mainThreadLabelCollisionPass(t2, a2, e, u2, r, i2) {
          prev_visible = visible, visible = {};
          var s = {}, l = {}, n = [], c2 = e.worldToScreen.bind(e), h = new TextMeshHelper(i2);
          for (var o in t2.forEach(function(o2) {
            for (var e2 in o2.meshes)
              o2.meshes[e2].forEach(function(e3) {
                if (e3.labels) {
                  for (var t3 in h.trackMesh(e3), e3.labels["non-collision"]) {
                    var r2 = _createContainer(e3.labels["non-collision"][t3], e3, c2, a2, o2);
                    r2.label.text_data && h.insertLabel(r2, o2);
                  }
                  for (var i3 in e3.labels.collision) {
                    var n2;
                    s[i3] || (n2 = _createContainer(e3.labels.collision[i3], e3, c2, a2, o2), s[i3] = n2.label, l[i3] = n2);
                  }
                }
              });
          }), l) {
            var f2 = l[o];
            f2.linked && (f2.linked = l[f2.linked]), n.push(f2);
          }
          var d = e.getViewport(), _ = d.width, p2 = d.height;
          return Collision.startTile("main", { apply_repeat_groups: true, return_hidden: true, grid_index: new GridIndex(_, p2, 30) }), Collision.addStyle("main", "main"), Collision.collide(n, "main", "main").then(function(e2) {
            return e2.forEach(function(e3) {
              var r2, i3, n2, t3, o2, a3, s2 = e3.mesh, l2 = e3.label.getTile();
              s2.valid && (!(r2 = 0) !== e3.show || u2 && e3.label.breach && !prev_visible[e3.label.id] || (r2 = 1), r2 && (visible[e3.label.id] = true), e3.label.text_data && h.insertLabel(e3, l2), i3 = s2.vertex_layout.offset.a_shape, n2 = s2.vertex_layout.stride, o2 = (t3 = s2.vertex_layout.attribs.find(function(e4) {
                return "a_shape" === e4.name;
              })).byte_size / t3.size, i3 += 3 * o2, a3 = true, e3.ranges.forEach(function(e4) {
                if (a3) {
                  for (var t4 = 0; t4 < e4[1]; t4++) {
                    if (s2.vertex_data[e4[0] + t4 * n2 + i3] === r2)
                      return void (a3 = false);
                    s2.vertex_data[e4[0] + t4 * n2 + i3] = r2;
                  }
                  h.trackMesh(s2);
                }
              }));
            }), h.createTextures(r).then(function() {
              return h.updateMeshes();
            });
          }).then(function(e2) {
            e2.forEach(function(e3) {
              return e3.valid && e3.upload();
            }), t2.forEach(function(e3) {
              e3.labeled = true;
            }), n = [], l = {}, s = {};
          });
        }
        var TextMeshHelper = function() {
          function t2(e) {
            _classCallCheck(this, t2), this.textureManager = getTextureManager(e), this.tiles = {}, this.meshes = [], this.containers = [];
          }
          return _createClass(t2, [{ key: "insertLabel", value: function(e, t3) {
            var r = e.label.text_data, i2 = r.text_settings_key, n = r.text, o = r.text_info;
            this.containers.push(e);
            var a2 = this._ensureTextSection(t3, i2);
            a2[n] ? e.label.text_data.text_info = a2[n] : a2[n] = o;
          } }, { key: "trackMesh", value: function(e) {
            -1 === this.meshes.indexOf(e) && this.meshes.push(e);
          } }, { key: "updateMeshes", value: function() {
            var h = this;
            return this.containers.forEach(function(e) {
              var t3, r, i2, n, o, a2, s, l, u2, c2;
              e.label.text_data && (t3 = e.label.getTile(), (r = e.mesh).valid ? (i2 = e.label.type, n = e.label.text_data.text_info, h.tiles[t3.id] && h.tiles[t3.id].textures && (o = h.tiles[t3.id].textures[0], r.uniforms.u_texture = o, -1 === r.textures.indexOf(o) && r.textures.push(o), "point" === i2 || "straight" === i2 ? (a2 = "point" === i2 ? n.align[e.label.align].texcoords : n.texcoords[i2].texcoord, h.setTexCoords(r, e, a2)) : "curved" === i2 && (s = n.segments.length, l = n.texcoords_stroke, u2 = n.texcoords.curved, h.setTexCoords(r, e, function(e2) {
                return e2 < s ? l[e2] : u2[e2 - s].texcoord;
              })))) : h.tiles[t3.id] && h.tiles[t3.id].textures && (c2 = h.tiles[t3.id].textures[0], h.textureManager.release(c2)));
            }), this.meshes;
          } }, { key: "setTexCoords", value: function(e, t3, _) {
            var r, i2, n, o, a2, p2, g = _ instanceof Function;
            g || (i2 = (r = _slicedToArray(_, 4))[0], n = r[1], o = r[2], a2 = r[3], p2 = [[i2, n], [o, n], [o, a2], [i2, a2]]);
            var m = e.vertex_layout.stride, y = new DataView(e.vertex_data.buffer), v = e.vertex_layout.offset.a_texcoord;
            t3.ranges.forEach(function(e2, t4) {
              var r2, i3, n2, o2, a3, s = _slicedToArray(e2, 3), l = s[0], u2 = s[1], c2 = s[2];
              g && (i3 = (r2 = _slicedToArray(_(t4), 4))[0], n2 = r2[1], o2 = r2[2], a3 = r2[3], p2 = [[i3, n2], [o2, n2], [o2, a3], [i3, a3]]);
              for (var h = c2 ? u2 / 2 : 0; h < u2; h++) {
                var f2 = p2[h % 4], d = l + h * m;
                y.setUint16(d + v, f2[0] * texcoord_normalize, IS_LITTLE_ENDIAN), y.setUint16(d + v + 2, f2[1] * texcoord_normalize, IS_LITTLE_ENDIAN);
              }
            });
          } }, { key: "createTextures", value: function(n) {
            var o = this;
            return Promise.all(Object.values(this.tiles).map(function(e) {
              var t3 = e.id, r = e.key, i2 = e.texts;
              return o._createTexturesForTile(n, i2, "labels-".concat(r, "-").concat(t3), t3, o.textureManager).then(function(e2) {
                e2.length && (e2.forEach(function(e3) {
                  o.textureManager.retain(e3), 1 < o.textureManager.getRetainCount(e3) && o.textureManager.release(e3);
                }), o.tiles[t3].textures = e2);
              });
            }));
          } }, { key: "_createTexturesForTile", value: function(e, t3, r, i2, n) {
            var o = new CanvasText(), a2 = o.setTextureTextPositions(t3);
            return o.rasterize(t3, a2, i2, r, e, n);
          } }, { key: "_ensureTile", value: function(e) {
            var t3 = e.id, r = e.key;
            return this.tiles[t3] || (this.tiles[t3] = { id: t3, key: r, texts: {} }), this.tiles[t3];
          } }, { key: "_ensureTextSection", value: function(e, t3) {
            var r = this._ensureTile(e).texts;
            return r[t3] || (r[t3] = {}), r[t3];
          } }]), t2;
        }(), TILE_VISIBILITY_COUNTER_THRESHOLD = 30, TileManager = function() {
          function n(e) {
            var i2 = this, t2 = e.scene, r = e.view;
            _classCallCheck(this, n), this._scene = t2, this._view = r, this._visible_tiles = {}, this._pyramid = new TilePyramid(), this._visible_coords = {}, this._building_tiles = null, this._renderable_tiles = [], this._active_styles = [], this._tile_visibility_counters = {}, this._update_labels_on_queue_check = false, this._all_visible_tiles_are_cached = false, this._debouncedUpdateLabels = debounce(this._updateLabels.bind(this), 100, 200), this._main_thread_target = ["TileManager", this._scene.id].join("_"), WorkerBroker.addTarget(this._main_thread_target, this), this._keepCoordinate = this._keepCoordinate.bind(this), this._removeTilesFilter = this._removeTilesFilter.bind(this), this._removeCachedTilesFilter = this._removeCachedTilesFilter.bind(this), this._is_labeled = false, this._tile_cache = new H.util.Cache(getMaxTileCacheSize(), function(e2, t3, r2) {
              i2._visible_tiles[e2] && i2._visible_tiles[e2] === t3 || t3.destroy();
            });
          }
          return _createClass(n, [{ key: "destroy", value: function() {
            this._tile_cache.removeAll(), this.forEachVisibleTile(function(e) {
              return e.destroy();
            }), this._visible_tiles = {}, this._pyramid = null, this._visible_coords = {}, this._scene = null, this._view = null;
          } }, { key: "keepTile", value: function(e) {
            this._visible_tiles[e.key] = e, this._pyramid.addTile(e);
          } }, { key: "hasTile", value: function(e) {
            return void 0 !== this._visible_tiles[e];
          } }, { key: "_forgetTile", value: function(e) {
            var t2, r;
            this.hasTile(e) && (t2 = this._visible_tiles[e], this._pyramid.removeTile(t2), delete this._visible_tiles[e], t2.loaded ? this._tile_cache.add(t2.key, t2, getTileByteLength(t2)) : (r = this._tile_cache.get(t2.key)) ? this._tile_cache.drop(r.key) : t2.destroy(), this._tileBuildStop(t2));
          } }, { key: "removeTile", value: function(e) {
            this._forgetTile(e), this._scene.requestRedraw();
          } }, { key: "forEachVisibleTile", value: function(e) {
            for (var t2 in this._visible_tiles)
              e(this._visible_tiles[t2]);
          } }, { key: "removeTiles", value: function(e) {
            for (var t2 in this._visible_tiles)
              e(this._visible_tiles[t2]) && this.removeTile(t2);
          } }, { key: "removeCachedTiles", value: function(r) {
            var i2 = this;
            this._tile_cache.forEach(function(e, t2) {
              r(t2) && i2._tile_cache.drop(e);
            });
          } }, { key: "updateTilesForView", value: function(e) {
            var t2 = 0 < arguments.length && void 0 !== e && e;
            this._visible_coords = {};
            for (var r = this._view.findVisibleTileCoordinates(), i2 = 0; i2 < r.length; i2++) {
              var n2 = r[i2];
              this._visible_coords[n2.key] = n2;
            }
            this.updateTileStates(t2);
          } }, { key: "updateTileStates", value: function(e) {
            var t2 = 0 < arguments.length && void 0 !== e && e;
            for (var r in this._all_visible_tiles_are_cached = true, this._visible_coords)
              this._keepCoordinate(r, t2);
            this._all_visible_tiles_are_cached && (this._is_labeled = false, this._debouncedUpdateLabels()), this._tile_cache.removeAll(this._removeCachedTilesFilter), this._updateProxyTiles(), this.removeTiles(this._removeTilesFilter), this._updateRenderableTiles(), this._updateActiveStyles();
          } }, { key: "_removeTilesFilter", value: function(e) {
            if (e.style_zoom === this._view.lookAtManipulator.getLookAtData().tile_level) {
              if (this._visible_coords[e.coords.key])
                return false;
              for (var t2 in this._visible_coords)
                if (Tile.isDescendant(e.coords, this._visible_coords[t2]))
                  return false;
            }
            return !e.isProxy();
          } }, { key: "_updateLabels", value: function() {
            var e, t2 = this;
            this._building_tiles && 0 !== Object.keys(this._building_tiles).length || (CanvasText.pruneTextCache(), e = this._renderable_tiles.sort(compareTileCoords), labelsMainPass.mainThreadLabelCollisionPass(e, roundPrecision(this._view.lookAtManipulator.getLookAtData().zoom, 2), this._view.lookAtManipulator, this.isLoadingVisibleTiles(), this._scene.gl, this._scene.id).then(function() {
              t2._is_labeled = !Task.hasPendingTasks(), t2._scene && t2._scene.immediateRedraw(), t2._update_labels_on_queue_check = false;
            }));
          } }, { key: "_updateProxyTiles", value: function() {
            var n2, o = this, a2 = this._view.lookAtManipulator.getZoomDirection();
            0 !== a2 && (n2 = false, this.forEachVisibleTile(function(e) {
              var t2;
              if (e.setProxyFor(null), 1 === a2)
                e.built || (t2 = o._pyramid.getAncestor(e)) && (t2.setProxyFor(e), n2 = true);
              else if (-1 === a2 && !e.built)
                for (var r = o._pyramid.getDescendants(e), i2 = 0; i2 < r.length; i2++)
                  r[i2].setProxyFor(e), n2 = true;
            }), n2 || this._view.lookAtManipulator.resetZoomDirection());
          } }, { key: "getRenderableTiles", value: function() {
            return this._renderable_tiles;
          } }, { key: "_updateRenderableTiles", value: function() {
            for (var e in this._renderable_tiles = [], this._visible_tiles) {
              var t2 = this._visible_tiles[e], r = this._tile_cache.get(e);
              t2.loaded ? (this._renderable_tiles.push(t2), r && r !== t2 && this._tile_cache.drop(e)) : r && (r.generation === this._scene.generation ? this._renderable_tiles.push(r) : this._tile_cache.drop(e));
            }
            return this._renderable_tiles;
          } }, { key: "getWorkerForTile", value: function(e, t2) {
            var r = t2.has_volatile_data ? this._scene.getWorkers(WorkerType.FAKE)[0] : t2.tiled ? this._scene.getWorkers(WorkerType.NATIVE)[Math.abs(e.x + e.y + e.z) % this._scene.num_workers] : this._scene.getWorkers(WorkerType.NATIVE)[t2.id % this._scene.num_workers];
            return r;
          } }, { key: "getActiveStyles", value: function() {
            return this._active_styles;
          } }, { key: "_updateActiveStyles", value: function() {
            for (var e = this._renderable_tiles, t2 = {}, r = 0; r < e.length; r++) {
              var i2 = e[r];
              Object.keys(i2.meshes).forEach(function(e2) {
                return t2[e2] = true;
              });
            }
            return this._active_styles = Object.keys(t2), this._active_styles;
          } }, { key: "isLoadingVisibleTiles", value: function() {
            var e = false;
            for (var t2 in this._visible_tiles) {
              if (!this._visible_tiles[t2].built) {
                e = true;
                break;
              }
            }
            return e;
          } }, { key: "updateTilesVisibilityCounters", value: function() {
            var t2 = this;
            Object.keys(this._visible_coords).forEach(function(e2) {
              e2 in t2._tile_visibility_counters || (t2._tile_visibility_counters[e2] = 0);
            });
            var e = Object.keys(this._tile_visibility_counters), r = [];
            e.forEach(function(e2) {
              e2 in t2._visible_coords ? (t2._tile_visibility_counters[e2]++, t2._tile_visibility_counters[e2] >= TILE_VISIBILITY_COUNTER_THRESHOLD && r.push(t2._visible_coords[e2])) : (t2._tile_visibility_counters[e2]--, t2._tile_visibility_counters[e2] <= 0 && delete t2._tile_visibility_counters[e2]);
            }), r.length && this.loadCoordinates(r);
          } }, { key: "loadCoordinates", value: function(e) {
            var l = this;
            e.sort(function(e2, t2) {
              var r = l._view.lookAtManipulator.getLookAtData().position, i2 = Geo$1.metersPerTile(e2.z) / 2, n2 = Geo$1.metersForTile(e2);
              n2.x += i2, n2.y -= i2;
              var o = Geo$1.metersForTile(t2);
              o.x += i2, o.y -= i2;
              var a2 = Math.abs(r[0] - n2.x) + Math.abs(r[1] - n2.y), s = Math.abs(r[0] - o.x) + Math.abs(r[1] - o.y);
              return (e2.center_dist = a2) < (t2.center_dist = s) ? -1 : s === a2 ? 0 : 1;
            }), e.forEach(function(e2) {
              return l.loadCoordinate(e2);
            });
          } }, { key: "_keepCoordinate", value: function(e, t2) {
            var r = 1 < arguments.length && void 0 !== t2 && t2, i2 = this._visible_coords[e];
            if (i2.z === this._view.center_tile.z)
              for (var n2 in this._scene.sources) {
                var o, a2, s, l = this._scene.sources[n2];
                l.builds_geometry_tiles && l.includesTile(i2, this._view.lookAtManipulator.getLookAtData().tile_level) && ((o = Tile.normalizedKey(i2, l, this._view.lookAtManipulator.getLookAtData().tile_level)) && !this.hasTile(o) && ((a2 = r && this._tile_cache.get(o)) || (this._all_visible_tiles_are_cached = false), s = a2 || new Tile({ source: l, coords: i2, worker: this.getWorkerForTile(i2, l), style_zoom: Utils$1.zoomToTileLevel(i2.z), view: this._view, sceneId: this._scene.id }), "ObjectSource" === l.config.type && (s.syncedAt = l.getSyncedAt()), this.keepTile(s)));
              }
          } }, { key: "loadCoordinate", value: function(e) {
            if (e.z === this._view.center_tile.z)
              for (var t2 in this._scene.sources) {
                var r, i2 = this._scene.sources[t2];
                i2.builds_geometry_tiles && i2.includesTile(e, this._view.lookAtManipulator.getLookAtData().tile_level) && (r = Tile.normalizedKey(e, i2, this._view.lookAtManipulator.getLookAtData().tile_level), this.hasTile(r) && this.buildTile(this._visible_tiles[r]));
              }
          } }, { key: "buildTile", value: function(e, t2) {
            this._building_tiles && this._building_tiles[e.key] || e.built && e.generation === this._scene.generation || (this._tileBuildStart(e.key), e.build(this._scene.generation, t2));
          } }, { key: "buildTileStylesCompleted", value: function(e) {
            var t2 = e.tile, r = e.progress;
            if (null == this._visible_tiles[t2.key])
              Tile.abortBuild(t2, this._scene.id);
            else if (t2.generation !== this._scene.generation)
              Tile.abortBuild(t2, this._scene.id);
            else {
              if (t2.id < this._visible_tiles[t2.key].id)
                return void Tile.abortBuild(t2, this._scene.id);
              t2 = this._visible_tiles[t2.key].merge(t2), r.done && (t2.built = true), t2.buildMeshes(this._scene.styles, r), this.updateTileStates(), this._scene.requestRedraw();
            }
            r.done && this._tileBuildStop(t2);
          } }, { key: "buildTileError", value: function(e) {
            this._forgetTile(e.key), Tile.abortBuild(e, this._scene.id);
          } }, { key: "_tileBuildStart", value: function(e) {
            this._is_labeled = false, this._building_tiles = this._building_tiles || {}, this._building_tiles[e] = true;
          } }, { key: "_tileBuildStop", value: function(e) {
            this._building_tiles && (e.source && e.source.hasLabeledData() && (this._update_labels_on_queue_check = true), delete this._building_tiles[e.key], Task.removeForTile(e.id), this.checkBuildQueue());
          } }, { key: "isReady", value: function() {
            return this._is_labeled && !this.isLoadingVisibleTiles();
          } }, { key: "checkBuildQueue", value: function() {
            this._building_tiles && 0 !== Object.keys(this._building_tiles).length || (this._building_tiles = null, this._update_labels_on_queue_check ? this._updateLabels() : (this._is_labeled = !Task.hasPendingTasks(), this._scene.immediateRedraw()));
          } }, { key: "_removeCachedTilesFilter", value: function(e, t2) {
            var r = t2.source;
            return !this._visible_tiles[e] && (t2.generation !== this._scene.generation || "ObjectSource" === r.config.type && r.getSyncedAt() > t2.syncedAt);
          } }]), n;
        }();
        function compareTileCoords(e, t2) {
          var r = e.coords, i2 = t2.coords;
          return r.z - i2.z || r.x - i2.x || r.y - i2.y;
        }
        function roundPrecision(e, t2) {
          var r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : 2, i2 = Math.pow(10, r);
          return Math.round(Math.floor(e * t2) / t2 * i2) / i2;
        }
        function getTileByteLength(e) {
          var t2 = 0;
          for (var r in e.meshes)
            for (var i2 = e.meshes[r], n = 0; n < i2.length; n++) {
              var o = i2[n];
              t2 += o.buffer_size;
              for (var a2 = 0; a2 < o.textures.length; a2++)
                t2 += e.textureManager.getByteLength(o.textures[a2]);
            }
          return t2;
        }
        function getMaxTileCacheSize() {
          var e = 0.1;
          return navigator && navigator.deviceMemory ? e = 5 * navigator.deviceMemory / 100 : window && window.screen && (e = window.screen.width / 512 * window.screen.height / 512 * 0.03 * 3, e = Math.min(e, 1)), 1024 * e * 1024 * 1024;
        }
        var RenderState = function() {
          function r(e, t2) {
            _classCallCheck(this, r), t2(e), this.value = e, this.setup = t2;
          }
          return _createClass(r, [{ key: "get", value: function() {
            return this.value;
          } }, { key: "set", value: function(e) {
            JSON.stringify(this.value) !== JSON.stringify(e) && (this.setup(e), this.value = e);
          } }]), r;
        }(), RenderStateManager = function e(t2) {
          _classCallCheck(this, e), this.defaults = {}, this.defaults.culling = true, this.defaults.culling_face = t2.BACK, this.defaults.blending = false, this.defaults.blending_src = t2.ONE_MINUS_SRC_ALPHA, this.defaults.blending_dst = t2.ONE_MINUS_SRC_ALPHA, this.defaults.blending_src_alpha = t2.ONE, this.defaults.blending_dst_alpha = t2.ONE_MINUS_SRC_ALPHA, this.defaults.depth_write = true, this.defaults.depth_test = true, t2.depthFunc(t2.LESS), this.culling = new RenderState({ cull: this.defaults.culling, face: this.defaults.culling_face }, function(e2) {
            e2.cull ? (t2.enable(t2.CULL_FACE), t2.cullFace(e2.face)) : t2.disable(t2.CULL_FACE);
          }), this.blending = new RenderState({ blend: this.defaults.blending, src: this.defaults.blending_src, dst: this.defaults.blending_dst, src_alpha: this.defaults.blending_src_alpha, dst_alpha: this.defaults.blending_dst_alpha }, function(e2) {
            e2.blend ? (t2.enable(t2.BLEND), e2.src_alpha && e2.dst_alpha ? t2.blendFuncSeparate(e2.src, e2.dst, e2.src_alpha, e2.dst_alpha) : t2.blendFunc(e2.src, e2.dst)) : t2.disable(t2.BLEND);
          }), this.depth_write = new RenderState({ depth_write: this.defaults.depth_write }, function(e2) {
            t2.depthMask(e2.depth_write);
          }), this.depth_test = new RenderState({ depth_test: this.defaults.depth_test }, function(e2) {
            e2.depth_test ? t2.enable(t2.DEPTH_TEST) : t2.disable(t2.DEPTH_TEST);
          });
        }, MediaCapture = function() {
          function e() {
            _classCallCheck(this, e), this.canvas = null, this.gl = null, this.screenshot_canvas = null, this.screenshot_context = null, this.queue_screenshot = null, this.video_capture = null;
          }
          return _createClass(e, [{ key: "setCanvas", value: function(e2, t2) {
            this.canvas = e2, this.gl = t2;
          } }, { key: "screenshot", value: function(e2) {
            var r = this, t2 = (0 < arguments.length && void 0 !== e2 ? e2 : {}).background;
            return null != this.queue_screenshot || (this.queue_screenshot = { background: t2 }, this.queue_screenshot.promise = new Promise(function(e3, t3) {
              r.queue_screenshot.resolve = e3, r.queue_screenshot.reject = t3;
            })), this.queue_screenshot.promise;
          } }, { key: "completeScreenshot", value: function() {
            if (null != this.queue_screenshot) {
              var e2 = this.canvas.width, t2 = this.canvas.height, r = new Uint8Array(e2 * t2 * 4);
              this.gl.readPixels(0, 0, e2, t2, this.gl.RGBA, this.gl.UNSIGNED_BYTE, r);
              for (var i2 = (i2 = this.queue_screenshot.background) && "transparent" !== i2 ? StyleParser.parseColor(i2).slice(0, 3).map(function(e3) {
                return 255 * e3;
              }) : null, n = new Uint8ClampedArray(e2 * t2 * 4), o = 0; o < t2; o++)
                for (var a2 = 0; a2 < e2; a2++) {
                  var s = 4 * ((t2 - o - 1) * e2 + a2), l = 4 * (o * e2 + a2), u2 = r[3 + s];
                  n[0 + l] = 255 * r[0 + s] / u2, n[1 + l] = 255 * r[1 + s] / u2, n[2 + l] = 255 * r[2 + s] / u2, n[3 + l] = u2, i2 && (u2 /= 255, n[0 + l] = n[0 + l] * u2 + i2[0] * (1 - u2), n[1 + l] = n[1 + l] * u2 + i2[1] * (1 - u2), n[2 + l] = n[2 + l] * u2 + i2[2] * (1 - u2), n[3 + l] = 255);
                }
              this.screenshot_canvas = this.screenshot_canvas || document.createElement("canvas");
              var c2 = this.screenshot_canvas;
              c2.width = e2, c2.height = t2, this.screenshot_context = this.screenshot_context || c2.getContext("2d");
              var h = this.screenshot_context, f2 = new ImageData(n, e2, t2);
              h.putImageData(f2, 0, 0);
              for (var d = c2.toDataURL("image/png"), _ = atob(d.slice(22)), p2 = new Uint8Array(_.length), g = 0; g < _.length; ++g)
                p2[g] = _.charCodeAt(g);
              var m = new Blob([p2], { type: "image/png" });
              this.queue_screenshot.resolve({ url: d, blob: m, type: "png" }), this.queue_screenshot = null;
            }
          } }, { key: "startVideoCapture", value: function() {
            var i2 = this;
            if ("function" != typeof window.MediaRecorder || !this.canvas || "function" != typeof this.canvas.captureStream)
              return log("warn", "Video capture (Canvas.captureStream and/or MediaRecorder APIs) not supported by browser"), false;
            if (this.video_capture)
              return log("warn", "Video capture already in progress, call Scene.stopVideoCapture() first"), false;
            try {
              var n = this.video_capture = {};
              n.chunks = [], n.stream = this.canvas.captureStream(), n.options = { mimeType: "video/webm" }, n.media_recorder = new MediaRecorder(n.stream, n.options), n.media_recorder.ondataavailable = function(e2) {
                var t2, r;
                0 < e2.data.size && n.chunks.push(e2.data), n.resolve && (r = createObjectURL(t2 = new Blob(n.chunks, { type: n.options.mimeType })), n.stream && (n.stream.getTracks() || []).forEach(function(e3) {
                  e3.stop(), n.stream.removeTrack(e3);
                }), n.stream = null, n.media_recorder = null, i2.video_capture = null, n.resolve({ url: r, blob: t2, type: "webm" }));
              }, n.media_recorder.start();
            } catch (e2) {
              return this.video_capture = null, log("error", "Scene video capture failed", e2), false;
            }
            return true;
          } }, { key: "stopVideoCapture", value: function() {
            var r = this;
            return this.video_capture ? (this.video_capture.promise = new Promise(function(e2, t2) {
              r.video_capture.resolve = e2, r.video_capture.reject = t2;
            }), this.video_capture.media_recorder.stop(), this.video_capture.promise) : (log("warn", "No scene video capture in progress, call Scene.startVideoCapture() first"), Promise.resolve({}));
          } }]), e;
        }(), SceneWorker = function() {
          function e() {
            _classCallCheck(this, e), this.sources = {}, this.styles = {}, this.layers = {}, this.tiles = {}, this._isConfigured = false;
          }
          return _createClass(e, [{ key: "init", value: function(e2, t2, r, i2, n, o, a2) {
            return this.setMeshVariantMaxLife(a2), this.scene_id = e2, this.textureManager = getTextureManager(e2), this._worker_id = t2, log.setLevel(r), Utils$1.device_pixel_ratio = i2, VertexElements.setElementIndexUint(n), FeatureSelection.setPrefix(this._worker_id), this._style_manager = new StyleManager(), this._importExternalScripts(o), Label.id_prefix = t2, this._isConfigured = false, t2;
          } }, { key: "dispose", value: function() {
            this._last_config_sources = null, this._config_sources = null, this.sources = null, this._style_manager = null, this.styles = null, this.layers = null, this.tiles = null;
          } }, { key: "_importExternalScripts", value: function(e2) {
            var t2;
            0 !== e2.length && (log("debug", "loading custom data source scripts in worker:", e2), t2 = Object.getOwnPropertyNames(window), importScripts.apply(void 0, _toConsumableArray(e2)), Object.getOwnPropertyNames(window).forEach(function(e3) {
              -1 === t2.indexOf(e3) && (self[e3] = window[e3]);
            }));
          } }, { key: "updateConfig", value: function(e2, t2) {
            var r = e2.config, i2 = e2.generation, n = e2.introspection, r = JSON.parse(r);
            for (var o in mergeDebugSettings(t2), this._generation = i2, this._isConfigured = false, r.layers)
              r.layers[o] && (r.layers[o].data = Utils$1.stringsToFunctions(r.layers[o].data));
            this.global = Utils$1.stringsToFunctions(r.global), this._createDataSources(r), r.styles = Utils$1.stringsToFunctions(r.styles, StyleParser.wrapFunction), this.styles = this._style_manager.build(r.styles), self.is_fake_worker = Thread.is_main, this._style_manager.initStyles({ generation: this._generation, styles: this.styles, sources: this.sources, introspection: n, id: this.scene_id }), delete self.is_fake_worker, this.layers = parseLayers(r.layers, this._style_manager.styles), this._configuring = this._syncTextures(r.textures);
          } }, { key: "setMeshVariantMaxLife", value: function(e2) {
            this.meshVariantMaxLife = e2;
          } }, { key: "_createDataSources", value: function(t2) {
            var r = this;
            this._last_config_sources = this._config_sources || {}, this._config_sources = t2.sources;
            var e2 = this.sources, i2 = [];
            for (var n in t2.sources = Utils$1.stringsToFunctions(t2.sources), this.sources = {}, self.is_fake_worker = Thread.is_main, t2.sources)
              if (JSON.stringify(this._last_config_sources[n]) !== JSON.stringify(t2.sources[n])) {
                var o = void 0;
                try {
                  o = DataSource.create(Object.assign({}, t2.sources[n], { name: n }), this.sources);
                } catch (e3) {
                  log("error", "Error creating source.", e3.message, t2.sources[n]);
                  continue;
                }
                o && (this.sources[n] = o, i2.push(n));
              } else
                this.sources[n] = e2[n];
            delete self.is_fake_worker, i2.forEach(function(e3) {
              for (var t3 in r.tiles)
                r.tiles[t3].source === e3 && delete r.tiles[t3];
            });
          } }, { key: "awaitConfiguration", value: function() {
            return this._configuring;
          } }, { key: "_onConfig", value: function(t2) {
            var r = this;
            if ((this._isConfigured = true) !== t2.loaded)
              t2.loading = true, t2.loaded = false, t2.error = null, this._loadTileSourceData(t2).then(function() {
                if (r.getTile(t2.id)) {
                  t2.loading = false, t2.loaded = true;
                  try {
                    Tile.buildGeometry(t2, r);
                  } catch (e2) {
                    t2.error = e2.toString(), WorkerBroker.postMessage("TileManager_".concat(r.scene_id, ".buildTileError"), Tile.slice(t2));
                  }
                } else
                  log("trace", "stop tile build after data source load because tile was removed. Key: ".concat(t2.key, ", id: ").concat(t2.id));
              }, function(e2) {
                t2.loading = false, t2.loaded = false, t2.error = e2.stack, log("error", "tile load error for tile with key ".concat(t2.key, " and id ").concat(t2.id, ": ").concat(t2.error)), WorkerBroker.postMessage("TileManager_".concat(r.scene_id, ".buildTileError"), Tile.slice(t2));
              });
            else {
              log("trace", "used worker cache for tile with key ".concat(t2.key, " and id ").concat(t2.id));
              try {
                Tile.buildGeometry(t2, this);
              } catch (e2) {
                t2.error = e2.toString(), WorkerBroker.postMessage("TileManager_".concat(this.scene_id, ".buildTileError"), Tile.slice(t2));
              }
            }
          } }, { key: "buildTile", value: function(e2) {
            var t2, r = e2.tile, i2 = this.getTile(r.id);
            i2 && i2.loading || (r = this.tiles[r.id] = Object.assign(i2 || {}, r), this._isConfigured ? this._onConfig(r) : (t2 = this).awaitConfiguration().then(function() {
              return t2._onConfig(r);
            }));
          } }, { key: "_loadTileSourceData", value: function(e2) {
            return this.sources[e2.source] ? this.sources[e2.source].load(e2) : (e2.source_data = {}, Promise.resolve(e2));
          } }, { key: "getTile", value: function(e2) {
            return this.tiles[e2];
          } }, { key: "removeTile", value: function(e2) {
            var t2 = this.tiles[e2];
            null != t2 && (true === t2.loading && (log("trace", "cancel tile load for tile id ".concat(e2)), t2.loading = false, Tile.cancel(t2)), delete this.tiles[e2], log("trace", "remove tile from cache, tile id: ".concat(e2)));
          } }, { key: "queryFeatures", value: function(e2) {
            var o = this, a2 = e2.filter, s = e2.visible, l = e2.geometry, t2 = e2.tile_ids, u2 = [], r = t2.map(function(e3) {
              return o.tiles[e3];
            }).filter(function(e3) {
              return e3;
            });
            return null != a2 && (a2 = -1 < ["{", "["].indexOf(a2[0]) ? JSON.parse(a2) : a2, a2 = Utils$1.stringsToFunctions(a2, StyleParser.wrapFunction)), a2 = buildFilter(a2, FilterOptions), r.forEach(function(n) {
              for (var e3 in n.source_data.layers)
                !function(i2) {
                  n.source_data.layers[i2].features.forEach(function(e4) {
                    var t3, r2;
                    true === s && e4.generation !== o._generation || false === s && e4.generation === o._generation || ((t3 = StyleParser.getFeatureParseContext(e4, n, o.global)).source = n.source, t3.layer = i2, a2(t3) && (r2 = { type: e4.type, properties: e4.properties }, true === l && (r2.geometry = Geo$1.copyGeometry(e4.geometry), Geo$1.tileSpaceToLatlng(r2.geometry, n.coords.z, n.min)), u2.push(r2)));
                  });
                }(e3);
            }), u2;
          } }, { key: "resetFeatureSelection", value: function() {
            FeatureSelection.reset();
          } }, { key: "_syncTextures", value: function(e2) {
            var t2 = [];
            return e2 && t2.push.apply(t2, _toConsumableArray(Object.keys(e2))), log("trace", "sync textures to worker:", t2), 0 < t2.length ? this.textureManager.syncTexturesToWorker(t2) : Promise.resolve();
          } }, { key: "profile", value: function(e2) {
            console.profile("worker ".concat(this._worker_id, ": ").concat(e2));
          } }, { key: "profileEnd", value: function(e2) {
            console.profileEnd("worker ".concat(this._worker_id, ": ").concat(e2));
          } }, { key: "terminate", value: function() {
            this.dispose();
          } }]), e;
        }();
        (Thread.is_worker || self.H && self.H.DEBUG) && WorkerBroker.addTarget("self", new SceneWorker());
        var Scene = function() {
          function l(e, t2) {
            _classCallCheck(this, l), t2 = t2 || {}, subscribeMixin(this), this.id = l.id++, this.textureManager = getTextureManager(this.id), this.initialized = false, this.initializing = null, this.sources = {}, this.view = new View(this, t2), this.tile_manager = new TileManager({ scene: this, view: this.view }), this.num_workers = t2.numWorkers || 2, true === t2.disableVertexArrayObjects && (VertexArrayObject.disabled = true), Utils$1.device_pixel_ratio = t2.devicePixelRatio, this.config = null, this.config_source = e, this.config_bundle = null, this.last_valid_config_source = null, this.styles = null, this.style_manager = new StyleManager(), this.building = null, this.dirty = true, t2.preUpdate && this.subscribe({ pre_update: t2.preUpdate }), t2.postUpdate && this.subscribe({ post_update: t2.postUpdate }), this.render_loop = !t2.disableRenderLoop, this.render_loop_active = false, this.render_loop_stop = false, this.render_count = 0, this.last_render_count = 0, this.render_count_changed = false, this.frame = 0, this.last_main_render = -1, this.last_selection_render = -1, this.media_capture = new MediaCapture(), this.selection = null, this.introspection = true === t2.introspection, this.viewport = t2.viewport, this.adjustMeshVariantMaxLife(), this.container = t2.container, this.canvas = null, this.contextOptions = t2.webGLContextOptions, this.lights = null, this.background = null, this.createListeners(), this.updating = 0, this.generation = l.generation, this.last_complete_generation = l.generation, this.log_level = t2.logLevel || "warn", log.setLevel(this.log_level), log.reset();
          }
          return _createClass(l, [{ key: "load", value: function(e, t2) {
            var i2 = this, r = 0 < arguments.length && void 0 !== e ? e : null, n = 1 < arguments.length && void 0 !== t2 ? t2 : {};
            return this.initializing || (log.reset(), this.updating++, this.initialized = false, this.initial_build_time = null, (n = "string" == typeof n ? { base_path: n } : n).blocking = void 0 === n.blocking || n.blocking, false !== this.render_loop && this.setupRenderLoop(), this.createCanvas(), this.textureManager.destroy(this.gl), this.initializing = this.loadScene(r, n).then(function() {
              return i2.createWorkers();
            }).then(function() {
              i2.resetFeatureSelection();
              var e2 = "object" === _typeof(i2.config_source) || i2.hasSubscribersFor("load"), t3 = i2.updateConfig({ serialize_funcs: e2, normalize: false, load_event: true, fade_in: true });
              if (true === n.blocking)
                return t3;
            }).then(function() {
              i2.updating--, i2.initializing = null, i2.initialized = true, i2.last_valid_config_source = i2.config_source, i2.last_valid_options = { base_path: n.base_path, file_type: n.file_type }, i2.requestRedraw();
            }).catch(function(e2) {
              var t3, r2;
              if (i2.initializing = null, i2.updating = 0, r2 = "YAMLException" === e2.name ? (t3 = "yaml", "Error parsing scene YAML") : "Error initializing scene", i2.trigger("error", { type: t3, message: r2, error: e2, url: i2.config_source }), r2 = "Scene.load() failed to load ".concat(i2.config_source, ": ").concat(e2.message), i2.last_valid_config_source)
                return log("warn", r2, e2), log("info", "Scene.load() reverting to last valid configuration"), i2.load(i2.last_valid_config_source, i2.last_valid_base_path);
              throw log("error", r2, e2), e2;
            })), this.initializing;
          } }, { key: "destroy", value: function() {
            var e;
            this.initialized = false, this.render_loop_stop = true, this.destroyListeners(), this.canvas && this.canvas.parentNode && (this.canvas.parentNode.removeChild(this.canvas), this.canvas = null), this.container = null, this.selection && this.selection.destroy(), this.gl && (this.textureManager.destroy(this.gl), this.style_manager.destroy(this.gl), this.styles = {}, ShaderProgram.reset(), (e = this.gl.getExtension("WEBGL_lose_context")) && e.loseContext(), this.gl = null), this.sources = {}, this.tile_manager.destroy(), this.tile_manager = null, this.destroyWorkers(), log.reset();
          } }, { key: "createCanvas", value: function() {
            if (!this.canvas) {
              this.container = this.container || document.body, this.canvas = document.createElement("canvas"), this.canvas.style.position = "absolute", this.canvas.style.top = 0, this.canvas.style.left = 0, this.container.style.backgroundColor = "transparent", this.container.appendChild(this.canvas);
              try {
                this.gl = Context$1.getContext(this.canvas, Object.assign({ alpha: true, premultipliedAlpha: false, stencil: true, device_pixel_ratio: Utils$1.device_pixel_ratio }, this.contextOptions));
              } catch (e) {
                throw new Error("Couldn't create WebGL context. Your browser may not support WebGL, or it's turned off? Visit http://webglreport.com/ for more info.");
              }
              this.handleViewportUpdate(), VertexArrayObject.init(this.gl), this.render_states = new RenderStateManager(this.gl), this.media_capture.setCanvas(this.canvas, this.gl);
            }
          } }, { key: "getWorkerUrl", value: function() {
            var e, t2;
            if (void 0 !== __worker_src__ && (t2 = "(" + __worker_src__ + ")()", __worker_src_origin__ && "" !== __worker_src_map__ && (t2 += "\n//# sourceMappingURL=" + __worker_src_origin__.slice(0, __worker_src_origin__.lastIndexOf("/") + 1) + __worker_src_map__), e = createObjectURL(new Blob([t2], { type: "application/javascript" }))), !e)
              throw new Error("Couldn't find internal Tangram source variable (may indicate the library did not build correctly)");
            return e;
          } }, { key: "updateExternalScripts", value: function() {
            var r = _toConsumableArray(this.external_scripts || []), e = [];
            if (this.config.scene.scripts)
              for (var t2 in this.config.scene.scripts)
                -1 === e.indexOf(this.config.scene.scripts[t2]) && e.push(this.config.scene.scripts[t2]);
            for (var i2 in this.config.sources) {
              var n = this.config.sources[i2];
              if (n.scripts)
                for (var o in n.scripts)
                  -1 === e.indexOf(n.scripts[o]) && e.push(n.scripts[o]);
            }
            return this.external_scripts = e, !(this.external_scripts.length === r.length && this.external_scripts.every(function(e2, t3) {
              return e2 === r[t3];
            }));
          } }, { key: "createWorkers", value: function() {
            return this.updateExternalScripts() && this.destroyWorkers(), this._workers ? Promise.resolve() : this.makeWorkers(this.getWorkerUrl());
          } }, { key: "makeWorkers", value: function(r) {
            var i2 = this, n = !!this.gl.getExtension("OES_element_index_uint"), o = [];
            this._workers = [];
            for (var a2 = 0; a2 < this.num_workers; a2++)
              !function() {
                var e2 = new Worker(r);
                i2._workers[a2] = e2, WorkerBroker.addWorker(e2), log("debug", "Scene.makeWorkers: initializing worker ".concat(a2));
                var t2 = a2;
                o.push(WorkerBroker.postMessage(e2, "self.init", i2.id, a2, i2.log_level, Utils$1.device_pixel_ratio, n, i2.external_scripts, i2.meshVariantMaxLife).then(function(e3) {
                  return log("debug", "Scene.makeWorkers: initialized worker ".concat(e3)), e3;
                }, function(e3) {
                  return log("error", "Scene.makeWorkers: failed to initialize worker ".concat(t2, ":"), e3), Promise.reject(e3);
                }));
              }();
            var e = new SceneWorker();
            return this._workers.push(e), o.push(e.init(this.id, a2, this.log_level, Utils$1.device_pixel_ratio, n, [], this.meshVariantMaxLife)), this.next_worker = 0, Promise.all(o).then(function() {
              log.setWorkers(i2._workers.slice(0, i2.num_workers)), revokeObjectURL(r);
            });
          } }, { key: "getWorkers", value: function(t2) {
            return this._workers.filter(function(e) {
              switch (t2) {
                case WorkerType.NATIVE:
                  return e instanceof Worker;
                case WorkerType.FAKE:
                  return e instanceof SceneWorker;
                default:
                  return true;
              }
            });
          } }, { key: "destroyWorkers", value: function() {
            this.selection = null, Array.isArray(this._workers) && (log.setWorkers(null), this._workers.forEach(function(e) {
              e.terminate();
            }), this._workers = null);
          } }, { key: "ready", value: function() {
            return !(!this.view.ready() || 0 === Object.keys(this.sources).length);
          } }, { key: "handleViewportUpdate", value: function() {
            var e = this.viewport, t2 = e.width, r = e.height;
            0 < t2 && 0 < r && (this.dirty = true, this.view.handleViewportUpdate(), this.gl && Context$1.resize(this.gl, t2, r, Utils$1.device_pixel_ratio)), this.adjustMeshVariantMaxLife() && this.syncMeshVariantMaxLife();
          } }, { key: "adjustMeshVariantMaxLife", value: function() {
            var e = this.viewport, t2 = e.width, r = e.height, i2 = Utils$1.device_pixel_ratio, n = t2 / i2 / 256 * (r / i2 / 256), o = Math.max(Math.ceil(2 * n), 8);
            if (this.meshVariantMaxLife !== o)
              return this.meshVariantMaxLife = o, true;
          } }, { key: "syncMeshVariantMaxLife", value: function() {
            this._workers && WorkerBroker.postMessage(this._workers, "self.setMeshVariantMaxLife", this.meshVariantMaxLife);
          } }, { key: "requestRedraw", value: function() {
            this.dirty = true;
          } }, { key: "immediateRedraw", value: function() {
            this.dirty = true, this.update();
          } }, { key: "renderLoop", value: function() {
            this.render_loop_active = true, this.initialized && this.update(), Task.setState({ user_moving_view: this.view.user_input_active }), Task.processAll(), this.render_loop_stop ? (this.render_loop_stop = false, this.render_loop_active = false) : window.requestAnimationFrame(this.renderLoop.bind(this));
          } }, { key: "setupRenderLoop", value: function() {
            var e = this;
            this.render_loop_active || setTimeout(function() {
              e.renderLoop();
            }, 0);
          } }, { key: "update", value: function() {
            var e = this.dirty, t2 = !!this.selection && this.selection.hasPendingRequests(), r = !(false === e && false === t2 || false === this.initialized || 0 < this.updating || false === this.ready());
            return this.trigger("pre_update", r), this.view.update(), r && (this.dirty = false, this.render({ main: e, selection: t2 }), this.updateViewComplete(), this.media_capture.completeScreenshot(), this.trigger("post_update", r), true !== this.animated && !this.view.isAnimating() || (this.dirty = true), this.frame++, log("trace", "Scene.render()"), true);
          } }, { key: "render", value: function(e) {
            var t2 = this, r = e.main, i2 = e.selection, n = this.gl;
            if (Object.keys(this.lights).forEach(function(e2) {
              return t2.lights[e2].update();
            }), r && (this.render_count = this.renderPass(), this.last_main_render = this.frame), i2) {
              if (this.view.panning || this.view.user_input_active)
                return void this.selection.clearPendingRequests();
              (this.last_selection_render < this.last_main_render || this.selection.has_dirty_buffer) && (this.selection.bind(), this.renderPass("selection_program", { allow_blend: false }), n.bindFramebuffer(n.FRAMEBUFFER, null), n.viewport(0, 0, this.canvas.width, this.canvas.height), n.clearColor.apply(n, _toConsumableArray(this.background.color)), this.last_selection_render = this.frame, this.selection.has_dirty_buffer = false), this.selection.read(this.tile_manager.getRenderableTiles()), this.selection.has_dirty_buffer && this.render({ main: false, selection: i2 });
            }
            return this.render_count_changed = false, this.render_count !== this.last_render_count && (this.render_count_changed = true), this.last_render_count = this.render_count, true;
          } }, { key: "renderPass", value: function(e, t2) {
            var r = this, i2 = 0 < arguments.length && void 0 !== e ? e : "program", n = (1 < arguments.length && void 0 !== t2 ? t2 : {}).allow_blend, o = this.gl, n = null == n || n;
            this.clearFrame();
            for (var a2, s = Style.sortByBlendOrderWithinLayers(this.tile_manager.getActiveStyles().map(function(e2) {
              return r.styles[e2];
            }).filter(function(e2) {
              return e2;
            })), l2 = 0, u2 = 0, c2 = 0; c2 < s.length; c2++) {
              var h, f2, d = s[c2], _ = u2 - (h = parseInt(d.name));
              (d.clean_depth || _) && (this.render_states.depth_write.value.depth_write ? o.clear(o.DEPTH_BUFFER_BIT) : (o.depthMask(true), o.clear(o.DEPTH_BUFFER_BIT), o.depthMask(false)), _ && (u2 = h)), d.blend !== a2 && (f2 = Object.assign({}, Style.render_states[d.blend], { blend: n && d.blend }), this.setRenderState(f2));
              var p2 = "translucent" === d.blend && "program" === i2;
              p2 && (this.gl.colorMask(false, false, false, false), this.renderStyle(d.name, i2), this.gl.colorMask(true, true, true, true), this.gl.depthFunc(this.gl.EQUAL), this.gl.enable(this.gl.STENCIL_TEST), this.gl.clear(this.gl.STENCIL_BUFFER_BIT), this.gl.stencilFunc(this.gl.EQUAL, this.gl.ZERO, 255), this.gl.stencilOp(this.gl.KEEP, this.gl.KEEP, this.gl.INCR)), l2 += this.renderStyle(d.name, i2), p2 && (this.gl.disable(this.gl.STENCIL_TEST), this.gl.depthFunc(this.gl.LESS)), a2 = d.blend;
            }
            return l2;
          } }, { key: "renderStyle", value: function(s, l2) {
            for (var u2, c2 = this, h = this.styles[s], f2 = true, d = 0, _ = this.tile_manager.getRenderableTiles(), e = Math.max.apply(Math, _toConsumableArray(_.map(function(e2) {
              return e2.meshes[s] ? Math.max.apply(Math, _toConsumableArray(e2.meshes[s].map(function(e3) {
                return e3.variant.order;
              }))) : -1;
            }))), t2 = 0; t2 < e + 1; t2++) {
              var r = function(t3) {
                for (var e2 = 0; e2 < _.length; e2++) {
                  var r2 = _[e2];
                  if (null != r2.meshes[s] && r2.shouldProxyForStyle(s))
                    for (var i2 = r2.meshes[s].filter(function(e3) {
                      return e3.variant.order === t3;
                    }), n = 0, o = i2.length; n < o; n += 1) {
                      var a2 = i2[n];
                      if (true === f2 && (f2 = false, !(u2 = c2.setupStyle(h, l2))))
                        return { v: 0 };
                      c2.view.setupTile(r2, u2), c2.selection.setupDiscards(u2), h.render(a2) && c2.requestRedraw(), d += a2.geometry_count;
                    }
                }
              }(t2);
              if ("object" === _typeof(r))
                return r.v;
            }
            return d;
          } }, { key: "setupStyle", value: function(t2, e) {
            var r;
            try {
              if (!(r = t2.getProgram(e)))
                return;
            } catch (e2) {
              return void this.trigger("warning", { type: "styles", message: "Error compiling style ".concat(t2.name), style: t2, shader_errors: t2.program && t2.program.shader_errors });
            }
            for (var i2 in r.use(), t2.setup(), this.view.setupProgram(r), this.lights)
              this.lights[i2].setupProgram(r);
            return r;
          } }, { key: "clearFrame", value: function() {
            this.initialized && (this.render_states.depth_write.set({ depth_write: true }), this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT | this.gl.STENCIL_BUFFER_BIT));
          } }, { key: "setRenderState", value: function(e) {
            var t2, r, i2 = 0 < arguments.length && void 0 !== e ? e : {}, n = i2.depth_test, o = i2.depth_write, a2 = i2.cull_face, s = i2.blend;
            this.initialized && (t2 = this.render_states, n = false !== n && t2.defaults.depth_test, o = false !== o && t2.defaults.depth_write, a2 = false !== a2 && t2.defaults.culling, s = null != s ? s : t2.defaults.blending, r = this.gl, t2.depth_test.set({ depth_test: n }), t2.depth_write.set({ depth_write: o }), t2.culling.set({ cull: a2, face: t2.defaults.culling_face }), !s || "opaque" === s ? t2.blending.set({ blend: false }) : "overlay" === s || "inlay" === s || "translucent" === s ? t2.blending.set({ blend: true, src: r.SRC_ALPHA, dst: r.ONE_MINUS_SRC_ALPHA, src_alpha: r.ONE, dst_alpha: r.ONE_MINUS_SRC_ALPHA }) : "add" === s ? t2.blending.set({ blend: true, src: r.ONE, dst: r.ONE }) : "multiply" === s && t2.blending.set({ blend: true, src: r.ZERO, dst: r.SRC_COLOR }));
          } }, { key: "getFeatureAt", value: function(e, t2, r) {
            var i2, n = t2.radius, o = t2.top_most_only;
            this.initialized ? (i2 = { x: e.x / this.view.size.css.width, y: e.y / this.view.size.css.height }, n = 0 < n ? { x: n / this.view.size.css.width, y: n / this.view.size.css.height } : null, this.selection.getFeatureAt(i2, { radius: n, top_most_only: o }, r)) : log("debug", "Scene.getFeatureAt() called before scene was initialized");
          } }, { key: "queryFeatures", value: function(e) {
            var t2 = 0 < arguments.length && void 0 !== e ? e : {}, r = t2.filter, i2 = t2.unique, l2 = void 0 === i2 || i2, n = t2.group_by, u2 = void 0 === n ? null : n, o = t2.visible, a2 = void 0 === o ? null : o, s = t2.geometry, c2 = void 0 !== s && s, r = Utils$1.serializeWithFunctions(r), h = this.tile_manager.getRenderableTiles().map(function(e2) {
              return e2.id;
            });
            return WorkerBroker.postMessage(this._workers, "self.queryFeatures", { filter: r, visible: a2, geometry: c2, tile_ids: h }).then(function(e2) {
              var i3 = [], n2 = {}, o2 = {}, a3 = (l2 = "string" == typeof l2 ? [l2] : l2) && function(e3) {
                return JSON.stringify(Array.isArray(l2) ? sliceObject(e3, l2) : e3);
              }, s2 = (u2 = ("string" == typeof u2 || Array.isArray(u2)) && u2) && function(e3) {
                return Array.isArray(u2) ? JSON.stringify(sliceObject(e3, u2)) : e3[u2];
              };
              return e2.forEach(function(e3) {
                return e3.forEach(function(e4) {
                  if (a3) {
                    var t3 = a3(e4);
                    if (n2[t3])
                      return;
                    n2[t3] = true;
                  }
                  var r2;
                  s2 ? (r2 = s2(e4.properties), o2[r2] = o2[r2] || [], o2[r2].push(e4)) : i3.push(e4);
                });
              }), s2 ? o2 : i3;
            });
          } }, { key: "loadScene", value: function(e, t2) {
            var i2 = this, r = 0 < arguments.length && void 0 !== e ? e : null, n = 1 < arguments.length && void 0 !== t2 ? t2 : {}, o = n.base_path, a2 = n.file_type;
            return this.config_source = r || this.config_source, "string" == typeof this.config_source ? this.base_path = pathForURL(o || this.config_source) : this.base_path = pathForURL(o), this.config_path = this.base_path, SceneLoader$1.loadScene(this.config_source, { path: this.base_path, type: a2 }).then(function(e2) {
              var t3 = e2.config, r2 = e2.bundle;
              return i2.config = t3, i2.config_bundle = r2, i2.config;
            });
          } }, { key: "createDataSources", value: function() {
            var t2 = this, r = [], e = Object.keys(this.sources), i2 = 0;
            for (var n in this.config.sources) {
              var o = this.config.sources[n], a2 = this.sources[n];
              try {
                var s = Object.assign({}, o, { name: n, id: i2++ });
                if (this.sources[n] = DataSource.create(s, this.sources), !this.sources[n])
                  throw {};
              } catch (e2) {
                delete this.sources[n];
                var l2 = "Could not create data source: ".concat(e2.message);
                log("warn", "Scene: ".concat(l2), o), this.trigger("warning", { type: "sources", source: o, message: l2 });
              }
              DataSource.sameConfig(this.sources[n], a2) || r.push(n);
            }
            for (var u2 in e.forEach(function(e2) {
              t2.config.sources[e2] || (delete t2.sources[e2], r.push(e2));
            }), 0 < r.length && this.tile_manager.removeTiles(function(e2) {
              return -1 < r.indexOf(e2.source.name);
            }), this.config.layers) {
              var c2 = this.config.layers[u2];
              false !== c2.enabled && c2.data && this.sources[c2.data.source] && (this.sources[c2.data.source].builds_geometry_tiles = true);
            }
          } }, { key: "loadTextures", value: function() {
            var e = this;
            return this.textureManager.createFromObject(this.gl, this.config.textures).then(function() {
              return e.textureManager.createDefault(e.gl);
            });
          } }, { key: "updateStyles", value: function() {
            if (!this.initialized && !this.initializing)
              throw new Error("Scene.updateStyles() called before scene was initialized");
            for (var e in this.styles = this.style_manager.build(this.config.styles), this.style_manager.initStyles(this), this.styles)
              this.styles[e].setGL(this.gl);
            this.dirty = true;
          } }, { key: "createLights", value: function() {
            for (var e in this.lights = {}, this.config.lights) {
              var t2;
              this.config.lights[e] && "object" === _typeof(this.config.lights[e]) && ((t2 = this.config.lights[e]).name = e.replace("-", "_"), t2.visible = false !== t2.visible, t2.visible && (this.lights[t2.name] = Light.create(this.view, t2)));
            }
            Light.inject(this.lights);
          } }, { key: "setBackground", value: function() {
            var e, t2 = this.config.scene.background;
            this.background = {}, t2 && t2.color && (this.background.color = StyleParser.parseColor(t2.color)), this.background.color || (this.background.color = [0, 0, 0, 0]), 1 === this.background.color[3] ? this.canvas.style.backgroundColor = "rgba(".concat(this.background.color.map(function(e2) {
              return Math.floor(255 * e2);
            }).join(", "), ")") : this.canvas.style.backgroundColor = "transparent", (e = this.gl).clearColor.apply(e, _toConsumableArray(this.background.color));
          } }, { key: "setIntrospection", value: function(e) {
            var t2 = this;
            return e !== this.introspection ? (this.introspection = e || false, this.updating++, this.updateConfig({ normalize: false }).then(function() {
              return t2.updating--;
            })) : Promise.resolve();
          } }, { key: "updateConfig", value: function(e) {
            var t2 = 0 < arguments.length && void 0 !== e ? e : {}, r = t2.load_event, i2 = void 0 !== r && r, n = t2.serialize_funcs, o = t2.normalize, a2 = void 0 === o || o;
            t2.fade_in;
            this.generation = ++l.generation, this.updating++, this.config = SceneLoader$1.applyGlobalProperties(this.config), a2 ? SceneLoader$1.normalize(this.config, this.config_bundle) : (SceneLoader$1.hoistStyleShaderUniformTextures(this.config, this.config_bundle, { include_globals: true }), SceneLoader$1.normalizeTextures(this.config, this.config_bundle)), this.trigger(i2 ? "load" : "update", { config: this.config }), this.style_manager.init(), this.createLights(), this.createDataSources(), this.loadTextures(), this.setBackground(), FontManager.loadFonts(this.config.fonts), this.updateStyles();
            var s = this.syncConfigToWorker({ serialize_funcs: n });
            return this.updating--, this.view.updateBounds(), this.requestRedraw(), s;
          } }, { key: "syncConfigToWorker", value: function(e) {
            var t2 = (0 < arguments.length && void 0 !== e ? e : {}).serialize_funcs, r = void 0 === t2 || t2 ? Utils$1.serializeWithFunctions(this.config) : JSON.stringify(this.config);
            return WorkerBroker.postMessage(this._workers, "self.updateConfig", { config: r, generation: this.generation, introspection: this.introspection }, debugSettings$1);
          } }, { key: "createListeners", value: function() {
            var t2 = this;
            this.listeners = {}, this.listeners.view = { move: function() {
              return t2.trigger("move");
            } }, this.view.subscribe(this.listeners.view), this.listeners.texture = { update: function() {
              return t2.dirty = true;
            }, warning: function(e) {
              return t2.trigger("warning", Object.assign({ type: "textures" }, e));
            } }, this.textureManager.subscribe(this.listeners.texture), this.listeners.scene_loader = { error: function(e) {
              return t2.trigger("error", Object.assign({ type: "scene" }, e));
            } }, SceneLoader$1.subscribe(this.listeners.scene_loader);
          } }, { key: "destroyListeners", value: function() {
            this.unsubscribeAll(), this.view.unsubscribe(this.listeners.view), this.textureManager.unsubscribe(this.listeners.texture), SceneLoader$1.unsubscribe(this.listeners.scene_loader), this.listeners = null;
          } }, { key: "resetFeatureSelection", value: function() {
            this.selection ? this._workers && WorkerBroker.postMessage(this._workers, "self.resetFeatureSelection") : this.selection = new FeatureSelection(this.gl, this.id);
          } }, { key: "updateViewComplete", value: function() {
            (this.render_count_changed || this.generation !== this.last_complete_generation) && this.tile_manager.isReady() && (this.last_complete_generation = this.generation, this.trigger("view_complete"));
          } }, { key: "resetViewComplete", value: function() {
            this.last_complete_generation = null;
          } }, { key: "screenshot", value: function(e) {
            var t2 = (0 < arguments.length && void 0 !== e ? e : {}).background, r = void 0 === t2 ? "white" : t2;
            return this.requestRedraw(), this.media_capture.screenshot({ background: r });
          } }, { key: "pixelRatio", value: function() {
            return Utils$1.device_pixel_ratio;
          } }, { key: "startVideoCapture", value: function() {
            return this.requestRedraw(), this.media_capture.startVideoCapture();
          } }, { key: "stopVideoCapture", value: function() {
            return this.media_capture.stopVideoCapture();
          } }, { key: "_profile", value: function(e) {
            console.profile("main thread: ".concat(e)), WorkerBroker.postMessage(this._workers, "self.profile", e);
          } }, { key: "_profileEnd", value: function(e) {
            console.profileEnd("main thread: ".concat(e)), WorkerBroker.postMessage(this._workers, "self.profileEnd", e);
          } }, { key: "getCameraMatrix", value: function() {
            return this.view.lookAtManipulator.getCameraMatrix();
          } }, { key: "animated", get: function() {
            var t2 = this;
            return void 0 !== this.config.scene.animated ? this.config.scene.animated : this.tile_manager.getActiveStyles().some(function(e) {
              return t2.styles[e] && t2.styles[e].animated;
            });
          } }], [{ key: "create", value: function(e, t2) {
            return new l(e, 1 < arguments.length && void 0 !== t2 ? t2 : {});
          } }]), l;
        }();
        Scene.id = 0, Scene.generation = 0;
        var RemoteTexture = function() {
          _inherits(u2, Texture);
          var l = _createSuper(u2);
          function u2(e, t2, r) {
            var i2 = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : {};
            _classCallCheck(this, u2);
            var n = Math.pow(2, i2.coords.z), o = Math.abs(Math.floor(i2.coords.x / n)), a2 = Math.abs(n * o - Math.abs(i2.coords.x)), s = i2.coords;
            return i2.coords = { x: a2, y: s.y, z: s.z }, l.call(this, e, t2, r, i2);
          }
          return _createClass(u2, [{ key: "load", value: function(i2) {
            var n = this;
            if (!i2 || !i2.uid)
              return _get(_getPrototypeOf(u2.prototype), "load", this).call(this, i2);
            var o = i2.coords, a2 = new Uint8Array([0, 0, 0, 0]);
            return this.loading = new Promise(function(e, t2) {
              var r = H.map.DataModel.invoke(i2.uid, "requestTileAsPromise", [o.x, o.y, o.z]) || null;
              r ? r.then(function(e2) {
                var t3 = e2.data;
                n.loaded = true, t3 && !(t3 instanceof ArrayBuffer) && ("IMG" === t3.tagName.toUpperCase() || "CANVAS" === t3.tagName.toUpperCase()) ? n.setElement(t3, i2) : n.setData(1, 1, a2, { filtering: "nearest" });
              }, function() {
                n.loaded = false;
              }).then(e, function(e2) {
                return t2(e2);
              }) : t2(new Error("Unable to invoke on target " + i2.uid));
            }), this.loading;
          } }]), u2;
        }();
        TextureManager.register(RemoteTexture, function(e) {
          return e && e.uid;
        }), self.H = self.H || {}, self.H.gl = { DataSource, Geo: Geo$1, MathUtils: MathUtils$1, Scene, Task, Tile, WorkerBroker, log, SceneLoader: SceneLoader$1, yaml: jsYaml$1 };
      }();
    })()